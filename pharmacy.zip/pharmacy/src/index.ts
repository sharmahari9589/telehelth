import * as express from "express";
import dotenv from "dotenv";
import Exceptionhandler from "./utils/exceptionhandler";
import router from "./app.routes";
import path from "path";
import cookieParser from "cookie-parser";
import { connect } from "mongoose";

const app = express.default();

dotenv.config({
  path: ".env",
});

connect(process.env.MONGODB_URL!);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "assets"));
//app.use("/assets",express.static(path.join(__dirname, "src/assets")));
app.use(express.static(path.join(__dirname, "assets")));

app.use("/:dashboardType", router);
app.use(Exceptionhandler);

app.use((req, res, next) => {
  
  res.status(404).json({
    status: 404,
    message: "Not found error",
  });
});

app.listen(process.env.PORT, () => {
  console.log(`Server started at ${process.env.PORT}`);
});
