import { Schema, model, Document } from "mongoose";

export interface EirCodes extends Document {
  eirCode: string;
  location: string;
}

const eirCodesSchema: Schema = new Schema<EirCodes>({
  eirCode: {
    type: String,
  },

  location: {
    type: String,
  },
});

export default model<EirCodes>("eirCode", eirCodesSchema);
