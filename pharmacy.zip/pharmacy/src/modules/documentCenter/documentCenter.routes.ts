import { Router } from "express";
import * as documentController from "./documentCenter.controller";

const router = Router({
  mergeParams: true,
});

router
  .route("/document-center")
  .get(documentController.getDocuments)
  .post(documentController.getDocuments);

router.route("/document-center/me").get(documentController.shareByMe);

router
  .route("/document-center/update/:id")
  .get(documentController.updateDocument)
  .post(documentController.updateDocument);

router
  .route("/document-center/delete/:id")
  .get(documentController.deleteDocument)
  .post(documentController.deleteDocument);

router
  .route("/document-center/share")
  .get(documentController.shareDocuments)
  .post(documentController.shareDocuments);

// router
//   .route("/document-center/sharedfiles")
//   .get(documentController.sharedFiles)
//   .post(documentController.sharedFiles);

router
  .route("/document-center/sharedwithme")
  .get(documentController.sharedWithMe)
  .post(documentController.sharedWithMe);

router
  .route("/document-center/users")
  .get(documentController.filterSharedDocument)
  .post(documentController.filterSharedDocument);

router.get(
  "/document-center/unshare/users/:documentId",
  documentController.filterUnharedDocument
);

router
  .route("/document-center/unshare/:id")
  .get(documentController.unshareMyDocument)
  .post(documentController.unshareMyDocument);

router.post(
  "/document-center/update-true",
  documentController.updateAllowStatus
);

router.post(
  "/document-center/update-false",
  documentController.updateNotAllowStatus
);

router.get("/document-center/check-status", documentController.ckeckStatus);

export default router;
