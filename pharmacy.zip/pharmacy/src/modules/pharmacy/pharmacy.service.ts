import { Types } from "mongoose";
import bcrypt from "bcryptjs";
import pharmacyModel from "./pharmacy.model";

export async function updateById(pharmacyId: Types.ObjectId, updateBody: any) {
  return pharmacyModel.findByIdAndUpdate(pharmacyId, { password: updateBody });
}

export async function updatePersonal(
  pharmacyId: Types.ObjectId,
  updateBody: any
) {
  return pharmacyModel.findByIdAndUpdate(pharmacyId, updateBody);
}

export async function getById(pharmacyId: Types.ObjectId) {
  return pharmacyModel.findById(pharmacyId);
}

/**
 * @description this function is used to compare password
 * @param {String} password
 * @param {String} hashpassword
 * @author Keshav suman
 * @returns {Boolean}
 */
export function comparePassword(
  password: string,
  hashpassword: string
): boolean {
  return bcrypt.compareSync(password, hashpassword);
}

export function encryptPassword(password: string) {
  return bcrypt.hashSync(password, 10);
}

export async function getUserByUserID(userId: Types.ObjectId) {
  const user = await pharmacyModel.findById(userId);
  return user;
}
