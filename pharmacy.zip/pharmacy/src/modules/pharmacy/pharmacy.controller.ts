import { Request, Response } from "express";
import httpStatus from "http-status";
import { Types } from "mongoose";
import * as pharmacyService from "./pharmacy.service";
import pharmacyModel from "./pharmacy.model";
import xlsx from "xlsx";

//EJS Rendor
import ejs from "ejs";
import Paths from "../../utils/path";
import { getViewFile } from "../../utils/ejsHelper";
import { mode } from "crypto-js";
import eircodeModel from "../../models/eircode.model";

export async function editProfile(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const pharmacyId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: {},
        message: "pharmacy update successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      const pharmacy: any = await pharmacyModel.findById(pharmacyId);

      if (req.method == "GET") {
        const fileContent = getViewFile("dashboard", "profile-edit.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            message1: "",
            user,
            activeTab: "pharmacyDashboard",
            pharmacy,
            filename: fileContent.templatePath,
          })
        );
      } else {
        const newv: any = req.body.files;
        let profilePic;
        let certificate;
        let signature;

        if (newv[0]) {
          if (newv[0].fieldname === "certificate") {
            //const documentURL =   "/" + req.body?.files[0]?.path;
            certificate = newv[0]?.path;
          }

          if (newv[0].fieldname === "profileImage") {
            //const documentURL =   "/" + req.body?.files[0]?.path;
            profilePic = newv[0]?.path;
          }

          if (newv[0].fieldname === "signature") {
            //const documentURL =   "/" + req.body?.files[0]?.path;
            signature = newv[0]?.path;
          }
        }

        if (newv[1]) {
          if (newv[1].fieldname === "certificate") {
            //const documentURL =   "/" + req.body?.files[0]?.path;
            certificate = newv[1]?.path;
          }

          if (newv[1].fieldname === "signature") {
            //const documentURL =   "/" + req.body?.files[0]?.path;
            signature = newv[1]?.path;
          }
        }

        if (newv[2]) {
          if (newv[2].fieldname === "signature") {
            //const documentURL =   "/" + req.body?.files[0]?.path;
            signature = newv[2]?.path;
          }
        }

        const openingDto: any = {
          Mon: req.body.monday,
          Tue: req.body.tuesday,
          Wed: req.body.wednesday,
          Thu: req.body.thursday,
          Fri: req.body.friday,
          Sat: req.body.saturday,
          Sun: req.body.sunday,
        };

        const editDto: any = {
          firstName: req.body.firstName,
          lastName: req.body.lastName,
          storeName: req.body.storeName,
          email: req.body.email,
          mobileNumber: req.body.mobileNumber,
          profilePic: profilePic,
          certificate: certificate,
          signature: signature,
          phoneNo: req.body.phoneNo,
          gender: req.body.gender,
          dateOfBirth: req.body.dateofbirth,
          description: req.body.description,
          location: req.body.location,
          cho: req.body.cho,
          country: req.body.country,
          eircode: req.body.eircode,
          opening_Hours: openingDto,
        };

        const pharmacies = await pharmacyService.updatePersonal(
          pharmacyId,
          editDto
        );

        const pharmacy: any = await pharmacyModel.findById(pharmacyId);

        res.redirect("/pharmacy/web/");
      }
    }

    //Post Method Code

    //Web Code End
  } catch (error) {
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for My Profile
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function myProfile(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const pharmacyId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const pharmacy = await pharmacyService.getById(pharmacyId);
    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("dashboard", "my-profile.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            message1: "",
            user,
            activeTab: "pharmacyDashboard",
            pharmacy,
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function getImage(req: Request, res: Response) {
  try {
    const userId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const { page, limit } = req.query;
    const images = await pharmacyModel.findById(userId);
    res.status(httpStatus.OK).send({
      data: images,
      message: "images fetched successfully",
      status: httpStatus.OK,
    });
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      status: httpStatus.INTERNAL_SERVER_ERROR,
      message: err.message,
    });
  }
}

/**
 * @description This function is for Change Profile Password
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function changePassword(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    let { currentPassword, password, confirmPassword } = req.body;
    let user: any = JSON.parse(res.get("user")!);
    user = await pharmacyService.getUserByUserID(user._id);
    const isMatch = pharmacyService.comparePassword(
      currentPassword,
      user.password
    );
    if (mode == "api") {
      //API Code Start
      if (isMatch) {
        if (password === confirmPassword) {
          const encryptPassword = pharmacyService.encryptPassword(password);
          const data = await pharmacyService.updateById(
            user._id,
            encryptPassword
          );
          res.status(httpStatus.OK).send({
            message: "Password reset successfully",
            status: httpStatus.OK,
          });
        } else {
          res.status(httpStatus.BAD_REQUEST).send({
            message: "Password not match",
            status: httpStatus.BAD_REQUESTs,
          });
        }
      } else {
        res.status(httpStatus.BAD_REQUEST).send({
          message: "Current password not match",
          status: httpStatus.BAD_REQUESTs,
        });
      }
      //API Code End
    } else {
      //Web Code Start
      const fileContent = getViewFile("dashboard", "profile-edit.ejs");
      const isMatch = pharmacyService.comparePassword(
        currentPassword,
        user.password
      );
      if (isMatch) {
        if (password === confirmPassword) {
          const encryptPassword = pharmacyService.encryptPassword(password);
          const data = await pharmacyService.updateById(
            user._id,
            encryptPassword
          );
          res.send(
            ejs.render(fileContent.file, {
              message: "Password reset successfully",
              message1: "",
              user,
              pharmacy: "",
              activeTab: "pharmacyDashboard",
              filename: fileContent.templatePath,
            })
          );
        } else {
          res.send(
            ejs.render(fileContent.file, {
              message1: "Password not match",
              message: "",
              user,
              pharmacy: "",
              activeTab: "pharmacyDashboard",
              filename: fileContent.templatePath,
            })
          );
        }
      } else {
        res.send(
          ejs.render(fileContent.file, {
            message1: "Current password not match",
            message: "",
            user,
            pharmacy: "",
            activeTab: "pharmacyDashboard",
            filename: fileContent.templatePath,
          })
        );
      }
      //Web Code End
    }
  } catch (err) {
    console.log(err);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: err,
      message: "Internal server error",
    });
  }
}

/**
 * @description This function is for Upload Pharmacy Details Through Excel
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function addPharmacyDetailsByFile(req: Request, res: Response) {
  try {
    // Read the Excel file
    const { mode } = req.params;

    const workbook = xlsx.readFile(
      "C:\\Users\\HP\\Desktop\\telehealth-ts-old\\pharmacy\\src\\modules\\pharmacy\\pharmacy Ireland database.xlsx"
    );
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    const rows: any = xlsx.utils.sheet_to_json(sheet);
    // console.log(rows.length);
    // Save each row to MongoDB
    for (let i = 0; i < rows.length; i++) {
      const row: any = rows[i];
      let passwordToString = row.password.toString();
      const encryptPassword = pharmacyService.encryptPassword(passwordToString);
      // console.log(`Creating shop ${row.storeName}`);
      const pharmacy = await pharmacyModel.create({
        cho: row.CHO,
        country: row.County,
        dlNumber: row.dlNumber,
        storeName: row.storeName,
        location: row.location,
        eircode: row.Eircode,
        mobileNumber: row.mobileNumber,
        email: row.email,
        password: encryptPassword,
        opening_Hours: {
          Mon: row.Mon,
          Tue: row.Tue,
          Wed: row.Wed,
          Thu: row.Thu,
          Fri: row.Fri,
          Sat: row.Sat,
          Sun: row.Sun,
        },
      });

      // const newData=await pharmacy.save();
    }
    res.status(httpStatus.OK).send({
      message: "data uploaded successfully",
      status: httpStatus.OK,
    });
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}





export async function eirSuggestion(req: Request, res: Response) {
  try {
    const { limit, page } = req.query;

    const { mode } = req.params;

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: "",
        message: "Booking update successfully",
        status: httpStatus.OK,
      });
    } else {
      //web code
      
      

      const  eircode = req.body.eircode;

      const suggestions: any = await eircodeModel.find(
        { location: { $regex:  eircode, $options: "i" } },
        "name"
      );

      
      

      const Id: Types.ObjectId = suggestions.map((e: any) => {
        return e._id;
      });

      const  eircodes = await eircodeModel.find({ _id: Id });

    
      

      res.json({ suggestions:  eircodes });
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}