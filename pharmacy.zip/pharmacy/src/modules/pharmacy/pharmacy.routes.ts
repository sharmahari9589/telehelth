import { Router } from "express";
import * as pharmacyController from "./pharmacy.controller";

const appRoutes = Router({
  mergeParams: true,
});

appRoutes
  .route("/editprofile")
  .get(pharmacyController.editProfile)
  .post(pharmacyController.editProfile);

  
  appRoutes
.route("/eir-suggestion")
.get(pharmacyController.eirSuggestion)
.post(pharmacyController.eirSuggestion);

appRoutes
  .route("/getImage")
  .get(pharmacyController.getImage)
  .post(pharmacyController.getImage);

appRoutes.get("/myprofile", pharmacyController.myProfile);

appRoutes
  .route("/change-password")
  .get(pharmacyController.changePassword)
  .post(pharmacyController.changePassword);

appRoutes
  .route("/file")
  .get(pharmacyController.addPharmacyDetailsByFile)
  .post(pharmacyController.addPharmacyDetailsByFile);

export default appRoutes;
