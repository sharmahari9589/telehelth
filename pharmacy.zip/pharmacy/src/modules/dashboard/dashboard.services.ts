import { Types } from "mongoose";
import orderModel, { orderStatus } from "../order/order.model";
import consultantModel from "../../models/consultant.model";
import patientModel from "../../models/patient.model";
import pharmacyModel from "../pharmacy/pharmacy.model";
import { Order } from "../order/order.model";
import bookingModel from "../booking/booking.model";

// all orders

export async function allordersPharmacy(pharmacyId: Types.ObjectId) {
  return await orderModel.find({
    pharmacy: pharmacyId,
  });
}

// pending
export async function pending(pharmacyId: Types.ObjectId) {
  return await orderModel.find({
    pharmacy: pharmacyId,
    orderStatus: orderStatus.inProcess,
  });
}

//  cancelled
export async function cancelled(pharmacyId: Types.ObjectId) {
  return await orderModel.find({
    pharmacy: pharmacyId,
    orderStatus: orderStatus.reject,
  });
}

// confirmed
export async function confirmed(pharmacyId: Types.ObjectId) {
  return await orderModel.find({
    pharmacy: pharmacyId,
    orderStatus: orderStatus.completed,
  });
}

// pending
export async function pendingCount(pharmacyId: Types.ObjectId) {
  return await orderModel.countDocuments({
    pharmacy: pharmacyId,
    orderStatus: orderStatus.inProcess,
  });
}
export async function readyOrderCount(pharmacyId: Types.ObjectId) {
  return await orderModel.countDocuments({
    pharmacy: pharmacyId,
    orderStatus: orderStatus.readyFordispatch,
  });
}

export async function newOrderCount(pharmacyId: Types.ObjectId) {
  return await orderModel.countDocuments({
    pharmacy: pharmacyId,
    orderStatus: orderStatus.pending,
  });
}

//  cancelled
export async function cancelledCount(pharmacyId: Types.ObjectId) {
  return await orderModel.countDocuments({
    pharmacy: pharmacyId,
    orderStatus: orderStatus.reject,
  });
}

// confirmed
export async function confirmedCount(pharmacyId: Types.ObjectId) {
  return await orderModel.countDocuments({
    pharmacy: pharmacyId,
    orderStatus: orderStatus.completed,
  });
}

//

//  dashboard data\

export async function getReadyOrders(
  pharmacyId: Types.ObjectId,
  startDate: string,
  endDate: string,
  search: string,
  limit: any,
  page: any
) {
  if (search) {
    return await orderModel.aggregate([
      {
        $match: {
          pharmacy: pharmacyId,
          orderStatus: "readyForDispatch",
        },
      },
      {
        $lookup: {
          from: "bookings",
          localField: "booking",
          foreignField: "_id",
          as: "booking",
        },
      },
      {
        $unwind: {
          path: "$booking",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "healthproblems",
          localField: "problem",
          foreignField: "_id",
          as: "problem",
        },
      },
      {
        $unwind: {
          path: "$problem",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "patients",
          localField: "patient",
          foreignField: "_id",
          as: "patient",
        },
      },
      {
        $unwind: {
          path: "$patient",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "doctors",
          localField: "consultant",
          foreignField: "_id",
          as: "consultant",
        },
      },
      {
        $lookup: {
          from: "pharmacies",
          localField: "pharmacy",
          foreignField: "_id",
          as: "pharmacy",
        },
      },
      {
        $unwind: {
          path: "$pharmacy",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $unwind: {
          path: "$consultant",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $unwind: {
          path: "$prescription",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $sort: {
          "booking.date": 1,
        },
      },
      {
        $match: {
          "booking.bookingFor.patientName": { $regex: search, $options: "i" },
        },
      },
    ]);
  }

  if (startDate) {
    if (startDate && endDate) {
      return await orderModel.aggregate([
        {
          $match: {
            pharmacy: pharmacyId,
            orderStatus: "readyForDispatch",
            deliveryDate: {
              $gte: new Date(startDate),
              $lte: new Date(endDate),
            },
          },
        },
        {
          $lookup: {
            from: "bookings",
            localField: "booking",
            foreignField: "_id",
            as: "booking",
          },
        },
        {
          $unwind: {
            path: "$booking",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "consultant",
            foreignField: "_id",
            as: "consultant",
          },
        },
        {
          $lookup: {
            from: "pharmacies",
            localField: "pharmacy",
            foreignField: "_id",
            as: "pharmacy",
          },
        },
        {
          $unwind: {
            path: "$pharmacy",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $unwind: {
            path: "$consultant",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $unwind: {
            path: "$prescription",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $sort: {
            "booking.date": 1,
          },
        },
      ]);
    } else {
      return await orderModel.aggregate([
        {
          $match: {
            pharmacy: pharmacyId,
            orderStatus: "inProcereadyForDispatch",
            deliveryDate: {
              $gte: new Date(startDate),
            },
          },
        },
        {
          $lookup: {
            from: "bookings",
            localField: "booking",
            foreignField: "_id",
            as: "booking",
          },
        },
        {
          $unwind: {
            path: "$booking",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "consultant",
            foreignField: "_id",
            as: "consultant",
          },
        },
        {
          $lookup: {
            from: "pharmacies",
            localField: "pharmacy",
            foreignField: "_id",
            as: "pharmacy",
          },
        },
        {
          $unwind: {
            path: "$pharmacy",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $unwind: {
            path: "$consultant",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $unwind: {
            path: "$prescription",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $sort: {
            "booking.date": 1,
          },
        },
      ]);
    }
  }
  if (endDate) {
    return await orderModel.aggregate([
      {
        $match: {
          pharmacy: pharmacyId,
          orderStatus: "readyForDispatch",
          deliveryDate: { $lte: new Date(endDate) },
        },
      },
      {
        $lookup: {
          from: "bookings",
          localField: "booking",
          foreignField: "_id",
          as: "booking",
        },
      },
      {
        $unwind: {
          path: "$booking",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "healthproblems",
          localField: "problem",
          foreignField: "_id",
          as: "problem",
        },
      },
      {
        $unwind: {
          path: "$problem",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "patients",
          localField: "patient",
          foreignField: "_id",
          as: "patient",
        },
      },
      {
        $unwind: {
          path: "$patient",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "doctors",
          localField: "consultant",
          foreignField: "_id",
          as: "consultant",
        },
      },
      {
        $lookup: {
          from: "pharmacies",
          localField: "pharmacy",
          foreignField: "_id",
          as: "pharmacy",
        },
      },
      {
        $unwind: {
          path: "$pharmacy",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $unwind: {
          path: "$consultant",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $unwind: {
          path: "$prescription",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $sort: {
          "booking.date": 1,
        },
      },
    ]);
  } else {
    return await orderModel.aggregate([
      {
        $match: {
          pharmacy: pharmacyId,
          orderStatus: "readyForDispatch",
        },
      },
      {
        $lookup: {
          from: "bookings",
          localField: "booking",
          foreignField: "_id",
          as: "booking",
        },
      },
      {
        $unwind: {
          path: "$booking",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "healthproblems",
          localField: "problem",
          foreignField: "_id",
          as: "problem",
        },
      },
      {
        $unwind: {
          path: "$problem",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "patients",
          localField: "patient",
          foreignField: "_id",
          as: "patient",
        },
      },
      {
        $unwind: {
          path: "$patient",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "doctors",
          localField: "consultant",
          foreignField: "_id",
          as: "consultant",
        },
      },
      {
        $lookup: {
          from: "pharmacies",
          localField: "pharmacy",
          foreignField: "_id",
          as: "pharmacy",
        },
      },
      {
        $unwind: {
          path: "$pharmacy",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $unwind: {
          path: "$consultant",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $unwind: {
          path: "$prescription",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $sort: {
          "booking.date": 1,
        },
      },
    ]);
  }

  // .limit(limit)
  //   .skip((page - 1) * limit);
}

export async function getOngoingOrders(
  pharmacyId: Types.ObjectId,
  startDate: string,
  endDate: string,
  search: string,
  limit: any,
  page: any
) {
  if (search) {
    return await orderModel
      .aggregate([
        {
          $match: {
            pharmacy: pharmacyId,
            orderStatus: "inProcess",
          },
        },
        {
          $lookup: {
            from: "bookings",
            localField: "booking",
            foreignField: "_id",
            as: "booking",
          },
        },
        {
          $unwind: {
            path: "$booking",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "consultant",
            foreignField: "_id",
            as: "consultant",
          },
        },
        {
          $lookup: {
            from: "pharmacies",
            localField: "pharmacy",
            foreignField: "_id",
            as: "pharmacy",
          },
        },
        {
          $unwind: {
            path: "$pharmacy",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $unwind: {
            path: "$consultant",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $unwind: {
            path: "$prescription",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $sort: {
            "booking.date": 1,
          },
        },
        {
          $match: {
            "booking.bookingFor.patientName": { $regex: search, $options: "i" },
          },
        },
      ])
      .skip(limit * page - limit);
  }

  if (startDate) {
    if (startDate && endDate) {
      return await orderModel
        .aggregate([
          {
            $match: {
              pharmacy: pharmacyId,
              orderStatus: "inProcess",
              deliveryDate: {
                $gte: new Date(startDate),
                $lte: new Date(endDate),
              },
            },
          },
          {
            $lookup: {
              from: "bookings",
              localField: "booking",
              foreignField: "_id",
              as: "booking",
            },
          },
          {
            $unwind: {
              path: "$booking",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $lookup: {
              from: "healthproblems",
              localField: "problem",
              foreignField: "_id",
              as: "problem",
            },
          },
          {
            $unwind: {
              path: "$problem",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $lookup: {
              from: "patients",
              localField: "patient",
              foreignField: "_id",
              as: "patient",
            },
          },
          {
            $unwind: {
              path: "$patient",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $lookup: {
              from: "doctors",
              localField: "consultant",
              foreignField: "_id",
              as: "consultant",
            },
          },
          {
            $lookup: {
              from: "pharmacies",
              localField: "pharmacy",
              foreignField: "_id",
              as: "pharmacy",
            },
          },
          {
            $unwind: {
              path: "$pharmacy",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $unwind: {
              path: "$consultant",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $unwind: {
              path: "$prescription",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $sort: {
              "booking.date": 1,
            },
          },
          {
            $match: {
              "patient.firstName": { $regex: search, $options: "i" },
            },
          },
        ])
        .skip(limit * page - limit);
    } else {
      return await orderModel
        .aggregate([
          {
            $match: {
              pharmacy: pharmacyId,
              orderStatus: "inProcess",
              deliveryDate: {
                $gte: new Date(startDate),
              },
            },
          },
          {
            $lookup: {
              from: "bookings",
              localField: "booking",
              foreignField: "_id",
              as: "booking",
            },
          },
          {
            $unwind: {
              path: "$booking",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $lookup: {
              from: "healthproblems",
              localField: "problem",
              foreignField: "_id",
              as: "problem",
            },
          },
          {
            $unwind: {
              path: "$problem",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $lookup: {
              from: "patients",
              localField: "patient",
              foreignField: "_id",
              as: "patient",
            },
          },
          {
            $unwind: {
              path: "$patient",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $lookup: {
              from: "doctors",
              localField: "consultant",
              foreignField: "_id",
              as: "consultant",
            },
          },
          {
            $lookup: {
              from: "pharmacies",
              localField: "pharmacy",
              foreignField: "_id",
              as: "pharmacy",
            },
          },
          {
            $unwind: {
              path: "$pharmacy",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $unwind: {
              path: "$consultant",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $unwind: {
              path: "$prescription",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $sort: {
              "booking.date": 1,
            },
          },
          {
            $match: {
              "patient.firstName": { $regex: search, $options: "i" },
            },
          },
        ])
        .skip(limit * page - limit);
    }
  }
  if (endDate) {
    return await orderModel
      .aggregate([
        {
          $match: {
            pharmacy: pharmacyId,
            orderStatus: "inProcess",
            deliveryDate: { $lte: new Date(endDate) },
          },
        },
        {
          $lookup: {
            from: "bookings",
            localField: "booking",
            foreignField: "_id",
            as: "booking",
          },
        },
        {
          $unwind: {
            path: "$booking",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "consultant",
            foreignField: "_id",
            as: "consultant",
          },
        },
        {
          $lookup: {
            from: "pharmacies",
            localField: "pharmacy",
            foreignField: "_id",
            as: "pharmacy",
          },
        },
        {
          $unwind: {
            path: "$pharmacy",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $unwind: {
            path: "$consultant",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $unwind: {
            path: "$prescription",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $sort: {
            "booking.date": 1,
          },
        },
        {
          $match: {
            "patient.firstName": { $regex: search, $options: "i" },
          },
        },
      ])
      .skip(limit * page - limit);
  } else {
    return await orderModel
      .aggregate([
        {
          $match: {
            pharmacy: pharmacyId,
            orderStatus: "inProcess",
          },
        },
        {
          $lookup: {
            from: "bookings",
            localField: "booking",
            foreignField: "_id",
            as: "booking",
          },
        },
        {
          $unwind: {
            path: "$booking",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "consultant",
            foreignField: "_id",
            as: "consultant",
          },
        },
        {
          $lookup: {
            from: "pharmacies",
            localField: "pharmacy",
            foreignField: "_id",
            as: "pharmacy",
          },
        },
        {
          $unwind: {
            path: "$pharmacy",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $unwind: {
            path: "$consultant",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $unwind: {
            path: "$prescription",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $sort: {
            "booking.date": 1,
          },
        },
      ])
      .skip(limit * page - limit);
  }

  // .limit(limit)
  //   .skip((page - 1) * limit);
}

// completed order

export async function getCompletedOrders(
  pharmacyId: Types.ObjectId,
  startDate: string,
  endDate: string,
  search: string,
  limit: any,
  page: any
) {
  if (search) {
    return await orderModel
      .aggregate([
        {
          $match: {
            pharmacy: pharmacyId,
            orderStatus: "completed",
          },
        },
        {
          $lookup: {
            from: "bookings",
            localField: "booking",
            foreignField: "_id",
            as: "booking",
          },
        },
        {
          $unwind: {
            path: "$booking",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "consultant",
            foreignField: "_id",
            as: "consultant",
          },
        },
        {
          $lookup: {
            from: "pharmacies",
            localField: "pharmacy",
            foreignField: "_id",
            as: "pharmacy",
          },
        },
        {
          $unwind: {
            path: "$pharmacy",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $unwind: {
            path: "$consultant",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $unwind: {
            path: "$prescription",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $sort: {
            "booking.date": 1,
          },
        },
        {
          $match: {
            "booking.bookingFor.patientName": { $regex: search, $options: "i" },
          },
        },
      ])
      .skip(limit * page - limit);
  }

  if (startDate) {
    if (startDate && endDate) {
      return await orderModel
        .aggregate([
          {
            $match: {
              pharmacy: pharmacyId,
              orderStatus: "completed",
              deliveryDate: {
                $gte: new Date(startDate),
                $lte: new Date(endDate),
              },
            },
          },
          {
            $lookup: {
              from: "bookings",
              localField: "booking",
              foreignField: "_id",
              as: "booking",
            },
          },
          {
            $unwind: {
              path: "$booking",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $lookup: {
              from: "healthproblems",
              localField: "problem",
              foreignField: "_id",
              as: "problem",
            },
          },
          {
            $unwind: {
              path: "$problem",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $lookup: {
              from: "patients",
              localField: "patient",
              foreignField: "_id",
              as: "patient",
            },
          },
          {
            $unwind: {
              path: "$patient",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $lookup: {
              from: "doctors",
              localField: "consultant",
              foreignField: "_id",
              as: "consultant",
            },
          },
          {
            $lookup: {
              from: "pharmacies",
              localField: "pharmacy",
              foreignField: "_id",
              as: "pharmacy",
            },
          },
          {
            $unwind: {
              path: "$pharmacy",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $unwind: {
              path: "$consultant",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $unwind: {
              path: "$prescription",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $sort: {
              "booking.date": 1,
            },
          },
        ])
        .skip(limit * page - limit);
    } else {
      return await orderModel
        .aggregate([
          {
            $match: {
              pharmacy: pharmacyId,
              orderStatus: "completed",
              deliveryDate: {
                $gte: new Date(startDate),
              },
            },
          },
          {
            $lookup: {
              from: "bookings",
              localField: "booking",
              foreignField: "_id",
              as: "booking",
            },
          },
          {
            $unwind: {
              path: "$booking",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $lookup: {
              from: "healthproblems",
              localField: "problem",
              foreignField: "_id",
              as: "problem",
            },
          },
          {
            $unwind: {
              path: "$problem",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $lookup: {
              from: "patients",
              localField: "patient",
              foreignField: "_id",
              as: "patient",
            },
          },
          {
            $unwind: {
              path: "$patient",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $lookup: {
              from: "doctors",
              localField: "consultant",
              foreignField: "_id",
              as: "consultant",
            },
          },
          {
            $lookup: {
              from: "pharmacies",
              localField: "pharmacy",
              foreignField: "_id",
              as: "pharmacy",
            },
          },
          {
            $unwind: {
              path: "$pharmacy",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $unwind: {
              path: "$consultant",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $unwind: {
              path: "$prescription",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $sort: {
              "booking.date": 1,
            },
          },
        ])
        .skip(limit * page - limit);
    }
  }
  if (endDate) {
    return await orderModel.aggregate([
      {
        $match: {
          pharmacy: pharmacyId,
          orderStatus: "completed",
          deliveryDate: { $lte: new Date(endDate) },
        },
      },
      {
        $lookup: {
          from: "bookings",
          localField: "booking",
          foreignField: "_id",
          as: "booking",
        },
      },
      {
        $unwind: {
          path: "$booking",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "healthproblems",
          localField: "problem",
          foreignField: "_id",
          as: "problem",
        },
      },
      {
        $unwind: {
          path: "$problem",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "patients",
          localField: "patient",
          foreignField: "_id",
          as: "patient",
        },
      },
      {
        $unwind: {
          path: "$patient",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "doctors",
          localField: "consultant",
          foreignField: "_id",
          as: "consultant",
        },
      },
      {
        $lookup: {
          from: "pharmacies",
          localField: "pharmacy",
          foreignField: "_id",
          as: "pharmacy",
        },
      },
      {
        $unwind: {
          path: "$pharmacy",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $unwind: {
          path: "$consultant",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $unwind: {
          path: "$prescription",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $sort: {
          "booking.date": 1,
        },
      },
    ]);
  } else {
    return await orderModel
      .aggregate([
        {
          $match: {
            pharmacy: pharmacyId,
            orderStatus: "completed",
          },
        },
        {
          $lookup: {
            from: "bookings",
            localField: "booking",
            foreignField: "_id",
            as: "booking",
          },
        },
        {
          $unwind: {
            path: "$booking",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "consultant",
            foreignField: "_id",
            as: "consultant",
          },
        },
        {
          $lookup: {
            from: "pharmacies",
            localField: "pharmacy",
            foreignField: "_id",
            as: "pharmacy",
          },
        },
        {
          $unwind: {
            path: "$pharmacy",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $unwind: {
            path: "$consultant",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $unwind: {
            path: "$prescription",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $sort: {
            "booking.date": 1,
          },
        },
      ])
      .skip(limit * page - limit);
  }

  // .limit(limit)
  //   .skip((page - 1) * limit);
}

// reject order

export async function getRejectedOrders(
  pharmacyId: Types.ObjectId,
  startDate: string,
  endDate: string,
  search: string,
  limit: any,
  page: any
) {
  if (search) {
    return await orderModel
      .aggregate([
        {
          $match: {
            pharmacy: pharmacyId,
            orderStatus: "reject",
          },
        },
        {
          $lookup: {
            from: "bookings",
            localField: "booking",
            foreignField: "_id",
            as: "booking",
          },
        },
        {
          $unwind: {
            path: "$booking",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "consultant",
            foreignField: "_id",
            as: "consultant",
          },
        },
        {
          $lookup: {
            from: "pharmacies",
            localField: "pharmacy",
            foreignField: "_id",
            as: "pharmacy",
          },
        },
        {
          $unwind: {
            path: "$pharmacy",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $unwind: {
            path: "$consultant",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $unwind: {
            path: "$prescription",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $sort: {
            "booking.date": 1,
          },
        },
        {
          $match: {
            "patient.firstName": { $regex: search, $options: "i" },
          },
        },
      ])
      .skip(limit * page - limit);
  }

  if (startDate) {
    if (startDate && endDate) {
      return await orderModel
        .aggregate([
          {
            $match: {
              pharmacy: pharmacyId,
              orderStatus: "reject",
              deliveryDate: {
                $gte: new Date(startDate),
                $lte: new Date(endDate),
              },
            },
          },
          {
            $lookup: {
              from: "bookings",
              localField: "booking",
              foreignField: "_id",
              as: "booking",
            },
          },
          {
            $unwind: {
              path: "$booking",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $lookup: {
              from: "healthproblems",
              localField: "problem",
              foreignField: "_id",
              as: "problem",
            },
          },
          {
            $unwind: {
              path: "$problem",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $lookup: {
              from: "patients",
              localField: "patient",
              foreignField: "_id",
              as: "patient",
            },
          },
          {
            $unwind: {
              path: "$patient",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $lookup: {
              from: "doctors",
              localField: "consultant",
              foreignField: "_id",
              as: "consultant",
            },
          },
          {
            $lookup: {
              from: "pharmacies",
              localField: "pharmacy",
              foreignField: "_id",
              as: "pharmacy",
            },
          },
          {
            $unwind: {
              path: "$pharmacy",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $unwind: {
              path: "$consultant",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $unwind: {
              path: "$prescription",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $sort: {
              "booking.date": 1,
            },
          },
          {
            $match: {
              "patient.firstName": { $regex: search, $options: "i" },
            },
          },
        ])
        .skip(limit * page - limit);
    } else {
      return await orderModel
        .aggregate([
          {
            $match: {
              pharmacy: pharmacyId,
              orderStatus: "reject",
              deliveryDate: {
                $gte: new Date(startDate),
              },
            },
          },
          {
            $lookup: {
              from: "bookings",
              localField: "booking",
              foreignField: "_id",
              as: "booking",
            },
          },
          {
            $unwind: {
              path: "$booking",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $lookup: {
              from: "healthproblems",
              localField: "problem",
              foreignField: "_id",
              as: "problem",
            },
          },
          {
            $unwind: {
              path: "$problem",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $lookup: {
              from: "patients",
              localField: "patient",
              foreignField: "_id",
              as: "patient",
            },
          },
          {
            $unwind: {
              path: "$patient",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $lookup: {
              from: "doctors",
              localField: "consultant",
              foreignField: "_id",
              as: "consultant",
            },
          },
          {
            $lookup: {
              from: "pharmacies",
              localField: "pharmacy",
              foreignField: "_id",
              as: "pharmacy",
            },
          },
          {
            $unwind: {
              path: "$pharmacy",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $unwind: {
              path: "$consultant",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $unwind: {
              path: "$prescription",
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $sort: {
              "booking.date": 1,
            },
          },
          {
            $match: {
              "patient.firstName": { $regex: search, $options: "i" },
            },
          },
        ])
        .skip(limit * page - limit);
    }
  }
  if (endDate) {
    return await orderModel
      .aggregate([
        {
          $match: {
            pharmacy: pharmacyId,
            orderStatus: "reject",
            deliveryDate: { $lte: new Date(endDate) },
          },
        },
        {
          $lookup: {
            from: "bookings",
            localField: "booking",
            foreignField: "_id",
            as: "booking",
          },
        },
        {
          $unwind: {
            path: "$booking",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "consultant",
            foreignField: "_id",
            as: "consultant",
          },
        },
        {
          $lookup: {
            from: "pharmacies",
            localField: "pharmacy",
            foreignField: "_id",
            as: "pharmacy",
          },
        },
        {
          $unwind: {
            path: "$pharmacy",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $unwind: {
            path: "$consultant",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $unwind: {
            path: "$prescription",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $sort: {
            "booking.date": 1,
          },
        },
        {
          $match: {
            "patient.firstName": { $regex: search, $options: "i" },
          },
        },
      ])
      .skip(limit * page - limit);
  } else {
    return await orderModel
      .aggregate([
        {
          $match: {
            pharmacy: pharmacyId,
            orderStatus: "reject",
          },
        },
        {
          $lookup: {
            from: "bookings",
            localField: "booking",
            foreignField: "_id",
            as: "booking",
          },
        },
        {
          $unwind: {
            path: "$booking",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "consultant",
            foreignField: "_id",
            as: "consultant",
          },
        },
        {
          $lookup: {
            from: "pharmacies",
            localField: "pharmacy",
            foreignField: "_id",
            as: "pharmacy",
          },
        },
        {
          $unwind: {
            path: "$pharmacy",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $unwind: {
            path: "$consultant",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $unwind: {
            path: "$prescription",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $sort: {
            "booking.date": 1,
          },
        },
      ])
      .skip(limit * page - limit);
  }
}

/**
 * @description This function works for filter of Pending Order
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function getFilteredPendingOrders(
  search: string,
  page: number,
  startDate: Date,
  endDate: Date,
  consultantId: Types.ObjectId
): Promise<Array<Order>> {
  const limit = 20;

  return await orderModel.aggregate([
    {
      $match: {
        pharmacy: consultantId,
        orderStatus: orderStatus.pending,
      },
    },
    {
      $lookup: {
        from: "patients",
        localField: "patient",
        foreignField: "_id",
        as: "patient",
      },
    },
    {
      $unwind: {
        path: "$patient",
        preserveNullAndEmptyArrays: true,
      },
    },
    // {
    //   $match:{
    //     $and: [
    //       {
    //         deliveryDate: {
    //           $gte: startDate,
    //          }
    //        },{
    //         deliveryDate:{
    //            $lte:endDate
    //          }
    //        }
    //      ]
    //     }
    // },
    {
      $match: {
        $or: [
          {
            "patient.firstName": {
              $regex: search,
              $options: "i",
            },
          },
        ],
      },
    },
  ]);
}

/**
 * @description This function works for filter of Pending Order
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function getFilteredOngoingOrders(
  search: string,
  page: number,
  startDate: Date,
  endDate: Date,
  consultantId: Types.ObjectId
): Promise<Array<Order>> {
  const limit = 20;

  return await orderModel.aggregate([
    {
      $match: {
        pharmacy: consultantId,
        orderStatus: orderStatus.inProcess,
      },
    },
    {
      $lookup: {
        from: "patients",
        localField: "patient",
        foreignField: "_id",
        as: "patient",
      },
    },
    {
      $unwind: {
        path: "$patient",
        preserveNullAndEmptyArrays: true,
      },
    },
    // {
    //   $match:{
    //     $and: [
    //       {
    //         deliveryDate: {
    //           $gte: startDate,
    //          }
    //        },{
    //         deliveryDate:{
    //            $lte:endDate
    //          }
    //        }
    //      ]
    //     }
    // },
    {
      $match: {
        $or: [
          {
            "patient.firstName": {
              $regex: search,
              $options: "i",
            },
          },
        ],
      },
    },
  ]);
}

/**
 * @description This function works for filter of Pending Order
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function getFilteredCompletedOrders(
  search: string,
  page: number,
  startDate: Date,
  endDate: Date,
  consultantId: Types.ObjectId
): Promise<Array<Order>> {
  const limit = 20;

  return await orderModel.aggregate([
    {
      $match: {
        pharmacy: consultantId,
        orderStatus: orderStatus.completed,
      },
    },
    {
      $lookup: {
        from: "patients",
        localField: "patient",
        foreignField: "_id",
        as: "patient",
      },
    },
    {
      $unwind: {
        path: "$patient",
        preserveNullAndEmptyArrays: true,
      },
    },
    // {
    //   $match:{
    //     $and: [
    //       {
    //         deliveryDate: {
    //           $gte: startDate,
    //          }
    //        },{
    //         deliveryDate:{
    //            $lte:endDate
    //          }
    //        }
    //      ]
    //     }
    // },
    {
      $match: {
        $or: [
          {
            "patient.firstName": {
              $regex: search,
              $options: "i",
            },
          },
        ],
      },
    },
  ]);
}

/**
 * @description This function works for filter of Pending Order
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function getFilteredRejectedOrders(
  search: string,
  page: number,
  startDate: Date,
  endDate: Date,
  consultantId: Types.ObjectId
): Promise<Array<Order>> {
  const limit = 20;

  return await orderModel.aggregate([
    {
      $match: {
        pharmacy: consultantId,
        orderStatus: orderStatus.reject,
      },
    },
    {
      $lookup: {
        from: "patients",
        localField: "patient",
        foreignField: "_id",
        as: "patient",
      },
    },
    {
      $unwind: {
        path: "$patient",
        preserveNullAndEmptyArrays: true,
      },
    },
    // {
    //   $match:{
    //     $and: [
    //       {
    //         deliveryDate: {
    //           $gte: startDate,
    //          }
    //        },{
    //         deliveryDate:{
    //            $lte:endDate
    //          }
    //        }
    //      ]
    //     }
    // },
    {
      $match: {
        $or: [
          {
            "patient.firstName": {
              $regex: search,
              $options: "i",
            },
          },
        ],
      },
    },
  ]);
}
