import { Request, Response } from "express";
import httpStatus from "http-status";
import * as orderServices from "./dashboard.services";
import * as orderService from "../order/order.service";

//EJS Rendor
import ejs from "ejs";
import { getViewFile } from "../../utils/ejsHelper";
import { Types } from "mongoose";
import orderModel, { Order } from "../order/order.model";
import { json } from "stream/consumers";
import { Booking } from "../booking/booking.model";
import { Certificate } from "crypto";

/**
 * @description This function is for Dashboard
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function dashboard(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const limit = 10;
    const page = req.query.page || 1;
    const pharmacyId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const newOrder = await orderServices.newOrderCount(pharmacyId);
    const readyOrder = await orderServices.readyOrderCount(pharmacyId);

    const ongoing = await orderServices.pendingCount(pharmacyId);
    const confirmed = await orderServices.confirmedCount(pharmacyId);
    const cancelled = await orderServices.cancelledCount(pharmacyId);
    let total = ongoing + cancelled + confirmed;

    const manageOrder: Array<Order> = await orderService.getPendingOrders(
      pharmacyId,
      limit,
      page
    );

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        ongoing,
        newOrder,
        confirmed,
        cancelled,
        total,
        manageOrder,
        massage: `order count is fetched`,
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("dashboard", "index.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            ongoing,
            readyOrder,
            confirmed,
            cancelled,
            activeTab: "pharmacyDashboard",
            total,
            newOrder,
            manageOrder,
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for Document Center
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function documentCenter(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("dashboard", "document-center.ejs");
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            type: "",
            documents: "",
            activeTab: "documentCenter",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for Manage Orders
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function manageOrders(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("dashboard", "manage-order.ejs");
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user: "",
            activeTab: "manageOrders",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for My Profile
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function myProfile(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("dashboard", "my-profile.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "pharmacyDashboard",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for New Booking
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */

export async function newBooking(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const pharmacyId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);


    if (mode == "api") {
    } else {
      //Web Code Start

      if (req.method == "GET") {
        const fileContent = getViewFile("dashboard", "new-booking.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "pharmacyDashboard",

            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for Edit Profile
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function editProfile(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("dashboard", "profile-edit.ejs");
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user: "",
            activeTab: "pharmacyDashboard",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for View All Orders
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function viewAllOrders(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const pharmacyId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    let ongoing;
    let cancelled;
    let confirmed;
    let total;

    if (req.body.choice == "all") {
      ongoing = await orderServices.pendingCount(pharmacyId);
      confirmed = await orderServices.confirmedCount(pharmacyId);
      cancelled = await orderServices.cancelledCount(pharmacyId);
      total = ongoing + cancelled + confirmed;
    }

    // filter by today

    if (req.body.choice == "today") {
      const ongoingData: Array<Order> = await orderServices.pending(pharmacyId);
      const confirmedData = await orderServices.confirmed(pharmacyId);
      const cancelledData = await orderServices.cancelled(pharmacyId);

      // filter today pending

      const filteredDataPending = [];
      const filteredDataconfirmed = [];
      const filteredDataCancelled = [];

      const today = new Date();
      ongoingData.forEach((item) => {
        const itemDate = new Date(item.createdAt);
        if (itemDate.toDateString() === today.toDateString()) {
          filteredDataPending.push(item);
        }
      });

      ongoing = filteredDataPending.length;

      // filter today confirmed
      confirmedData.forEach((item) => {
        const itemDate = new Date(item.createdAt);
        if (itemDate.toDateString() === today.toDateString()) {
          filteredDataconfirmed.push(item);
        }
      });

      confirmed = filteredDataCancelled.length;

      // filter today cancelled
      cancelledData.forEach((item) => {
        const itemDate = new Date(item.createdAt);
        if (itemDate.toDateString() === today.toDateString()) {
          filteredDataCancelled.push(item);
        }
      });

      cancelled = filteredDataCancelled.length;
      total = ongoing + confirmed + cancelled;
    }

    // filter by week

    if (req.body.choice == "week") {
      const ongoingData: Array<Order> = await orderServices.pending(pharmacyId);
      const confirmedData = await orderServices.confirmed(pharmacyId);
      const cancelledData = await orderServices.cancelled(pharmacyId);
      // filter by week  pending
      let year: any = new Date(new Date().getFullYear());
      let currentDate: any = new Date();
      let start: any = new Date(currentDate.getFullYear(), 0, 1);
      let days = Math.floor((currentDate - start) / (24 * 60 * 60 * 1000));

      let week = Math.ceil(days / 7);

      // Calculate the start and end dates of the requested week
      const startDate = new Date(year, 0, 1);
      startDate.setDate(startDate.getDate() + (week - 1) * 7);
      const endDate = new Date(year, 0, 1);
      endDate.setDate(endDate.getDate() + week * 7);

      // Filter the data based on the date range

      const filteredDatapending = ongoingData.filter((item) => {
        const itemDate = new Date(item.createdAt);
        return itemDate >= startDate && itemDate < endDate;
      });

      ongoing = filteredDatapending.length;
      // filter by week pending

      // filter by week cancelled
      const filteredDatacanceeled = cancelledData.filter((item) => {
        const itemDate = new Date(item.createdAt);
        return itemDate >= startDate && itemDate < endDate;
      });

      cancelled = filteredDatacanceeled.length;
      // filter by week cancelled

      // filter by week confirmed
      const filteredDataconfirmed = confirmedData.filter((item) => {
        const itemDate = new Date(item.createdAt);
        return itemDate >= startDate && itemDate < endDate;
      });

      confirmed = filteredDataconfirmed.length;
      total = ongoing + confirmed + cancelled;
      // filter by week confirmed
    }

    //filter by this month

    if (req.body.choice == "month") {
      const ongoingData: Array<Order> = await orderServices.pending(pharmacyId);
      const confirmedData = await orderServices.confirmed(pharmacyId);
      const cancelledData = await orderServices.cancelled(pharmacyId);

      // pending this month
      const thisMonthDatapending = ongoingData.filter((item) => {
        const itemDate = new Date(item.createdAt);
        const now = new Date();
        return (
          itemDate.getMonth() === now.getMonth() &&
          itemDate.getFullYear() === now.getFullYear()
        );
      });

      // pending this month

      // cancelled this month
      const thisMonthDatacancelled = cancelledData.filter((item) => {
        const itemDate = new Date(item.createdAt);
        const now = new Date();
        return (
          itemDate.getMonth() === now.getMonth() &&
          itemDate.getFullYear() === now.getFullYear()
        );
      });

      // cancelled this month

      // confirmrd this month
      const thisMonthDataconfirmed = confirmedData.filter((item) => {
        const itemDate = new Date(item.createdAt);
        const now = new Date();
        return (
          itemDate.getMonth() === now.getMonth() &&
          itemDate.getFullYear() === now.getFullYear()
        );
      });

      ongoing = thisMonthDatapending.length;
      cancelled = thisMonthDatacancelled.length;
      confirmed = thisMonthDataconfirmed.length;
      total = ongoing + cancelled + confirmed;

      // confirmed this month
    }

    // filter by this month

    // filter data by last month

    if (req.body.choice == "lastmonth") {
      const ongoingData: Array<Order> = await orderServices.pending(pharmacyId);
      const confirmedData = await orderServices.confirmed(pharmacyId);
      const cancelledData = await orderServices.cancelled(pharmacyId);
      // Get the start and end date of the last month
      const today = new Date();
      const lastMonthStartDate = new Date(
        today.getFullYear(),
        today.getMonth() - 1,
        1
      );
      const lastMonthEndDate = new Date(
        today.getFullYear(),
        today.getMonth(),
        0
      );

      // pending filter

      const filteredDatapending = ongoingData.filter((item) => {
        const itemDate = new Date(item.createdAt);
        return itemDate >= lastMonthStartDate && itemDate <= lastMonthEndDate;
      });

      // pending filter

      // cancelled filter
      const filteredDatacancelled = cancelledData.filter((item) => {
        const itemDate = new Date(item.createdAt);
        return itemDate >= lastMonthStartDate && itemDate <= lastMonthEndDate;
      });
      // cancelled filter

      // confirmed
      const filteredDataConfirmed = confirmedData.filter((item) => {
        const itemDate = new Date(item.createdAt);
        return itemDate >= lastMonthStartDate && itemDate <= lastMonthEndDate;
      });
      // confirmed

      ongoing = filteredDatapending.length;
      cancelled = filteredDatacancelled.length;
      confirmed = filteredDataConfirmed.length;
      total = ongoing + cancelled + confirmed;

      // confirmed this month
    }
    // filter data by last month

    // filter dat by this year

    if (req.body.choice == "year") {
      // pending
      const ongoingData: Array<Order> = await orderServices.pending(pharmacyId);
      const confirmedData = await orderServices.confirmed(pharmacyId);
      const cancelledData = await orderServices.cancelled(pharmacyId);

      const pendingthisYearData = ongoingData.filter((item) => {
        const itemDate = new Date(item.createdAt);
        const now = new Date();
        return itemDate.getFullYear() === now.getFullYear();
      });

      // canceeled
      const cancelledthisYearData = cancelledData.filter((item) => {
        const itemDate = new Date(item.createdAt);
        const now = new Date();
        return itemDate.getFullYear() === now.getFullYear();
      });

      // confirmed

      const confirmedthisYearData = confirmedData.filter((item) => {
        const itemDate = new Date(item.createdAt);
        const now = new Date();
        return itemDate.getFullYear() === now.getFullYear();
      });

      ongoing = pendingthisYearData.length;
      cancelled = cancelledthisYearData.length;
      confirmed = confirmedthisYearData.length;
      total = ongoing + confirmed + cancelled;

      // confirmed this month
    }

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        ongoing,
        confirmed,
        cancelled,
        total,
        massage: `order count is fetched`,
        status: httpStatus.OK,
      });
      // all order count
    } else {
      //Web Code Start
      if (req.method == "GET" || req.method == "POST") {
        const fileContent = getViewFile("dashboard", "index.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            ongoing,
            cancelled,
            confirmed,
            total,
            activeTab: "pharmacyDashboard",
            filename: fileContent.templatePath,
          })
        );
      }
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}
// for count all document

// ranjit

/**
 * @description This function is foronGoingOrder
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function onGoingOrder(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const limit = 10;
    const page = req.query.page || 1;
    const pharmacyId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const { startDate, endDate, search } = req.query;

    const orders: Array<Order> = await orderServices.getOngoingOrders(
      pharmacyId,
      startDate as string,
      endDate as string,
      search as string,
      limit,
      page
    );
    const count = await orderModel
      .find({ pharmacy: pharmacyId, orderStatus: "inProcess" })
      .count();

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        status: httpStatus.OK,
        data: orders,
        current: page,
        pages: Math.ceil(count / limit),
        message: "Orders fetched successfully",
      });
    } else {
      //Web Code Start

      if (req.method == "GET") {
        const fileContent = getViewFile("dashboard", "on-going-order.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            orders,
            activeTab: "manageOrders",
            current: page,

            pages: Math.ceil(count / limit),
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is foronGoingOrder
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function completeOrder(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const limit = 10;
    const page = req.query.page || 1;
    const pharmacyId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const { startDate, endDate, search } = req.query;
    const orders: Array<Order> = await orderServices.getCompletedOrders(
      pharmacyId,
      startDate as string,
      endDate as string,
      search as string,
      limit,
      page
    );
    const count = await orderModel
      .find({ pharmacy: pharmacyId, orderStatus: "completed" })
      .count();
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        status: httpStatus.OK,
        data: orders,
        current: page,
        pages: Math.ceil(count / limit),
        message: "Orders fetched successfully",
      });
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("dashboard", "complete-order.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "manageOrders",
            orders,
            current: page,
            pages: Math.ceil(count / limit),
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is rejected-order
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function rejectedOrder(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const pharmacyId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const { startDate, endDate, search } = req.query;
    const limit = 10;
    const page = req.query.page || 1;
    const orders: Array<Order> = await orderServices.getRejectedOrders(
      pharmacyId,
      startDate as string,
      endDate as string,
      search as string,
      limit,
      page
    );

    const count = await orderModel
      .find({ pharmacy: pharmacyId, orderStatus: "reject" })
      .count();

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        status: httpStatus.OK,
        data: orders,
        current: page,
        pages: Math.ceil(count / limit),
        message: "Orders fetched successfully",
      });
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("dashboard", "rejected-order.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            orders,
            activeTab: "manageOrders",
            current: page,
            pages: Math.ceil(count / limit),
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is pendingOrder
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function readyForDispatch(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const pharmacyId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const { startDate, endDate, search } = req.query;
    const limit = 10;
    const page = req.query.page || 1;
    const orders: Array<Order> = await orderServices.getReadyOrders(
      pharmacyId,
      startDate as string,
      endDate as string,
      search as string,
      limit,
      page
    );

    const count = orders.length;
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        status: httpStatus.OK,
        data: orders,
        current: page,
        pages: Math.ceil(count / limit),
        message: "Orders fetched successfully",
      });
    } else {
      //Web Code Start

      if (req.method == "GET") {
        const fileContent = getViewFile("dashboard", "manage-order.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            orders,
            activeTab: "manageOrders",
            current: page,
            pages: Math.ceil(count / limit),
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function works for filter of Pending Order
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function managePendingOrderFilter(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { search, page, startDate, endDate } = req.body;
    const searchvalue = search ?? "";
    const consultantId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const orders: Array<Order> = await orderServices.getFilteredPendingOrders(
      searchvalue as string,
      parseInt(page as string),
      new Date(startDate as Date),
      new Date(endDate as Date),
      consultantId
    );
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: orders,
        message: "patients fetched successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      const fileContent = getViewFile("dashboard", "manage-order.ejs");
      const user: any = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          user,
          orders,
          activeTab: "manageOrders",
          filename: fileContent.templatePath,
        })
      );
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ data: error });
  }
}

/**
 * @description This function works for filter of Pending Order
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function manageOngoingOrderFilter(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { search, page, startDate, endDate } = req.body;
    const searchvalue = search ?? "";
    const consultantId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const orders: Array<Order> = await orderServices.getFilteredOngoingOrders(
      searchvalue as string,
      parseInt(page as string),
      new Date(startDate as Date),
      new Date(endDate as Date),
      consultantId
    );
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: orders,
        message: "patients fetched successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      const fileContent = getViewFile("dashboard", "manage-order.ejs");
      const user: any = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          user,
          orders,
          activeTab: "manageOrders",
          filename: fileContent.templatePath,
        })
      );
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ data: error });
  }
}

/**
 * @description This function works for filter of Pending Order
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function manageRejectedOrderFilter(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { search, page, startDate, endDate } = req.body;
    const searchvalue = search ?? "";
    const consultantId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const orders: Array<Order> = await orderServices.getFilteredRejectedOrders(
      searchvalue as string,
      parseInt(page as string),
      new Date(startDate as Date),
      new Date(endDate as Date),
      consultantId
    );
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: orders,
        message: "patients fetched successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      const fileContent = getViewFile("dashboard", "manage-order.ejs");
      const user: any = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          user,
          orders,
          activeTab: "manageOrders",
          filename: fileContent.templatePath,
        })
      );
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ data: error });
  }
}

/**
 * @description This function works for filter of Pending Order
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function manageCompletedOrderFilter(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { search, page, startDate, endDate } = req.body;
    const searchvalue = search ?? "";
    const consultantId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const orders: Array<Order> = await orderServices.getFilteredCompletedOrders(
      searchvalue as string,
      parseInt(page as string),
      new Date(startDate as Date),
      new Date(endDate as Date),
      consultantId
    );
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: orders,
        message: "patients fetched successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      const fileContent = getViewFile("dashboard", "manage-order.ejs");
      const user: any = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          user,
          orders,
          activeTab: "manageOrders",
          filename: fileContent.templatePath,
        })
      );
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ data: error });
  }
}
