import { Router } from "express";
import * as dashboardController from "../dashboard/dashboard.controller";

const dashboardRoutes: Router = Router({ mergeParams: true });

dashboardRoutes
  .route("/")
  .get(dashboardController.dashboard)
  .post(dashboardController.dashboard);

dashboardRoutes.get("/viewallorders", dashboardController.viewAllOrders);
dashboardRoutes.post("/viewallorders", dashboardController.viewAllOrders);

dashboardRoutes.get("/documentcenter", dashboardController.documentCenter);

dashboardRoutes
  .route("/readyfordispatch")
  .get(dashboardController.readyForDispatch)
  .post(dashboardController.managePendingOrderFilter);

// inprocess order filter and listing
dashboardRoutes
  .route("/ongoing-order")
  .get(dashboardController.onGoingOrder)
  .post(dashboardController.manageOngoingOrderFilter);

// rejected order filter and listing
dashboardRoutes
  .route("/rejected-order")
  .get(dashboardController.rejectedOrder)
  .post(dashboardController.manageRejectedOrderFilter);

// rejected order filter and listing
dashboardRoutes
  .route("/complete-order")
  .get(dashboardController.completeOrder)
  .post(dashboardController.manageCompletedOrderFilter);

  

export default dashboardRoutes;
