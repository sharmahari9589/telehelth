import { Types } from "mongoose";
import consultantModel from "../../models/consultant.model";
import patientModel from "../../models/patient.model";
import pharmacyModel from "../../modules/pharmacy/pharmacy.model";
import orderModel, { Order } from "./order.model";

export async function getOrdersByPatientId(
  patientId: Types.ObjectId
): Promise<Array<Order | null>> {
  return await orderModel.find({ patient: patientId });
}

export async function getOrderByPharmacyId(
  pharmacyId: Types.ObjectId
): Promise<Array<Order | null>> {
  return await orderModel.find({ pharmacy: pharmacyId });
}

export async function getOrderByConsultantId(
  consultantId: Types.ObjectId
): Promise<Array<Order | null>> {
  return await orderModel.find({ consultant: consultantId });
}

export async function createOrder(createOrderDto: any): Promise<Order> {
  return await orderModel.create(createOrderDto);
}

export async function getOrders(
  pharmacyId: Types.ObjectId,
  startDate: Date,
  endDate: Date,
  limit: number,
  page: number
): Promise<Array<Order>> {
  return await orderModel
    .find({
      pharmacy: pharmacyId,
      createdAt: {
        $and: [
          {
            $gte: startDate,
          },
          {
            $lte: endDate,
          },
        ],
      },
    })
    .populate({ path: "pharmacy", model: pharmacyModel })
    .populate({ path: "consultant", model: consultantModel })
    .populate({ path: "patient", model: patientModel })
    .populate({ path: "pharmacy", model: pharmacyModel })
    .populate({ path: "consultant", model: consultantModel })
    .populate({ path: "patient", model: patientModel })
    .limit(limit)
    .skip(limit * (page - 1));
}

export async function updateOrderById(
  orderId: Types.ObjectId,
  orderData: any,
  orderStatus: any
) {
  return await orderModel.findByIdAndUpdate(orderId, {
    ...orderData,
    orderStatus,
  });
}

export async function updatedeclineOrderstatusById(
  orderId: Types.ObjectId,
  orderStatus: any,
  rejectReason: any
) {
  return await orderModel.findByIdAndUpdate(orderId, {
    orderStatus,
    rejectReason,
  });
}

export async function updateOrderstatusById(
  orderId: Types.ObjectId,
  orderStatus: any
) {
  return await orderModel.findByIdAndUpdate(orderId, { orderStatus });
}

export async function invoiceFill(orderId: Types.ObjectId) {
  return await orderModel.findByIdAndUpdate(orderId);
}

export async function rescheduleOrderById(
  orderId: Types.ObjectId,
  orderStatus: any
) {
  return await orderModel.findByIdAndUpdate(orderId, { ...orderStatus });
}

export async function getPendingOrders(
  pharmacyId: Types.ObjectId,
  limit: any,
  page: any
) {
  return await orderModel
    .aggregate([
      {
        $match: {
          pharmacy: pharmacyId,
          orderStatus: "pending",
        },
      },
      {
        $lookup: {
          from: "bookings",
          localField: "booking",
          foreignField: "_id",
          as: "booking",
        },
      },
      {
        $unwind: {
          path: "$booking",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "healthproblems",
          localField: "problem",
          foreignField: "_id",
          as: "problem",
        },
      },
      {
        $unwind: {
          path: "$problem",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "patients",
          localField: "patient",
          foreignField: "_id",
          as: "patient",
        },
      },
      {
        $unwind: {
          path: "$patient",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "doctors",
          localField: "consultant",
          foreignField: "_id",
          as: "consultant",
        },
      },
      {
        $unwind: {
          path: "$consultant",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $unwind: {
          path: "$prescription",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $sort: {
          "booking.date": 1,
        },
      },
    ])
    .skip(limit * page - limit);
}

export async function findPatient(pharmacyId: Types.ObjectId) {
  return await orderModel.aggregate([
    {
      $match: {
        pharmacy: pharmacyId,
      },
    },
    {
      $lookup: {
        from: "bookings",
        localField: "booking",
        foreignField: "_id",
        as: "booking",
      },
    },
    {
      $unwind: {
        path: "$booking",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $lookup: {
        from: "healthproblems",
        localField: "problem",
        foreignField: "_id",
        as: "problem",
      },
    },
    {
      $unwind: {
        path: "$problem",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $lookup: {
        from: "patients",
        localField: "patient",
        foreignField: "_id",
        as: "patient",
      },
    },
    {
      $unwind: {
        path: "$patient",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $lookup: {
        from: "doctors",
        localField: "consultant",
        foreignField: "_id",
        as: "consultant",
      },
    },
    {
      $unwind: {
        path: "$consultant",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $unwind: {
        path: "$prescription",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $sort: {
        "booking.date": 1,
      },
    },
  ]);
}

export async function getOngoingOrders(
  pharmacyId: Types.ObjectId,
  limit: number,
  page: number
) {
  return await orderModel
    .find({
      pharmacy: pharmacyId,
      orderStatus: "inProcess",
    })
    .populate({ path: "pharmacy", model: pharmacyModel })
    .populate({ path: "consultant", model: consultantModel })
    .populate({ path: "patient", model: patientModel })
    .limit(limit)
    .skip((page - 1) * limit);
}

export async function countNumber(pharmacy: Types.ObjectId) {
  return await orderModel.find({ pharmacy }).count();
}

export async function create_invoice(OrderId: Types.ObjectId, invoice: any) {
  return await orderModel.findByIdAndUpdate(OrderId, { invoice });
}

export async function FillData(
  pharmacyId: Types.ObjectId,
  limit: number,
  page: number
) {
  return await orderModel.aggregate([
    {
      $match: {
        pharmacy: pharmacyId,
        orderStatus: "inProcess",
      },
    },
    {
      $lookup: {
        from: "bookings",
        localField: "booking",
        foreignField: "_id",
        as: "booking",
      },
    },
    {
      $unwind: {
        path: "$booking",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $lookup: {
        from: "healthproblems",
        localField: "problem",
        foreignField: "_id",
        as: "problem",
      },
    },
    {
      $unwind: {
        path: "$problem",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $lookup: {
        from: "patients",
        localField: "patient",
        foreignField: "_id",
        as: "patient",
      },
    },
    {
      $unwind: {
        path: "$patient",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $lookup: {
        from: "doctors",
        localField: "consultant",
        foreignField: "_id",
        as: "consultant",
      },
    },
    {
      $lookup: {
        from: "pharmacies",
        localField: "pharmacy",
        foreignField: "_id",
        as: "pharmacy",
      },
    },
    {
      $unwind: {
        path: "$pharmacy",
        preserveNullAndEmptyArrays: true,
      },
    },

    {
      $unwind: {
        path: "$consultant",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $unwind: {
        path: "$prescription",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $sort: {
        "booking.date": 1,
      },
    },
  ]);
  // .limit(limit)
  //   .skip((page - 1) * limit);
}

const invoiceCounters = new Map();

export function generateInvoiceNumber(pharmacy: any) {
  const currentDate = new Date().toISOString().split("T")[0]; // Get the current date in "YYYY-MM-DD" format

  // Get or initialize the counter for the current date
  let counter = invoiceCounters.get(currentDate) || 0;
  counter++;

  // Update the counter for the current date
  invoiceCounters.set(currentDate, counter);

  const invoiceNumber = `${currentDate}_${counter}`;
  return invoiceNumber;
}
