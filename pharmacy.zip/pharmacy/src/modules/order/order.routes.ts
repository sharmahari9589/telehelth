import { Router } from "express";
import * as orderController from "./order.controller";

const router = Router();

router.get("/", orderController.getOrders);
router.post("/", orderController.createOrder);
router.post("/update/:id", orderController.updateOrder);
router.get("/pendingOrders", orderController.getPendingOrders);

router.get("/inprocessOrders", orderController.getinprocessOrders);

router.post("/reschedule/:id", orderController.rescheduleOrder);
router.post("/reschedule-ready/:id", orderController.rescheduleReadyOrder);

router.post("/decline/:id", orderController.declineOrder);

router.post("/decline-order/:id", orderController.declineOrder);

router.post("/dispatch/:id", orderController.readyToDispatchOrder);
router.post("/readyfordispatch/:id", orderController.readyForDispatchOrders);

router
  .route("/invoice/:id")
  .get(orderController.createInvoice)
  .post(orderController.createInvoice);


export default router;
