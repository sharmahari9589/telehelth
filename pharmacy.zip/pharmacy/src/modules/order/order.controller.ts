import { Request, Response } from "express";
import httpStatus from "http-status";
import { Types } from "mongoose";
import orderModel, { Order, orderStatus } from "./order.model";
import * as orderService from "./order.service";
import * as orderservices from "../dashboard/dashboard.services";
import * as notification from "../notification/notification.controller";
//EJS Rendor
import ejs from "ejs";
import Paths from "../../utils/path";
import { getViewFile } from "../../utils/ejsHelper";
import { connect } from "http2";
import { log } from "console";

export async function createOrder(req: Request, res: Response) {
  try {
    const order = await orderService.createOrder(req.body);
    res.status(httpStatus.OK).send({
      status: httpStatus.OK,
      message: "Order created Successfully",
      data: order,
    });
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      status: httpStatus.INTERNAL_SERVER_ERROR,
      message: err.message,
    });
  }
}

export async function getOrders(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { startDate, endDate, limit, page } = req.query;
    const pharmacyId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const orders: Array<Order> = await orderService.getOrders(
      pharmacyId,
      new Date(startDate as string),
      new Date(endDate as string),
      parseInt(limit as string),
      parseInt(page as string)
    );

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: orders,
        message: "Orders fetched successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start

      const fileContent = getViewFile("dashboard", "manage-order.ejs");
      const user: any = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          message: "",
          user,
          orders,
          activeTab: "manageOrders",
          filename: fileContent.templatePath,
        })
      );

      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      status: httpStatus.INTERNAL_SERVER_ERROR,
      message: err.message,
    });
  }
}

export async function updateOrder(req: Request, res: Response) {
  try {
    const pharmacyId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const { mode } = req.params;
    const orderStatus = "inProcess";
    const orderId: Types.ObjectId = new Types.ObjectId(req.params.id);

    const patientId = await orderService.findPatient(orderId);
    const order: Order | null = await orderService.updateOrderById(
      orderId,
      req.body,
      orderStatus
    );
    if (order) {
      //Create Notification
      const createNotificationDto: any = {
        notificationTitle: "order accepted Sucessfully",
        notificationDescription: "Notification Description",
        notificationBy: pharmacyId,
        notificationTo: order.patient,
        notificationType: "order_notification",
        notificationTypeId: pharmacyId,
      };

      const d: any = await notification.createNotification(
        createNotificationDto
      );
    }
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: order,
        status: httpStatus.OK,
        message: "Order updated sucessfully",
      });
    } else {
      //Web Code Start
      res.redirect("/pharmacy/web/ongoing-order");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      status: httpStatus.INTERNAL_SERVER_ERROR,
      message: err.message,
    });
  }
}

export async function getPendingOrders(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const limit = 10;
    const page = req.query.page || 1;
    const pharmacyId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const orders: Array<Order> = await orderService.getPendingOrders(
      pharmacyId,
      limit,
      page
    );

    const count = await orderModel.find({ pharmacy: pharmacyId }).count();

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        status: httpStatus.OK,
        data: orders,
        current: page,
        pages: Math.ceil(count / limit),
        message: "Orders fetched successfully",
      });
    } else {
      //Web Code Start

      const fileContent = getViewFile("dashboard", "new-booking.ejs");
      const user: any = JSON.parse(res.get("user")!);

      res.send(
        ejs.render(fileContent.file, {
          message: "",
          user,
          orders,
          activeTab: "pendingOrders",
          current: page,
          pages: Math.ceil(count / limit),
          filename: fileContent.templatePath,
        })
      );
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      status: httpStatus.INTERNAL_SERVER_ERROR,
      message: err.message,
    });
  }
}

// reshedule order

export async function rescheduleOrder(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const pharmacyId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const orderId: Types.ObjectId = new Types.ObjectId(req.params.id);
    const order: Order | null = await orderService.rescheduleOrderById(
      orderId,
      req.body
    );

    if (order) {
      //Create Notification
      const createNotificationDto: any = {
        notificationTitle: "order Rescheduled",
        notificationDescription: "Notification Description",
        notificationBy: pharmacyId,
        notificationTo: order.patient,
        notificationType: "order_notification",
        notificationTypeId: pharmacyId,
      };

      const d: any = await notification.createNotification(
        createNotificationDto
      );
    }

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: order,
        status: httpStatus.OK,
        message: "Order updated sucessfully",
      });
    } else {
      //Web Code Start
      res.redirect("/pharmacy/web/ongoing-order");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      status: httpStatus.INTERNAL_SERVER_ERROR,
      message: err.message,
    });
  }
}

export async function rescheduleReadyOrder(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const pharmacyId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const orderId: Types.ObjectId = new Types.ObjectId(req.params.id);
    const order: Order | null = await orderService.rescheduleOrderById(
      orderId,
      req.body
    );

    if (order) {
      //Create Notification
      const createNotificationDto: any = {
        notificationTitle: "order Rescheduled",
        notificationDescription: "Notification Description",
        notificationBy: pharmacyId,
        notificationTo: order.patient,
        notificationType: "order_notification",
        notificationTypeId: pharmacyId,
      };

      const d: any = await notification.createNotification(
        createNotificationDto
      );
    }

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: order,
        status: httpStatus.OK,
        message: "Order updated sucessfully",
      });
    } else {
      //Web Code Start
      res.redirect("/pharmacy/web/readyfordispatch");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      status: httpStatus.INTERNAL_SERVER_ERROR,
      message: err.message,
    });
  }
}

// decline order

export async function declineOrder(req: Request, res: Response) {
  try {
    const pharmacyId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const { mode } = req.params;
    const orderStatus = "reject";
    const rejectReason = req.body.rejectReason;
    const orderId: Types.ObjectId = new Types.ObjectId(req.params.id);
    const order: Order | null = await orderService.updatedeclineOrderstatusById(
      orderId,
      orderStatus,
      rejectReason
    );

    if (order) {
      //Create Notification
      const createNotificationDto: any = {
        notificationTitle: "order Decline By pharmacy",
        notificationDescription: "Notification Description",
        notificationBy: pharmacyId,
        notificationTo: order.patient,
        notificationType: "order_notification",
        notificationTypeId: pharmacyId,
      };

      const d: any = await notification.createNotification(
        createNotificationDto
      );
    }

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: order,
        status: httpStatus.OK,
        message: "Order updated sucessfully",
      });
    } else {
      //Web Code Start
      res.redirect("/pharmacy/web/rejected-order");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      status: httpStatus.INTERNAL_SERVER_ERROR,
      message: err.message,
    });
  }
}

export async function readyForDispatchOrders(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { limit, page } = req.query;

    const orderStatus = "readyForDispatch";
    const orderId: Types.ObjectId = new Types.ObjectId(req.params.id);
    const pharmacyId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const fillInvoice: Order | null = await orderService.invoiceFill(orderId);

    const data: any = fillInvoice?.invoice;
    let order: any;

    //Web Code Start
    if (data[0]) {
      order = await orderService.updateOrderstatusById(orderId, orderStatus);

      if (order) {
        //Create Notification
        const createNotificationDto: any = {
          notificationTitle: "order Readyfordispatch",
          notificationDescription: "Notification Description",
          notificationBy: pharmacyId,
          notificationTo: order.patient,
          notificationType: "order_notification",
          notificationTypeId: pharmacyId,
        };

        const d: any = await notification.createNotification(
          createNotificationDto
        );
      }
      res.redirect("/pharmacy/web/readyfordispatch");
    } else {
      const limit = 10;
      const page = req.query.page || 1;
      const pharmacyId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
      const { startDate, endDate, search } = req.query;

      const orders: Array<Order> = await orderservices.getOngoingOrders(
        pharmacyId,
        startDate as string,
        endDate as string,
        search as string,
        limit,
        page
      );
      const count = await orderModel
        .find({ pharmacy: pharmacyId, orderStatus: "inProcess" })
        .count();

      // const orders: Array<Order> = await orderService.FillData(
      //   pharmacyId,
      //   parseInt(limit as string),
      //   parseInt(page as string)
      // )

      // res.redirect("/pharmacy/web/ongoing-order")
      const fileContent = getViewFile("dashboard", "on-going-order.ejs");
      const user: any = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          message: "please Create Invoice First",
          user,
          orders,
          current: page,
          pages: Math.ceil(count / limit),

          filename: fileContent.templatePath,
        })
      );
    }
    //Web Code End
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      status: httpStatus.INTERNAL_SERVER_ERROR,
      message: err.message,
    });
  }
}

// ready to dispatch

export async function readyToDispatchOrder(req: Request, res: Response) {
  try {
    const pharmacyId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const { mode } = req.params;
    const orderStatus = "completed";
    const orderId: Types.ObjectId = new Types.ObjectId(req.params.id);
    const order: Order | null = await orderService.updateOrderstatusById(
      orderId,
      orderStatus
    );

    if (order) {
      //Create Notification
      const createNotificationDto: any = {
        notificationTitle: "order Completed",
        notificationDescription: "Notification Description",
        notificationBy: pharmacyId,
        notificationTo: order.patient,
        notificationType: "order_notification",
        notificationTypeId: pharmacyId,
      };

      const d: any = await notification.createNotification(
        createNotificationDto
      );
    }

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        // data: order,
        status: httpStatus.OK,
        message: "Order updated sucessfully",
      });
    } else {
      //Web Code Start
      res.redirect("/pharmacy/web/complete-order");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      status: httpStatus.INTERNAL_SERVER_ERROR,
      message: err.message,
    });
  }
}

// get inprocess order

export async function getinprocessOrders(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const pharmacyId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const { limit, page } = req.query;
    const orders: Array<Order> = await orderService.getOngoingOrders(
      pharmacyId,
      parseInt(limit as string),
      parseInt(page as string)
    );
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        status: httpStatus.OK,
        data: orders,
        message: "Orders fetched successfully",
      });
    } else {
      //Web Code Start

      const fileContent = getViewFile("dashboard", "manage-order.ejs");
      const user: any = JSON.parse(res.get("user")!);

      res.send(
        ejs.render(fileContent.file, {
          message: "",
          user,
          orders,
          activeTab: "manageOrders",
          filename: fileContent.templatePath,
        })
      );
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      status: httpStatus.INTERNAL_SERVER_ERROR,
      message: err.message,
    });
  }
}

// create invoice

export async function createInvoice(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    let count;
    const pharmacy: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const pharmacyName = res.get("user");
    if (pharmacyName == undefined) {
    } else {
      let c = JSON.parse(pharmacyName);

      const { limit, page } = req.query;

      count = orderService.generateInvoiceNumber(c.storeName.toUpperCase());

      // Map to store counters for each date
    }

    let invoiceDate = new Date(Date.now());

    const invoiceData = req.body;

    const orderId: Types.ObjectId = new Types.ObjectId(req.params.id);

    const invoiceDto: any = {
      medicineName: invoiceData.medicineName,
      quantity: invoiceData.quantity || invoiceData.Quantity,
      price: invoiceData.price || invoiceData.Price,
      amount: invoiceData.amount || invoiceData.Amount,
    };

    let items;
    if (Array.isArray(invoiceDto.medicineName)) {
      items = [];

      for (let i = 0; i < invoiceData.medicineName.length; i++) {
        const convertedObject: any = {};

        for (const key in invoiceDto) {
          convertedObject[key] = invoiceDto[key][i];
        }

        items.push(convertedObject);
      }
    } else {
      items = invoiceDto;
    }

    const data = {
      items,
      invoiceNo: count,
      invoiceDate,
      totalPrice: req.body.totalPrice,
    };

    const order = await orderService.create_invoice(orderId, data);

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: order,
        status: httpStatus.OK,
        message: "Order updated sucessfully",
      });
    } else {
      //Web Code Start
      res.redirect("/pharmacy/web/ongoing-order");

      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      status: httpStatus.INTERNAL_SERVER_ERROR,
      message: err.message,
    });
  }
}
