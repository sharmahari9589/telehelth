enum Mode {
  API = "api",
  WEB = "web",
}

export default Mode;
