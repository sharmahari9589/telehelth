import nodemailer from "nodemailer";

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "khatriankur14@gmail.com",
    pass: "zyjoerivrayocaav",
  },
});

export default transporter;
