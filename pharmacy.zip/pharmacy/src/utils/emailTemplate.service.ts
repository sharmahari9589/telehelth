// import emailSchema from "../models/email.model"
// /**
//  * @description This function is use for add email
//  * @param {Object} user 
//  * @returns {Promise<User>}
//  * @author Aakrti Satle
//  */

// export const addEmail = async (data: any): Promise<emailSchema> => {
//     const newUser = await emailSchema.create(data)
//     return newUser;
// }

// export const findEmailEvent = async (data: any): Promise<emailSchema | null> => {
//     const existUser = await emailSchema.findOne({
//         where: {
//             email_event: data.email_event
//         }
//     });
//     return existUser;
// }
// /**s
//  * @description This function is use for update email
//  * @param {Object} user 
//  * @returns {Promise<User>}
//  * @author Aakrti Satle
//  */

// export const updateEmailTempById = async (id: any, updatebody: any) => {

//     await emailSchema.update(updatebody, { where: { id: id } });
//     const user = await viewEmailTempById(id)
//     return user;

// }

// /**
//  * @description This function is use for view all email
//  * @param {Object} user 
//  * @returns {Promise<User>}
//  * @author Aakrti Satle
//  */

// export const viewEmailTempById = async (id: any) =>{
//     const viewEmail = await emailSchema.findAll({
//         where: {
//             id: id
//         }
//     });
//     return viewEmail;
// }

// export const viewAllEmail = async () => {

//     const viewEmail = await emailSchema.findAll({
//         raw: true
//     });
//     return viewEmail;

// }

// /**
//  * @description This function is use for delete email
//  * @param {Object} user
//  * @returns {Promise<User>}
//  * @author Aakrti Satle
//  */
// export const deleteEmailTempById = async (id: number)=> {

//     const deleteEmail = await emailSchema.destroy({
//         where: {
//             id: id
//         }
//     });
//     return deleteEmail

// }

