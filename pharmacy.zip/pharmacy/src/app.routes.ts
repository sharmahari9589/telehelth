import { Router } from "express";
import dashboardRoutes from "./modules/dashboard/dashboard.route";
import verify from "./middleware/jwtAuth";
import appRoutes from "./modules/pharmacy/pharmacy.routes";
import documentCenterRoutes from "./modules/documentCenter/documentCenter.routes";
import bookingsRoutes from "./modules/order/order.routes";
import allRoutes from "./modules/dashboard/dashboard.route";
import router from "./modules/order/order.routes";
import orderRoutes from "./modules/order/order.routes";
import notificationRoutes from "./modules/notification/notification.routes";

const appRouter = Router();

appRouter.use(verify);

appRouter.use("/:mode", dashboardRoutes);
appRouter.use("/:mode", appRoutes);
appRouter.use("/:mode", documentCenterRoutes);
appRouter.use("/:mode/bookings", bookingsRoutes);
appRouter.use("/:mode",router)
appRouter.use("/:mode",notificationRoutes)

// appRouter.use("/:mode/bookings", bookingsRoutes);

export default appRouter;
