import { Request, Response, NextFunction } from "express";
import httpStatus from "http-status";
import jsonwebtoken from "jsonwebtoken";
import Mode from "../utils/mode";
import ejs from "ejs";
import { getViewFile } from "../../src/utils/ejsHelper";

export default async function verify(
  req: Request,
  res: Response,
  next: NextFunction
) {
  if (req.params.mode === Mode.API) {
    const authorization = req.headers.authorization;
    if (!authorization) {
      res.status(httpStatus.UNAUTHORIZED).send({
        message: "Unauthorised",
      });
    } else {
      const bearer = authorization.split(" ");
      if (bearer[0] !== "Bearer") {
        res.status(httpStatus.UNAUTHORIZED).send({
          message: "Unauthorised",
        });
      } else {
        const token = bearer[1];
        const user: any = jsonwebtoken.verify(token, process.env.JWT_Token!);
        res.set("userId", user._id);
        res.set("user", JSON.stringify(user));
        next();
      }
    }
  } else {
    //For Web
    const authorization = req.headers.authorization;
    if (!authorization) {
      res.status(httpStatus.UNAUTHORIZED).send({
        message: "Unauthorised",
      });
    } else {
      const bearer = authorization.split(" ");

      if (bearer[1]=='undefined') {

        const fileContent = getViewFile("dashboard", "error-404.ejs");
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            
            filename: fileContent.templatePath,
          })
        );
        
        
        return        
                
              }
   
      if (bearer[0] !== "Bearer") {
        res.status(httpStatus.UNAUTHORIZED).send({
          message: "Unauthorised",
        });
      } else {
        const token = bearer[1];
        const user: any = jsonwebtoken.verify(token, process.env.JWT_Token!);
        if (user.dashboardType === 'pharmacy') {


          res.set("userId", user._id);
          res.set("user", JSON.stringify(user));
          next();
          
      
        } else {
          // Invalid dashboard type
          const fileContent = getViewFile("dashboard", "error-404.ejs");
          res.send(
            ejs.render(fileContent.file, {
              message: "",
              
              filename: fileContent.templatePath,
            })
          );
        }
          return;
        }


      }
    }
  }
