import { NextFunction, Request, Response } from "express";
import HttpException from "./exceptions/httpException";

const Exceptionhandler = (
  err: HttpException,
  req: Request,
  res: Response,
  next: NextFunction
) => {
  let { name, message, statusCode } = err;
  console.log(err);
  if (req.params.mode == "web") {
    // res.render();
  } else {
    res.status(statusCode ?? 500).send({
      status: statusCode,
      message,
    });
  }
};

export default Exceptionhandler;
