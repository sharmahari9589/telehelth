export default class Paths {
    static patinetDashboard = "/patient/index";
    static consultantDashboard = "consultant/index";
    static adminDashboard = "/admin/dashboard";
    static pharmacyDashboard = "/pharmacy/dashboard";
    static login = "sign-in";
    static signup = "sign-up";
    static forgetpassword = "forget-password";
    static resetpassword = "reset-password";
  }
  