import { Router } from "express";
import pharmacyRoutes from "./modules/pharmacy/pharmacy.routes";
import patientRoutes from "./modules/patient/patient.routes";
import consultantRoutes from "./modules/consultant/consultant.routes";
import specialityRoutes from "./modules/speciality/speciality.routes";
import adminRoutes from "./modules/adminDashboard/admin.routes";
import documentCenterRoutes from "./modules/documentCenter/documentCenter.routes";
import verify from "./middlewares/jwtAuth";
import questionnaireRoutes from "./modules/questionnaire/questionnaire.routes";
import masterDataRoutes from "./modules/masterData/masterData.routes";
import bookingRoutes from "./modules/booking/booking.routes";
import roleAndPermission from "./modules/roleAndPermission/roleAndPermission.routes";
import orderRouter from "./modules/order/order.routes";
import staffRoutes from "./modules/staff/staff.routes";
import medicineroutes from "./modules/adminDashboard/medicine/medicine-routes";
import serviceroutes from "./modules/services/services.routes";
import emailtempletRoutes from "./modules/emailTemplete/template.routes";
import referRoutes from "./modules/referManagment/refer.routes";
import icdRoutes from "./modules/icdCodes/icd-routes";
import eircodeRoutes from "./modules/eirCodes/eircode-routes"
import notificationRoutes from "./modules/notification/notification.routes";
import scheduleRoute from "./modules/schedule/schedule.routes";

const appRouter = Router();

appRouter.use(verify);

appRouter.use("/:mode", adminRoutes);

appRouter.use("/:mode/pharmacy", pharmacyRoutes);
appRouter.use("/:mode/consultant", consultantRoutes);
appRouter.use("/:mode/patient", patientRoutes);
appRouter.use("/:mode/speciality", specialityRoutes);
appRouter.use("/:mode/health-problem", questionnaireRoutes);
appRouter.use("/:mode", documentCenterRoutes);
appRouter.use("/:mode", notificationRoutes);
appRouter.use("/:mode", scheduleRoute);

appRouter.use("/:mode/master-data", masterDataRoutes);
appRouter.use("/:mode", roleAndPermission);
appRouter.use("/:mode", orderRouter);
appRouter.use("/:mode/booking", bookingRoutes);
appRouter.use("/:mode", staffRoutes);
appRouter.use("/:mode/medicine", medicineroutes);
appRouter.use("/:mode", icdRoutes);
appRouter.use("/:mode", eircodeRoutes);

appRouter.use("/:mode", serviceroutes);
appRouter.use("/:mode", emailtempletRoutes);
appRouter.use("/:mode", referRoutes);

export default appRouter;
