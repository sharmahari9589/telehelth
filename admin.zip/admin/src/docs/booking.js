const schedule = {
  consultant1: {
    monday: [
      {
        startTime: "0700",
        endTime: "1200",
      },
      {
        startTime: "1500",
        endTime: "1800",
      },
    ],
    tuesday: [],
    wednesday: [],
    thursday: [],
    friday: [],
    saturday: [],
    sunday: [],
  },
};

const bookingSettings = {
  consultantId: "1",
  slotDurations: 45,
};

const bookings = {
  consultantId: 1,
  slot: {
    startTime: "1000",
    endTime: "1045",
  },
  date: "12/sep/2022",
  patientId: 2,
};

/**
 * 1. To show bookings on the calendar
 * 2. customize calendar on the basis of schedule
 * 3. show booked slots available slots
 * 4. start booking for a particular slot
 */
