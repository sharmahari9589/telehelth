import { Request, Response } from "express";
import httpStatus from "http-status";
import { Types } from "mongoose";
import ejs from "ejs";
import { getViewFile } from "../../utils/ejsHelper";

import mongoose from "mongoose";
import serviceModel, { Service } from "./service.model";

import * as serviceService from "./services.service";

import { log } from "console";
import { types } from "util";
import consultantModel from "../consultant/consultant.model";
import * as notification from "../notification/notification.controller";



export async function getServices(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    let { doctorId, adminId, limit, page }: any = req.query;
    limit = limit ? limit : 10;
    page = page ? page : 1;

    const allData = await serviceModel.find();

    if (mode == "api") {
      if (doctorId) {
        let serviceData = await serviceModel.find({ doctors: doctorId });
        if (serviceData.length == 0) {
          return res.status(httpStatus.NOT_FOUND).send({
            status: httpStatus.NOT_FOUND,
            message: "No services found",
            data: null,
          });
        } else {
          return res.status(httpStatus.OK).send({
            status: httpStatus.OK,
            message: "Services found",
            data: serviceData,
          });
        }
      } else if (adminId) {
        const services = await serviceService.getServices(
          adminId,
          parseInt(limit as string),
          parseInt(page as string)
        );
        return res.status(httpStatus.OK).send({
          status: httpStatus.OK,
          message: "Services found",
          data: services,
        });
      } else {
        return res.status(httpStatus.BAD_REQUEST).send({
          status: httpStatus.BAD_REQUEST,
          message: "doctorId or adminId is required",
          data: null,
        });
      }
    } else {
      const doctors = await consultantModel.find();

      const fileContent = getViewFile(
        "adminDashboard",
        "add-services-category.ejs"
      );
      const user: any = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          message: "",
          user,
          activeTab: "service",
          doctors,
          allData,

          filename: fileContent.templatePath,
        })
      );
    }
  } catch (error) {
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      status: httpStatus.INTERNAL_SERVER_ERROR,
      message: "Something went wrong",
      data: error,
    });
  }
}

export async function addservicescategory(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const doctors = await consultantModel.find();

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "adminDashboard",
          "add-services.ejs.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "service",
            doctors,
            body: req.body,
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function addservices(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const doctors = await consultantModel.find();

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "adminDashboard",
          "add-services.ejs.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);

        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "service",
            doctors,
            body: req.body,
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function createService(req: Request, res: Response) {
  try {
    const userId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const { mode } = req.params;

    const {
      name,
      description,
      cost,
      serviceTime,
      bufferTime,
      video,
      shareDoc,
    } = req.body;

    if (shareDoc !== undefined) {
      var shareDocIds;

      if (Array.isArray(shareDoc)) {
        shareDocIds = shareDoc.map((a: any) => {
          return new Types.ObjectId(a);
        });
      } else {
        shareDocIds = new Types.ObjectId(shareDoc);
      }

      var price = parseInt(cost);

      var value1;
      if (video !== undefined) {
        value1 = true;
      } else {
        value1 = false;
      }

      const service = {
        name,
        description,
        cost: price,
        serviceTime,
        bufferTime,
        videoMeeting: value1,
        doctors: shareDocIds,
      };

      const Services = await serviceService.createService(service);

      if (Services) {
        const doctors = await consultantModel.find();
        //Create Notification
        const createNotificationDto: any = {
          notificationTitle: "New Services Added Sucessfully",
          notificationDescription: "Notification Description",
          notificationBy: userId,
          notificationTo: shareDocIds,
          notificationType: "services_notification",
          notificationTypeId: userId,
        };

        const d: any = await notification.createNotification(
          createNotificationDto
        );
      }

      if (mode == "api") {
        return res.status(httpStatus.OK).send({
          status: httpStatus.OK,
          message: "Service created successfully",
          data: "",
          body: req.body,
        });
      } else {
        //Web Code Start
        res.redirect("/admin/web/viewservices");
      }
    } else {
      const doctors = await consultantModel.find();

      const fileContent = getViewFile("adminDashboard", "add-services.ejs.ejs");
      const user: any = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          message: "Add Doctors for which you want to Add Services",
          user,
          activeTab: "service",
          doctors,
          body: req.body,
          filename: fileContent.templatePath,
        })
      );
    }
  } catch (error) {
    return res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      status: httpStatus.INTERNAL_SERVER_ERROR,
      message: "Something went wrong",
      data: error,
    });
  }
}

export async function EditServices(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    let { doctorId, adminId, limit, page, id }: any = req.query;
    const dataId: Types.ObjectId = new Types.ObjectId(req.params.id);
    limit = limit ? limit : 10;
    page = page ? page : 1;

    const doctors = await consultantModel.find();

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const allData = await serviceService.getServiceById(dataId);

        const fileContent = getViewFile("adminDashboard", "edit.service.ejs");
        const user: any = JSON.parse(res.get("user")!);

        res.send(
          ejs.render(fileContent.file, {
            message: "",
            activeTab: "service",
            user,
            body: req.body,
            doctors,
            allData,
            filename: fileContent.templatePath,
          })
        );
      } else {
        const {
          name,
          description,
          cost,
          serviceTime,
          bufferTime,
          video,
          shareDoc,
        } = req.body;

        if (shareDoc !== undefined) {
          var shareDocIds;

          if (Array.isArray(shareDoc)) {
            shareDocIds = shareDoc.map((a: any) => {
              return new Types.ObjectId(a);
            });
          } else {
            shareDocIds = new Types.ObjectId(shareDoc);
          }

          var price = parseInt(cost);

          var value1;
          if (video !== undefined) {
            value1 = true;
          } else {
            value1 = false;
          }

          const bodyDto = {
            name,
            description,
            cost: price,
            serviceTime,
            bufferTime,
            videoMeeting: value1,
            doctors: shareDocIds,
          };

          const allData = await serviceService.getEditService(dataId, bodyDto);

          res.redirect("/admin/web/viewservices");
          //Post Method Code
        }
        //Web Code End
      }
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function deleteServices(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const dataId: Types.ObjectId = new Types.ObjectId(req.params.id);

    const serviceDelete = await serviceService.deleteService(dataId);

    if (mode == "api") {
    } else {
      //Post Method Code
    }
    //Web Code End
    res.redirect("/admin/web/viewservices");
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function updateService(req: Request, res: Response) {
  const serviceId = req.params.id;
  let updateObj: any = {};
  if (req.body.name) updateObj.name = req.body.name;
  if (req.body.description) updateObj.description = req.body.description;
  if (req.body.cost) updateObj.cost = req.body.cost;
  if (req.body.serviceTime) updateObj.serviceTime = req.body.serviceTime;
  if (req.body.bufferTime) updateObj.bufferTime = req.body.bufferTime;
  if (req.body.videoMeeting) updateObj.videoMeeting = req.body.videoMeeting;
  if (req.body.doctors) updateObj.doctors = req.body.doctors;
  const service = await serviceService.updateServiceById(
    new mongoose.Types.ObjectId(serviceId),
    updateObj
  );
  res.status(httpStatus.OK).send({
    status: httpStatus.OK,
    message: "Settings updated Successfully",
    data: service,
  });
}
