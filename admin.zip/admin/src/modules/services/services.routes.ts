import { Router } from "express";
import * as serviceController from "./services.controller";

const router: Router = Router({
  mergeParams: true,
});

router.get("/addservices", serviceController.addservices);
router.get("/addservicescategory", serviceController.addservicescategory);
router.post("/addservicescategory", serviceController.addservicescategory);

router.post("/create-service", serviceController.createService);
router.get("/viewservices", serviceController.getServices);

router.get("/update-service/:id", serviceController.EditServices);
router.post("/update-service/:id", serviceController.EditServices);

router.get("/delete-service/:id", serviceController.deleteServices);
router.post("/delete-service/:id", serviceController.deleteServices);

export default router;
