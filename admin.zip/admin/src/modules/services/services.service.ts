import { Types } from "mongoose";
import serviceModel, { Service } from "./service.model";

export async function getServices(
  adminId: Types.ObjectId,
  limit: number,
  page: number
): Promise<Array<Service>> {
  return await serviceModel
    .find({})
    .limit(limit)
    .skip((page - 1) * limit);
}

export async function createService(createServiceDto: any): Promise<Service> {
  return await serviceModel.create(createServiceDto);
}

export async function deleteService(
  dataId: Types.ObjectId
): Promise<Service | null> {
  return await serviceModel.findByIdAndDelete(dataId);
}

export async function getAllService(
  limit: number,
  page: number
): Promise<Array<Service>> {
  return await serviceModel
    .find({})
    .limit(limit)
    .skip((page - 1) * limit);
}

export async function getEditService(
  dataId: Types.ObjectId,
  bodyDto: any
): Promise<Service | null> {
  return await serviceModel.findByIdAndUpdate(dataId, bodyDto);
}

export async function getServiceById(
  serviceId: Types.ObjectId
): Promise<Service | null> {
  return await serviceModel.findOne(serviceId);
}

export async function updateServiceById(
  serviceId: Types.ObjectId,
  updateServiceDto: any
): Promise<Service | null> {
  return await serviceModel.findByIdAndUpdate(serviceId, updateServiceDto);
}
