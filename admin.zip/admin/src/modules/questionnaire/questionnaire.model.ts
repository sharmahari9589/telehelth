import mongoose, { model, Schema } from "mongoose";

export interface Question extends Document {
  addedBy: mongoose.Types.ObjectId;
  title: string;
  answerType: Boolean;
  subQuestions: Array<{
    question: string;
    answerType: string;
  }>;
}

const questionSchema: Schema = new Schema<Question>({
  addedBy: {
    type: mongoose.Schema.Types.ObjectId,
  },
  title: {
    type: String,
  },
  answerType: {
    type: Boolean,
  },
  subQuestions: [
    {
      question: { type: String },
      answerType: { type: String },
    },
  ],
});

export default model<Question>("question", questionSchema);
