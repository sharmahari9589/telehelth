import { Router } from "express";
import * as questionnaireController from "./questionnaire.controller";

const router: Router = Router({
  mergeParams: true,
});

router
  .route("/createquestion")
  .get(questionnaireController.createQuestionnaire)
  .post(questionnaireController.createQuestionnaire);

router.get("/get-question", questionnaireController.getQuestionnaires);

router
  .route("/create-static-question")
  .get(questionnaireController.createStaticQuestions)
  .post(questionnaireController.createStaticQuestions);

router.get("/get-static-question", questionnaireController.getStaticQuestions);

router
  .route("/update-static/:id")
  .get(questionnaireController.updateStaticQuestions)
  .post(questionnaireController.updateStaticQuestions);

router
  .route("/update/:id")
  .get(questionnaireController.updateQuestinaire)
  .post(questionnaireController.updateQuestinaire);

router
  .route("/delete/:id")
  .get(questionnaireController.deleteQuestionnaire)
  .post(questionnaireController.deleteQuestionnaire);



router
  .route("/get-health-problem")
  .get(questionnaireController.getHealthProblems)
  .post(questionnaireController.createHealthProblem);

router.post(
  "/update-health-problem/:id",
  questionnaireController.updateHealthProblem
);

router.post(
  "/delete-health-problem/:id",
  questionnaireController.deleteHealthProblem
);

export default router;
