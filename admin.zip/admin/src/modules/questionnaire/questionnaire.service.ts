import { Types } from "mongoose";
import healthProblemModel, { HealthProblem } from "./healthProblem.model";
import questionModel, { Question } from "./question.model";
import staticQuestionModel, { StaticQuestion } from "./static.question.model";

export async function getProblems(
  name: String,
  limit: number,
  page: number
): Promise<Array<HealthProblem>> {
  if (name) {
    return await healthProblemModel
      .find({
        name: {
          $regex: name,
          $options: "i",
        },
      })
      .limit(limit)
      .skip((page - 1) * limit);
  } else {
    return await healthProblemModel
      .find()
      .limit(limit)
      .skip((page - 1) * limit);
  }
}

export async function createProblem(body: any): Promise<HealthProblem> {
  const healthProblem = await healthProblemModel.create(body);
  return healthProblem;
}

export async function updateHealthProblem(
  problemId: Types.ObjectId,
  body: any
): Promise<HealthProblem | null> {
  const healthProblem = await healthProblemModel.findByIdAndUpdate(
    problemId,
    body,
    { new: true }
  );
  return healthProblem;
}

export async function deleteHealthProblem(
  problemId: Types.ObjectId
): Promise<HealthProblem | null> {
  const healthProblem = await healthProblemModel.findByIdAndDelete(problemId);
  return healthProblem;
}

export async function getQuestionnaire(
  search: string = "",
  match: object,
  limit: number,
  page: number
): Promise<Array<Question>> {
  return await questionModel
    .find({
      title: {
        $regex: search,
        $options: "i",
      },
      ...match,
    })
    .limit(limit)
    .skip((page - 1) * limit);
}

export async function createQuestion(
  createQuestionDto: any
): Promise<Question> {
  return await questionModel.create(createQuestionDto);
}

export async function updateQuestionById(
  questionId: Types.ObjectId,
  updateQuestionDto: any
): Promise<Question | null> {
  return await questionModel.findByIdAndUpdate(questionId, updateQuestionDto);
}

export async function deleteQuestionById(
  questionId: Types.ObjectId
): Promise<Question | null> {
  return await questionModel.findByIdAndDelete(questionId);
}

export async function getQuestion(
  search: string = "",
  match: object,
  limit: number,
  page: number
): Promise<Array<StaticQuestion>> {
  return await staticQuestionModel
    .find({
      title: {
        $regex: search,
        $options: "i",
      },
      ...match,
    })
    .sort({ questionNo: 1 })
    .limit(limit)
    .skip((page - 1) * limit);
}

export async function createStaticQuestion(
  createQuestionDto: any
): Promise<StaticQuestion> {
  return await staticQuestionModel.create(createQuestionDto);
}

export async function updateStaticQuestionById(
  questionId: Types.ObjectId,
  updateQuestionDto: any
): Promise<StaticQuestion | null> {
  return await staticQuestionModel.findByIdAndUpdate(
    questionId,
    updateQuestionDto
  );
}
