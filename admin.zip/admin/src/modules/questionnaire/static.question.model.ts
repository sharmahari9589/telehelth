import mongoose, { model, Schema } from "mongoose";

export interface StaticQuestion extends Document {
  addedBy: mongoose.Types.ObjectId;
  title: string;
  questionNo: Number;
}

const questionSchema: Schema = new Schema<StaticQuestion>({
  addedBy: {
    type: mongoose.Schema.Types.ObjectId,
  },
  questionNo: {
    type: Number,
  },
  title: {
    type: String,
  },
});

export default model<StaticQuestion>("staticQuestion", questionSchema);
