import mongoose, { model, Schema } from "mongoose";

export interface Question extends Document {
  addedBy: mongoose.Types.ObjectId;
  title: string;
  description: string;
  answerType: string;
  // options: Array<string>;
  problem: string;
}

const questionSchema: Schema = new Schema<Question>({
  addedBy: {
    type: mongoose.Schema.Types.ObjectId,
  },
  title: {
    type: String,
  },
  description: {
    type: String,
  },
  answerType: {
    type: String,
  },
  // options: [{ type: String }],

  problem: {
    type: String,
  },
});

export default model<Question>("question", questionSchema);
