import { Request, Response } from "express";
import httpStatus from "http-status";
import { Types } from "mongoose";
import healthProblemModel, { HealthProblem } from "./healthProblem.model";
import * as questionnaireServies from "./questionnaire.service";
import specialityModel from "../speciality/speciality.model";

//EJS Rendor
import ejs from "ejs";
import Paths from "../../utils/path";
import { getViewFile } from "../../utils/ejsHelper";
import { mode } from "crypto-js";
import Mode from "../../utils/mode";
import { log } from "console";
import questionModel from "./question.model";

export async function createHealthProblem(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    // const { name, description, speciality } = req.body;
    const healthProblem: HealthProblem =
      await questionnaireServies.createProblem(req.body);
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: healthProblem,
        message: "Health problem created successfully",
        status: httpStatus.OK,
      });
    } else {
      res.redirect(
        "/admin/web/health-problem/get-health-problem?search=&page=1&limit=100"
      );
      //Web Code Start
      // const fileContent =  getViewFile("adminDashboard", "health-problem.ejs");
      // const user:any = JSON.parse(res.get('user')!);
      // res.send(
      //   ejs.render(fileContent.file, {
      //     message: "",
      //     user,
      //     filename: fileContent.templatePath
      // }));
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "",
    });
  }
}

export async function getHealthProblems(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { name, limit, page } = req.query;
    const speciality = await specialityModel.find();
    const healthProblems = await questionnaireServies.getProblems(
      name as string,
      parseInt(limit as string),
      parseInt(page as string)
    );
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: healthProblems,
        message: "Health Problems fetched successfully",
        status: httpStatus.INTERNAL_SERVER_ERROR,
      });
    } else {
      //Web Code Start
      const fileContent = getViewFile("adminDashboard", "health-problem.ejs");
      const user: any = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          message: "",
          healthProblems,
          user,
          activeTab: "problem",
          speciality,
          filename: fileContent.templatePath,
        })
      );
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "internal server error",
    });
  }
}

export async function updateHealthProblem(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const problemId: Types.ObjectId = new Types.ObjectId(req.params.id);
    const healthProblem: HealthProblem | null =
      await questionnaireServies.updateHealthProblem(problemId, req.body);
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        status: httpStatus.OK,
        data: healthProblem,
        message: "Health problem updated successfully",
      });
    } else {
      //Web Code Start
      res.redirect("/admin/web/health-problem/get-health-problem");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "internal server error",
    });
  }
}

export async function deleteHealthProblem(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const problemId: Types.ObjectId = new Types.ObjectId(req.params.id);
    const healthProblem: HealthProblem | null =
      await questionnaireServies.deleteHealthProblem(problemId);
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        status: httpStatus.OK,
        data: healthProblem,
        message: "Health problem deleted successfully",
      });
    } else {
      //Web Code Start
      res.redirect("/admin/web/health-problem/get-health-problem");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Internal server error",
    });
  }
}

export async function createQuestionnaire(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const user: any = JSON.parse(res.get("user")!);

    // const addedBy: Types.ObjectId = new Types.ObjectId(res.get("userId"));
    const adminId = new Types.ObjectId(user._id);

    let userid;
    if (user.addedBy == undefined) {
      userid = adminId;
    } else {
      userid = new Types.ObjectId(user.addedBy);
    }

    const health = await healthProblemModel.find();

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "adminDashboard",
          "add-questionaire.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            health,
            activeTab: "addQues",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code

        const { title, description, answer, options, problem } = req.body;
        const questionnaire = await questionnaireServies.createQuestion({
          userid,
          title,
          description,
          answer,
          options,
          problem,
        });

        const fileContent = getViewFile(
          "adminDashboard",
          "add-questionaire.ejs"
        );
        res.send(
          ejs.render(fileContent.file, {
            message: "Questionnaire created successfully",
            user,
            questionnaire,
            health,activeTab: "viewQues",
            filename: fileContent.templatePath,
          })
        );
        return;
      }
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function getQuestionnaires(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const { search, limit, page, addedBy } = req.query;

    const health = await healthProblemModel.find();

    const questions = await questionnaireServies.getQuestionnaire(
      search as string,
      addedBy ? { addedBy } : {},
      parseInt(limit as string),
      parseInt(page as string)
    );

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: questions,
        message: "Questionnaire fetched successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "adminDashboard",
          "view-all-questionaire-list.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            activeTab: "viewQues",
            user,
            questions,
            health,
            filename: fileContent.templatePath,
          })
        );
      }
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Questionnaire fetched successfully",
      status: httpStatus.INTERNAL_SERVER_ERROR,
    });
  }
}

export async function updateQuestinaire(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const questionnaireId: Types.ObjectId = new Types.ObjectId(req.params.id);

    const questionaaire = await questionnaireServies.updateQuestionById(
      questionnaireId,
      req.body
    );
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: questionaaire,
        message: "Questionnaire updated successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      res.redirect("/admin/web/health-problem/get-question");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Internal server error",
      status: httpStatus.INTERNAL_SERVER_ERROR,
    });
  }
}

export async function deleteQuestionnaire(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const questionnaireId: Types.ObjectId = new Types.ObjectId(req.params.id);

    const questionaaire = await questionnaireServies.deleteQuestionById(
      questionnaireId
    );

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: questionaaire,
        message: "Questionnaire deleted successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      res.redirect("/admin/web/health-problem/get-question");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Internal server error",
      status: httpStatus.INTERNAL_SERVER_ERROR,
    });
  }
}

export async function createStaticQuestions(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const addedBy: Types.ObjectId = new Types.ObjectId(res.get("userId"));

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "adminDashboard",
          "add-static-question.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "viewDyQues",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code

        const { title, questionNo } = req.body;

        const questionnaire = await questionnaireServies.createStaticQuestion({
          addedBy,
          title,
          questionNo,
        });

        const user: any = JSON.parse(res.get("user")!);

        const fileContent = getViewFile(
          "adminDashboard",
          "add-static-question.ejs"
        );
        res.send(
          ejs.render(fileContent.file, {
            message: "Questionnaire created successfully",
            user,
            questionnaire,
            activeTab: "viewDyQues",
            filename: fileContent.templatePath,
          })
        );
        return;
      }
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function getStaticQuestions(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { search, limit, page, addedBy } = req.query;

    const health = await healthProblemModel.find();

    const questions = await questionnaireServies.getQuestion(
      search as string,
      addedBy ? { addedBy } : {},
      parseInt(limit as string),
      parseInt(page as string)
    );

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: questions,
        message: "Questionnaire fetched successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "adminDashboard",
          "view.static.question.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            activeTab: "viewDyQues",
            user,
            questions,
            health,
            filename: fileContent.templatePath,
          })
        );
      }
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Questionnaire fetched successfully",
      status: httpStatus.INTERNAL_SERVER_ERROR,
    });
  }
}

export async function updateStaticQuestions(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const questionnaireId: Types.ObjectId = new Types.ObjectId(req.params.id);

    const questionaaire = await questionnaireServies.updateStaticQuestionById(
      questionnaireId,
      req.body
    );
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: questionaaire,
        message: "Questionnaire updated successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      res.redirect("/admin/web/health-problem/get-static-question");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Internal server error",
      status: httpStatus.INTERNAL_SERVER_ERROR,
    });
  }
}
