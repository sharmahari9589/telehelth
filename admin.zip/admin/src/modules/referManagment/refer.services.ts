import { Types } from "mongoose";
import referModel, { Refer } from "./refer.model";

export async function createHospital(createReferDto: any): Promise<Refer> {
  return await referModel.create(createReferDto);
}

export async function updateHospital(
  hospitalId: Types.ObjectId,
  updateBody: any
): Promise<Refer | null> {
  return await referModel.findByIdAndUpdate(hospitalId, updateBody);
}

export async function deleteHospital(
  hospitalId: Types.ObjectId
): Promise<Refer | null> {
  return await referModel.findByIdAndDelete(hospitalId);
}
