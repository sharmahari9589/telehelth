import { Router } from "express";
import * as referController from "./refer.controller";

const appRoutes = Router({
  mergeParams: true,
});

appRoutes.get("/referredmanagement", referController.referredmanagement);

appRoutes
  .route("/add")
  .get(referController.addHospital)
  .post(referController.addHospital);

appRoutes
  .route("/edit/:id")
  .get(referController.editHospital)
  .post(referController.editHospital);

appRoutes
  .route("/hospital-delete/:id")
  .get(referController.deleteHospital)
  .post(referController.deleteHospital);

export default appRoutes;
