import { Request, Response } from "express";
import httpStatus from "http-status";
import { Types } from "mongoose";
//EJS Rendor
import ejs from "ejs";
import { getViewFile } from "../../utils/ejsHelper";
import * as referService from "./refer.services";
import referModel from "./refer.model";

export async function referredmanagement(req: Request, res: Response) {
  try {
    const limit = 10;
    const page: any = req.query.page || 1;
    const { mode } = req.params;
    const { search } = req.query;
    let hospital;
    if (search) {
      hospital = await referModel.find({
        hospital: { $regex: search, $options: "i" },
      });
    } else
      [
        (hospital = await referModel
          .find()
          .limit(limit)
          .skip((page - 1) * limit)),
      ];

    const count = await referModel.find().count();
    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "adminDashboard",
          "referredmanagement.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            activeTab: "refer",
            user,
            hospital,
            current: page,
            pages: Math.ceil(count / limit),
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for addhospitals
 * @param req
 * @param res
 * @author sourav argade
 */

export async function addHospital(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const medicine = await referService.createHospital(req.body);

    if (mode == "api") {
    } else {
      //Web Code Start
      res.redirect("/admin/web/referredmanagement");
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function editHospital(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const hospitalId: Types.ObjectId = new Types.ObjectId(req.params.id);

    const medicine = await referService.updateHospital(hospitalId, req.body);

    if (mode == "api") {
    } else {
      //Web Code Start
      res.redirect("/admin/web/referredmanagement");
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function deleteHospital(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const hospitalId: Types.ObjectId = new Types.ObjectId(req.params.id);

    const questionaaire = await referService.deleteHospital(hospitalId);

    if (mode == "api") {
    } else {
      //Web Code Start
      res.redirect("/admin/web/referredmanagement");
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}
