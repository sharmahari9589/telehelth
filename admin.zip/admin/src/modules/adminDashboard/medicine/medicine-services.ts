import { Types } from "mongoose";
import medicineModel, { Medicine } from "./medicine-model";

export async function createMedicine(
  createMedicineDto: any
): Promise<Medicine> {
  return await medicineModel.create(createMedicineDto);
}

export async function updateMedicine(
  medicineId: Types.ObjectId,
  updateBody: any
): Promise<Medicine | null> {
  return await medicineModel.findByIdAndUpdate(medicineId, updateBody);
}

export async function deleteMedicine(
  medicineId: Types.ObjectId
): Promise<Medicine | null> {
  return await medicineModel.findByIdAndDelete(medicineId);
}
