import { Request, Response } from "express";
import httpStatus from "http-status";
import { Types } from "mongoose";
import * as medicineService from "./medicine-services";
import * as notification from "../../notification/notification.controller";

//EJS Rendor
import ejs from "ejs";
import { getViewFile } from "../../../utils/ejsHelper";
import consultantModel from "../../consultant/consultant.model";
import pharmacyModel from "../../pharmacy/pharmacy.Model";

/**
 * @description This function is for Dashboard
 * @param req
 * @param res
 * @author sourav argade
 */

export async function addMedicine(req: Request, res: Response) {
  try {
    console.log("hii");
    
    const { mode } = req.params;
    const userId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const medicine = await medicineService.createMedicine(req.body);

    if (medicine) {
      const doctors = await consultantModel.find();
      const pharmacy = await pharmacyModel.find();
      //Create Notification
      const createNotificationDto = [
        {
          notificationTitle: "New Medicine Added Sucessfully",
          notificationDescription: "Notification Description",
          notificationBy: userId,
          notificationTo: doctors,
          notificationType: "medicine_notification",
          notificationTypeId: userId,
        },
        {
          notificationTitle: "New Medicine Added Sucessfully",
          notificationDescription: "Notification Description",
          notificationBy: userId,
          notificationTo: pharmacy,
          notificationType: "medicine_notification",
          notificationTypeId: userId,
        },
      ];

      const d: any = await notification.createNotification(
        createNotificationDto
      );
    }

    if (mode == "api") {
    } else {
      //Web Code Start
      res.redirect("/admin/web/view-medicine");
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function editMedicine(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const medicineId: Types.ObjectId = new Types.ObjectId(req.params.id);

    const medicine = await medicineService.updateMedicine(medicineId, req.body);

    if (mode == "api") {
    } else {
      //Web Code Start
      res.redirect("/admin/web/view-medicine");
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function deleteMedicine(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const medicineId: Types.ObjectId = new Types.ObjectId(req.params.id);

    const questionaaire = await medicineService.deleteMedicine(medicineId);

    if (mode == "api") {
    } else {
      //Web Code Start
      res.redirect("/admin/web/view-medicine");
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}
