import { Router } from "express";
import * as medicineController from "./medicine-controller";

const appRoutes = Router({
  mergeParams: true,
});

appRoutes 
  .route("/add-medicine")
  .get(medicineController.addMedicine)
  .post(medicineController.addMedicine);

appRoutes
  .route("/edit-medicine/:id")
  .get(medicineController.editMedicine)
  .post(medicineController.editMedicine);

appRoutes
  .route("/delete-medicine/:id")
  .get(medicineController.deleteMedicine)
  .post(medicineController.deleteMedicine);

export default appRoutes;
