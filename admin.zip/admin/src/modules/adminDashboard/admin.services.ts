import { Types } from "mongoose";
import bookingModel from "../booking/booking.model";
import consultantModel from "../consultant/consultant.model";
import patientModel from "../patient/patient.model";
import adminModel from "./admin.model";
import bcrypt from "bcryptjs";
import medicineModel from "./medicine/medicine-model";
import staffModel from "../staff/staff.model";

export async function updateById(adminId: Types.ObjectId, updateBody: any) {
  return adminModel.findByIdAndUpdate(adminId, updateBody);
}

export async function updateStaffById(
  adminId: Types.ObjectId,
  updateBody: any
) {
  return staffModel.findByIdAndUpdate(adminId, updateBody);
}

export async function getAdmin(adminId: Types.ObjectId) {
  return adminModel.findById(adminId);
}

export async function getStaff(adminId: Types.ObjectId) {
  return staffModel.findById(adminId);
}

export async function count() {
  return await adminModel.countDocuments();
}

export async function appointmentstcount(adminId: Types.ObjectId) {
  return await bookingModel.countDocuments();
}

export async function doctorsCount(adminId: Types.ObjectId) {
  return await consultantModel.countDocuments();
}
export async function patienttCount(adminId: Types.ObjectId) {
  return await patientModel.countDocuments();
}

export async function updatePassword(adminId: Types.ObjectId, updateBody: any) {
  return adminModel.findByIdAndUpdate(adminId, { password: updateBody });
}
export async function updateStaffPassword(
  adminId: Types.ObjectId,
  updateBody: any
) {
  return staffModel.findByIdAndUpdate(adminId, { password: updateBody });
}

export function comparePassword(
  password: string,
  hashpassword: string
): boolean {
  return bcrypt.compareSync(password, hashpassword);
}
export function encryptedPassword(password: string) {
  return bcrypt.hashSync(password, 10);
}

export async function getUserByUserID(userId: Types.ObjectId) {
  const user = await adminModel.findById(userId);
  return user;
}

export async function getStaffByUserID(userId: Types.ObjectId) {
  const user = await staffModel.findById(userId);
  return user;
}

export async function getMedicine(search: string, limit: any, page: any) {
  if (search) {
    return await medicineModel.find({
      medicineName: { $regex: search, $options: "i" },
    });
  } else {
    return await medicineModel
      .find().sort({medicineName:1})
      .limit(limit)
      .skip(limit * page - limit);
  }
}

export async function findBookingById(bookingId: Types.ObjectId) {
  return await bookingModel.findById(bookingId);
}

export async function bookingupdateById(
  bookingId: Types.ObjectId,
  rescheduleDto: any,
  status: String,
  previousdata: any
) {
  return await bookingModel.findByIdAndUpdate(bookingId, {
    ...rescheduleDto,
    status,
    $push: { reschedule: previousdata },
  });
}
