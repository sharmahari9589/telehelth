import { Router } from "express";
import * as adminController from "./admin.controller";

const appRoutes = Router({
  mergeParams: true,
});

appRoutes.get("/", adminController.adminDashboard);
appRoutes.get("/myprofile", adminController.myProfile);
appRoutes.get("/addpatient", adminController.addPatient);
appRoutes.get("/viewallpatient", adminController.viewAllPatient);
appRoutes.get("/addconsultant", adminController.addConsultant);
appRoutes.get("/viewallconsultant", adminController.viewAllConsultant);
appRoutes.get("/addpharmacy", adminController.addPharmacy);
appRoutes.get("/viewallpharmacy", adminController.viewAllPharmacy);
appRoutes.get("/addquestionaire", adminController.addQuestionaire);
appRoutes.get("/viewallquestionaire", adminController.viewAllQuestionaire);

appRoutes.get("/add-static-question", adminController.addQuestionaire);
appRoutes.get("/viewall-static-questions", adminController.viewAllQuestionaire);
appRoutes.get("/adduser", adminController.addUser);
appRoutes.get("/viewuser", adminController.viewUser);
appRoutes.get("/viewcountries", adminController.viewCountries);
appRoutes.get("/viewstate", adminController.viewState);
appRoutes.get("/viewcities", adminController.viewCities);
appRoutes.get("/viewlanguage", adminController.viewLanguage);
appRoutes.get("/viewemail", adminController.viewEmail);
appRoutes.get("/documentcenter", adminController.documentCenter);
appRoutes.get("/privacypolicy", adminController.privacyPolicy);
appRoutes.get("/termsofuse", adminController.termsOfUse);

appRoutes.get("/addrole", adminController.addRole);
appRoutes.get("/services", adminController.services);

appRoutes.get("/roleaccess", adminController.roleAccess);
appRoutes
  .route("/profileedit")
  .get(adminController.editProfile)
  .post(adminController.editProfile);

appRoutes
  .route("/change-password")
  .get(adminController.changePassword)
  .post(adminController.changePassword);

appRoutes
  .route("/view-medicine")
  .get(adminController.viewMedicine)
  .post(adminController.viewMedicine);

appRoutes
  .route("/getImage")
  .get(adminController.getImage)
  .post(adminController.getImage);

  appRoutes
.route("/reschedule-date-and-time")
.get(adminController.rescheduleDateAndTime)
.post(adminController.rescheduleDateAndTime);


appRoutes
.route("/reschedule-booking")
.get(adminController.bookingReSchedule)
.post(adminController.bookingReSchedule);

appRoutes.get("/invite", adminController.Invite);
appRoutes.post("/invite", adminController.Invite);

appRoutes
  .route("/getrole-access")
  .get(adminController.getRole)
  .post(adminController.getRole);



export default appRoutes;
