import { Request, Response } from "express";
import httpStatus from "http-status";
import { Types } from "mongoose";
import * as adminService from "./admin.services";
import * as pharmacyService from "../pharmacy/pharmacy.service";
import * as consultantservices from "../consultant/consultant.services";
import * as patientservice from "../patient/patient.services";
import * as roleService from "../roleAndPermission/roleAndPermission.service";
import * as staffService from "../staff/staff.service";
//EJS Rendor
import ejs from "ejs";
import { getViewFile } from "../../utils/ejsHelper";
import healthProblemModel from "../questionnaire/healthProblem.model";
import roleAndPermissionModel, {
  Role,
} from "../roleAndPermission/roleAndPermission.model";
import staffModel, { Staff } from "../staff/staff.model";
import medicineModel from "./medicine/medicine-model";
import adminModel from "./admin.model";
import bookingModel from "../booking/booking.model";
import * as notification from "../notification/notification.controller";
import { sendMail } from "../../utils/sendMail";

/**
 * @description This function is for Dashboard
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function adminDashboard(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const adminId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    let admin;
    admin = await adminService.getAdmin(adminId);
    if (admin) {
      admin = await adminService.getAdmin(adminId);
    } else {
      admin = await adminService.getStaff(adminId);
    }

    const patient = await patientservice.patientcount();
    const pharmacy = await pharmacyService.pharmacycount();
    const consultant = await consultantservices.consultantcount();

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const user: any = JSON.parse(res.get("user")!);
        const fileContent = getViewFile("adminDashboard", "index.ejs");
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            admin,
            activeTab: "adminDashboard",
            consultant,
            pharmacy,
            patient,
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for My Profile
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function myProfile(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const user: any = JSON.parse(res.get("user")!);

    const adminId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    let admin;
    admin = await adminService.getAdmin(adminId);
    if (admin) {
      admin = await adminService.getAdmin(adminId);
    } else {
      admin = await adminService.getStaff(adminId);
    }

    const bookings = await adminService.appointmentstcount(adminId);
    const doctors = await adminService.doctorsCount(adminId);
    const patients = await adminService.patienttCount(adminId);

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("adminDashboard", "my-profile.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            admin,
            activeTab: "adminDashboard",
            bookings,
            doctors,
            patients,
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for Edit Profile
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function editProfile(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const adminId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    if (mode == "api") {
    } else {
      //Web Code Start

      if (req.method == "GET") {
        let admin;
        admin = await adminModel.findById(adminId);
        if (admin) {
          admin = await adminModel.findById(adminId);
        } else {
          admin = await staffModel.findById(adminId);
        }

        const fileContent = getViewFile("adminDashboard", "profile-edit.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "adminDashboard",
            admin,
            filename: fileContent.templatePath,
          })
        );
      } else {
        const user: any = JSON.parse(res.get("user")!);

        if (user.addedBy) {
          const adminProfile = await staffModel.findById(adminId);

          let profile;
          if (req.body.files[0]) {
            profile = "/" + req.body.files[0]?.path;
          } else {
            profile = adminProfile?.profilePic;
          }

          const editDto = {
            firstName: req.body.firstName,
            lastName: req.body.lastName,
            email: req.body.email,
            mobileNumber: req.body.mobileNumber,
            gender: req.body.gender,
            dateOfBirth: req.body.dob,
            location: req.body.location,
            eirCode: req.body.eirCode,
            profilePic: profile,
          };

          const admins = await adminService.updateStaffById(adminId, editDto);

          const admin = await staffModel.findById(adminId);

          const fileContent = getViewFile("adminDashboard", "profile-edit.ejs");
          res.send(
            ejs.render(fileContent.file, {
              message: "profile Updated Successfully",
              user,
              admin,
              activeTab: "adminDashboard",
              filename: fileContent.templatePath,
            })
          );
        } else {
          const adminProfile = await adminModel.findById(adminId);

          let profile;
          if (req.body.files[0]) {
            profile = "/" + req.body.files[0]?.path;
          } else {
            profile = adminProfile?.profilePic;
          }

          const editDto = {
            firstName: req.body.firstName,
            lastName: req.body.lastName,
            email: req.body.email,
            mobileNumber: req.body.mobileNumber,
            gender: req.body.gender,
            dateOfBirth: req.body.dob,
            profilePic: profile,
          };

          const admins = await adminService.updateById(adminId, editDto);

          const admin = await adminModel.findById(adminId);

          const fileContent = getViewFile("adminDashboard", "profile-edit.ejs");
          res.send(
            ejs.render(fileContent.file, {
              message: "profile Updated Successfully",
              user,
              admin,
              activeTab: "adminDashboard",
              filename: fileContent.templatePath,
            })
          );
        }
      }
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function changePassword(req: Request, res: Response) {
  try {
    const { mode, dashboardType } = req.params;

    const { currentPassword, password, confirmPassword } = req.body;

    let user: any = JSON.parse(res.get("user")!);

    const adminId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    if (user.addedBy) {
      const admin = await staffModel.findById(adminId);

      user = await adminService.getStaffByUserID(user._id);
      const isMatch = adminService.comparePassword(
        currentPassword,
        user.password
      );

      if (mode == "api") {
        //API Code Start
        if (isMatch) {
          if (password === confirmPassword) {
            const data = await adminService.updatePassword(user._id, password);
            res.status(httpStatus.OK).send({
              message: "Password reset successfully",
              status: httpStatus.OK,
            });
          } else {
            res.status(httpStatus.BAD_REQUEST).send({
              message: "Password not match",
              status: httpStatus.BAD_REQUESTs,
            });
          }
        } else {
          res.status(httpStatus.BAD_REQUEST).send({
            message: "Current password not match",
            status: httpStatus.BAD_REQUESTs,
          });
        }
        //API Code End
      } else {
        //Web Code Start
        const fileContent = getViewFile("adminDashboard", "profile-edit.ejs");
        if (isMatch) {
          if (password === confirmPassword) {
            const encryptPassword = adminService.encryptedPassword(password);
            const data = await adminService.updateStaffPassword(
              user._id,
              encryptPassword
            );
            res.send(
              ejs.render(fileContent.file, {
                message: "Password reset successfully",
                user,
                data,
                activeTab: "adminDashboard",
                admin,
                filename: fileContent.templatePath,
              })
            );
          } else {
            res.send(
              ejs.render(fileContent.file, {
                message: "Password not match",
                user,
                activeTab: "adminDashboard",
                admin,
                filename: fileContent.templatePath,
              })
            );
          }
        } else {
          res.send(
            ejs.render(fileContent.file, {
              message: "Current password not match",
              user,
              activeTab: "adminDashboard",
              admin: "",
              filename: fileContent.templatePath,
            })
          );
        }
        //Web Code End
      }
    } else {
      const admin = await adminModel.findById(adminId);

      user = await adminService.getUserByUserID(user._id);
      const isMatch = adminService.comparePassword(
        currentPassword,
        user.password
      );

      if (mode == "api") {
        //API Code Start
        if (isMatch) {
          if (password === confirmPassword) {
            const data = await adminService.updatePassword(user._id, password);
            res.status(httpStatus.OK).send({
              message: "Password reset successfully",
              status: httpStatus.OK,
            });
          } else {
            res.status(httpStatus.BAD_REQUEST).send({
              message: "Password not match",
              status: httpStatus.BAD_REQUESTs,
            });
          }
        } else {
          res.status(httpStatus.BAD_REQUEST).send({
            message: "Current password not match",
            status: httpStatus.BAD_REQUESTs,
          });
        }
        //API Code End
      } else {
        //Web Code Start
        const fileContent = getViewFile("adminDashboard", "profile-edit.ejs");
        if (isMatch) {
          if (password === confirmPassword) {
            const encryptPassword = adminService.encryptedPassword(password);
            const data = await adminService.updatePassword(
              user._id,
              encryptPassword
            );
            res.send(
              ejs.render(fileContent.file, {
                message: "Password reset successfully",
                user,
                data,
                activeTab: "adminDashboard",
                admin,
                filename: fileContent.templatePath,
              })
            );
          } else {
            res.send(
              ejs.render(fileContent.file, {
                message: "Password not match",
                user,
                activeTab: "adminDashboard",
                admin,
                filename: fileContent.templatePath,
              })
            );
          }
        } else {
          res.send(
            ejs.render(fileContent.file, {
              message: "Current password not match",
              user,
              activeTab: "adminDashboard",
              admin: "",
              filename: fileContent.templatePath,
            })
          );
        }
        //Web Code End
      }
    }
  } catch (err) {
    console.log(err);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: err,
      message: "Internal server error",
    });
  }
}

/**
 * @description This Function Is For  Add Patient
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function addPatient(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("adminDashboard", "add-patient.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "addPatient",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This Function Is For  View All Patient
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function viewAllPatient(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "adminDashboard",
          "view-patient-list.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "viewPatient",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This Function Is For  Add Consultant
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function addConsultant(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("adminDashboard", "add-consultant.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "addDoctor",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This Function Is For  View All Consultant
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function viewAllConsultant(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "adminDashboard",
          "view-consultant-list.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "viewDoctor",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This Function Is For  Add Pharmacy
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function addPharmacy(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("adminDashboard", "add-pharmacy.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "addpharma",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This Function Is For  View All Pharmacy
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function viewAllPharmacy(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "adminDashboard",
          "view-all-pharmacy.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "viewpharma",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This Function Is For Add Questionaire
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function addQuestionaire(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const problem = await healthProblemModel.find();

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "adminDashboard",
          "add-questionaire.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "addQues",
            problem,
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This Function Is For View All Questionaire
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function viewAllQuestionaire(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "adminDashboard",
          "view-all-questionaire-list.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "viewQues",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This Function Is For Add Questionaire
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function addStaticQuestion(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "adminDashboard",
          "add-static-question.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "viewQues",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This Function Is For View All Questionaire
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function viewAllStaticQuestion(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "adminDashboard",
          "view.static.question.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "viewDyQues",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}
/**
 * @description This Function Is For Add Sub Admin
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function addUser(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const addedBy: Types.ObjectId = new Types.ObjectId(res.get("userId"));
    const roles: Array<Role> = await roleService.getRoles(addedBy);
    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("adminDashboard", "add-user.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            roles,
            activeTab: "addUser",
            oldUser: "",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This Function Is For View All Admin
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function viewUser(req: Request, res: Response) {
  try {
    const query: Types.ObjectId = new Types.ObjectId(res.get("userId"));

    const { mode } = req.params;
    const { id, firstName, role } = req.query;

    const roles: Array<Role> = await roleService.getRoles(query);
    const staffs = await staffService.getStaffs(
      query as Types.ObjectId,
      role as string,
      firstName as string
    );

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("adminDashboard", "view-user.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            staffs,
            roles,
            activeTab: "viewUser",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This Function Is For View Countries
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function viewCountries(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("adminDashboard", "add-country.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "country",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This Function Is For View State
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function viewState(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("adminDashboard", "add-state.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "States",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This Function Is For View Cities
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function viewCities(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("adminDashboard", "add-city.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "cities",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This Function Is For View Language
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function viewLanguage(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("adminDashboard", "add-language.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "cities",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This Function Is For View Email
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function viewEmail(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("adminDashboard", "view-email.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "email",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This Function Is For Document Center
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function documentCenter(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "adminDashboard",
          "document-center.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "document",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This Function Is For Privacy Policy
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function privacyPolicy(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("adminDashboard", "privacy-policy.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "doctorDashboard",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This Function Is For Terms Of Use
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function termsOfUse(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("adminDashboard", "terms-of-use.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "doctorDashboard",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This Function Is For Speciality
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function speciality(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("adminDashboard", "speciality.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "speciality",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This Function Is For roleAccess
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */

export async function roleAccess(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const addedBy: Types.ObjectId = new Types.ObjectId(res.get("userId"));
    const roles: Array<Role> = await roleService.getRoles(addedBy);
    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("adminDashboard", "role-access.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "accessCnt",
            roles,
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This Function Is For Add Role
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function addRole(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const addedBy: Types.ObjectId = new Types.ObjectId(res.get("userId"));
    const roles: Array<Role> = await roleService.getRoles(addedBy);
    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("adminDashboard", "add-role.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            roles,
            activeTab: "addRole",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This Function Is For Add Role
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function services(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("adminDashboard", "services.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "service",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function createtemplete(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "adminDashboard",
          "create-templete.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "creTemp",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function viewtemplete(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("adminDashboard", "view-templete.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "viewTemp",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function viewMedicine(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { search } = req.query;
    const limit = 10;
    const page = Number(req.query.page )|| 1;
    const medicine = await adminService.getMedicine(
      search as string,
      limit,
      page
    );

    const count = await medicineModel.find().count();

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("adminDashboard", "medicine-list.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "medicine",
            medicine,
            current: page,
            pages: Math.ceil(count / limit),
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function referredmanagement(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const medicine = await medicineModel.find();

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "adminDashboard",
          "referredmanagement.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "refer",
            medicine,
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function getImage(req: Request, res: Response) {
  try {
    const userId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const user: any = JSON.parse(res.get("user")!);

    const { page, limit } = req.query;

    let adminId;
    if (user.addedBy == undefined) {
      adminId = userId;
    } else {
      adminId = new Types.ObjectId(user._id);
    }
    let getImage;
    getImage = await adminModel.findById(userId);
    if (getImage) {
      getImage = await adminModel.findById(userId);
    } else {
      getImage = await staffModel.findById(adminId);
    }

    res.status(httpStatus.OK).send({
      data: getImage,
      message: "data fetched successfully",
      status: httpStatus.OK,
    });
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      status: httpStatus.INTERNAL_SERVER_ERROR,
      message: err.message,
    });
  }
}

export async function getRole(req: Request, res: Response) {
  try {
    const userId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const user: any = JSON.parse(res.get("user")!);

    const { page, limit } = req.query;

    let adminId;
    if (user.addedBy == undefined) {
      adminId = userId;
    } else {
      adminId = new Types.ObjectId(user._id);
    }
    let getImage;
    getImage = await adminModel.findById(userId);
    if (getImage) {
      getImage = await adminModel.findById(userId);
    } else {
      getImage = await staffModel
        .findById(adminId)
        .populate({ path: "role", model: roleAndPermissionModel });
    }

    res.status(httpStatus.OK).send({
      data: getImage,
      message: "data fetched successfully",
      status: httpStatus.OK,
    });
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      status: httpStatus.INTERNAL_SERVER_ERROR,
      message: err.message,
    });
  }
}

export async function rescheduleDateAndTime(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const user = JSON.parse(res.get("user")!);
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        message: "Slot Booked Successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      const bookingData = req.body;

      const booking = new Types.ObjectId(bookingData.id);

      const updateBooking = await bookingModel.findById(booking);

      const startTime = updateBooking?.startTime;
      const endTime = updateBooking?.endTime;

      const startTimestamp: any = startTime?.getTime();

      const endTimestamp: any = endTime?.getTime();

      const timeDifference = endTimestamp - startTimestamp;

      const time = Math.floor(timeDifference / (1000 * 60));

      const fileContent = getViewFile(
        "adminDashboard",
        "reschedule-date-time.ejs"
      );
      res.send(
        ejs.render(fileContent.file, {
          user,
          message: "",
          bookingData,
          updateBooking,
          time,
          activeTab: "viewbook",
          filename: fileContent.templatePath,
        })
      );
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function bookingReSchedule(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const { bookingDate, id, slot } = req.body;

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: "",
        message: "booking update successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start

      if (slot) {
        // const bookDate = new Date(bookingDate);

        const slotTime = Number(req.body.slotTime);

        const time = slot[slotTime];

        let startTime = time.slice(1, 6);

        let endTime = time.slice(7, 12);

        const date = new Date(bookingDate);

        const startDate = new Date(bookingDate);

        const endDate = new Date(bookingDate);

        const formattedDate = date.toISOString();

        const formattedDateWithOffset = formattedDate.replace("Z", "+00:00");

        const [hours, minutes] = startTime.split(":");

        startDate.setHours(hours);
        startDate.setMinutes(minutes);

        // Adding delay of 5.30 hours

        const delayHours = 5;
        const delayMinutes = 30;

        startDate.setHours(startDate.getHours() + delayHours);
        startDate.setMinutes(startDate.getMinutes() + delayMinutes);

        const newStartTime = startDate;

        const [endHours, endMinutes] = endTime.split(":");

        endDate.setHours(endHours);
        endDate.setMinutes(endMinutes);

        const delayHoursEnd = 5;
        const delayMinutesEnd = 30;

        endDate.setHours(endDate.getHours() + delayHoursEnd);
        endDate.setMinutes(endDate.getMinutes() + delayMinutesEnd);

        const newEndTime = endDate;

        const bookingId: Types.ObjectId = new Types.ObjectId(id);

        const data = await adminService.findBookingById(bookingId);

        const previousdata = {
          date: data?.date,
          startTime: data?.startTime,
          endTime: data?.endTime,
        };

        const rescheduleDto = {
          date: formattedDateWithOffset,
          startTime: newStartTime,
          endTime: newEndTime,
        };

        const status = "reschedule";
        const booking = await adminService.bookingupdateById(
          bookingId,
          rescheduleDto,
          status,
          previousdata
        );

        if (booking) {
          //Create Notification
          const createNotificationDto = {
            notificationTitle: "Booking Rescheduled by admin",
            notificationDescription: "Notification Description",
            notificationBy: booking?.doctor,
            notificationTo: [booking?.doctor, booking?.patient], //booking?.doctor
            notificationType: "booking_notification",
            notificationTypeId: booking?._id,
          };
          await notification.createNotification(createNotificationDto);
        }

        res.redirect("/admin/web/booking/viewall-bookings");
        //Web Code End
      } else {
        const bookingData = req.body;

        const booking = new Types.ObjectId(bookingData.id);

        const updateBooking = await bookingModel.findById(booking);

        const startTime = updateBooking?.startTime;
        const endTime = updateBooking?.endTime;

        const startTimestamp: any = startTime?.getTime();

        const endTimestamp: any = endTime?.getTime();

        const timeDifference = endTimestamp - startTimestamp;

        const time = Math.floor(timeDifference / (1000 * 60));

        const user = JSON.parse(res.get("user")!);

        const fileContent = getViewFile(
          "consultantDashboard",
          "reschedule-date-time.ejs"
        );
        res.send(
          ejs.render(fileContent.file, {
            user,
            message: "Doctor is Not Available on this Date ",
            bookingData,
            updateBooking,
            time,
            activeTab: "viewbook",
            filename: fileContent.templatePath,
          })
        );
      }
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}



export async function Invite(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const user: any = JSON.parse(res.get("user")!);



 
    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("adminDashboard", "invite.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,activeTab:"invite",
            filename: fileContent.templatePath,
          })
        );
      } else {
        
        
  let to = req.body.to.split(',');

  const recipients = to; // Assuming `to` is an array of email addresses
  const mailBody = `
  <!DOCTYPE html>
  <html>
  <head>
    <style>
      / Inline CSS for styling /
      body {
        font-family: Arial, sans-serif;
        line-height: 1.6;
        margin: 0;
        padding: 0;
      }
      .container {
        max-width: 600px;
        margin: 0 auto;
        padding: 20px;
      }
      h1 {
        font-size: 24px;
      }
      / Add more inline styles as needed /
    </style>
  </head>
  <body>
    <div class="container">
     <pre style="line-height: normal; font-size: 12px; font-family: 'Helvetica'; border: none;">${req.body.mailBody}</pre>
    </div>
  </body>
  </html>
  `;
  const sendAllEmails = async () => {
    const emailPromises = recipients.map(async (recipient:any, index:any) => {
      return new Promise(async (resolve) => {
        setTimeout(async () => {
          const data = await sendMail(recipient, req.body.subject, mailBody);
          resolve(data);
        }, index * 4000);
      });
    });
  
    await Promise.all(emailPromises);
  
    const fileContent = getViewFile("adminDashboard", "invite.ejs");
    const user: any = JSON.parse(res.get("user")!);
    res.send(
      ejs.render(fileContent.file, {
        message: "Invitation mails sent successfully",
        user,
        activeTab: "invite",
        filename: fileContent.templatePath,
      })
    );
  };
  
  sendAllEmails().catch((error) => {
    console.error("An error occurred while sending emails:", error);
    // Handle the error as needed
  });
  

  
        
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}