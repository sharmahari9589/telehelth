import { model, Schema } from "mongoose";

export interface Speciality extends Document {
  name: String;
}

const specialitySchema: Schema = new Schema<Speciality>(
  {
    name: {
      type: String,
    },
  },
  {
    timestamps: true,
  }
);

export default model<Speciality>("speciality", specialitySchema);
