import bcrypt from "bcryptjs";
import httpStatus from "http-status";
import { Request, Response } from "express";
import * as staffService from "./staff.service";
import { Staff } from "./staff.model";
import { Types } from "mongoose";
import ejs from "ejs";

import * as roleService from "../roleAndPermission/roleAndPermission.service";
import { getViewFile } from "../../utils/ejsHelper";

const generateHash = (password: string) => {
  const salt = bcrypt.genSaltSync();
  return bcrypt.hashSync(password, salt);
};
export async function createStaff(req: Request, res: Response) {
  try {
    const addedBy: Types.ObjectId = new Types.ObjectId(res.get("userId"));
    const {
      email,
      firstname,
      lastname,
      date_of_birth,
      mobileNumber,
      roleid,
      gender,
      location,
      eirCode,
    } = req.body;

    const oldUser = await staffService.findOldStaff(email);

    if (oldUser) {
      const roles = await roleService.getRoles(addedBy);

      const fileContent = getViewFile("adminDashboard", "add-user.ejs");

      const user: any = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          message: " User with the email already exists",
          user,
          activeTab: "addUser",
          roles,
          oldUser,
          filename: fileContent.templatePath,
        })
      );
    } else {
      if (req.body.password) {
        const password = generateHash(req.body.password);

        const data: Staff = await staffService.createStaff({
          email,
          password,
          firstname,
          lastname,
          mobileNumber,
          roleid,
          addedBy,
          date_of_birth,
          gender,
          location,
          eirCode,
        });

        const roles = await roleService.getRoles(addedBy);
        const fileContent = getViewFile("adminDashboard", "add-user.ejs");

        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: " User created successfully",
            user,
            activeTab: "addUser",
            roles,
            oldUser: "",
            filename: fileContent.templatePath,
          })
        );
      } else {
        res.redirect("/admin/web/adduser");
      }
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err,
    });
  }
}

export async function getStaffs(req: Request, res: Response) {
  const { addedBy, id, firstName } = req.query;
  try {
    let query: any = {};
    if (addedBy) query.addedBy = addedBy;
    const staffs = await staffService.getStaffs(
      query,
      id as any,
      firstName as string
    );
    res.status(httpStatus.OK).send({
      data: staffs,
      message: "Staff fetched successfully",
      status: httpStatus.OK,
    });
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err,
    });
  }
}

export async function updateStaff(req: Request, res: Response) {
  try {
    const staffId = req.params.id;
    const staff: Staff | null = await staffService.updateStaff(
      staffId,
      req.body
    );
    res.redirect("/admin/web/viewuser");
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err,
    });
  }
}

export async function deleteStaff(req: Request, res: Response) {
  try {
    const staffId = req.params.id;
    const staff: Staff | null = await staffService.deleteStaff(staffId);
    res.redirect("/admin/web/viewuser");
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err,
    });
  }
}
