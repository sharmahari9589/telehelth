import mongoose, { Schema, Document, Types } from "mongoose";

export enum Gender {
  Male = "male",
  Female = "female",
  Other = "other",
  Transgender = "transgender",
  Notdisclosed = "notDisclosed",
}

export enum MaritialStatus {
  Married = "married",
  Single = "single",
  Partnered = "partnered",
  Divorce = "divorce",
  Widow = "widow",
  Others = "others",
  Notdisclosed = "notDisclosed",
}

export interface Staff extends Document {
  firstName: string;
  lastName: string;
  email: string;
  eirCode: string;

  gender: Gender;
  password?: string;
  mobileNumber: string;
  isDeleted: boolean;
  location: any;
  dateOfBirth: Date;
  addedBy: Types.ObjectId;
  role: Types.ObjectId;
  profilePic: string;
}

const staffSchema: Schema = new Schema<Staff>({
  firstName: {
    type: String,
  },
  lastName: {
    type: String,
  },
  dateOfBirth: {
    type: Date,
  },
  gender: {
    type: String,
    enum: Gender,
  },
  email: {
    type: String,
    unique: true,
  },
  profilePic: {
    type: String,
  },
  eirCode: {
    type: String,
  },
  location: {
    type: String,
  },
  password: {
    type: String,
  },
  mobileNumber: {
    type: String,
  },
  isDeleted: {
    type: Boolean,
    default: false,
  },
  addedBy: {
    type: mongoose.Schema.Types.ObjectId,
  },
  role: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "role",
  },
});

export default mongoose.model<Staff>("staff", staffSchema);
