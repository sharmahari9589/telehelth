import { Types } from "mongoose";
import staffAndPermissionModel, { Staff } from "./staff.model";
import staffModel from "./staff.model";

export async function createStaff(createStaffDto: any): Promise<Staff> {
  return await staffAndPermissionModel.create({
    email: createStaffDto.email,
    password: createStaffDto.password,
    firstName: createStaffDto.firstname,
    lastName: createStaffDto.lastname,
    mobileNumber: createStaffDto.mobileNumber,
    role: createStaffDto.roleid,
    addedBy: createStaffDto.addedBy,
    gender: createStaffDto.gender,
    dateOfBirth: createStaffDto.date_of_birth,
    location: createStaffDto.location,
    eirCode: createStaffDto.eirCode,
  });
}

export async function getStaffs(
  query: Types.ObjectId,
  role: string,
  firstName: string
) {
  if (firstName && role == "") {
    const fullNameParts = firstName.split(" ");
    const firstNameRegex = new RegExp(fullNameParts[0], "i");
    const lastNameRegex = new RegExp(fullNameParts.slice(1).join(" "), "i");

    if (fullNameParts.length === 1) {
      return await staffAndPermissionModel.aggregate([
        {
          $match: {
            addedBy: query,
          },
        },
        {
          $lookup: {
            from: "roles",
            localField: "role",
            foreignField: "_id",
            as: "role",
          },
        },
        {
          $unwind: {
            path: "$role",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: {
            $or: [
              {
                firstName: {
                  $regex: `^${firstNameRegex.source}`,
                  $options: firstNameRegex.flags,
                },
              },
              {
                lastName: { $regex: firstNameRegex },
              },
            ],
          },
        },
      ]);
    } else {
      return await staffAndPermissionModel.aggregate([
        {
          $match: {
            addedBy: query,
          },
        },
        {
          $lookup: {
            from: "roles",
            localField: "role",
            foreignField: "_id",
            as: "role",
          },
        },
        {
          $unwind: {
            path: "$role",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: {
            $or: [{ firstName: firstNameRegex }, { lastName: lastNameRegex }],
          },
        },
      ]);
    }
  }

  if (role == "all" && firstName == "") {
    return await staffAndPermissionModel.aggregate([
      {
        $match: {
          addedBy: query,
        },
      },
      {
        $match: {
          isDeleted: false,
        },
      },
      {
        $lookup: {
          from: "roles",
          localField: "role",
          foreignField: "_id",
          as: "role",
        },
      },
      {
        $unwind: {
          path: "$role",
          preserveNullAndEmptyArrays: true,
        },
      },
    ]);
  }

  if (firstName && role == "all") {
    const fullNameParts = firstName.split(" ");
    const firstNameRegex = new RegExp(fullNameParts[0], "i");
    const lastNameRegex = new RegExp(fullNameParts.slice(1).join(" "), "i");

    if (fullNameParts.length === 1) {
      return await staffAndPermissionModel.aggregate([
        {
          $match: {
            addedBy: query,
          },
        },
        {
          $lookup: {
            from: "roles",
            localField: "role",
            foreignField: "_id",
            as: "role",
          },
        },
        {
          $unwind: {
            path: "$role",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: {
            $or: [
              {
                firstName: {
                  $regex: `^${firstNameRegex.source}`,
                  $options: firstNameRegex.flags,
                },
              },
              {
                lastName: { $regex: firstNameRegex },
              },
            ],
          },
        },
      ]);
    } else {
      return await staffAndPermissionModel.aggregate([
        {
          $match: {
            addedBy: query,
          },
        },
        {
          $lookup: {
            from: "roles",
            localField: "role",
            foreignField: "_id",
            as: "role",
          },
        },
        {
          $unwind: {
            path: "$role",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: {
            $or: [{ firstName: firstNameRegex }, { lastName: lastNameRegex }],
          },
        },
      ]);
    }
  }

  if (role && firstName == "") {
    return await staffAndPermissionModel.aggregate([
      {
        $match: {
          addedBy: query,
        },
      },
      {
        $lookup: {
          from: "roles",
          localField: "role",
          foreignField: "_id",
          as: "role",
        },
      },
      {
        $unwind: {
          path: "$role",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $match: {
          "role.name": role,
        },
      },
    ]);
  }

  if (role && firstName) {
    const fullNameParts = firstName.split(" ");
    const firstNameRegex = new RegExp(fullNameParts[0], "i");
    const lastNameRegex = new RegExp(fullNameParts.slice(1).join(" "), "i");

    if (fullNameParts.length === 1) {
      return await staffAndPermissionModel.aggregate([
        {
          $match: {
            addedBy: query,
          },
        },
        {
          $lookup: {
            from: "roles",
            localField: "role",
            foreignField: "_id",
            as: "role",
          },
        },
        {
          $unwind: {
            path: "$role",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: {
            $and: [
              {
                "role.name": role,
              },
              {
                $or: [
                  {
                    firstName: {
                      $regex: `^${firstNameRegex.source}`,
                      $options: firstNameRegex.flags,
                    },
                  },
                  {
                    lastName: { $regex: firstNameRegex },
                  },
                ],
              },
            ],
          },
        },
      ]);
    } else {
      return await staffAndPermissionModel.aggregate([
        {
          $match: {
            addedBy: query,
          },
        },
        {
          $lookup: {
            from: "roles",
            localField: "role",
            foreignField: "_id",
            as: "role",
          },
        },
        {
          $unwind: {
            path: "$role",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: {
            $and: [
              {
                "role.name": role,
              },
              {
                $or: [
                  { firstName: firstNameRegex },
                  { lastName: lastNameRegex },
                ],
              },
            ],
          },
        },
      ]);
    }
  } else {
    return await staffAndPermissionModel.aggregate([
      {
        $match: {
          addedBy: query,
        },
      },
      {
        $match: {
          isDeleted: false,
        },
      },
      {
        $lookup: {
          from: "roles",
          localField: "role",
          foreignField: "_id",
          as: "role",
        },
      },
      {
        $unwind: {
          path: "$role",
          preserveNullAndEmptyArrays: true,
        },
      },
    ]);
  }
}

export async function updateStaff(
  staffId: any,
  updateStaffDto: any
): Promise<Staff | null> {
  return await staffAndPermissionModel.findByIdAndUpdate(
    staffId,
    updateStaffDto,
    { new: true }
  );
}

export async function deleteStaff(staffId: any): Promise<Staff | null> {
  return await staffAndPermissionModel.findByIdAndUpdate(staffId, {
    isDeleted: true,
  });
}

export async function findOldStaff(email: any): Promise<Staff | null> {
  return await staffAndPermissionModel.findOne({ email: email });
}
