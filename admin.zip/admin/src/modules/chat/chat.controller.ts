import { Request, Response } from "express";
import httpStatus from "http-status";
import { Types } from "mongoose";
import * as chatService from "./chat.service";
import chatModel from "./chat.model";
import bookingModel from "../booking/booking.model";
import consultantModel from "../consultant/consultant.model";
import patientModel from "../patient/patient.model";

export async function SaveMessage(req: Request, res: Response) {
  try {
    const userId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const { senderId, message, receiverId } = req.body;

    let sender = new Types.ObjectId(senderId);
    let reciever = new Types.ObjectId(receiverId);

    let c = await chatService.createMessage(
      sender as Types.ObjectId,
      reciever as Types.ObjectId,
      message as string
    );

    let data = await chatModel.findById(c?._id);
    res.json(data);
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
  }
}

export async function GetMeessage(req: Request, res: Response) {
  try {
    const senderId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const { receiverId } = req.body;

    let reciever = new Types.ObjectId(receiverId.split("-")[1]);

    let data = await chatService.getPreviousMessages(senderId, reciever);

    res.json(data);
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
  }
}

export async function deleteChat(req: Request, res: Response) {
  try {
    const userId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const secondUser = new Types.ObjectId(req.params.id);

    let data = await chatService.getPreviousMessages(userId, secondUser);

    let result = await chatModel.findByIdAndUpdate(data?._id, {
      isDeleted: true,
    });

    res.redirect("/patient/web/chat");
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
  }
}

export async function GetRecievedMessage(req: Request, res: Response) {
  try {
    const recieverId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const { senderId } = req.body;

    let sender = new Types.ObjectId(senderId);
    setTimeout(async () => {
      let message = await chatService.getPreviousMessages(sender, recieverId);
      let data = await chatModel.findById(message?._id);
      res.json(data);
    }, 2000);
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
  }
}

export async function getPatient(req: Request, res: Response) {
  const patientId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

  const patient = await patientModel.findById(patientId);

  res.json(patient);
}

export async function updateCallStatus(req: Request, res: Response) {
  let status = req.body.callStatus;
  let id = new Types.ObjectId(req.body.callId);

  const booking = await bookingModel.findById(id);

  if (status == "calling" || status == "leave" || status == "voicecalling") {
    const doctor = await consultantModel.findByIdAndUpdate(booking?.doctor, {
      callStatus: status,
    });
  } else if (status == "reject") {
    const doctor = await consultantModel.findByIdAndUpdate(booking?.doctor, {
      callStatus: status,
    });
    const patient = await patientModel.findByIdAndUpdate(booking?.patient, {
      callStatus: status,
    });
  } else if (status == "notAccepted") {
    const patient = await patientModel.findByIdAndUpdate(booking?.patient, {
      callStatus: status,
    });
  } else {
    const patient = await patientModel.findByIdAndUpdate(booking?.patient, {
      callStatus: status,
    });
  }

  res.json({ message: "ok" });
}
