import { Types } from "mongoose";
import chatModel from "./chat.model";


export async function createMessage(
    sender:Types.ObjectId,
    reciever:Types.ObjectId,
    message:string,
    ){
        
    let data = await chatModel.findOne({
        $and: [
            { user1:reciever},
            { user2:sender }
          ]
         })
    
    if(data ){

        return await chatModel.findByIdAndUpdate(data._id,{
            $push:{message:{msg:message,sendBy:sender,recievedBy:reciever,date:Date.now()}}

        })
    }else{
        return await chatModel.create({user1:reciever,user2:sender,message:[{msg:message,sendBy:sender,recievedBy:reciever,date:new Date()}]})
    }

}


export async function getPreviousMessages(
    sender:Types.ObjectId,
    reciever:Types.ObjectId,
    ){
        
     let data =  await chatModel.findOne({
            $and: [
                { user1:sender},
                { user2:reciever },
                {isDeleted:false}
              ]
             }).sort({date:1})

             if(data){
                return data

             }
             else{
                return await chatModel.findOne({
                    $and: [
                        { user2:sender},
                        { user1:reciever },
                {isDeleted:false}

                      ]
                     }).sort({date:1})
             }

    }