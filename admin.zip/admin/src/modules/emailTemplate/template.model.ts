import mongoose, { Document, model, Schema, Types } from "mongoose";

export interface Template extends Document {
  addedBy: Types.ObjectId;
    name: string;
    description: string;
    isPrimary: boolean;
    htmlPart: string;
    previewHtml : string;
    replaceObject: object
}

const templateSchema = new Schema<Template>({
  addedBy:{
    type: mongoose.Schema.Types.ObjectId,
    required: true
  },
    name:{
        type: String,
        required: true
    },
    description:{
      type: String,
  },
    isPrimary:{
        type: Boolean,
        default: false
    },
    htmlPart:{
        type: String,
        required: true
    },
    previewHtml :{
      type: String,
    },
    replaceObject:{
        type: Object,
        //required: true
    }
},{
    timestamps: true
});

export default model<Template>("template", templateSchema);
