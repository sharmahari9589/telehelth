import { Request, Response } from "express";
import httpStatus from "http-status";
import * as templateService from "./template.service";
import { ObjectId, Types } from "mongoose";
import { sendMail }  from "../../utils/sendMail";

//EJS Rendor
import ejs from "ejs";
import { getViewFile } from "../../utils/ejsHelper";
import { log } from "console";
import { types } from "util";
import referModel from "../models/refer.model";
import bookingModel, { Booking } from "../booking/booking.model";
import * as consultantservices from "../consultantDashboard/consultant.services"
import templateModel from "./template.model";
import consultantModel from "../consultant/consultant.model";
import fs  from 'fs';
import util from 'util';
import ordersModel from "../orders/orders.model";
import patientModel from "../patient/patient.model";




export async function createTemplate(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const user: any = JSON.parse(res.get("user")!);
    const userid = new Types.ObjectId(user._id)
   
    const manageBooking: Array<Booking> = await consultantservices.myUpcomingBooking(userid,
      // parseInt(limit as string),
      // parseInt(page as string)
    );
    
    
    if (mode == "api") {
      //API Code
      // const templateData = await templateService.createTemplate(templateDto);

      
      res.status(httpStatus.OK).send({
        data: "",
        message: "Template created successfully",
        status: httpStatus.OK,
        });
    } else {
      //Web Code
      
      const fileContent = getViewFile("consultantDashboard","doctor-templete.ejs");
      if(req.method == "GET"){
        res.send(
          ejs.render(fileContent.file, {
            message: "",message1: "",
            user,manageBooking,
            filename: fileContent.templatePath,
          })
        );
      }else{
        //Post Code 
    

        const html=req.body.editor1

        if(html){

    var removedTags = html.replace(/<[^>]*>/g, '');
  

var removedNBSP = removedTags.replace(/&nbsp;|<li>/g, ' ');

    
    const templateDto = {
      htmlPart:removedNBSP,
      name:req.body.templateName,
      description:req.body.templateDescription,
      addedBy:userid
    }
    

      const templateData = await templateService.createTemplate(templateDto);

     
   
      
      
          const manageBooking: Array<Booking> = await consultantservices.myUpcomingBooking(userid,
            // parseInt(limit as string),
            // parseInt(page as string)
          );
          
          const{name}= req.query
      const templates =  await templateService.getTemplateByAddedBy(userid,name as string );
      const fileContent = getViewFile("consultantDashboard","view-templete.ejs");
      res.send(
        ejs.render(fileContent.file, {
          message: "Templete Created Successfully",message1: "",
          user,
          templates,manageBooking,
          filename: fileContent.templatePath,
        })
      );
      }else{

        const fileContent = getViewFile("consultantDashboard","doctor-templete.ejs");
        
          res.send(
            ejs.render(fileContent.file, {
              message1: "Create proper tempalte for it",message: "",
              user,manageBooking,
              filename: fileContent.templatePath,
            })
          );

      }
      }
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Internal server error",
    });
  }
}

export async function getTemplate(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    if (mode == "api") {
      const addedById: Types.ObjectId = new Types.ObjectId(res.get("addedBy")!);
      const templateId: Types.ObjectId = new Types.ObjectId(res.get("templateId")!);

      if (!addedById && !templateId) return res.status(httpStatus.BAD_REQUEST).send({
        data: null,
        message: "Id is required",
        status: httpStatus.BAD_REQUEST,
      });
      if (addedById) {
        const templateData = await templateService.getTemplateByAddedBy(addedById,req.query.name as string);
        res.status(httpStatus.OK).send({
          data: templateData,
          message: "Template fetched successfully",
          status: httpStatus.OK,
        });
      } else {
        const templateData = await templateService.getTemplateById(templateId);
        res.status(httpStatus.OK).send({
          data: templateData,
          message: "Template fetched successfully",
          status: httpStatus.OK,
        });
      }
    } else {
      //Nikhil Code Start
      const user: any = JSON.parse(res.get("user")!);
      const userid = new Types.ObjectId(user._id)

      let consultantId;
      if (user.addedBy== undefined){
        consultantId = userid
      }
      else{
        consultantId =new Types.ObjectId( user.addedBy)
      }
      
      
          const manageBooking: Array<Booking> = await consultantservices.myUpcomingBooking(userid,
            // parseInt(limit as string),
            // parseInt(page as string)
          );
          
          const{name}= req.query
      const templates =  await templateService.getTemplateByAddedBy(consultantId,name as string );
      const fileContent = getViewFile("consultantDashboard","view-templete.ejs");
      res.send(
        ejs.render(fileContent.file, {
          message: "",message1: "",
          user,
          templates,manageBooking,
          filename: fileContent.templatePath,
        })
      );
      //Nikhil Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Internal server error",
    });
  }
}

export async function updateTemplate(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const templateId: Types.ObjectId = new Types.ObjectId(req.params.id);

    // Get Only Value Start
    const requestBody: { [key: string]: string } = req.body;
    const keys = Object.keys(requestBody);      
    const key = keys[0];
    const value = requestBody[key];
    //Get Only Value End
    const template = await templateService.updateTemplate(templateId,value);
  
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        message: "Template updated successfully",
        //data: template,
        status: httpStatus.OK,
      });
    }else{
        //Web Code Start
        res.redirect('/consultant/web/getTemplate');
        //Web COde End
    }
    
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Internal server error",
    });
  }
}

export async function deleteTemplate(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const templateId: Types.ObjectId = new Types.ObjectId(req.params.id);
    const template = await templateService.deleteTemplate(templateId);
    
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        message1: "Template deleted successfully",message: "",
        data: null,
        status: httpStatus.OK,
      });
    }else{
      res.redirect('/consultant/web/getTemplate');
    }
    
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Internal server error",
    });
  }
}


export async function useTemplate(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const templateId: Types.ObjectId = new Types.ObjectId(req.params.id);

    let template = await templateService.getTemplateById(templateId);
    let html:any = template?.htmlPart
    
    const replaceObject:any = req.body;
    
    for (const key in replaceObject) {
      html = html.replace(new RegExp(`{{${key}}}`, 'g'), replaceObject[key]);
  }

  

  // var removedPTags = html.replace(/<\/?p>/g, '');
  var removedTags = html.replace(/<[^>]*>/g, '');
  

var removedNBSP = removedTags.replace(/&nbsp;|<li>/g, ' ');


  



 
  

  const previewHtml= await templateService.updatePreviewTemplate(templateId,html);
  

  // const previewHtml= await templateModel.find({_id:templateId})
  

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        message: "Template successfully",
        data: null,
        status: httpStatus.OK,
      });
    }else{
      //res.redirect('/consultant/web/getTemplate');
      const fileContent = getViewFile("consultantDashboard","prviewTemplate.ejs");
      res.send(
        ejs.render(fileContent.file, {
          message: "",html,message1: "",
          previewHtml,removedNBSP,
          filename: fileContent.templatePath,
        })
      );
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Internal server error",
    });
  }
}



export async function sendTemplate(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const to = req.body.to;
    const subject = req.body.subject;
    const mailBody = req.body.mailBody;


    
    await sendMail(to,subject,mailBody);

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        message: "Template deleted successfully",
        data: null,
        status: httpStatus.OK,
      });
    }else{
      // res.redirect('/consultant/web/getTemplate');
      const user: any = JSON.parse(res.get("user")!);
      const userid = new Types.ObjectId(user._id)
      
      
          const manageBooking: Array<Booking> = await consultantservices.myUpcomingBooking(userid,
            // parseInt(limit as string),
            // parseInt(page as string)
          );
          
          const{name}= req.query
      const templates =  await templateService.getTemplateByAddedBy(userid,name as string );
      const fileContent = getViewFile("consultantDashboard","view-templete.ejs");
      res.send(
        ejs.render(fileContent.file, {
          message: "Email Send Successfully",message1: "",
          user,
          templates,manageBooking,
          filename: fileContent.templatePath,
        })
      );
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Internal server error",
    });
  }
}


/**
 * @description This function is for Create Prescription Template
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function prescriptionTemplate(req: Request, res: Response) {
  try {

    const { mode } = req.params;
    const user: any = JSON.parse(res.get("user")!);

    const userId= new Types.ObjectId(user._id)


    const doctorDetial= await  consultantModel.findById(userId)
    

    const doctor=req.body.consultantName;
    const department=req.body.department;
    const hospitalName=req.body.hospitalName;
    const address=req.body.hAddress
    const mobNumber=req.body.hNumber;
    const email=req.body.hEmail
    
  

    const findReferTo = await referModel.findOne({
      doctor: req.body.consultantName, department: req.body.department
    }).select('-_id -__v');

   
 const bookingId:Types.ObjectId = new Types.ObjectId(req.body.bookingId);

    const getFilteredData = await bookingModel.aggregate(
    [
      {
        '$match': {
          '_id': bookingId
        }
      }, {
        '$lookup': {
          'from': 'patients', 
          'localField': 'patient', 
          'foreignField': '_id', 
          'as': 'patient'
        }
      }, {
        '$unwind': {
          'path': '$patient', 
          'preserveNullAndEmptyArrays': true
        }
      }, {
        '$lookup': {
          'from': 'doctors', 
          'localField': 'doctor', 
          'foreignField': '_id', 
          'as': 'doctor'
        }
      }, {
        '$unwind': {
          'path': '$doctor', 
          'preserveNullAndEmptyArrays': true
        }
      }, {
        '$lookup': {
          'from': 'orders', 
          'localField': '_id', 
          'foreignField': 'booking', 
          'as': 'order'
        }
      }, {
        '$unwind': {
          'path': '$order', 
          'preserveNullAndEmptyArrays': true
        }
      },
     /* {
        $project: {
          'patient.firstname': 1,
          'patient.lastname': 1,
          'doctor.firstname': 1,
          'doctor.lastname': 1,
          'order.field1': 1,
          'order.field2': 1
        }
      }*/
    ]);


    //Web Code
      const fileContent = getViewFile("consultantDashboard","prescription-template.ejs");
      if(req.method == "POST"){
        res.send(
          ejs.render(fileContent.file, {
            message: "",message1: "",
            user,findReferTo,addReferTo:"",getFilteredData,bookingId,
            doctor,department, hospitalName,mobNumber, address,email,doctorDetial,
            filename: fileContent.templatePath,
          })
        );
      }else{
        //Post Method
      }

  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Internal server error",
    });
  }
}


/**
 * @description This function is for Send Prescription Template
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function sendPrescriptionTemplate(req: Request, res: Response) {
  try {


const bookingId= req.body.bookingId;

    const refereDto ={

      doctorName:req.body.doctor,
      
      department:req.body.department,
      hospitalName:req.body.hospitalName,
      mobileNumber:req.body.mobNumber,
      location:req.body.address,
      email:req.body.email
 }


 const addReferTo = await bookingModel.findByIdAndUpdate(
  bookingId, { referedTo: refereDto 
  });

    const to = req.body.to;
    const subject = req.body.subject;
    const html = req.body.editor1;

    await sendMail(to,subject,html);
    res.redirect('/consultant/web/managebooking');
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Internal server error",
    });
  }
}






export async function genrateCertificate(req: Request, res: Response) {
  try {
    let bookingId : Types.ObjectId = new Types.ObjectId(req.body.bookingId);


    let order = await ordersModel.find({booking:bookingId});

    
    let orderData;

    if(req.body.meidcineCheck){
      
      orderData =  order[0]?.prescription[0]?. medicine
      
    }
    
    const { mode } = req.params;
    const templateId: Types.ObjectId = new Types.ObjectId(req.body.templateId);

    let template = await templateService.getTemplateById(templateId);


    const booking:any= await consultantservices.getBookingDetail(bookingId)
    let pastData ;

    if(req.body.pastCheck){
pastData = await consultantservices.pastBookings(booking?.patient)
    }

    let notes;

    if(req.body.notesCheck){
notes = "on"

    }
    
    
    let html:any = req.body.mailBody

    
    
 
  

  // var removedPTags = html.replace(/<\/?p>/g, '');
  var removedTags = html
  

var removedNBSP = removedTags



    if (mode == "api") {
      res.status(httpStatus.OK).send({

        message: "Template successfully",
        data: null,
        status: httpStatus.OK,
      });
    }else{
      
      const fileContent = getViewFile("consultantDashboard","previewCertificate.ejs");
      res.send(
        ejs.render(fileContent.file, {
          message: "",html,booking,removedNBSP,template,orderData,notes,pastData,
          message1: "",
          filename: fileContent.templatePath,
        })
      );
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Internal server error",
    });
  }
}




export async function genrateReferalCertificate(req: Request, res: Response) {
  try {
    
    const data = req.body;
    let bookingId : Types.ObjectId = new Types.ObjectId(req.body.bookingId);


    let order = await ordersModel.find({booking:bookingId});

    
    let orderData;

    if(req.body.meidcineCheck){
      
      orderData =  order[0]?.prescription[0]?. medicine
      
    }
    
    const { mode } = req.params;
    const templateId: Types.ObjectId = new Types.ObjectId(req.body.templateName);

    let template = await templateService.getTemplateById(templateId);


    const booking:any= await consultantservices.getBookingDetail(bookingId)
    let pastData ;

    if(req.body.pastCheck){
pastData = await consultantservices.pastBookings(booking?.patient)
    }

    let notes;

    if(req.body.notesCheck){
notes ="on"

    }
    
    
    let html:any = req.body.mailBody

    
    
 
  

  // var removedPTags = html.replace(/<\/?p>/g, '');
  var removedTags = html
  

var removedNBSP = removedTags



    if (mode == "api") {
      res.status(httpStatus.OK).send({

        message: "Template successfully",
        data: null,
        status: httpStatus.OK,
      });
    }else{
      
      const fileContent = getViewFile("consultantDashboard","referal-preview.ejs");
      res.send(
        ejs.render(fileContent.file, {
          message: "",html,booking,removedNBSP,template,orderData,notes,pastData,data,
          
          filename: fileContent.templatePath,
        })
      );
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Internal server error",
    });
  }
}





// export async function genratePdf(req: Request, res: Response) {
//   try {

//     const readFile= util.promisify(fs.readFile);

// const htmlFilePath:any= req.body.htmlContent


// const pdfFilePath = './output.pdf';


// // const browser = await puppeteer.launch({ headless: 'new' });

// const browser = await puppeteer.launch({

//   headless: 'new',
//   // Increase the protocol timeout (in milliseconds) as needed
//   timeout: 0, // Set to 0 for no timeout
//   defaultViewport: null,
// });
// // console.log(browser,"broswe");
// // const browser = await puppeteer.launch();
// const page = await browser.newPage();
// const htmlContent:any = await readFile(htmlFilePath,"base64");
// // You can modify the options like page size, orientation, etc. as per your requirements
// const pdfOptions: puppeteer.PDFOptions = {
//   path: pdfFilePath,
//   format: 'A4',
// };
// await page.setContent(htmlContent);
// await page.emulateMediaType('screen');
//    const d=await page.pdf(pdfOptions);
// await browser.close(); 
//     const { mode } = req.params;
//     if (mode == "api") {
//       res.status(httpStatus.OK).send({

//         message: "Template successfully",
//         data: null,
//         status: httpStatus.OK,
//       });
//     }else{
//     }
//   } catch (error) {
//     console.log(error);
//     res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
//       data: error,
//       message: "Internal server error",
//     });
//   }
// }




export async function genrateGovtCertificate(req: Request, res: Response) {
  try {
const data = req.body;
let book = new Types.ObjectId(req.body.bookingid);

let mappedData;

if(req.body.medicineCheck){
  let order:any = await ordersModel.find(
    {booking:book});
   mappedData = order[0]?.prescription[0]?. medicine
}
else{
  
}
    const { mode } = req.params;
    if (mode == "api") {
      res.status(httpStatus.OK).send({

        message: "Template successfully",
        data: null,
        status: httpStatus.OK,
      });
    }else{
      
      const fileContent = getViewFile("consultantDashboard","govertment-certificate.ejs");
      res.send(
        ejs.render(fileContent.file, {
          message: "",data,mappedData,message1: "",
          filename: fileContent.templatePath,
        })
      );
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Internal server error",
    });
  }
}




export async function generateReferModal(req: Request, res: Response) {
  try {
    const {mode } = req.query;
    const data = req.body;
    const bookId = new Types.ObjectId(req.body.bookingId)
    const bokking = await bookingModel.findById(bookId)     .populate({ path: "doctor", model: consultantModel })
    .populate({ path: "patient", model: patientModel })

    const templateid = new Types.ObjectId(req.body.templateName);

    const template = await templateService.getTemplateById(templateid);


    if (mode == "api") {
      res.status(httpStatus.OK).send({
        message: "Template successfully",
        data: null,
        status: httpStatus.OK,
      });
    }else{
      const user: any = JSON.parse(res.get("user")!);
      const fileContent = getViewFile("consultantDashboard","refModal.ejs");
      res.send(
        ejs.render(fileContent.file, {
          message: "",user,data,template,bokking,templateid,message1: "",
          filename: fileContent.templatePath,
        })
      );
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Internal server error",
    });
  }
}
