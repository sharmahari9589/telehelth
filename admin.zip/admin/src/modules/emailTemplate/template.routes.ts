import { Router } from "express";
import * as templateController from "./template.controller";

const router: Router = Router({mergeParams:true});

router.route("/createTemplate")
    .get(templateController.createTemplate)
    .post(templateController.createTemplate);
//router.post("/createTemplate", templateController.createTemplate);

router.get("/getTemplate", templateController.getTemplate);
router.route("/updateTemplate/:id")
.get(templateController.updateTemplate)
.post(templateController.updateTemplate)

router.route("/deleteTemplate/:id")
.post(templateController.deleteTemplate);

//Use Template
router.route("/useTemplate/:id")
.get(templateController.useTemplate)
    .post(templateController.useTemplate);


    

    router.route("/genrateCertificate")
    .get(templateController.genrateCertificate)
        .post(templateController.genrateCertificate);
    

        router.route("/genrateReferalCertificate")
        .get(templateController.genrateReferalCertificate)
            .post(templateController.genrateReferalCertificate);

    //     router.route("/genrate-pdf")
    // .get(templateController.genratePdf)
    //     .post(templateController.genratePdf);
    

        router.route("/genrate-refer")
        .get(templateController.generateReferModal)
            .post(templateController.generateReferModal);

       


//Send Template    
router.route("/sendTemplate")
    .post(templateController.sendTemplate);


    
//Prescription Template    
router.route("/prescriptionTemplate")
.get(templateController.prescriptionTemplate)
.post(templateController.prescriptionTemplate);

//Send Prescription Template
router.post("/send-prescription-template", templateController.sendPrescriptionTemplate);  

router.route("/generate-govt-certificate")
.get(templateController.genrateGovtCertificate)
    .post(templateController.genrateGovtCertificate);



export default router;
