import httpStatus from "http-status";
import { Request, Response } from "express";
import * as roleService from "./roleAndPermission.service";
import { Role } from "./roleAndPermission.model";
import mongoose, { Types, ObjectId } from "mongoose";
import { getViewFile } from "../../utils/ejsHelper";
import ejs from "ejs";
/**
 * @description This function is for create role
 * @param req
 * @param res
 * @author Meet Gajera
 */
export async function createRole(req: Request, res: Response) {
  try {
    const { name, Description } = req.body;
    if (name == undefined && Description == undefined) {
      res.redirect("/admin/web/addrole");
    } else {
      const addedBy: Types.ObjectId = new Types.ObjectId(res.get("userId"));

      const data: Role = await roleService.createRole({
        name: name,
        Description: Description,
        addedBy: addedBy,
      });

      // res.redirect("/admin/web/addrole")

      const roles: Array<Role> = await roleService.getRoles(addedBy);

      const fileContent = getViewFile("adminDashboard", "add-role.ejs");
      const user: any = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          message: "role Created Suceessfully",
          user,
          activeTab: "addRole",
          roles,
          filename: fileContent.templatePath,
        })
      );
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err,
    });
  }
}

/**
 * @description This function is for get role
 * @param req
 * @param res
 * @author Meet Gajera
 */
export async function getRoles(req: Request, res: Response) {
  try {
    const addedBy: Types.ObjectId = new Types.ObjectId(res.get("userId"));
    const roles: Array<Role> = await roleService.getRoles(addedBy);
    res.status(httpStatus.OK).send({
      data: roles,
      message: "Role fetched successfully",
      status: httpStatus.OK,
    });
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err,
    });
  }
}

/**
 * @description This function is for update role
 * @param req
 * @param res
 * @author Meet Gajera
 */
export async function updateRole(req: Request, res: Response) {
  try {
    const roleId: Types.ObjectId = new Types.ObjectId(req.params.id);
    const addedBy: Types.ObjectId = new Types.ObjectId(res.get("userId"));

    // if(req.body.name==undefined&& req.body.Description==undefined){
    //   res.redirect("/admin/web/addrole")
    // }
    // else{

    const role: Role | null = await roleService.updateRole(roleId, req.body);

    const roles: Array<Role> = await roleService.getRoles(addedBy);

    const fileContent = getViewFile("adminDashboard", "add-role.ejs");
    const user: any = JSON.parse(res.get("user")!);
    res.send(
      ejs.render(fileContent.file, {
        message: "role Update Suceessfully",
        user,
        activeTab: "addRole",
        roles,
        filename: fileContent.templatePath,
      })
    );
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err,
    });
  }
}

/**
 * @description This function is for delete role
 * @param req
 * @param res
 * @author Meet Gajera
 */
export async function deleteRole(req: Request, res: Response) {
  try {
    const roleId: Types.ObjectId = new Types.ObjectId(req.params.id);
    const role: Role | null = await roleService.deleteRole(roleId);
    res.redirect("/admin/web/addrole");
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err,
    });
  }
}

export async function updateRoleAces(req: Request, res: Response) {
  try {
    // if(req.body.name==undefined&& req.body.Description==undefined){
    //   res.redirect("/admin/web/addrole")
    // }
    // else{
    const roleId = new mongoose.Types.ObjectId(req.body.id);

    const keys = Object.keys(req.body);

    keys.forEach((key) => {
      if (!Array.isArray(key)) {
        req.body[key] = req.body[key] == "on" ? true : false;
      }
    });

    const permissionDto = {
      permission: {
        patients: {
          view: req.body["patient-view"] ? true : false,
        },
        consultant: {
          view: req.body["consultant-view"] ? true : false,
        },
        pharmacy: {
          view: req.body["pharmacy-view"] ? true : false,
        },
        questionnaire: {
          view: req.body["questionnaire-view"] ? true : false,
        },
        order: {
          view: req.body["order-view"] ? true : false,
        },
        template: {
          view: req.body["template-view"] ? true : false,
        },
        manageRole: {
          view: req.body["managerole-view"] ? true : false,
        },
        masterData: {
          view: req.body["masterdata-view"] ? true : false,
        },
        medicine: {
          view: req.body["medicine-view"] ? true : false,
        },
        email: {
          view: req.body["email-view"] ? true : false,
        },
        referal: {
          view: req.body["ref-view"] ? true : false,
        },
        ICD: {
          view: req.body["icd-view"] ? true : false,
        },
        Eir: {
          view: req.body["eirCode-view"] ? true : false,
        },
        invite: {
          view: req.body["invite-view"] ? true : false,
        },
        documentCenter: {
          view: req.body["documentcenter-view"] ? true : false,
        },
        settings: {
          view: req.body["settings-view"] ? true : false,
        },
      },
    };

    const role = await roleService.updateRoleAcces(roleId, permissionDto);
    res.redirect("/admin/web/roleaccess");
    // }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err,
    });
  }
}

// hari

export async function getRolesById(req: Request, res: Response) {
  try {
    const id: Types.ObjectId = new Types.ObjectId(req.params.id);

    const roles = await roleService.getMyRoles(id);

    res.status(httpStatus.OK).send({
      data: roles,
      message: "Role fetched successfully",
      status: httpStatus.OK,
    });
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err,
    });
  }
}
