import mongoose, { Schema, Document } from "mongoose";

export interface Role extends Document {
  name: string;
  Description: string;
  isDeleted: boolean;
  permission: {
    patients: {
      view: boolean;
    };
    consultant: {
      view: boolean;
    };
    pharmacy: {
      view: boolean;
    };
    documentCenter: {
      view: boolean;
    };
    questionnaire: {
      view: boolean;
    };
    booking: {
      view: boolean;
    };
    manageRole: {
      view: boolean;
    };
    masterData: {
      view: boolean;
    };
    settings: {
      view: boolean;
    };
    template: {
      view: boolean;
    };
    order: {
      view: boolean;
    };
    medicine: {
      view: boolean;
    };
    email: {
      view: boolean;
    };
    referal: {
      view: boolean;
    };
    ICD: {
      view: boolean;
    };
    Eir: {
      view: boolean;
    };
    invite: {
      view: boolean;
    };
  };
  addedBy: mongoose.Schema.Types.ObjectId;
}

const accessSchema: Schema = new mongoose.Schema(
  {
    view: {
      type: Boolean,
      default: false,
    },
  },
  { _id: false }
);

const roleSchema: Schema = new mongoose.Schema<Role>(
  {
    name: {
      type: String,
    },
    Description: {
      type: String,
    },
    permission: {
      type: {
        patients: accessSchema,
        consultant: accessSchema,
        pharmacy: accessSchema,
        documentCenter: accessSchema,
        questionnaire: accessSchema,
        booking: accessSchema,
        manageRole: accessSchema,
        masterData: accessSchema,
        settings: accessSchema,
        template: accessSchema,
        order: accessSchema,
        medicine: accessSchema,
        email: accessSchema,
        referal: accessSchema,
        ICD: accessSchema,
        Eir: accessSchema,
        invite: accessSchema,


      },
      default: {
        patients: { view: false },
        consultant: { view: false },
        pharmacy: { view: false },
        documentCenter: { view: false },
        questionnaire: { view: false },
        booking: { view: false },
        manageRole: { view: false },
        masterData: { view: false },
        settings: { view: false },
        template: { view: false },
        order: { view: false },
        medicine: { view: false },
        email: { view: false },
        referal: { view: false },
        ICD: { view: false },
        Eir: { view: false },
        invite: { view: false },
      },
    },
    addedBy: {
      type: mongoose.Schema.Types.ObjectId,
    },
    isDeleted: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
    minimize: false,
  }
);

export default mongoose.model<Role>("role", roleSchema);
