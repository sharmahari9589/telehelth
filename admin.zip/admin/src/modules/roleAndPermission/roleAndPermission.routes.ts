import { Router } from "express";
import * as roleController from "./roleAndPermission.controller";

const router = Router({
  mergeParams: true,
});

router.post("/create-role", roleController.createRole);
router.get("/create-role", roleController.createRole);
router.post("/get-roles", roleController.getRoles);
router.post("/update-role/:id", roleController.updateRole);
router.get("/update-role/:id", roleController.updateRole);
router.post("/delete-role/:id", roleController.deleteRole);
router.post("/update-role-access", roleController.updateRoleAces);
router.get("/update-role-access", roleController.updateRoleAces);
router.get("/get-role/:id", roleController.getRolesById);

export default router;
