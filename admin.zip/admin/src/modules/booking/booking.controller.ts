import { Request, Response } from "express";
import httpStatus from "http-status";
import * as bookingService from "./booking.service";
import * as questionnaireService from "../questionnaire/questionnaire.service";
import * as pharmacyService from "../pharmacy/pharmacy.service";
import { Types } from "mongoose";

//EJS Rendor
import ejs from "ejs";
import { getViewFile } from "../../utils/ejsHelper";
import bookingModel from "./booking.model";
import healthProblemModel from "../questionnaire/healthProblem.model";
import payementModel from "./payementModel";

export async function viewAllBooking(req: Request, res: Response) {
  try {
    const { mode, id } = req.params;
    const { search, status, startDate, endDate } = req.query;
    const limit = 10;
    const page = req.query.page || 1;

    const problem = await healthProblemModel.find();
    const bookings = await bookingService.getAllBookings(
      search as string,
      status as string,
      startDate as string,
      endDate as string,
      limit,
      page
    );

    const ID = bookings.map((a) => {
      return a._id;
    });

    const payement = await payementModel.find({ bookingId: ID });

    const count = await bookingModel.find().count();

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: "",
        message: "bookings fetched successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      const fileContent = getViewFile("adminDashboard", "view-booking.ejs");
      const user = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          user,
          activeTab: "viewbook",
          bookings,
          problem,
          payement,
          current: page,
          pages: Math.ceil(count / limit),
          filename: fileContent.templatePath,
        })
      );
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}
