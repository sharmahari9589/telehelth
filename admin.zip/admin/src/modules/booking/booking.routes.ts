import { Router } from "express";
import * as bookingController from "./booking.controller";

const router = Router({
  mergeParams: true,
});

  router
  .route("/viewall-bookings")
  .get(bookingController.viewAllBooking)
  .post(bookingController.viewAllBooking);


export default router;
