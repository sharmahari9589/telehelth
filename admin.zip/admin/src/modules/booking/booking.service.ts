import { Types } from "mongoose";
import bookingModel, { BookingMode, Booking } from "./booking.model";
import * as consultantService from "../consultant/consultant.services";
import consultantModel, { Gender } from "../consultant/consultant.model";
import patientModel from "../patient/patient.model";
import serviceModel from "../services/service.model";
import payementModel from "./payementModel";
import healthProblemModel from "../questionnaire/healthProblem.model";
export async function setDefaultBookingSettings(consultantId: string) {
  const data = await bookingModel.create({});
}

export async function fetchDoctors(
  status: BookingMode,
  gender: Gender,
  problemId: Types.ObjectId
) {
  const data = await consultantService.findConsultants();
  return data;
}

/**
 * @description This function is used to create the booking
 * @param createBookingDto
 * @returns Promise<Booking>
 * @author Nikhil chouhan
 */
export async function createBooking(createBookingDto: any): Promise<Booking> {
  return await bookingModel.create(createBookingDto);
}

/**
 * @description This function is used to get the list of pharmacies
 * @param {Number} page
 * @param {Number} limit
 * @returns {Promise<Array<Booking>>}
 */
export async function getBookings(
  limit: number,
  page: number,
  patientId: Types.ObjectId
): Promise<Array<Booking>> {
  return await bookingModel.aggregate([
    {
      $match: {
        patient: patientId,
      },
    },
    {
      $lookup: {
        from: "consultants",
        localField: "doctor",
        foreignField: "_id",
        as: "doctor",
      },
    },
    {
      $lookup: {
        from: "healthproblems",
        localField: "problem",
        foreignField: "_id",
        as: "problem",
      },
    },
    {
      $lookup: {
        from: "pharmacies",
        localField: "pharmacy",
        foreignField: "_id",
        as: "pharmacy",
      },
    },
    {
      $lookup: {
        from: "patients",
        localField: "patient",
        foreignField: "_id",
        as: "patient",
      },
    },
    {
      $unwind: {
        path: "$doctor",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $unwind: {
        path: "$problem",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $unwind: {
        path: "$pharmacy",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $unwind: {
        path: "$patient",
        preserveNullAndEmptyArrays: true,
      },
    },
  ]);
}

export async function getBookingById(id: string): Promise<Booking | null> {
  return await bookingModel
    .findById(id)
    .populate([
      "doctor",
      "problem",
      "pharmacy",
      "patient",
      "answers.questionnaireID",
    ]);
}
export async function cancelBooking(
  bookingId: Types.ObjectId
): Promise<Booking | null> {
  return await bookingModel.findByIdAndDelete(bookingId);
}

export async function bookingupdateById(
  bookingId: Types.ObjectId,
  updateBody: any
) {
  return await bookingModel.findByIdAndUpdate(bookingId, updateBody);
}

export async function getAllBookings(
  search: string,
  status: string,
  startDate: string,
  endDate: string,
  limit: any,
  page: any
): Promise<Array<Booking>> {
  if (search && startDate == "" && endDate == "" && status == "") {
    return await bookingModel.aggregate([
      {
        $lookup: {
          from: "patients",
          localField: "patient",
          foreignField: "_id",
          as: "patient",
        },
      },
      {
        $unwind: {
          path: "$patient",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "doctors",
          localField: "doctor",
          foreignField: "_id",
          as: "doctor",
        },
      },
      {
        $unwind: {
          path: "$doctor",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "healthproblems",
          localField: "problem",
          foreignField: "_id",
          as: "problem",
        },
      },
      {
        $unwind: {
          path: "$problem",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "services",
          localField: "service",
          foreignField: "_id",
          as: "service",
        },
      },
      {
        $unwind: {
          path: "$service",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "payments",
          localField: "_id",
          foreignField: "bookingId",
          as: "payment",
        },
      },
      {
        $unwind: {
          path: "$payment",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $match: {
          "bookingFor.patientName": { $regex: search, $options: "i" },
        },
      },
    ]);
  }
  if (startDate && search == "" && endDate == "" && status == "") {
    return await bookingModel
      .find({
        date: { $gte: new Date(startDate) },
      })
      .populate({ path: "patient", model: patientModel })
      .populate({ path: "doctor", model: consultantModel })
      .populate({ path: "service", model: serviceModel })
      .populate({ path: "problem", model: healthProblemModel })
      .populate({ path: "payment", model: payementModel })
      .sort({ date: 1 });
  }
  if (endDate && startDate == "" && search == "" && status == "") {
    return await bookingModel
      .find({
        date: { $lte: new Date(endDate) },
      })
      .populate({ path: "patient", model: patientModel })
      .populate({ path: "doctor", model: consultantModel })
      .populate({ path: "service", model: serviceModel })
      .populate({ path: "problem", model: healthProblemModel })
      .populate({ path: "payment", model: payementModel })
      .sort({ date: -1 });
  }

  if (startDate && endDate && search == "" && status == "") {
    return await bookingModel
      .find({
        date: { $gte: new Date(startDate), $lte: new Date(endDate) },
      })
      .populate({ path: "patient", model: patientModel })
      .populate({ path: "doctor", model: consultantModel })
      .populate({ path: "service", model: serviceModel })
      .populate({ path: "problem", model: healthProblemModel })
      .populate({ path: "payment", model: payementModel })
      .sort({ date: 1 });
  }
  if (status && startDate == "" && endDate == "" && search == "") {
    return await bookingModel
      .find({ status: status })
      .populate({ path: "patient", model: patientModel })
      .populate({ path: "doctor", model: consultantModel })
      .populate({ path: "service", model: serviceModel })
      .populate({ path: "problem", model: healthProblemModel })
      .populate({ path: "payment", model: payementModel })
      .sort({ date: 1 });
  }

  if (search && startDate && endDate == "" && status == "") {
    return await bookingModel
      .aggregate([
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "doctor",
            foreignField: "_id",
            as: "doctor",
          },
        },
        {
          $unwind: {
            path: "$doctor",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "payments",
            localField: "_id",
            foreignField: "bookingId",
            as: "payment",
          },
        },
        {
          $unwind: {
            path: "$payment",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: {
            $and: [
              {
                "bookingFor.patientName": { $regex: search, $options: "i" },
              },
              { date: { $gte: new Date(startDate) } },
            ],
          },
        },
      ])
      .sort({ date: 1 });
  }

  if (search && startDate == "" && endDate && status == "") {
    return await bookingModel
      .aggregate([
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "doctor",
            foreignField: "_id",
            as: "doctor",
          },
        },
        {
          $unwind: {
            path: "$doctor",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "payments",
            localField: "_id",
            foreignField: "bookingId",
            as: "payment",
          },
        },
        {
          $unwind: {
            path: "$payment",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: {
            $and: [
              {
                "bookingFor.patientName": { $regex: search, $options: "i" },
              },
              { date: { $lte: new Date(endDate) } },
            ],
          },
        },
      ])
      .sort({ date: -1 });
  }

  if (search && startDate == "" && endDate == "" && status) {
    return await bookingModel.aggregate([
      {
        $lookup: {
          from: "patients",
          localField: "patient",
          foreignField: "_id",
          as: "patient",
        },
      },
      {
        $unwind: {
          path: "$patient",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "doctors",
          localField: "doctor",
          foreignField: "_id",
          as: "doctor",
        },
      },
      {
        $unwind: {
          path: "$doctor",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "healthproblems",
          localField: "problem",
          foreignField: "_id",
          as: "problem",
        },
      },
      {
        $unwind: {
          path: "$problem",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "services",
          localField: "service",
          foreignField: "_id",
          as: "service",
        },
      },
      {
        $unwind: {
          path: "$service",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "payments",
          localField: "_id",
          foreignField: "bookingId",
          as: "payment",
        },
      },
      {
        $unwind: {
          path: "$payment",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $match: {
          $and: [
            {
              "bookingFor.patientName": { $regex: search, $options: "i" },
            },
            { status: status },
          ],
        },
      },
    ]);
  }

  if (search && startDate && endDate && status == "") {
    return await bookingModel
      .aggregate([
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "doctor",
            foreignField: "_id",
            as: "doctor",
          },
        },
        {
          $unwind: {
            path: "$doctor",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "payments",
            localField: "_id",
            foreignField: "bookingId",
            as: "payment",
          },
        },
        {
          $unwind: {
            path: "$payment",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: {
            $and: [
              {
                "bookingFor.patientName": { $regex: search, $options: "i" },
              },
              { date: { $gte: new Date(startDate), $lte: new Date(endDate) } },
            ],
          },
        },
      ])
      .sort({ date: 1 });
  }

  if (search && startDate && endDate == "" && status) {
    return await bookingModel
      .aggregate([
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "doctor",
            foreignField: "_id",
            as: "doctor",
          },
        },
        {
          $unwind: {
            path: "$doctor",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "payments",
            localField: "_id",
            foreignField: "bookingId",
            as: "payment",
          },
        },
        {
          $unwind: {
            path: "$payment",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: {
            $and: [
              {
                "bookingFor.patientName": { $regex: search, $options: "i" },
              },
              { status: status },
              { date: { $gte: new Date(startDate) } },
            ],
          },
        },
      ])
      .sort({ date: 1 });
  }

  if (search && startDate == "" && endDate && status) {
    return await bookingModel
      .aggregate([
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "doctor",
            foreignField: "_id",
            as: "doctor",
          },
        },
        {
          $unwind: {
            path: "$doctor",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "payments",
            localField: "_id",
            foreignField: "bookingId",
            as: "payment",
          },
        },
        {
          $unwind: {
            path: "$payment",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: {
            $and: [
              {
                "bookingFor.patientName": { $regex: search, $options: "i" },
              },
              { status: status },
              { date: { $lte: new Date(endDate) } },
            ],
          },
        },
      ])
      .sort({ date: -1 });
  }

  if (search && startDate && endDate && status) {
    return await bookingModel
      .aggregate([
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "doctor",
            foreignField: "_id",
            as: "doctor",
          },
        },
        {
          $unwind: {
            path: "$doctor",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "payments",
            localField: "_id",
            foreignField: "bookingId",
            as: "payment",
          },
        },
        {
          $unwind: {
            path: "$payment",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: {
            $and: [
              {
                "bookingFor.patientName": { $regex: search, $options: "i" },
              },
              { status: status },
              { date: { $gte: new Date(startDate), $lte: new Date(endDate) } },
            ],
          },
        },
      ])
      .sort({ date: 1 });
  }

  if (search == "" && startDate && endDate == "" && status) {
    return await bookingModel
      .aggregate([
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "doctor",
            foreignField: "_id",
            as: "doctor",
          },
        },
        {
          $unwind: {
            path: "$doctor",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "payments",
            localField: "_id",
            foreignField: "bookingId",
            as: "payment",
          },
        },
        {
          $unwind: {
            path: "$payment",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: {
            $and: [{ status: status }, { date: { $gte: new Date(startDate) } }],
          },
        },
      ])
      .sort({ date: 1 });
  }

  if (search == "" && startDate == "" && endDate && status) {
    return await bookingModel
      .aggregate([
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "doctor",
            foreignField: "_id",
            as: "doctor",
          },
        },
        {
          $unwind: {
            path: "$doctor",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "payments",
            localField: "_id",
            foreignField: "bookingId",
            as: "payment",
          },
        },
        {
          $unwind: {
            path: "$payment",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: {
            $and: [{ status: status }, { date: { $lte: new Date(endDate) } }],
          },
        },
      ])
      .sort({ date: -1 });
  }

  if (search == "" && startDate && endDate && status) {
    return await bookingModel
      .aggregate([
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "doctor",
            foreignField: "_id",
            as: "doctor",
          },
        },
        {
          $unwind: {
            path: "$doctor",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "payments",
            localField: "_id",
            foreignField: "bookingId",
            as: "payment",
          },
        },
        {
          $unwind: {
            path: "$payment",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: {
            $and: [
              { status: status },
              { date: { $gte: new Date(startDate), $lte: new Date(endDate) } },
            ],
          },
        },
      ])
      .sort({ date: 1 });
  } else {
    return await bookingModel
      .find()
      .populate({ path: "patient", model: patientModel })
      .populate({ path: "doctor", model: consultantModel })
      .populate({ path: "payment", model: payementModel })
      .populate({ path: "problem", model: healthProblemModel })
      .populate({ path: "service", model: serviceModel })
      .limit(limit)
      .skip(limit * page - limit)
      .sort({ bookingId: -1 });
  }
}
