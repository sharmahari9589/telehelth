import { query, Request, Response } from "express";
import { Types } from "mongoose";
import bookingModel, { Booking } from "../booking/booking.model";


export async function getFilterPatients(
    search: string,
    page: number,
    startDate:Date,
    endDate:Date,
    consultantId:Types.ObjectId

  ): Promise<Array<Booking>> {

    console.log(typeof search ,typeof page ,typeof startDate ,typeof endDate ,typeof consultantId)
   const limit=20
    return await bookingModel
      .aggregate([
        {
          $match: {
            doctor: consultantId
          }
        }, {
          $lookup: {
            from: 'patients', 
            localField: 'patient', 
            foreignField: '_id', 
            as: 'patient'
          }
        }, {
          $unwind: {
            path: '$patient', 
            preserveNullAndEmptyArrays: true
          }
        },
         {
          $match: {
            $or: [
              {
                "patient.firstName": {
                  "$regex":search, 
                  '$options': 'i'
                }
                
                
              }, {
                'createdAt': {
                  '$gte': startDate,
                  '$lte': endDate
                }
              }
            ]
          }
        },
        //  {
        //   '$limit':(limit)
        // }, {
        //   '$skip': (page-1)*limit 
        // }
      ]);
      
   
}