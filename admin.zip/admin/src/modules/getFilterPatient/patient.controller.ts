
 import { Request, Response } from "express";
import httpStatus from "http-status";
import * as patientService from "./patient.services";
import { ObjectId, Types } from "mongoose";

//EJS Rendor
import ejs from "ejs";
import { getViewFile } from "../../utils/ejsHelper";
import { getFilterPatients } from "./patient.services";
import { Booking } from "../booking/booking.model";

export async function getfilterdata(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { search, page,startDate,endDate } = req.body;
  const searchvalue = search??""  
    const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const user= (JSON.parse(res.get("user")!)); 
    let consultantId;
    if (user.addedBy== undefined){
      consultantId = id
    }
    else{
      consultantId =new Types.ObjectId( user.addedBy)
    }
    
    
    
    const bookings: Array<Booking> = await patientService.getFilterPatients(
      searchvalue as string,
      parseInt(page as string),
      new Date(startDate as string),
      new Date(endDate as string),
        consultantId ,
    );
    
    
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: bookings,
        message: "patients fetched successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
     
        const fileContent = getViewFile(
          "consultantDashboard",
          "view-patient-list.ejs"
        );
        const user:any = JSON.parse(res.get('user')!);
        // res.send(
        //   ejs.render(fileContent.file, { 
        //     patients,
        //     bookings:"",
        //     filename: fileContent.templatePath
        // }));
        res.redirect('/consultant/web/managepatient');
      //Web Code End
        }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ data: error });
  }
}