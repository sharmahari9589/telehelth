import { Router } from "express";
import { getfilterdata } from "./patient.controller";
import * as patientController from "./patient.controller";


const filterRouter: Router = Router(
    {
        mergeParams:true
    }
);

// // filterRouter.post("/filter",getfilterdata);
// filterRouter.route("/managepatient")
// .get(patientController.getfilterdata)
// .post(patientController.getfilterdata)


export default filterRouter;