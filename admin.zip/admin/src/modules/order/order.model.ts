import mongoose, { model, Schema, Document } from "mongoose";

export interface Order extends Document {
  problem: mongoose.Types.ObjectId;
  booking: mongoose.Types.ObjectId;
  service: mongoose.Types.ObjectId;
  pharmacy: mongoose.Types.ObjectId;
  amount: number;
  patient: mongoose.Types.ObjectId;
  consultant: mongoose.Types.ObjectId;
  rejectReason: String;
  deliveryDate: any;
  orderStatus: string;
  createdAt: Date;
  updatedAt: Date;
  medicine: Array<string>;
  flowUpDate: Date;
  Diagnosys: Array<string>;
  prescription: Array<any>;
  invoice: Array<any>;
}
export enum orderStatus {
  pending = "pending",
  completed = "completed",
  reject = "reject",
  inProcess = "inProcess",
  readyFordispatch = "readyForDispatch",
}

export enum FollowUp {
  Between0To10 = "Between 0 to 10 days",
  Between10To20 = "Between 10 to 20 days",
  Between20To30 = "Between 20 to 30 days",
}

export enum Notes {
  BeforeFood = "Before Food",
  AfterFood = "After Food",
}
const medicineSchema = new mongoose.Schema(
  {
    medicineName: String,
    frequency: String,
    preparation: String,
    quantity: String,
    duration: String,
    notes: String,
  },
  { _id: false }
);

const appointmentSchema = new mongoose.Schema(
  {
    medicine: [medicineSchema],
    avoidSunlight: String,
    diagnosis: String,
    instructions: String,
    followUp: String,
    allergy: String,
    repeat: String,
    symptoms: String,
    icdCode: String,
  },
  { _id: false }
);

const totalSchema = new mongoose.Schema(
  {
    medicineName: String,

    quantity: Number,
    price: String,
    amount: String,
  },
  { _id: false }
);

const invoiceSchema = new mongoose.Schema(
  {
    invoiceDate: {
      type: Date,
      default: Date.now(),
    },

    invoiceNo: {
      type: String,
    },

    pharmacy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "pharmacie",
    },
    orderId: {
      type: mongoose.Schema.Types.ObjectId,
    },

    items: [totalSchema],

    totalPrice: {
      type: String,
    },
  },

  { _id: false, timestamps: true }
);

const date: any = new Date();

const orderSchema: Schema = new Schema<Order>(
  {
    booking: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "booking",
    },

    service: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "service",
    },
    problem: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "healthproblem",
    },
    pharmacy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "pharmacie",
    },
    patient: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "patient",
    },
    consultant: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "doctor",
    },
    amount: {
      type: Number,
      default: 0,
    },
    rejectReason: {
      type: String,
    },
    deliveryDate: {
      type: Date,
      default: date.setDate(date.getDate() + 5),
    },
    orderStatus: {
      type: String,
      default: orderStatus.pending,
      enum: orderStatus,
    },
    prescription: {
      type: [{ type: appointmentSchema }],
    },
    invoice: {
      type: [{ type: invoiceSchema }],
    },
  },
  { timestamps: true }
);

export default model<Order>("order", orderSchema);
