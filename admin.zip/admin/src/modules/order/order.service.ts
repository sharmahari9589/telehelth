import { Types } from "mongoose";
import patientModel from "../patient/patient.model";
import pharmacyModel from "../pharmacy/pharmacy.Model";
import orderModel, { Order } from "./order.model";
import consultantModel from "../consultant/consultant.model";
import healthProblemModel from "../questionnaire/healthProblem.model";
import bookingModel from "../booking/booking.model";
import serviceModel from "../services/service.model";

export async function getOrdersByPatientId(
  patientId: Types.ObjectId
): Promise<Array<Order | null>> {
  return await orderModel.find({ patient: patientId });
}

export async function getOrderByPharmacyId(
  pharmacyId: Types.ObjectId
): Promise<Array<Order | null>> {
  return await orderModel.find({ pharmacy: pharmacyId });
}

export async function getOrderByConsultantId(
  consultantId: Types.ObjectId
): Promise<Array<Order | null>> {
  return await orderModel.find({ consultant: consultantId });
}

export async function createOrder(createOrderDto: any): Promise<Order> {
  return await orderModel.create(createOrderDto);
}

export async function getOrders(
  orderStatus: string,
  firstName: string,
  startDate: string,
  endDate: string,
  limit: any,
  page: any
): Promise<Array<Order>> {
  if (orderStatus && firstName == "" && startDate == "" && endDate == "") {
    return orderModel
      .find({ orderStatus: orderStatus })
      .populate({ path: "pharmacy", model: pharmacyModel })
      .populate({ path: "booking", model: bookingModel })
      .populate({ path: "consultant", model: consultantModel })
      .populate({ path: "problem", model: healthProblemModel })
      .populate({ path: "service", model: serviceModel });
  }

  if (firstName && orderStatus == "" && startDate == "" && endDate == "") {
    return orderModel.aggregate([
      {
        $lookup: {
          from: "pharmacies",
          localField: "pharmacy",
          foreignField: "_id",
          as: "pharmacy",
        },
      },
      {
        $unwind: {
          path: "$pharmacy",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $match: {
          "pharmacy.storeName": {
            $regex: firstName,
            $options: "i",
          },
        },
      },
      {
        $lookup: {
          from: "bookings",
          localField: "booking",
          foreignField: "_id",
          as: "booking",
        },
      },
      {
        $unwind: {
          path: "$booking",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "doctors",
          localField: "consultant",
          foreignField: "_id",
          as: "doctor",
        },
      },
      {
        $unwind: {
          path: "$doctor",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "healthproblems",
          localField: "problem",
          foreignField: "_id",
          as: "problem",
        },
      },
      {
        $unwind: {
          path: "$problem",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "services",
          localField: "service",
          foreignField: "_id",
          as: "service",
        },
      },
      {
        $unwind: {
          path: "$service",
          preserveNullAndEmptyArrays: true,
        },
      },
    ]);
  }

  if (startDate && orderStatus == "" && firstName == "" && endDate == "") {
    return orderModel
      .find({ deliveryDate: { $gte: new Date(startDate) } })
      .populate({ path: "pharmacy", model: pharmacyModel })
      .populate({ path: "booking", model: bookingModel })
      .populate({ path: "consultant", model: consultantModel })
      .populate({ path: "problem", model: healthProblemModel })
      .populate({ path: "service", model: serviceModel })
      .sort({ deliveryDate: 1 });
  }

  if (endDate && orderStatus == "" && firstName == "" && startDate == "") {
    return orderModel
      .find({ deliveryDate: { $lte: new Date(endDate) } })
      .populate({ path: "pharmacy", model: pharmacyModel })
      .populate({ path: "booking", model: bookingModel })
      .populate({ path: "consultant", model: consultantModel })
      .populate({ path: "problem", model: healthProblemModel })
      .populate({ path: "service", model: serviceModel })
      .sort({ deliveryDate: -1 });
  }

  if (startDate && endDate && orderStatus == "" && firstName == "") {
    return orderModel
      .find({
        deliveryDate: {
          $gte: new Date(startDate),
          $lte: new Date(endDate),
        },
      })
      .populate({ path: "pharmacy", model: pharmacyModel })
      .populate({ path: "booking", model: bookingModel })
      .populate({ path: "consultant", model: consultantModel })
      .populate({ path: "problem", model: healthProblemModel })
      .populate({ path: "service", model: serviceModel })
      .sort({ deliveryDate: 1 });
  }

  if (startDate && endDate && orderStatus && firstName == "") {
    return orderModel
      .find({
        $and: [
          {
            deliveryDate: {
              $gte: new Date(startDate),
              $lte: new Date(endDate),
            },
          },
          { orderStatus: orderStatus },
        ],
      })
      .populate({ path: "pharmacy", model: pharmacyModel })
      .populate({ path: "booking", model: bookingModel })
      .populate({ path: "consultant", model: consultantModel })
      .populate({ path: "problem", model: healthProblemModel })
      .populate({ path: "service", model: serviceModel })
      .sort({ deliveryDate: 1 });
  }
  if (startDate && endDate && orderStatus && firstName) {
    return orderModel
      .aggregate([
        {
          $lookup: {
            from: "pharmacies",
            localField: "pharmacy",
            foreignField: "_id",
            as: "pharmacy",
          },
        },
        {
          $unwind: {
            path: "$pharmacy",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "bookings",
            localField: "booking",
            foreignField: "_id",
            as: "booking",
          },
        },
        {
          $unwind: {
            path: "$booking",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "consultant",
            foreignField: "_id",
            as: "doctor",
          },
        },
        {
          $unwind: {
            path: "$doctor",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: {
            $and: [
              {
                "pharmacy.storeName": {
                  $regex: firstName,
                  $options: "i",
                },
              },
              {
                deliveryDate: {
                  $gte: new Date(startDate),
                  $lte: new Date(endDate),
                },
              },
              { orderStatus: orderStatus },
            ],
          },
        },
      ])
      .sort({ deliveryDate: 1 });
  }

  if (startDate && endDate == "" && orderStatus && firstName == "") {
    return orderModel
      .find({
        $and: [
          {
            deliveryDate: {
              $gte: new Date(startDate),
            },
          },
          {
            orderStatus: orderStatus,
          },
        ],
      })
      .populate({ path: "pharmacy", model: pharmacyModel })
      .populate({ path: "booking", model: bookingModel })
      .populate({ path: "consultant", model: consultantModel })
      .populate({ path: "problem", model: healthProblemModel })
      .populate({ path: "service", model: serviceModel })
      .sort({ deliveryDate: 1 });
  }

  if (startDate && endDate && orderStatus == "" && firstName) {
    return orderModel
      .aggregate([
        {
          $lookup: {
            from: "pharmacies",
            localField: "pharmacy",
            foreignField: "_id",
            as: "pharmacy",
          },
        },
        {
          $unwind: {
            path: "$pharmacy",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "bookings",
            localField: "booking",
            foreignField: "_id",
            as: "booking",
          },
        },
        {
          $unwind: {
            path: "$booking",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "consultant",
            foreignField: "_id",
            as: "doctor",
          },
        },
        {
          $unwind: {
            path: "$doctor",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: {
            $and: [
              {
                "pharmacy.storeName": {
                  $regex: firstName,
                  $options: "i",
                },
              },
              {
                deliveryDate: {
                  $gte: new Date(startDate),
                  $lte: new Date(endDate),
                },
              },
            ],
          },
        },
      ])
      .sort({ deliveryDate: 1 });
  }

  if (startDate && endDate == "" && orderStatus && firstName) {
    return orderModel
      .aggregate([
        {
          $lookup: {
            from: "pharmacies",
            localField: "pharmacy",
            foreignField: "_id",
            as: "pharmacy",
          },
        },
        {
          $unwind: {
            path: "$pharmacy",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "bookings",
            localField: "booking",
            foreignField: "_id",
            as: "booking",
          },
        },
        {
          $unwind: {
            path: "$booking",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "consultant",
            foreignField: "_id",
            as: "doctor",
          },
        },
        {
          $unwind: {
            path: "$doctor",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: {
            $and: [
              {
                "pharmacy.storeName": {
                  $regex: firstName,
                  $options: "i",
                },
              },
              {
                deliveryDate: {
                  $gte: new Date(startDate),
                },
              },
              { orderStatus: orderStatus },
            ],
          },
        },
      ])
      .sort({ deliveryDate: 1 });
  }
  if (startDate && endDate == "" && orderStatus == "" && firstName) {
    return orderModel
      .aggregate([
        {
          $lookup: {
            from: "pharmacies",
            localField: "pharmacy",
            foreignField: "_id",
            as: "pharmacy",
          },
        },
        {
          $unwind: {
            path: "$pharmacy",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "bookings",
            localField: "booking",
            foreignField: "_id",
            as: "booking",
          },
        },
        {
          $unwind: {
            path: "$booking",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "consultant",
            foreignField: "_id",
            as: "doctor",
          },
        },
        {
          $unwind: {
            path: "$doctor",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: {
            $and: [
              {
                "pharmacy.storeName": {
                  $regex: firstName,
                  $options: "i",
                },
              },
              {
                deliveryDate: {
                  $gte: new Date(startDate),
                },
              },
            ],
          },
        },
      ])
      .sort({ deliveryDate: 1 });
  }

  if (startDate == "" && endDate && orderStatus && firstName) {
    return orderModel
      .aggregate([
        {
          $lookup: {
            from: "pharmacies",
            localField: "pharmacy",
            foreignField: "_id",
            as: "pharmacy",
          },
        },
        {
          $unwind: {
            path: "$pharmacy",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "bookings",
            localField: "booking",
            foreignField: "_id",
            as: "booking",
          },
        },
        {
          $unwind: {
            path: "$booking",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "consultant",
            foreignField: "_id",
            as: "doctor",
          },
        },
        {
          $unwind: {
            path: "$doctor",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: {
            $and: [
              {
                "pharmacy.storeName": {
                  $regex: firstName,
                  $options: "i",
                },
              },
              {
                deliveryDate: {
                  $lte: new Date(endDate),
                },
              },
              { orderStatus: orderStatus },
            ],
          },
        },
      ])
      .sort({ deliveryDate: -1 });
  }

  if (startDate == "" && endDate && orderStatus && firstName == "") {
    return orderModel
      .find({
        $and: [
          {
            deliveryDate: {
              $lte: new Date(endDate),
            },
          },
          { orderStatus: orderStatus },
        ],
      })
      .populate({ path: "pharmacy", model: pharmacyModel })
      .populate({ path: "booking", model: bookingModel })
      .populate({ path: "consultant", model: consultantModel })
      .populate({ path: "problem", model: healthProblemModel })
      .populate({ path: "service", model: serviceModel })
      .sort({ deliveryDate: -1 });
  }

  if (startDate == "" && endDate && orderStatus == "" && firstName) {
    return orderModel
      .aggregate([
        {
          $lookup: {
            from: "pharmacies",
            localField: "pharmacy",
            foreignField: "_id",
            as: "pharmacy",
          },
        },
        {
          $unwind: {
            path: "$pharmacy",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "bookings",
            localField: "booking",
            foreignField: "_id",
            as: "booking",
          },
        },
        {
          $unwind: {
            path: "$booking",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "consultant",
            foreignField: "_id",
            as: "doctor",
          },
        },
        {
          $unwind: {
            path: "$doctor",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $match: {
            $and: [
              {
                "pharmacy.storeName": {
                  $regex: firstName,
                  $options: "i",
                },
              },
              {
                deliveryDate: {
                  $lte: new Date(endDate),
                },
              },
            ],
          },
        },
      ])
      .sort({ deliveryDate: -1 });
  }

  if (startDate == "" && endDate == "" && orderStatus && firstName) {
    return orderModel.aggregate([
      {
        $lookup: {
          from: "pharmacies",
          localField: "pharmacy",
          foreignField: "_id",
          as: "pharmacy",
        },
      },
      {
        $unwind: {
          path: "$pharmacy",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "bookings",
          localField: "booking",
          foreignField: "_id",
          as: "booking",
        },
      },
      {
        $unwind: {
          path: "$booking",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "doctors",
          localField: "consultant",
          foreignField: "_id",
          as: "doctor",
        },
      },
      {
        $unwind: {
          path: "$doctor",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "healthproblems",
          localField: "problem",
          foreignField: "_id",
          as: "problem",
        },
      },
      {
        $unwind: {
          path: "$problem",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "services",
          localField: "service",
          foreignField: "_id",
          as: "service",
        },
      },
      {
        $unwind: {
          path: "$service",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $match: {
          $and: [
            {
              "pharmacy.storeName": {
                $regex: firstName,
                $options: "i",
              },
            },

            { orderStatus: orderStatus },
          ],
        },
      },
    ]);
  } else {
    return orderModel
      .find({})
      .populate({ path: "pharmacy", model: pharmacyModel })
      .populate({ path: "booking", model: bookingModel })
      .populate({ path: "consultant", model: consultantModel })
      .populate({ path: "problem", model: healthProblemModel })
      .populate({ path: "service", model: serviceModel })

      .limit(limit)
      .skip(limit * page - limit)
      .sort({ deliveryDate: -1 });
  }
}



export async function updateOrderById(
  orderId: Types.ObjectId,
  updateOrderDto: any
): Promise<Order | null> {
  return await orderModel.findByIdAndUpdate(orderId, updateOrderDto);
}
