import { Request, Response } from "express";
import httpStatus from "http-status";
import { Types } from "mongoose";
import orderModel, { Order } from "./order.model";
import * as orderService from "./order.service";
import ejs from "ejs";
import { getViewFile } from "../../utils/ejsHelper";

export async function createOrder(req: Request, res: Response) {
  try {
    const order = await orderService.createOrder(req.body);

    res.status(httpStatus.OK).send({
      status: httpStatus.OK,
      message: "Order created Successfully",
      data: order,
    });
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      status: httpStatus.INTERNAL_SERVER_ERROR,
      message: err.message,
    });
  }
}

export async function getOrders(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const limit = 10;
    const page = req.query.page || 1;

    const { orderStatus, fullName, startDate, endDate } = req.query;

    const orders: Array<Order> = await orderService.getOrders(
      orderStatus as string,
      fullName as string,
      startDate as string,
      endDate as string,
      limit,
      page
    );

    const count = await orderModel.find().count();

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: orders,
        message: "Orders fetched successfully",
        status: httpStatus.OK,
      });
    } else {
      const fileContent = getViewFile("adminDashboard", "order-list.ejs");
      const user: any = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          message: "",
          user,
          orders,
          activeTab: "vieworder",
          current: page,
          pages: Math.ceil(count / limit),
          filename: fileContent.templatePath,
        })
      );
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      status: httpStatus.INTERNAL_SERVER_ERROR,
      message: err.message,
    });
  }
}

export async function updateOrders(req: Request, res: Response) {
  try {
    const orderId: Types.ObjectId = new Types.ObjectId(req.params.id);
    const order: Order | null = await orderService.updateOrderById(
      orderId,
      req.body
    );
    res.status(httpStatus.OK).send({
      status: httpStatus.OK,
      message: "Orders update successfully",
      data: order,
    });
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      status: httpStatus.INTERNAL_SERVER_ERROR,
      message: err.message,
    });
  }
}
