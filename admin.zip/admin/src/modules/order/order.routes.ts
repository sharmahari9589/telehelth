import { Router } from "express";
import * as orderController from "./order.controller";

const router = Router();

router.get("/viewallorders", orderController.getOrders);
router.post("/", orderController.createOrder);
router.post("/update/:id", orderController.updateOrders);

export default router;
