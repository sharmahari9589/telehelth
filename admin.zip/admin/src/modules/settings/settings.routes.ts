import { Router } from "express";
import * as SettingsController from "./settings.controller";
import { jwtverify } from "../../middlewares";

const router = Router({
  mergeParams: true,
});

router.use(jwtverify);
router.get("/", SettingsController.getSettings);
router.put("/updateSettings", SettingsController.updateSettings);
export default router;
