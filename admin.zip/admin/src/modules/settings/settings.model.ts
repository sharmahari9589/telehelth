import mongoose from "mongoose";

const settingSchema = new mongoose.Schema();

export default mongoose.model("setting", settingSchema);
