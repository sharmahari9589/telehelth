import { Request, Response } from "express";
import httpStatus from "http-status";
import * as emailService from "./email.service";
import { Types } from "mongoose";

//EJS Rendor
import ejs from "ejs";
import { getViewFile } from "../../utils/ejsHelper";
import { log } from "console";
import { Booking } from "../booking/booking.model";
import * as consultantservices from "../consultant/consultant.service";

/**
 * @description This function is for Create Email Management
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function createEmail(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const user: any = JSON.parse(res.get("user")!);
    const userid = new Types.ObjectId(user._id);

    const manageBooking: Array<Booking> =
      await consultantservices.myUpcomingBooking(
        userid
        // parseInt(limit as string),
        // parseInt(page as string)
      );
    const emailDto = {
      emailPlatform: req.body.emailPlatform,
      email: req.body.email,
      appPassword: req.body.appPassword,
      userId: userid,
    };

    if (mode == "api") {
      //API Code
      const emailData = await emailService.createEmail(emailDto);
      res.status(httpStatus.OK).send({
        data: emailData,
        message: "Email created successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code
      const getAllEmails = await emailService.getEmailByUserId(userid);
      const fileContent = getViewFile(
        "consultantDashboard",
        "emailSending.ejs"
      );
      if (req.method == "GET") {
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            getAllEmails,
            manageBooking,
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Code Start
        const getAllEmails = await emailService.getEmailByUserId(userid);

        if (getAllEmails) {
          const updateEmail = await emailService.updateEmail(
            getAllEmails._id,
            emailDto
          );

          res.send(
            ejs.render(fileContent.file, {
              message: "Email Update Sucessfully",
              user,
              updateEmail,
              getAllEmails,
              manageBooking,
              filename: fileContent.templatePath,
            })
          );
          //Post Code End
        } else {
          const emailData = await emailService.createEmail(emailDto);

          const updateEmail = await emailService.getEmailByUserId(userid);

          res.send(
            ejs.render(fileContent.file, {
              message: "Email Created Sucessfully",
              user,
              updateEmail,
              emailData,
              getAllEmails,
              manageBooking,
              filename: fileContent.templatePath,
            })
          );
          //Post Code End
        }
      }
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Internal server error",
    });
  }
}

/**
 * @description This function is for Update Email
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function updateEmail(req: Request, res: Response) {
  try {
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Internal server error",
    });
  }
}
