import { Types } from "mongoose";
import specialityModel, { Speciality } from "./speciality.model";

export async function getSpecialities(
  name: string,
  limit: number,
  page: number
) {
  if (name) {
    return await specialityModel.find({
      name: {
        $regex: name,
        $options: "i",
      },
    });
  } else {
    return await specialityModel.find();
  }
}

export async function createSpeciality(
  createSpecialityDto: any
): Promise<Speciality> {
  return await specialityModel.create(createSpecialityDto);
}

export async function updateSpeciality(
  specialityId: Types.ObjectId,
  updateSpecialityDto: any
): Promise<Speciality | null> {
  return await specialityModel.findByIdAndUpdate(
    specialityId,
    updateSpecialityDto,
    {
      new: true,
    }
  );
}

export async function deleteSpeciality(
  specialityId: Types.ObjectId
): Promise<Speciality | null> {
  return await specialityModel.findByIdAndDelete(specialityId);
}

export async function specialityServices(
  name: String
): Promise<Speciality | null> {
  return specialityModel.findOne({ name });
}
