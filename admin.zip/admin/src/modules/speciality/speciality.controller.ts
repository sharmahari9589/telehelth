import { Request, Response } from "express";
import httpStatus from "http-status";
import { Types } from "mongoose";
import * as specialityServices from "./speciality.service";

//EJS Rendor
import ejs from "ejs";
import { getViewFile } from "../../utils/ejsHelper";

export async function createSpeciality(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    if (mode == "api") {
      const { name } = req.body;
      const existingSpeciality = await specialityServices.specialityServices(
        name
      );
      if (existingSpeciality) {
        res.status(httpStatus.BAD_REQUEST).send({
          status: httpStatus.BAD_REQUEST,
          message: "Speciality with this name already exists",
        });
      }
      const speciality = await specialityServices.createSpeciality(req.body);
      res.status(httpStatus.OK).send({
        data: speciality,
        message: "Speciality created successully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      const { name } = req.body;
      const existingSpeciality = await specialityServices.specialityServices(
        name
      );
      if (existingSpeciality) {
        const fileContent = getViewFile("adminDashboard", "speciality.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "Speciality with this name already exists",
            user,
            activeTab: "speciality",
            filename: fileContent.templatePath,
          })
        );
      }
      const speciality = await specialityServices.createSpeciality(req.body);
      // const fileContent = getViewFile("adminDashboard", "speciality.ejs");
      //   const user: any = JSON.parse(res.get('user')!);
      //   res.send(
      //     ejs.render(fileContent.file, {
      //       message: "Speciality created successully",
      //       user,
      //       filename: fileContent.templatePath
      //     }));
      //Web Code Start
      res.redirect("/admin/web/speciality?search=&page=1&limit=10");
      //Web Code End
      //Web Code End
    }
  } catch (error) {
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Internal server error",
      status: httpStatus.INTERNAL_SERVER_ERROR,
    });
  }
}

export async function getSpeciality(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { search, limit, page, name } = req.query;

    const specialities = await specialityServices.getSpecialities(
      name as string,
      parseInt(limit as string),
      parseInt(page as string)
    );
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: specialities,
        message: "Specialities fetched successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      const fileContent = getViewFile("adminDashboard", "speciality.ejs");
      const user: any = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          message: "",
          user,
          activeTab: "speciality",
          specialities,
          filename: fileContent.templatePath,
        })
      );
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Internal server error",
    });
  }
}

export async function updateSpeciality(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const specialityId: Types.ObjectId = new Types.ObjectId(
      req.params.specialityId
    );
    const speciality = await specialityServices.updateSpeciality(
      specialityId,
      req.body
    );
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        message: "Speciality updated successfully",
        data: speciality,
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      res.redirect("/admin/web/speciality?search=&page=1&limit=10");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      status: httpStatus.OK,
      message: "internal server error",
      data: error,
    });
  }
}

export async function deleteSpeciality(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const specialityId: Types.ObjectId = new Types.ObjectId(
      req.params.specialityId
    );
    const speciality = await specialityServices.deleteSpeciality(specialityId);
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        message: "Speciality deleted successfully",
        data: speciality,
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      res.redirect("/admin/web/speciality?search=&page=1&limit=10");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      status: httpStatus.OK,
      message: "internal server error",
      data: error,
    });
  }
}
