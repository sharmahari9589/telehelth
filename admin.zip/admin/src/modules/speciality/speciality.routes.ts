import { Router } from "express";
import * as specialityController from "./speciality.controller";

const router = Router();

router
  .route("/")
  .get(specialityController.getSpeciality)
  .post(specialityController.createSpeciality);
router.post("/update/:specialityId", specialityController.updateSpeciality);
router.post("/delete/:specialityId", specialityController.deleteSpeciality);

export default router;
