import { Types } from "mongoose";
import consultantModel, { Consultant } from "./consultant.model";
import scheduleModel, { Schedule } from "../../modules/schedule/schedule.model";
import bookingModel from "../booking/booking.model";

export async function getSchedule(
  doctorId: Types.ObjectId
): Promise<Schedule | null> {
  return scheduleModel.findOne({ doctor: doctorId });
}

export async function findConsultants(
  search: string,
  problemId: Types.ObjectId,
  limit: number,
  page: number
): Promise<Array<Consultant>> {
  return await consultantModel
    .find({
    
    })
    .limit(limit)
    .skip((page - 1) * limit);
}


export async function myUpcomingBooking(_id: Types.ObjectId){
  // Get the current time
var currentTime = new Date();

// Add 5.5 hours (in milliseconds)
var addedTime = currentTime.getTime() + (3.5 * 60 * 60 * 1000);

// Create a new Date object with the added time
var newTime = new Date(addedTime);


  return await bookingModel.aggregate([
    {
      '$match': {
        'doctor': _id
      }
    }, {
      '$match': {
        'status': 'accepted',
        'startTime':{$gte:newTime}
      },
      
    }, {
      '$lookup': {
        'from': 'patients', 
        'localField': 'patient', 
        'foreignField': '_id', 
        'as': 'patient'
      }
    }, {
      '$unwind': {
        'path': '$patient', 
        'preserveNullAndEmptyArrays': true
      }
    },
    {
      $sort:{"startTime":1}
    }
  ])
}