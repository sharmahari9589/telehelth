import mongoose, { Schema, model, Document } from "mongoose";

export enum Gender {
  Male = "male",
  Female = "female",
  Other = "other",
  Transgender = "transgender",
  Notdisclosed = "notDisclosed",
}

export enum MaritialStatus {
  Married = "married",
  Single = "single",
  Partnered = "partnered",
  Divorce = "divorce",
  Widow = "widow",
  Others = "others",
  Notdisclosed = "notDisclosed",
}

export interface Consultant extends Document {
  firstName: string;
  lastName: string;
  email: string;
  password?: string;
  mobileNumber: string;
  gender: Gender;
  maritialStatus: MaritialStatus;
  dateOfBirth: Date;
  experience: Array<string>;
  medicalDegree: string;
  specialistDegree: string;
  indemnityCertificate: string;
  medicalCouncilCertificate: string;
  cctCertification: string;
  indemnityExpiryDate: Date;
  medicalCouncilExpiryDate: Date;
  speciality: Array<string>;
  description: string;
  profilePic: string;
  medicalCouncilNo: string;
  medicalEmail: string;
  medicalPhoneNo: string;
  medicalAddress: string;
  signature: string;
  restricLogin: Boolean;

  location: any;
  eirCode: string;
  qualification: string;
  isDeleted: boolean;
  callStatus: String;
  role: {
    permission: {
      documentCenter: {
        view: boolean;
      };
      questionnaire: {
        view: boolean;
      };
      booking: {
        view: boolean;
      };
      manageRole: {
        view: boolean;
      };
      template: {
        view: boolean;
      };
      manageTemplate: {
        view: boolean;
      };
      email: {
        view: boolean;
      };
      myCalander: {
        view: boolean;
      };
      chat: {
        view: boolean;
      };
    };
  };
  isAllow: Boolean;
}

const accessSchema: Schema = new mongoose.Schema(
  {
    create: {
      type: Boolean,
      default: true,
    },
    view: {
      type: Boolean,
      default: true,
    },
    update: {
      type: Boolean,
      default: true,
    },
    delete: {
      type: Boolean,
      default: true,
    },
  },
  { _id: false }
);

const consultantSchema: Schema = new Schema<Consultant>(
  {
    firstName: {
      type: String,
    },
    lastName: {
      type: String,
    },
    email: {
      type: String,
      unique: true,
      required: true,
    },
    restricLogin: {
      type: Boolean,
      default: true,
    },
    password: {
      type: String,
      required: true,
    },
    mobileNumber: {
      type: String,
    },
    gender: {
      type: String,
      enum: Gender,
    },
    maritialStatus: {
      type: String,
      enum: MaritialStatus,
    },
    dateOfBirth: {
      type: Date,
    },
    experience: {
      type: [{ type: String }],
    },
    medicalDegree: {
      type: String,
    },
    specialistDegree: {
      type: String,
    },
    indemnityCertificate: {
      type: String,
    },
    cctCertification: {
      type: String,
    },
    medicalCouncilCertificate: {
      type: String,
    },
    medicalCouncilExpiryDate: {
      type: Date,
    },
    indemnityExpiryDate: {
      type: Date,
    },

    speciality: {
      type: [{ type: String }],
    },
    description: {
      type: String,
    },
    eirCode: {
      type: String,
    },

    qualification: {
      type: String,
    },
    medicalAddress: {
      type: String,
    },
    medicalCouncilNo: {
      type: String,
    },
    medicalEmail: {
      type: String,
    },
    medicalPhoneNo: {
      type: String,
    },
    signature: {
      type: String,
    },

    profilePic: {
      type: String,
    },
    location: {
      type: String, // Don't do `{ location: { type: String } }`
    },
    isDeleted: {
      type: Boolean,
    },
    callStatus: {
      type: String,
    },
    role: {
      permission: {
        type: {
          documentCenter: accessSchema,
          questionnaire: accessSchema,
          booking: accessSchema,
          manageRole: accessSchema,
          manageTemplate: accessSchema,
          template: accessSchema,

          chat: accessSchema,
          email: accessSchema,
          myCalander: accessSchema,
        },
        default: {
          documentCenter: { view: true },
          questionnaire: { view: true },
          booking: { view: true },
          manageRole: { view: true },
          template: { view: true },
          manageTemplate: { view: true },
          chat: { view: true },
          myCalander: { view: true },
          email: { view: true },
        },
      },
    },
    isAllow: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
  }
);

export default model<Consultant>("doctor", consultantSchema);
