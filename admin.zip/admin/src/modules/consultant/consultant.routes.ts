import { Router } from "express";
import * as consultantController from "./consultant.controller";

const router = Router({
  mergeParams: true,
});

router.route("/get-consultant").get(consultantController.getConsultants);

router
  .route("/add-consultant")
  .get(consultantController.createConsultant)
  .post(consultantController.createConsultant);


  router
  .route("/consultant-decline-permisson")
  .get(consultantController.declinePermissonDcoctor)
  .post(consultantController.declinePermissonDcoctor);


  router
  .route("/consultant-login-permisson")
  .get(consultantController.acessPermisoonToDcoctor)
  .post(consultantController.acessPermisoonToDcoctor);
router
  .route("/multiple")
  .get(consultantController.createMultipleConsultant)
  .post(consultantController.createMultipleConsultant);

router
  .route("/update-consultant/:consultantId")
  .get(consultantController.updateConsultant)
  .post(consultantController.updateConsultant);

router
  .route("/delete-consultant/:consultantId")
  .get(consultantController.deleteConsultant)
  .post(consultantController.deleteConsultant);

export default router;
