import { Request, Response } from "express";
import httpStatus from "http-status";
import { Types } from "mongoose";
import consultantModel, { Consultant } from "./consultant.model";
import * as consultantsService from "./consultant.services";

//EJS Rendor
import ejs from "ejs";
import { getViewFile } from "../../utils/ejsHelper";
import specialityModel from "../speciality/speciality.model";
import { log } from "console";
export async function getConsultants(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { name, speciality } = req.query;
    const limit = 10;
    const page = Number(req.query.page) || 1;

    const consultants: Array<Consultant> =
      await consultantsService.getConsultants(
        name as string,
        speciality as string,
        limit,
        page
      );

    const count = await consultantModel.find().count();

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: consultants,
        message: "consultants fetched successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      const user: any = JSON.parse(res.get("user")!);
      const fileContent = getViewFile(
        "adminDashboard",
        "view-consultant-list.ejs"
      );
      res.send(
        ejs.render(fileContent.file, {
          message: "consultants fetched successfully",
          consultants,
          user,
          activeTab: "viewDoctor",
          current: page,
          pages: Math.ceil(count / limit),
          filename: fileContent.templatePath,
        })
      );
      //Web Code End
    }
  } catch (error) {
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ data: error });
    console.log(error);
  }
}

export async function declinePermissonDcoctor(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const { hasPermission, userId } = req.body;

    const consultantId = new Types.ObjectId(userId);

    const doctor = await consultantsService.findConsultantsById(
      consultantId,
      hasPermission
    );

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: "",
        message: "consultants fetched successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start

      res.send(doctor);
    }
  } catch (error) {
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ data: error });
    console.log(error);
  }
}

export async function acessPermisoonToDcoctor(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { name, speciality, page, limit } = req.query;

    const { hasPermission, userId } = req.body;

    const consultantId = new Types.ObjectId(userId);

    const doctor = await consultantsService.findConsultantsById(
      consultantId,
      hasPermission
    );

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: "",
        message: "consultants fetched successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start

      res.send(doctor);
      //Web Code End
    }
  } catch (error) {
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ data: error });
    console.log(error);
  }
}

export async function createConsultant(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
      const {
        fullName,
        email,
        gender,
        maritialStatus,
        status,
        experience,
        location,
        certificate,
        password,
        mobileNumber,
        confirmPassword,
        dateOfBirth,
        speciality,
        description,
      } = req.body;
      if (password !== confirmPassword) {
        res.status(httpStatus.BAD_REQUEST).send({
          message: "Password and confirm password doesn't matched",
          status: httpStatus.BAD_REQUEST,
        });
      }
      const consultant: Consultant | null =
        await consultantsService.getConsultantByEmail(email);
      if (consultant) {
        res.status(httpStatus.BAD_REQUEST).send({
          status: httpStatus.BAD_REQUEST,
          message: "Consultant already exists with this email Id",
        });
        return;
      }
      const encryptPassword = consultantsService.encryptedPassword(password);

      const name: Array<string> = fullName.split(" ");
      const createConsultantDto: any = {
        firstName: name.splice(0, 1).pop(),
        lastName: name.join(" "),
        email: email,
        gender: gender,
        maritialStatus: maritialStatus,
        status: status,
        experience: experience,
        location: location,
        certificate: certificate,
        password: encryptPassword,
        mobileNumber: mobileNumber,
        dateOfBirth: dateOfBirth,
        speciality: speciality,
        description: description,
      };
      const consultant_new: Consultant =
        await consultantsService.createConsultant(createConsultantDto);
      res.status(httpStatus.OK).send({
        data: consultant_new,
        message: "Consultant created successfully",
        status: httpStatus.OK,
      });
      return;
    } else {
      const specialities = await specialityModel.find();
      //Web Code Start
      if (req.method == "GET") {
        const user: any = JSON.parse(res.get("user")!);
        const fileContent = getViewFile("adminDashboard", "add-consultant.ejs");
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            activeTab: "addDoctor",
            user,
            consultant_new: "",
            specialities,
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code Start

        const {
          fullName,
          dob,
          gender,
          maritialStatus,
          email,
          eirCode,
          mobilenumber,
          experience,
          speciality,
          location,
          description,
          medicalDegree,
          specialistDegree,
          cct_Certification,
          medicalIndemnityCertificate,
          indemnityExpiryDate,
          medicalCouncilCertificate,
          medicalCouncilExpiryDate,
          password,
          confirmPassword,
          status,
        } = req.body;

        if (password !== confirmPassword) {
          const fileContent = getViewFile(
            "adminDashboard",
            "add-consultant.ejs"
          );

          res.send(
            ejs.render(fileContent.file, {
              message: "Password and confirm password doesn't matched",
              user: "",
              consultant_new: "",
              specialities,
              activeTab: "addDoctor",
              filename: fileContent.templatePath,
            })
          );
          return;
        }

        const consultant: Consultant | null =
          await consultantsService.getConsultantByEmail(email);

        if (consultant) {
          const fileContent = getViewFile(
            "adminDashboard",
            "add-consultant.ejs"
          );

          res.send(
            ejs.render(fileContent.file, {
              message: "Consultant already exists with this email Id",
              user: "",
              consultant_new: "",
              specialities,
              filename: fileContent.templatePath,
              activeTab: "addDoctor",
            })
          );
          return;
        }

        const medical = req.body.files[0]?.path;
        const medical1 = req.body.files[1]?.path;
        const medical2 = req.body.files[2]?.path;
        const medical3 = req.body.files[3]?.path;
        const medical4 = req.body.files[4]?.path;

        const encryptPassword = consultantsService.encryptedPassword(password);

        const name: Array<string> = fullName.split(" ");
        const createConsultantDto: any = {
          firstName: name.splice(0, 1).pop(),
          lastName: name.join(" "),
          email: email,
          password: encryptPassword,
          status: status,
          eirCode: eirCode,
          dateOfBirth: dob,
          speciality: speciality,
          description: description,
          gender: gender,
          maritialStatus: maritialStatus,
          mobileNumber: mobilenumber,
          experience: experience,
          location: location,
          cctCertification: medical2,
          medicalCouncilCertificate: medical4,
          medicalCouncilExpiryDate: medicalCouncilExpiryDate,
          indemnityCertificate: medical3,
          indemnityExpiryDate: indemnityExpiryDate,
          medicalDegree: medical,
          specialistDegree: medical1,
        };
        const user: any = JSON.parse(res.get("user")!);

        const consultant_new: Consultant =
          await consultantsService.createConsultant(createConsultantDto);
        const fileContent = getViewFile("adminDashboard", "add-consultant.ejs");

        res.send(
          ejs.render(fileContent.file, {
            message: "Consultant created successfully",
            user,
            consultant_new,
            specialities,
            activeTab: "addDoctor",
            filename: fileContent.templatePath,
          })
        );
        return;
        //Post Method Code End
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      messaage: "Internal server error",
      status: httpStatus.INTERNAL_SERVER_ERROR,
    });
  }
}

export async function updateConsultant(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const consultantId: Types.ObjectId = new Types.ObjectId(
      req.params.consultantId
    );

    const consultant = await consultantsService.updateConsultant(
      consultantId,
      req.body
    );
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        status: httpStatus.OK,
        message: "Consultant updated successfully",
        data: consultant,
      });
    } else {
      //Web Code Start
      res.redirect(
        "/admin/web/consultant/get-consultant?search=&page=1&limit=10"
      );
      //Web Code End
    }
  } catch (error) {
    console.log(error);
  }
}

export async function createMultipleConsultant(req: Request, res: Response) {
  try {
  } catch (error) {
    console.log(error);
  }
}

export async function deleteConsultant(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const consultantId: Types.ObjectId = new Types.ObjectId(
      req.params.consultantId
    );
    const consultant: Consultant | null =
      await consultantsService.deleteConsultant(consultantId);

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: consultant,
        message: "Consultants delted successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      res.redirect(
        "/admin/web/consultant/get-consultant?search=&page=1&limit=10"
      );
      //Web Code End
    }
  } catch (error) {
    console.log(error);
  }
}
