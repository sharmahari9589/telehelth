import mongoose, { Schema, model, Document } from "mongoose";

interface Services {
  durationInMin: number;
  price: number;
}

interface Breaks {
  startTime: number;
  endTime: number;
}

interface Availability {
  isAvailable: boolean;
  startTime: number;
  endTime: number;
  breaks: Array<Breaks>;
}

interface TimeOffs {
  startDate: Date;
  endDate: Date;
  startTime: number;
  endTime: number;
  isAllDay: boolean;
}

export interface Schedule extends Document {
  doctor: mongoose.Types.ObjectId;
  services: Array<Services>;
  availability: {
    monday: Availability;
    tuesday: Availability;
    wednesday: Availability;
    thursday: Availability;
    friday: Availability;
    saturday: Availability;
    sunday: Availability;
  };
  slotBuffer: number;
  timeOffs: Array<TimeOffs>;
}

const availabilitySchema: Schema = new Schema<Availability>(
  {
    isAvailable: mongoose.Schema.Types.Boolean,
    startTime: Number,
    endTime: Number,
    breaks: [{ startTime: Number, endTime: Number }],
  },
  {
    _id: false,
  }
);

const timeOffsSchema: Schema = new Schema(
  {
    startDate: Date,
    endDate: Date,
    startTime: Number,
    endTime: Number,
    isAllDay: mongoose.Schema.Types.Boolean,
  },
  {
    _id: false,
  }
);

const scheduleSchema: Schema = new Schema<Schedule>({
  doctor: {
    type: mongoose.Schema.Types.ObjectId,
  },
  services: [{ durationInMin: Number, price: Number }],
  availability: {
    monday: availabilitySchema,
    tuesday: availabilitySchema,
    wednesday: availabilitySchema,
    thursday: availabilitySchema,
    friday: availabilitySchema,
    saturday: availabilitySchema,
    sunday: availabilitySchema,
  },
  slotBuffer: {
    type: Number,
  },
  timeOffs: [{ type: timeOffsSchema }],
});

export default model<Schedule>("schedule", scheduleSchema);
