import { Types } from "mongoose";
import consultantModel, {
  Consultant,
  
} from "./consultant.model";

import bcrypt from "bcryptjs"
export async function getConsultants(
  name: string,
  speciality: string,
  limit: any,
  page: any
): Promise<Array<Consultant>> {
  
  if (name === undefined && speciality === undefined) {
    
    const query1 = { restricLogin: false };
    const query2 = { restricLogin: true };
    
    const data1 = await consultantModel.find(query1)
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ updatedAt: -1 });
  
    const data2 = await consultantModel.find(query2)
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ updatedAt: -1 });
;
      
  
    const data = [...data2, ...data1];
    
    return data;





   
  }
  


if(name && speciality == ""){
  const fullNameParts = name.split(' ');
const firstNameRegex = new RegExp(fullNameParts[0], 'i');
const lastNameRegex = new RegExp(fullNameParts.slice(1).join(' '), 'i');

if (fullNameParts.length === 1) {

  return await consultantModel.find({
   
    $or:[{
      firstName : { $regex: `^${firstNameRegex.source}`, $options: firstNameRegex.flags },
      },{
      lastName : { $regex: firstNameRegex }}],

}).limit(limit).skip((page - 1) * limit).sort({createdAt:-1});;


}

else{
  return await consultantModel.find({
   
       firstName:firstNameRegex,
       lastName: lastNameRegex, 
  
  }).limit(limit).skip((page - 1) * limit).sort({createdAt:-1});;
 }
}

 if(name=="" && speciality){
  return await consultantModel.find({
 speciality: { $regex: speciality, $options: "i" },
  }).limit(limit).skip((page - 1) * limit).sort({createdAt:-1});;
 }


 if(name && speciality){
  const fullNameParts = name.split(' ');
const firstNameRegex = new RegExp(fullNameParts[0], 'i');
const lastNameRegex = new RegExp(fullNameParts.slice(1).join(' '), 'i');

if (fullNameParts.length === 1) {

  return await consultantModel.find({
   
    $or:[{
      firstName : { $regex: `^${firstNameRegex.source}`, $options: firstNameRegex.flags },
      },{
      lastName : { $regex: firstNameRegex }},
      {speciality: { $regex: speciality, $options: "i" }},],

}).limit(limit).skip((page - 1) * limit).sort({createdAt:-1});;


}

else{
  return await consultantModel.find({
   
       firstName:firstNameRegex,
       lastName: lastNameRegex, 
       speciality: { $regex: speciality, $options: "i" },
  
  }).limit(limit).skip((page - 1) * limit).sort({createdAt:-1});;
 }
}

 else(name == ""&& speciality == "")
 {
  return await consultantModel.find().limit(limit).skip((page - 1) * limit).sort({createdAt:-1});;
 }

}
export async function createConsultant(
  createConsultantDto: any
): Promise<Consultant> {
  return await consultantModel.create(createConsultantDto);
}

export function encryptedPassword(
  password: string,
) {
  return bcrypt.hashSync(password, 10);
}

export async function updateConsultant(
  consultantId: Types.ObjectId,
  updateBody: any
): Promise<Consultant | null> {
  return await consultantModel.findByIdAndUpdate(consultantId, updateBody);
}

export async function getConsultantByEmail(
  email: string
): Promise<Consultant | null> {
  return await consultantModel.findOne({ email });
}

export async function deleteConsultant(
  consultantId: Types.ObjectId
): Promise<Consultant | null> {
  return await consultantModel.findByIdAndDelete(consultantId)
}

export async function consultantcount() {
  return await consultantModel.countDocuments();
}


export async function findConsultants(
  

): Promise<Consultant | null> {
  return await consultantModel.findOne()
}


export async function findConsultantsById(consultantId:Types.ObjectId,hasPermission:any ): Promise<Consultant | null> {
    return await consultantModel.findByIdAndUpdate(consultantId,{restricLogin:hasPermission})
  }
  
