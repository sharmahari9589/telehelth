import { Types } from "mongoose";
import pharmacyModel, { Pharmacy } from "./pharmacy.Model";
import bcrypt from "bcryptjs";
/**
 * @description this function is used to create the pharmacy
 * @param {any} createPharmacyDto
 * @returns {Promise<Pharmacy>}
 * @author Keshav suman
 */
export async function createPharmacy(
  createPharmacyDto: any
): Promise<Pharmacy> {
  return await pharmacyModel.create(createPharmacyDto);
}

export function encryptedPassword(password: string) {
  return bcrypt.hashSync(password, 10);
}
/**
 * @description thsi function is used to get pharmacies
 * @param {string} search
 * @param {number} page
 * @param {number} limit
 * @returns {Promise<Pharmacy>}
 * @author Keshav suman
 */

export async function getPharamcies(
  dto: any,
  page: any,
  limit: number
): Promise<Array<Pharmacy>> {
  if (dto.CHO) {
    return await pharmacyModel
      .find({ cho: dto.CHO })
      .skip(limit * page - limit)
      .sort({ createdAt: 1 });
  } else if (dto.EirCode) {
    return await pharmacyModel
      .find({ eircode: dto.EirCode })
      .sort({ createdAt: 1 });
  } else if (dto.fullName) {
    return await pharmacyModel
      .find({ storeName: { $regex: dto.fullName, $options: "i" } })
      .sort({ createdAt: 1 });
  } else if (dto.location) {
    return await pharmacyModel
      .find({ location: { $regex: dto.location, $options: "i" } })
      .sort({ createdAt: 1 });
  } else {
    return await pharmacyModel
      .find()
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
  }
}

/**
 * @description this function is used to xupdate the pharmacy
 * @param {Types.ObjectId} pharmacyId
 * @param {any} updatePharmacyDto
 * @returns {Promise<Pharmacy|null>}
 * @author Keshav suman
 */
export async function updatePharmacy(
  pharmacyId: Types.ObjectId,
  updatePharmacyDto: any
): Promise<Pharmacy | null> {
  return await pharmacyModel.findByIdAndUpdate(pharmacyId, updatePharmacyDto);
}

/**
 * @description THis fucntion is used to delete the pharamcy
 * @param pharmacyId
 * @returns
 */
export async function deletePharmacy(
  pharmacyId: Types.ObjectId
): Promise<Pharmacy | null> {
  return await pharmacyModel.findByIdAndDelete(pharmacyId);
}

export async function pharmacycount() {
  return await pharmacyModel.countDocuments();
}

export async function findPharmacyById(
  pharamcyId: Types.ObjectId,
  hasPermission: any
): Promise<Pharmacy | null> {
  return await pharmacyModel.findByIdAndUpdate(pharamcyId, {
    restricLogin: hasPermission,
  });
}

export async function getPharmacyByEmail(
  email: string
): Promise<Pharmacy | null> {
  return await pharmacyModel.findOne({ email });
}
