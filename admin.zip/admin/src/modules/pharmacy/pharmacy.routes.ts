import express from "express";
import * as pharmacyController from "./pharmacy.controller";
import verify from "../../middlewares/jwtAuth";

const route = express.Router({
  mergeParams: true,
});

route
  .route("/pharmacy-decline-permisson")
  .get(pharmacyController.declinePermissonPharmacy)
  .post(pharmacyController.declinePermissonPharmacy);

route
  .route("/pharmacy-login-permisson")
  .get(pharmacyController.acessPermissonToPharmacy)
  .post(pharmacyController.acessPermissonToPharmacy);

route
  .route("/add-pharmacy")
  .get(pharmacyController.createPharmacy)
  .post(pharmacyController.createPharmacy);
route.get("/get-pharmacy", pharmacyController.getPharmacies);
route.post("/update-pharmacy/:id", pharmacyController.updatePharamcy);
route.post("/delete-pharmacy/:id", pharmacyController.deletePharmacy);

//Export Route
export default route;
