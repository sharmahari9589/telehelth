import { Schema, model, Document } from "mongoose";
export enum Gender {
  Male = "male",
  Female = "female",
  Other = "other",
  Transgender = "transgender",
  Notdisclosed = "notDisclosed",
}

export enum MaritialStatus {
  Married = "married",
  Single = "single",
  Partnered = "partnered",
  Divorce = "divorce",
  Widow = "widow",
  Others = "others",
  Notdisclosed = "notDisclosed",
}

export interface Pharmacy extends Document {
  firstName: string;
  lastName: string;
  storeName: string;
  gender: Gender;
  maritialStatus: MaritialStatus;

  email: string;
  password: string;
  dlNumber: string;
  mobileNumber: string;
  description: string;
  location: string;
  cho: string;
  country: string;
  eircode: string;
  // healthmail:string;
  opening_Hours: any;
  isDeleted: Boolean;
  securityQuestion: string;
  securityAnswer: string;
  restricLogin: Boolean;
  certificate: Array<string>;
}

const pharmacySchema: Schema = new Schema<Pharmacy>(
  {
    firstName: {
      type: String,
    },
    lastName: {
      type: String,
    },
    storeName: {
      type: String,
    },
    email: {
      type: String,
      unique: false,
      //  required: true,
    },
    password: {
      type: String,
      // required: true,
    },
    dlNumber: {
      type: String,
    },
    mobileNumber: {
      type: String,
    },
    description: {
      type: String,
    },
    location: {
      type: String,
    },
    cho: {
      type: String,
    },
    country: {
      type: String,
    },
    eircode: {
      type: String,
    },
    certificate: {
      type: [{ type: String }],
    },
    // healthmail:{
    //   type:String
    // },
    opening_Hours: {
      type: Schema.Types.Mixed,
    },

    isDeleted: {
      type: Boolean,
      default: false,
    },
    securityQuestion: {
      type: String,
    },
    securityAnswer: {
      type: String,
    },

    restricLogin: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true,
  }
);

export default model<Pharmacy>("pharmacie", pharmacySchema);
