import { Request, Response } from "express";
import httpStatus from "http-status";
import { Types } from "mongoose";
import * as eirService from "./eircode-service";
import * as notification from "../notification/notification.controller";

//EJS Rendor
import ejs from "ejs";
import { getViewFile } from "../../utils/ejsHelper";
import eirModel from "./eircode-model";
import consultantModel from "../consultant/consultant.model";
import eircodeModel from "./eircode-model";

/**
 * @description This function is for Dashboard
 * @param req
 * @param res
 * @author sourav argade
 */
export async function viewEirCodes(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const limit = 10;
    const page: any = req.query.page || 1;
    const { eirCode } = req.query;

    let eirCodes;

    if (eirCode) {
      eirCodes = await eirModel.aggregate([
        {
          $match: {
            $or: [{ eirCode: { $regex: eirCode, $options: "i" } },
            { location: { $regex: eirCode, $options: "i" } },
        
        ],
          },
        },
      ]);
    } else {
      eirCodes = await eirModel
        .find()
        .limit(limit)
        .skip(limit * page - limit);
    }

    const count = await eirModel.find().count();

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("adminDashboard", "eir-code.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            activeTab: "eirCode",
            user,
            eirCodes,
            current: page,
            pages: Math.ceil(count / limit),
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function addEirCodes(req: Request, res: Response) {
  try {
    const userId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const { mode } = req.params;

    const eirCodes = await eirService.createEirCodes(req.body);

   

    if (mode == "api") {
    } else {
      //Web Code Start
      res.redirect("/admin/web/view-eir-code");
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function editEirCodes(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const eirId: Types.ObjectId = new Types.ObjectId(req.body.id);

    const icdCode = await eirService.updateEirCodes(eirId, req.body);

    if (mode == "api") {
    } else {
      //Web Code Start
      res.redirect("/admin/web/view-eir-code");
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function deleteEirCode(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const eirId: Types.ObjectId = new Types.ObjectId(req.body.id);

    const icdCode = await eirService.deleteEirCodes(eirId);

    if (mode == "api") {
    } else {
      //Web Code Start
      res.redirect("/admin/web/view-eir-code");
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}





export async function eirSuggestion(req: Request, res: Response) {
  try {
    const { limit, page } = req.query;

    const { mode } = req.params;

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: "",
        message: "Booking update successfully",
        status: httpStatus.OK,
      });
    } else {
      //web code
      

      const  eircode = req.body.eircode;

      const suggestions: any = await eircodeModel.find(
        { location: { $regex:  eircode, $options: "i" } },
        "name"
      );

      

      const Id: Types.ObjectId = suggestions.map((e: any) => {
        return e._id;
      });

      const  eircodes = await eircodeModel.find({ _id: Id });

      

      res.json({ suggestions:  eircodes });
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}