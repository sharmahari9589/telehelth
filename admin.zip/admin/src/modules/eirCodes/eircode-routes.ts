import { Router } from "express";
import * as icdController from "./eircode-controller";

const appRoutes = Router({
  mergeParams: true,
});

appRoutes
  .route("/view-eir-code")
  .get(icdController.viewEirCodes)
  .post(icdController.viewEirCodes);

  appRoutes
  .route("/get-eircode")
  .get(icdController.eirSuggestion)
  .post(icdController.eirSuggestion);

appRoutes
  .route("/add-eir-code")
  .get(icdController.addEirCodes)
  .post(icdController.addEirCodes);

appRoutes
  .route("/edit-eir-code")
  .get(icdController.editEirCodes)
  .post(icdController.editEirCodes);

appRoutes
  .route("/delete-eir-code")
  .get(icdController.deleteEirCode)
  .post(icdController.deleteEirCode);

export default appRoutes;
