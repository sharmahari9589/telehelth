import { Types } from "mongoose";
import eircodeModel, { EirCodes } from "./eircode-model";
 "./eircode-model";


export async function createEirCodes(createEirDto: any): Promise<EirCodes> {
  return await eircodeModel.create(createEirDto);
}

export async function updateEirCodes(
  eirId: Types.ObjectId,
  updateBody: any
): Promise<EirCodes | null> {
  return await eircodeModel.findByIdAndUpdate(eirId, updateBody);
}

export async function deleteEirCodes(
  eirId: Types.ObjectId
): Promise<EirCodes | null> {
  return await eircodeModel.findByIdAndDelete(eirId);
}
