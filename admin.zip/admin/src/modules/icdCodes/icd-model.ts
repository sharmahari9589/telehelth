import { Schema, model, Document } from "mongoose";

export interface IcdCodes extends Document {
  icdCode: string;
  description: string;
}

const icdCodesSchema: Schema = new Schema<IcdCodes>({
  icdCode: {
    type: String,
  },

  description: {
    type: String,
  },
});

export default model<IcdCodes>("icdCode", icdCodesSchema);
