import { Types } from "mongoose";
import icdModel, { IcdCodes } from "./icd-model";

export async function createIcdCodes(createIcdDto: any): Promise<IcdCodes> {
  return await icdModel.create(createIcdDto);
}

export async function updateIcdCodes(
  icdId: Types.ObjectId,
  updateBody: any
): Promise<IcdCodes | null> {
  return await icdModel.findByIdAndUpdate(icdId, updateBody);
}

export async function deleteIcdCodes(
  icdId: Types.ObjectId
): Promise<IcdCodes | null> {
  return await icdModel.findByIdAndDelete(icdId);
}
