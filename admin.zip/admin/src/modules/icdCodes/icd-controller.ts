import { Request, Response } from "express";
import httpStatus from "http-status";
import { Types } from "mongoose";
import * as icdService from "./icd-services";
import * as notification from "../notification/notification.controller";

//EJS Rendor
import ejs from "ejs";
import { getViewFile } from "../../utils/ejsHelper";
import icdModel from "./icd-model";
import consultantModel from "../consultant/consultant.model";

/**
 * @description This function is for Dashboard
 * @param req
 * @param res
 * @author sourav argade
 */
export async function viewIcdCodes(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const limit = 10;
    const page: any = req.query.page || 1;
    const { icdCode } = req.query;

    let icdCodes;

    if (icdCode) {
      icdCodes = await icdModel.aggregate([
        {
          $match: {
            $or: [{ icdCode: { $regex: icdCode, $options: "i" } }],
          },
        },
      ]);
    } else {
      icdCodes = await icdModel
        .find()
        .limit(limit)
        .skip(limit * page - limit);
    }

    const count = await icdModel.find().count();

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("adminDashboard", "icd-code.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            activeTab: "icdCode",
            user,
            icdCodes,
            current: page,
            pages: Math.ceil(count / limit),
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function addIcdCodes(req: Request, res: Response) {
  try {
    const userId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const { mode } = req.params;

    const icdCodes = await icdService.createIcdCodes(req.body);

    if (icdCodes) {
      const doctors = await consultantModel.find();
      //Create Notification
      const createNotificationDto: any = {
        notificationTitle: "New ICD Code Added Sucessfully",
        notificationDescription: "Notification Description",
        notificationBy: userId,
        notificationTo: doctors,
        notificationType: "icd10_notification",
        notificationTypeId: userId,
      };

      const d: any = await notification.createNotification(
        createNotificationDto
      );
    }

    if (mode == "api") {
    } else {
      //Web Code Start
      res.redirect("/admin/web/view-icd-code");
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function editIcdCodes(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const icdId: Types.ObjectId = new Types.ObjectId(req.body.id);

    const icdCode = await icdService.updateIcdCodes(icdId, req.body);

    if (mode == "api") {
    } else {
      //Web Code Start
      res.redirect("/admin/web/view-icd-code");
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function deleteIcdCode(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const icdId: Types.ObjectId = new Types.ObjectId(req.body.id);

    const icdCode = await icdService.deleteIcdCodes(icdId);

    if (mode == "api") {
    } else {
      //Web Code Start
      res.redirect("/admin/web/view-icd-code");
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}
