import { Router } from "express";
import * as icdController from "./icd-controller";

const appRoutes = Router({
  mergeParams: true,
});

appRoutes
  .route("/view-icd-code")
  .get(icdController.viewIcdCodes)
  .post(icdController.viewIcdCodes);

appRoutes
  .route("/add-icd-code")
  .get(icdController.addIcdCodes)
  .post(icdController.addIcdCodes);

appRoutes
  .route("/edit-icd-code")
  .get(icdController.editIcdCodes)
  .post(icdController.editIcdCodes);

appRoutes
  .route("/delete-icd-code")
  .get(icdController.deleteIcdCode)
  .post(icdController.deleteIcdCode);

export default appRoutes;
