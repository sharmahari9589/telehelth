import { Router } from "express";
import * as templateController from "./template.controller";

const router: Router = Router({ mergeParams: true });

router
  .route("/createTemplate")
  .get(templateController.createTemplate)
  .post(templateController.createTemplate);

router.get("/getTemplate", templateController.getTemplate);
router
  .route("/updateTemplate/:id")
  .get(templateController.updateTemplate)
  .post(templateController.updateTemplate);

router.route("/deleteTemplate/:id").post(templateController.deleteTemplate);

//Use Template
router.route("/useTemplate/:id").post(templateController.useTemplate);

//Send Template
router.route("/sendTemplate").post(templateController.sendTemplate);
export default router;
