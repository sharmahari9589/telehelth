import { Types } from "mongoose";
import templateModel, { Template } from "./template.model";

export async function createTemplate(data: any) {
  return await templateModel.create({
    addedBy: data.addedBy,
    name: data.name,
    description: data.description,
    isPrimary: data.isPrimary,
    htmlPart: data.htmlPart,
  });
}

export async function getTemplateById(
  templateId: Types.ObjectId
): Promise<Template | null> {
  return await templateModel.findOne({
    _id: templateId,
  });
}

export async function getTemplateByAddedBy(
  addedBy: Types.ObjectId,
  name: any
): Promise<Array<Template>> {
  if (name) {
    return await templateModel
      .find({
        addedBy: addedBy,
        name: { $regex: name, $options: "i" },
      })
      .sort({ createdAt: -1 });
  } else {
    return await templateModel
      .find({
        addedBy: addedBy,
      })
      .sort({ createdAt: -1 });
  }
}

export async function updateTemplate(
  templateId: Types.ObjectId,
  // templateData: any
  htmlPart: any
): Promise<Template | null> {
  return await templateModel.findByIdAndUpdate(templateId, { htmlPart });
}

export async function deleteTemplate(
  templateId: Types.ObjectId
): Promise<Template | null> {
  return await templateModel.findByIdAndDelete(templateId);
}

export async function updatePreviewTemplate(
  templateId: Types.ObjectId,
  previewHtml: any
): Promise<Template | null> {
  return await templateModel.findByIdAndUpdate(templateId, { previewHtml });
}
