import { Request, Response } from "express";
import httpStatus from "http-status";
import * as templateService from "./template.service";
import { Types } from "mongoose";
import { sendMail } from "../../utils/sendMail";

//EJS Rendor
import ejs from "ejs";
import { getViewFile } from "../../utils/ejsHelper";
import { log } from "console";
import { types } from "util";
import consultantModel from "../consultant/consultant.model";
import * as notification from "../notification/notification.controller";

export async function createTemplate(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const user: any = JSON.parse(res.get("user")!);
    const adminId = new Types.ObjectId(user._id);

    let userid;
    if (user.addedBy == undefined) {
      userid = adminId;
    } else {
      userid = new Types.ObjectId(user.addedBy);
    }

    if (mode == "api") {
      //API Code
      res.status(httpStatus.OK).send({
        data: ``,
        message: "Template created successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code
      const fileContent = getViewFile("adminDashboard", "create-templete.ejs");
      if (req.method == "GET") {
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "creTemp",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Code Start
        if (req.body.editor1) {
          const templateDto = {
            htmlPart: req.body.editor1,
            name: req.body.templateName,
            description: req.body.templateDescription,
            addedBy: userid,
          };
          const templateData = await templateService.createTemplate(
            templateDto
          );

          if (templateData) {
            const doctors = await consultantModel.find();
            //Create Notification
            const createNotificationDto: any = {
              notificationTitle: "New Template Added Sucessfully",
              notificationDescription: "Notification Description",
              notificationBy: userid,
              notificationTo: doctors,
              notificationType: "template_notification",
              notificationTypeId: userid,
            };

            const d: any = await notification.createNotification(
              createNotificationDto
            );
          }
          res.redirect("/admin/web/getTemplate");
          //Post Code End
        } else {
          const fileContent = getViewFile(
            "adminDashboard",
            "create-templete.ejs"
          );
          res.send(
            ejs.render(fileContent.file, {
              message: "Create Proper Tempalte",
              user,
              filename: fileContent.templatePath,
            })
          );
        }
      }
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Internal server error",
    });
  }
}

export async function getTemplate(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const limit = 10;
    const page = req.query.page || 1;
    let name = req.query.search;
    if (mode == "api") {
      const addedById: Types.ObjectId = new Types.ObjectId(res.get("addedBy")!);
      const templateId: Types.ObjectId = new Types.ObjectId(
        res.get("templateId")!
      );

      if (!addedById && !templateId)
        return res.status(httpStatus.BAD_REQUEST).send({
          data: null,
          message: "Id is required",
          status: httpStatus.BAD_REQUEST,
        });
      if (addedById) {
        const templateData = await templateService.getTemplateByAddedBy(
          addedById,
          name
        );
        res.status(httpStatus.OK).send({
          data: templateData,
          message: "Template fetched successfully",
          status: httpStatus.OK,
        });
      } else {
        const templateData = await templateService.getTemplateById(templateId);
        res.status(httpStatus.OK).send({
          data: templateData,
          message: "Template fetched successfully",
          status: httpStatus.OK,
        });
      }
    } else {
      //Nikhil Code Start
      const user: any = JSON.parse(res.get("user")!);

      const adminId = new Types.ObjectId(user._id);

      let userid;
      if (user.addedBy == undefined) {
        userid = adminId;
      } else {
        userid = new Types.ObjectId(user.addedBy);
      }

      const templates = await templateService.getTemplateByAddedBy(
        userid,
        name
      );
      const fileContent = getViewFile("adminDashboard", "view-templete.ejs");
      res.send(
        ejs.render(fileContent.file, {
          message: "",
          user,
          activeTab: "viewTemp",
          templates,
          filename: fileContent.templatePath,
        })
      );
      //Nikhil Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Internal server error",
    });
  }
}

export async function updateTemplate(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const templateId: Types.ObjectId = new Types.ObjectId(req.params.id);

    // Get Only Value Start
    const requestBody: { [key: string]: string } = req.body;
    const keys = Object.keys(requestBody);
    const key = keys[0];
    const value = requestBody[key];
    //Get Only Value End
    const template = await templateService.updateTemplate(templateId, value);

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        message: "Template updated successfully",
        //data: template,
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      res.redirect("/admin/web/getTemplate");
      //Web COde End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Internal server error",
    });
  }
}

export async function deleteTemplate(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const templateId: Types.ObjectId = new Types.ObjectId(req.params.id);
    const template = await templateService.deleteTemplate(templateId);

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        message: "Template deleted successfully",
        data: null,
        status: httpStatus.OK,
      });
    } else {
      res.redirect("/admin/web/getTemplate");
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Internal server error",
    });
  }
}

export async function useTemplate(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const templateId: Types.ObjectId = new Types.ObjectId(req.params.id);

    let template = await templateService.getTemplateById(templateId);
    let html: any = template?.htmlPart;

    const replaceObject: any = req.body;
    for (const key in replaceObject) {
      html = html.replace(new RegExp(`{{${key}}}`, "g"), replaceObject[key]);
    }

    // var removedPTags = html.replace(/<\/?p>/g, '');

    // var removedNBSP = removedPTags.replace(/&nbsp;/g, ' ');

    var removedTags = html.replace(/<[^>]*>/g, "");

    var removedNBSP = removedTags.replace(/&nbsp;|<li>/g, " ");

    const previewHtml = await templateService.updatePreviewTemplate(
      templateId,
      html
    );

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        message: "Template successfully",
        data: null,
        status: httpStatus.OK,
      });
    } else {
      //res.redirect('/consultant/web/getTemplate');
      const fileContent = getViewFile("adminDashboard", "prviewTemplate.ejs");
      res.send(
        ejs.render(fileContent.file, {
          message: "",
          previewHtml,
          html,
          removedNBSP,
          activeTab: "viewTemp",
          filename: fileContent.templatePath,
        })
      );
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Internal server error",
    });
  }
}
export async function sendTemplate(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    
    const to = req.body.to;
    const subject = req.body.subject;

    const mailBody = `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        / Inline CSS for styling /
        body {
          font-family: Arial, sans-serif;
          line-height: 1.6;
          margin: 0;
          padding: 0;
        }
        .container {
          max-width: 600px;
          margin: 0 auto;
          padding: 20px;
        }
        h1 {
          font-size: 24px;
        }
        / Add more inline styles as needed /
      </style>
    </head>
    <body>
      <div class="container">
       <pre style="line-height: normal; font-size: 12px; font-family: 'Helvetica'; border: none;">${req.body.mailBody.trimStart()}</pre>
      </div>
    </body>
    </html>
    `;
    let result = await sendMail(to,subject,mailBody);

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        message: "Template sent successfully",
        data: null,
        status: httpStatus.OK,
      });
    }else{
    if(result){
      const user: any = JSON.parse(res.get("user")!);

      const adminId = new Types.ObjectId(user._id)

      let userid;
   if (user.addedBy== undefined){
     userid =adminId 
   }
   else{
     userid =new Types.ObjectId( user.addedBy)
   }
let name;

     const templates =  await templateService.getTemplateByAddedBy(userid,name);
     const fileContent = getViewFile("adminDashboard","view-templete.ejs");
     res.send(
       ejs.render(fileContent.file, {
         message: "Template sent successfully",
         user,activeTab:'viewTemp',
         templates,
         filename: fileContent.templatePath,
       })
     );
    }
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Internal server error",
    });
  }
}
