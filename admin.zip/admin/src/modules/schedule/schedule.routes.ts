import { Router } from "express";
import * as scheduleController from "./schedule.controller";

const appRouter = Router({
  mergeParams: true,
});

appRouter.route("/count").get(scheduleController.scheduleCount);

appRouter.get("/getschedule", scheduleController.getMySchedule);

appRouter.post("/updateschedule", scheduleController.updateMySchedule);

appRouter
  .route("/get-slot")
  .get(scheduleController.getSlotByReDate)
  .post(scheduleController.getSlotByReDate);

export default appRouter;
