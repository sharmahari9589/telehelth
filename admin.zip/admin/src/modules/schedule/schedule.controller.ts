import { Request, Response } from "express";
import httpStatus from "http-status";
import { ObjectId, Types } from "mongoose";
import * as scheduleService from "./schedule.service";
import { sendMail } from "../../utils/sendMail";

//EJS Rendor
import ejs from "ejs";
import { getViewFile } from "../../utils/ejsHelper";
import scheduleModel from "./schedule.model";
import { log } from "console";
import { devNull } from "os";
import moment from "moment";
import consultantModel from "../consultant/consultant.model";
import { Booking } from "../booking/booking.model";
const availabilityData: any = {
  1: "monday",
  2: "tuesday",
  3: "wednesday",
  4: "thursday",
  5: "friday",
  6: "saturday",
  0: "sunday",
};
export async function getMySchedule(req: Request, res: Response) {
  try {
    const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const user = JSON.parse(res.get("user")!);
    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = id;
    } else {
      consultantId = user.addedBy;
    }
    const schedule = scheduleService.getMySchedule(consultantId);
    res.status(httpStatus.OK).send({
      data: schedule,
      message: "Schedule fetched successfully",
      status: httpStatus.OK,
    });
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.OK).send({
      message: err.message,
    });
  }
}

export async function updateMySchedule(req: Request, res: Response) {
  try {
    const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const user = JSON.parse(res.get("user")!);
    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = id;
    } else {
      consultantId = user.addedBy;
    }
    const schedule = scheduleService.getMySchedule(consultantId);
    res.status(httpStatus.OK).send({
      data: schedule,
      message: "Schedule fetched successfully",
      status: httpStatus.OK,
    });
  } catch (error) {
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function updateSchedule(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { scheduleId, services, availability, slotBuffer, timeOffs } =
      req.body;
    const schedule = await scheduleService.updateMySchedule(scheduleId, {
      services,
      availability,
      slotBuffer,
      timeOffs,
    });

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: schedule,
        message: "schedule update successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      //Web Code End
    }
  } catch (error) {
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function scheduleCount(req: Request, res: Response) {
  const { mode } = req.params;

  if (mode == "api") {
    res.status(httpStatus.OK).send({
      data: "",
      message: "pharmacy count succesfully",
      status: httpStatus.OK,
    });
  } else {
    //Web Code Start
    //Web Code End
  }
}

export async function getSlotByDate(req: Request, res: Response) {
  const { mode } = req.params;
  try {
    let {
      doctorId,
      date,
      slotTime,
    }: { date: any; doctorId: Types.ObjectId; slotTime: number } = req.body;
    date = new Date(date);
    const schedule: any = await scheduleService.getScheduleByDoctorId(doctorId);
    if (!schedule) {
      return res.status(404).json({ message: "Schedule not found" });
    }
    const dayOfWeek = new Date(date).getDay();

    const availability = schedule.availability[availabilityData[dayOfWeek]];
    if (!availability.isAvailable) {
      return res
        .status(404)
        .json({ message: "Doctor is not available on this day" });
    }
    const { startTime, endTime, breaks } = availability;
    const timeOffs = schedule.timeOffs.filter(
      (timeOff: {
        startDate: Date;
        endDate: Date;
        isAllDay: any;
        startTime: Date;
        endTime: Date;
      }) => {
        return (
          timeOff.startDate <= date &&
          timeOff.endDate >= date &&
          (timeOff.isAllDay ||
            (timeOff.startTime >= startTime && timeOff.endTime <= endTime))
        );
      }
    );
    const slots = generateSlots(slotTime, startTime, endTime, breaks, timeOffs);
    res.json(slots);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal server error" });
  }
  if (mode == "api") {
    res.status(httpStatus.OK).send({
      data: "",
      message: "pharmacy count succesfully",
      status: httpStatus.OK,
    });
  } else {
    //Web Code Start
    //Web Code End
  }
}

function generateSlots(
  slotTime: number,
  startTime: Date,
  endTime: Date,
  breaks: any[],
  timeOffs: any[]
): Date[] {
  const slots: Date[] = [];
  let currentSlot = startTime;
  while (currentSlot < endTime) {
    const isBreakTime = breaks.some((breakTime) => {
      return (
        currentSlot >= breakTime.startTime && currentSlot < breakTime.endTime
      );
    });
    const isTimeOff = timeOffs.some((timeOff) => {
      return (
        timeOff.isAllDay ||
        (currentSlot >= timeOff.startTime && currentSlot < timeOff.endTime)
      );
    });
    if (!isBreakTime && !isTimeOff) {
      slots.push(currentSlot);
    }
    
  }
  return slots;
}

export async function getSlotByReDate(req: Request, res: Response) {
  const { mode } = req.params;

  const userId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

  let {
    doctorId,
    date,
    timeSlot,
  }: { date: Date; doctorId: Types.ObjectId; timeSlot: string } = req.body;
  date = new Date(date);
  var slotTime = parseInt(timeSlot);

  try {
    const schedule: any = await scheduleService.getScheduleByDoctorId(doctorId);

    if (!schedule) {
      return res.json({ message: "Schedule not found" });
    }

    let end = new Date(date);
    end.setHours(23, 59, 59);

    let findBookRecord = await scheduleService.findSlotIsBooked(
      doctorId,
      userId,
      date,
      end
    );

    function findSlotIsBooked(start: Date, end: Date) {
      let isBooked = false;
      findBookRecord?.forEach((item: any) => {
        if (
          moment(item.startTime).format("HHmm") < moment(end).format("HHmm") &&
          moment(item.endTime).format("HHmm") > moment(start).format("HHmm")
        ) {
          isBooked = true;
        }
      });

      return isBooked;
    }
    const dayOfWeek = date.getDay(); // 0 (Sunday) through 6 (Saturday)

    const availabilityKey = dayOfWeekToString(dayOfWeek);

    if (!schedule.availability[0][availabilityKey]) {
      return res.json({ message: "Invalid date" });
    }

    const { isAvailable, startTime, endTime, breaks } =
      schedule.availability[0][availabilityKey];

    if (isAvailable == false) {
      return res.json({ message: "Doctor is not available on this date" });
    }

    const dates = startTime;
    const dateString = dates.toISOString();

    const timestamp = dateString;
    const milliseconds = moment.utc(timestamp).valueOf();

    // Convert start time, end time, and break times to milliseconds
    const startMs = startTime.getTime();
    const endMs = endTime.getTime();

    const breakMs = breaks?.map((breakTime: any) => ({
      start: breakTime.startTime.getTime(),
      end: breakTime.endTime.getTime(),
    }));

    const timeOffs = schedule.timeOffs.filter((timeOff: any) => {
      return (
        timeOff.startDate <= date &&
        timeOff.endDate >= date &&
        (timeOff.isAllDay ||
          (moment(startTime).format("HHmm") <
            moment(timeOff.endTime).format("HHmm") &&
            moment(endTime).format("HHmm") >
              moment(timeOff.startTime).format("HHmm")))
      );
    });

    // Calculate available time slots
    const slotDuration = slotTime * 60000; // Convert minutes to milliseconds
    // const slotBuffer = schedule.slotBuffer * 60000; // Convert minutes to milliseconds
    let slotBuffer = 0;
    const availableSlots = [];
    let slotStart = startMs;
    let slotEnd = slotStart + slotDuration;

    while (slotEnd <= endMs) {
      // Check if slot is within doctor's availability and not during a break
      const isWithinAvailability =
        slotStart >= startMs + slotBuffer &&
        slotEnd <= endMs - slotBuffer &&
        !breakMs.some(
          (breakTime: any) =>
            slotStart < breakTime.end && slotEnd > breakTime.start
        );

      let isAvailable =
        slotStart >= startMs + slotBuffer &&
        slotEnd <= endMs - slotBuffer &&
        !timeOffs.some(
          (timeOff: any) =>
            timeOff.isAllDay ||
            (moment(slotStart).format("HHmm") <
              moment(timeOff.endTime).format("HHmm") &&
              moment(slotEnd).format("HHmm") >
                moment(timeOff.startTime).format("HHmm"))
        );

      if (
        isWithinAvailability &&
        isAvailable &&
        !findSlotIsBooked(slotStart, slotEnd)
      ) {
        availableSlots.push({
          start: new Date(slotStart),
          end: new Date(slotEnd),
        });
      }

      // Move on to next time slot
      slotStart += slotDuration;
      slotEnd += slotDuration;
    }

    if (availableSlots) {
      if (availableSlots[0]) {
        const currentTime = new Date();

        if (currentTime.toDateString() === date.toDateString()) {
          const upcomingSlots = [];

          for (let i = 0; i < availableSlots.length; i++) {
            const slot = availableSlots[i];
            const oldSlot = new Date(slot.start);

            // Extract the time portion of the current time and oldSlot
            const currentTimeTime =
              currentTime.getHours() * 60 + currentTime.getMinutes();

            const oldSlotTime =
              oldSlot.getUTCHours() * 60 + oldSlot.getUTCMinutes();

            if (currentTimeTime < oldSlotTime) {
              upcomingSlots.push(slot);
            }
          }

          return res.json({ availableSlots: upcomingSlots });
        } else {
          // Dates don't match
          return res.json({ availableSlots });
        }
      } else {
        return res.json({ message: "The Doctor is on leave on this day" });
      }
    } else {
      return res.json({ message: "No available slots" });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Internal server error" });
  }
}

function dayOfWeekToString(dayOfWeek: number) {
  const daysOfWeek = [
    "sunday",
    "monday",
    "tuesday",
    "wednesday",
    "thursday",
    "friday",
    "saturday",
  ];
  return daysOfWeek[dayOfWeek];
}
