import mongoose, { model } from "mongoose";

const symptomsSchema = new mongoose.Schema({});
export default model("");
