import {
  BelongsTo,
  Column,
  DataType,
  ForeignKey,
  Model,
  Table,
} from "sequelize-typescript";
import User from "../authentication/user.model";

@Table({
  timestamps: true,
  paranoid: true,
  underscored: true,
})
class Payment extends Model {
  @Column({
    type: DataType.INTEGER,
    autoIncrement: true,
    primaryKey: true,
    allowNull: false,
  })
  id!: number;

  @Column({
    type: DataType.INTEGER,
    allowNull: false,
  })
  @ForeignKey(() => User)
  @BelongsTo(() => User, {
    as: "consultantId",
  })
  consultantid!: number;

  @ForeignKey(() => User)
  @BelongsTo(() => User, {
    as: "pharmacyId",
  })
  pharmacyid!: number;

  @ForeignKey(() => User)
  @BelongsTo(() => User, {
    as: "patientId",
  })
  patientid!: number;
}

export default Payment;
