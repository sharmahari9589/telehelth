import serviceModel from "../services/service.model";
import {
  countryModel,
  stateModel,
  cityModel,
  Country,
  State,
  City,
  languageModel,
  Language,
  Service,
  Commison,
  commisonModel,
} from "./masterData.model";
import { Types } from "mongoose";

/**
 * @description This function is used create country
 * @param createCountryDto
 * @returns {Promise<Country>}
 * @author Keshav suman
 */

export async function createCountry(createCountryDto: any): Promise<Country> {
  return await countryModel.create(createCountryDto);
}

/**
 * @description This function is used to get countries
 * @param {number} page
 * @param {number} limit
 * @returns {Promise<Array<Country>>}
 * @author Keshav suman
 */
export async function getCountries(
  page: number,
  limit: number
): Promise<Array<Country>> {
  return await countryModel
    .find({})
    .limit(limit)
    .skip((page - 1) * limit);
}

/**
 * @description This function is used to update the country
 * @param {Types.ObjectId} countryId
 * @param {any} updateCountryDto
 * @returns {Promise<Country>}
 * @author Keshav suman
 */
export async function updateCountry(
  countryId: Types.ObjectId,
  updateCountryDto: any
): Promise<Country | null> {
  return await countryModel.findByIdAndUpdate(countryId, updateCountryDto);
}

/**
 * @description this function is used to deleteCountry
 * @param {Types.ObjectId} countryId
 * @returns {Promise<Country>}
 */
export async function deleteCountry(
  countryId: Types.ObjectId
): Promise<Country | null> {
  return await countryModel.findByIdAndDelete(countryId);
}

// State master data

/**
 * @description this function is used to create state
 * @param {any} createCountryDto
 * @returns {Promise<State>}
 * @author Keshav suman
 */
export async function createState(createCountryDto: any): Promise<State> {
  return await stateModel.create(createCountryDto);
}

/**
 * @description this function is used to get the states
 * @param {number} page
 * @param {number} limit
 * @returns {Promise<Array<State>>}
 * @author Keshav suman
 */
export async function getState(
  page: number,
  limit: number
): Promise<Array<State>> {
  return await stateModel
    .find({})
    .limit(limit)
    .skip((page - 1) * limit);
}

/**
 * @description This function is used to update the state
 * @param {Types.ObjectId} stateId
 * @param {any} updateStateDto
 * @returns {Promise<State|null>}
 * @author Keshav suman
 */
export async function updateState(
  stateId: Types.ObjectId,
  updateStateDto: any
): Promise<State | null> {
  return await stateModel.findByIdAndUpdate(stateId, updateStateDto);
}

/**
 * @description This function is used to delete the state
 * @param {Types.ObjectId} stateId
 * @returns {Promise<State|null>}
 * @author Keshav suman
 */
export async function deleteState(
  stateId: Types.ObjectId
): Promise<State | null> {
  return await stateModel.findByIdAndDelete(stateId);
}

// City master data

/**
 * @description this function is used to city
 * @param {any} createCityDto
 * @returns {Promise<City>}
 * @author Keshav suman
 */
export async function createCity(createCityDto: any): Promise<City> {
  return await cityModel.create(createCityDto);
}

/**
 * @description This function is used to get the city
 * @param {number} page
 * @param {number} limit
 * @returns {Promise<Array<City>>}
 * @author Keshav suman
 */
export async function getCity(
  page: number,
  limit: number
): Promise<Array<City>> {
  return await cityModel
    .find({})
    .limit(limit)
    .skip((page - 1) * limit);
}

/**
 * @description This function is used to update the city
 * @param {Types.ObjectId} countryId
 * @param {any} updateCityDto
 * @returns {Promise<City|null>}
 * @author Keshav suman
 */
export async function updateCity(
  countryId: Types.ObjectId,
  updateCityDto: any
): Promise<City | null> {
  return await cityModel.findByIdAndUpdate(countryId, updateCityDto);
}

/**
 * @description This function is used to delete the city
 * @param {Types.ObjectId} countryId
 * @returns {Promise<City|null>}
 * @author Keshav suman
 */
export async function deleteCity(cityId: Types.ObjectId): Promise<City | null> {
  return await cityModel.findByIdAndDelete(cityId);
}

/**
 * @description This function is used to create the language
 * @param {any} createLanguageDto
 * @returns {Promise<Language>}
 * @author Keshav suman
 */
export async function createLanguage(
  createLanguageDto: any
): Promise<Language> {
  return await languageModel.create(createLanguageDto);
}

/**
 * @description this function is used to get the languages
 * @param {number} page
 * @param {number} limit
 * @returns {Promise<Array<Language>>}
 * @author Keshav suman
 */

export async function getLanguage(
  page: number,
  limit: number
): Promise<Array<Language>> {
  return await languageModel
    .find()
    .skip(page)
    .limit((page - 1) * limit);
}

/**
 * @description this function is used to update the language
 * @param {Types.ObjectId} languageId
 * @param {any} updateLanguageDto
 * @author Keshav suman
 * @returns {Promise<Language|null>}
 */

export async function updateLanguage(
  languageId: Types.ObjectId,
  updateLanguageDto: any
): Promise<Language | null> {
  return await languageModel.findByIdAndUpdate(languageId, updateLanguageDto);
}

/**
 * @description this function is used to delete the language
 * @param {Types.ObjectId} languageId
 * @author Keshav suman
 * @returns {Promise<Language|null>}
 */
export async function deleteLanguage(
  languageId: Types.ObjectId
): Promise<Language | null> {
  return await languageModel.findByIdAndDelete(languageId);
}

export async function createService(createServiceDto: any): Promise<Service> {
  return await serviceModel.create(createServiceDto);
}

export async function createCommison(
  createCommisonDto: any
): Promise<Commison> {
  return await commisonModel.create(createCommisonDto);
}

export async function getAllCommison(): Promise<Array<Commison>> {
  return await commisonModel.find();
}

/**
 * @description this function is used to update the language
 * @param {Types.ObjectId} commisonId
 * @param {any} updateLanguageDto
 * @author Keshav suman
 * @returns {Promise<Language|null>}
 */

export async function updateCommisonById(
  commisonId: Types.ObjectId,
  updateBodyDto: any
): Promise<Commison | null> {
  return await commisonModel.findByIdAndUpdate(commisonId, updateBodyDto);
}

/**
 * @description this function is used to delete the language
 * @param {Types.ObjectId}
 * @author Keshav suman
 * @returns {Promise<Language|null>}
 */
export async function deleteCommisonById(
  commisonId: Types.ObjectId
): Promise<Commison | null> {
  return await commisonModel.findByIdAndDelete(commisonId);
}
