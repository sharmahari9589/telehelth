import { Router } from "express";
import * as masterDataController from "./masterData.controller";

const router: Router = Router();

//Country
router
  .route("/countries")
  .get(masterDataController.getCountry)
  .post(masterDataController.createCountry);
router.post("/update-country/:id", masterDataController.updateCountry);
router.post("/delete-country/:id", masterDataController.deleteCountry);

//State
router
  .route("/state")
  .get(masterDataController.getState)
  .post(masterDataController.createState);
router.post("/update-state/:id", masterDataController.updateState);
router.post("/delete-state/:id", masterDataController.deleteState);

//City
router
  .route("/city")
  .get(masterDataController.getCities)
  .post(masterDataController.createCity);
router.post("/update-city/:id", masterDataController.updateCity);
router.post("/delete-city/:id", masterDataController.deleteCity);

//Language
router
  .route("/language")
  .get(masterDataController.getLanguage)
  .post(masterDataController.createLangauge);
router.post("/update-language/:id", masterDataController.updateLanguage);
router.post("/delete-language/:id", masterDataController.deleteLanguage);

//Services
router
  .route("/service")
  .get(masterDataController.getLanguage)
  .post(masterDataController.createServices);
router.post("/update-service/:id", masterDataController.updateLanguage);
router.post("/delete-service/:id", masterDataController.deleteLanguage);

router

  .route("/create-commison")
  .get(masterDataController.createCommison)
  .post(masterDataController.createCommison);

router

  .route("/commison")
  .get(masterDataController.getCommison)
  .post(masterDataController.getCommison);

router.post("/update-commison/:id", masterDataController.updateCommison);
router.post("/delete-commison/:id", masterDataController.deleteCommison);

export default router;
