import mongoose, { model, Schema } from "mongoose";

export interface Country {
  name: string;
  countryCode: string;
}

const countrySchema: Schema = new Schema<Country>({
  name: {
    type: String,
  },
  countryCode: {
    type: String,
  },
});

export interface State {
  name: string;
  country: mongoose.Types.ObjectId;
}

const stateSchema: Schema = new Schema<State>({
  name: {
    type: String,
  },
  country: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "country",
  },
});

export interface City {
  name: string;
  state: mongoose.Types.ObjectId;
}

const citySchema: Schema = new Schema<City>({
  name: {
    type: String,
  },
  state: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "state",
  },
});

export interface Language {
  name: string;
  langCode: string;
}

const languageSchema: Schema = new Schema<Language>({
  name: {
    type: String,
  },
  langCode: {
    type: String,
  },
});

export interface Service {
  name: string;
}

const ServiceSchema: Schema = new Schema<Service>({
  name: {
    type: String,
  },
});

export interface Commison {
  doctorCommison: Number;
  doctorTax: Number;
  pharmacyCommsion: Number;
  pharmacyTax: Number;
}

const CommisonSchema: Schema = new Schema<Commison>({
  doctorCommison: {
    type: Number,
  },
  doctorTax: {
    type: Number,
  },
  pharmacyCommsion: {
    type: Number,
  },
  pharmacyTax: {
    type: Number,
  },
});

export const countryModel = model<Country>("country", countrySchema);
export const stateModel = model<State>("state", stateSchema);
export const cityModel = model<City>("city", citySchema);
export const languageModel = model<Language>("language", languageSchema);
export const commisonModel = model<Commison>("commison", CommisonSchema);
