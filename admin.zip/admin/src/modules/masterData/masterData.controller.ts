import { Request, Response } from "express";
import httpStatus from "http-status";
import { Types } from "mongoose";
import * as masterDataService from "./masterData.service";

//EJS Rendor
import ejs from "ejs";
import { getViewFile } from "../../utils/ejsHelper";
import { commisonModel } from "./masterData.model";
import { log } from "console";

export async function createCountry(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { countryName, countryCode } = req.body;
    const data = masterDataService.createCountry({
      name: countryName,
      countryCode: countryCode,
    });

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: data,
        message: "Country created succesfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      res.redirect("/admin/web/master-data/countries?page=1&limit=10");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ message: err.message });
  }
}

export async function getCountry(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { limit, page } = req.query;
    const countries = await masterDataService.getCountries(
      parseInt(page as string),
      parseInt(limit as string)
    );
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: countries,
        message: "Countries fetched successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      const fileContent = getViewFile("adminDashboard", "add-country.ejs");
      const user: any = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          message: "",
          countries,
          user,
          activeTab: "country",
          filename: fileContent.templatePath,
        })
      );
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ message: err.message });
  }
}

export async function updateCountry(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const countryId: Types.ObjectId = new Types.ObjectId(req.params.id);
    const updateCountryDto: any = {
      ...req.body,
      name: req.body.countryName,
    };
    const country = await masterDataService.updateCountry(
      countryId,
      updateCountryDto
    );
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: country,
        message: "Country updated successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      res.redirect("/admin/web/master-data/countries?page=1&limit=10");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ message: err.message });
  }
}

export async function deleteCountry(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const countryId: Types.ObjectId = new Types.ObjectId(req.params.id);
    const country = await masterDataService.deleteCountry(countryId);
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: country,
        message: "Country created successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      res.redirect("/admin/web/master-data/countries?page=1&limit=10");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ message: err.message });
  }
}

// States
export async function createState(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { stateName } = req.body;
    const state = masterDataService.createState({ name: stateName });
    if (req.method == "api") {
      res.status(httpStatus.OK).send({
        data: state,
        message: "State created successfully",
        status: httpStatus.OK,
      });
    } else {
      res.redirect("/admin/web/master-data/state?page=1&limit=10");
    }
  } catch (error) {
    console.log(error);
    const err = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ message: err.message });
  }
}

export async function getState(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { limit, page } = req.query;
    const states = await masterDataService.getState(
      parseInt(page as string),
      parseInt(limit as string)
    );
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: states,
        message: "States fetched successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      const fileContent = getViewFile("adminDashboard", "add-state.ejs");
      const user: any = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          message: "",
          states,
          activeTab: "States",
          user,
          filename: fileContent.templatePath,
        })
      );
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ message: err.message });
  }
}

export async function updateState(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const stateId: Types.ObjectId = new Types.ObjectId(req.params.id);
    const updateStateDto: any = {
      ...req.body,
      name: req.body.stateName,
    };
    const state = await masterDataService.updateState(stateId, updateStateDto);
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: state,
        message: "state updated successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      res.redirect("/admin/web/master-data/state?page=1&limit=10");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ message: err.message });
  }
}

export async function deleteState(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const stateId: Types.ObjectId = new Types.ObjectId(req.params.id);
    const state = await masterDataService.deleteState(stateId);
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: state,
        message: "state created successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      res.redirect("/admin/web/master-data/state?page=1&limit=10");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ message: err.message });
  }
}

export async function createCity(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { cityName } = req.body;
    const city = masterDataService.createCity({ name: cityName });
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: city,
        message: "City created successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      res.redirect("/admin/web/master-data/city?page=1&limit=10");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ message: err.message });
  }
}

export async function getCities(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { limit, page } = req.query;
    const City = await masterDataService.getCity(
      parseInt(page as string),
      parseInt(limit as string)
    );
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: City,
        message: "Cities fetched successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      const fileContent = getViewFile("adminDashboard", "add-city.ejs");
      const user: any = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          message: "",
          City,
          activeTab: "cities",
          user,
          filename: fileContent.templatePath,
        })
      );
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ message: err.message });
  }
}

export async function updateCity(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const cityId: Types.ObjectId = new Types.ObjectId(req.params.id);
    const updateCityDto: any = {
      ...req.body,
      name: req.body.cityName,
    };
    const city = await masterDataService.updateCity(cityId, updateCityDto);
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: city,
        message: "City updated successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      res.redirect("/admin/web/master-data/city?page=1&limit=10");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ message: err.message });
  }
}

export async function deleteCity(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const cityId: Types.ObjectId = new Types.ObjectId(req.params.id);
    const city = await masterDataService.deleteCity(cityId);
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: city,
        message: "city deleted successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      res.redirect("/admin/web/master-data/city?page=1&limit=10");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ message: err.message });
  }
}

//Language
export async function createLangauge(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { languageName, langCode } = req.body;
    const language = masterDataService.createLanguage({
      name: languageName,
      langCode: langCode,
    });
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: language,
        message: "Language created successfully",
        status: httpStatus.CREATED,
      });
    } else {
      //Web Code Start
      res.redirect("/admin/web/master-data/language?page=1&limit=10");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ message: err.message });
  }
}

export async function getLanguage(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { limit, page } = req.query;
    const languages = await masterDataService.getLanguage(
      parseInt(page as string),
      parseInt(limit as string)
    );
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: languages,
        message: "Language created successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      const fileContent = getViewFile("adminDashboard", "add-language.ejs");
      const user: any = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          message: "Language created successfully",
          languages,
          user,
          activeTab: "cities",
          filename: fileContent.templatePath,
        })
      );
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ message: err.message });
  }
}

export async function updateLanguage(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const languageId: Types.ObjectId = new Types.ObjectId(req.params.id);
    const language = await masterDataService.updateLanguage(languageId, {
      ...req.body,
      name: req.body.languageName,
    });
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: language,
        message: "Language updated successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      res.redirect("/admin/web/master-data/language?page=1&limit=10");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ message: err.message });
  }
}

export async function deleteLanguage(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const languageId: Types.ObjectId = new Types.ObjectId(req.params.id);
    const language = await masterDataService.deleteLanguage(languageId);
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: language,
        message: "Language deleted successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      res.redirect("/admin/web/master-data/language?page=1&limit=10");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ message: err.message });
  }
}

export async function createServices(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { serviceName } = req.body;
    const service = masterDataService.createService({ name: serviceName });
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: service,
        message: "Service created successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      res.redirect("/admin/web/master-data/service?page=1&limit=10");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ message: err.message });
  }
}

export async function createCommison(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: "",
        message: "commison created successfully",
        status: httpStatus.OK,
      });
    } else {
      if (req.method == "GET") {
        const fileContent = getViewFile("adminDashboard", "add.commison.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "commison",
            filename: fileContent.templatePath,
          })
        );
      } else {
        const commisonExist = await commisonModel.find();

        if (commisonExist.length !== 0) {
          // Code to execute if the array is not blank and contains objects

          const allCommison = await masterDataService.getAllCommison();

          const fileContent = getViewFile(
            "adminDashboard",
            "view.commison.ejs"
          );
          const user: any = JSON.parse(res.get("user")!);
          res.send(
            ejs.render(fileContent.file, {
              message: "commsion already created",
              allCommison,
              user,
              activeTab: "commison",
              filename: fileContent.templatePath,
            })
          );
        } else {
          const { docCommison, docTax, pharmaCommison, pharmaTax } = req.body;

          var doctorCommison = parseInt(docCommison);
          var doctorTax = parseInt(docTax);
          var pharmacyCommsion = parseInt(pharmaCommison);
          var pharmacyTax = parseInt(pharmaTax);

          const commison = {
            doctorCommison,
            doctorTax,
            pharmacyCommsion,
            pharmacyTax,
          };

          const service = masterDataService.createCommison(commison);
          //Post Method Code
          //Web Code Start
          res.redirect("/admin/web/master-data/commison");
          //Web Code End
        }
      }
    }
  } catch (error) {
    console.log(error);
    const err = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ message: err.message });
  }
}

export async function getCommison(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { limit, page } = req.query;
    const allCommison = await masterDataService.getAllCommison();
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: allCommison,
        message: "",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      const fileContent = getViewFile("adminDashboard", "view.commison.ejs");
      const user: any = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          message: "",
          allCommison,
          user,
          activeTab: "commison",
          filename: fileContent.templatePath,
        })
      );
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ message: err.message });
  }
}

export async function updateCommison(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: "",
        message: "commison updated successfully",
        status: httpStatus.OK,
      });
    } else {
      const commisonId: Types.ObjectId = new Types.ObjectId(req.params.id);

      const { docCommison, docTax, pharmaCommison, pharmaTax } = req.body;

      var doctorCommison = parseInt(docCommison);
      var doctorTax = parseInt(docTax);
      var pharmacyCommsion = parseInt(pharmaCommison);
      var pharmacyTax = parseInt(pharmaTax);

      const bodyDto = {
        doctorCommison,
        doctorTax,
        pharmacyCommsion,
        pharmacyTax,
      };

      const commison = await masterDataService.updateCommisonById(
        commisonId,
        bodyDto
      );

      //Web Code Start
      res.redirect("/admin/web/master-data/commison");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ message: err.message });
  }
}

export async function deleteCommison(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const languageId: Types.ObjectId = new Types.ObjectId(req.params.id);
    const language = await masterDataService.deleteCommisonById(languageId);
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: language,
        message: "commison deleted successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      res.redirect("/admin/web/master-data/commison");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ message: err.message });
  }
}
