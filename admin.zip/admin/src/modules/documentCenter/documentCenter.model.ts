import mongoose, { Schema, model } from "mongoose";

export enum DocumentType {
  bloodResult = "bloodResult",
  imageingResult = "imageingResult",
  general = "general",
}

export interface TH_Document extends Document {
  documentURL: string;
  documentType: string;
  documentDescription: string;
  document_alias: string;
  document_type: DocumentType;
  document_mimeType: string;
  document_name: string;
  userId: mongoose.Schema.Types.ObjectId;
  isDeleted:Boolean
}

const documentSchema: Schema = new Schema<TH_Document>({
  documentURL: {
    type: String,
  },
  documentType: {
    type: String,
  },
  document_name: {
    type: String,
  },
  documentDescription: {
    type: String,
  },
  document_alias: {
    type: String,
  },
  document_type: {
    type: String,
    enum: DocumentType,
  },
  document_mimeType: {
    type: String,
  },
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
  },
  isDeleted:{
    type:Boolean,
    default:false
  }
 
},
{
  timestamps: true
});

export default model<TH_Document>("document", documentSchema);
