import { Types } from "mongoose";
import bookingModel, { Booking } from "../booking/booking.model";
import patientModel, { Patient } from "./patient.model";
import bcrypt from "bcryptjs";

export async function getPatients(
  search: string,
  limit: any,
  page: any
): Promise<Array<Patient>> {
  if (search == "") {
    return await patientModel
      .find()
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
  }

  if (search) {
    const fullNameParts = search.split(" ");
    const firstNameRegex = new RegExp(fullNameParts[0], "i");
    const lastNameRegex = new RegExp(fullNameParts.slice(1).join(" "), "i");

    if (fullNameParts.length === 1) {
      return await patientModel
        .find({
          $or: [
            {
              firstName: {
                $regex: `^${firstNameRegex.source}`,
                $options: firstNameRegex.flags,
              },
            },
            {
              lastName: { $regex: firstNameRegex },
            },
          ],
        })
        .limit(limit)
        .skip((page - 1) * limit)
        .sort({ createdAt: -1 });
    } else {
      return await patientModel
        .find({
          $or: [{ firstName: firstNameRegex }, { lastName: lastNameRegex }],
        })
        .limit(limit)
        .skip((page - 1) * limit)
        .sort({ createdAt: -1 });
    }
  } else {
    return await patientModel
      .find()
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
  }
}

export async function createPatient(createPatientDto: any): Promise<Patient> {
  return await patientModel.create(createPatientDto);
}

export async function createMultiplePatients() {}

export async function updatePatients(
  patientId: Types.ObjectId,
  updateBody: any
): Promise<Patient | null> {
  return await patientModel.findByIdAndUpdate(patientId, updateBody);
}

export async function getPatientByEmail(
  email: string
): Promise<Patient | null> {
  return await patientModel.findOne({ email });
}
export function encryptedPassword(password: string) {
  return bcrypt.hashSync(password, 10);
}

export async function deletePatient(
  patientId: Types.ObjectId
): Promise<Patient | null> {
  return await patientModel.findByIdAndDelete(patientId);
}
export async function patientcount() {
  return await patientModel.countDocuments();
}

export async function managePatients(
  search: string,

  page: number,
  startDate: Date,
  endDate: Date,
  consultantId: Types.ObjectId
): Promise<Array<Booking>> {
  const limit = 20;
  return await bookingModel.aggregate([
    {
      $match: {
        doctor: consultantId,
      },
    },
    {
      $lookup: {
        from: "patients",
        localField: "patient",
        foreignField: "_id",
        as: "patient",
      },
    },
    {
      $unwind: {
        path: "$patient",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $match: {
        $or: [
          {
            "patient.firstName": {
              $regex: search,
              $options: "i",
            },
          },
          {
            createdAt: {
              $gte: startDate,
              $lte: endDate,
            },
          },
        ],
      },
    },
    {
      $limit: limit,
    },
    {
      $skip: (page - 1) * limit,
    },
  ]);
}
