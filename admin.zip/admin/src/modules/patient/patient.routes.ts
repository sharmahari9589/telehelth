import { Router } from "express";
import * as patientController from "./patient.controller";

const router = Router({
  mergeParams: true,
});

router.route("/get-patient").get(patientController.getpatients);
router.route("/filter").get(patientController.getfilterData);

router
  .route("/add-patient")
  .get(patientController.createPatient)
  .post(patientController.createPatient);

router
  .route("/multiple")
  .get(patientController.createMultiplePatients)
  .post(patientController.createMultiplePatients);

router
  .route("/update-patient/:patientId")
  .get(patientController.updatePatient)
  .post(patientController.updatePatient);

router
  .route("/delete-patient/:patientId")
  .get(patientController.deletePatient)
  .post(patientController.deletePatient);

export default router;
