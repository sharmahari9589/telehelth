import { Request, Response } from "express";
import httpStatus from "http-status";
import { Types } from "mongoose";
import patientModel, { Patient } from "./patient.model";
import * as patientService from "./patient.services";

//EJS Rendor
import ejs from "ejs";
import { getViewFile } from "../../utils/ejsHelper";
import bookingModel, { Booking } from "../booking/booking.model";
import { log } from "console";

export async function getpatients(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const { fullName } = req.query;
    const limit = 10;
    const page = Number(req.query.page) || 1;

    const patients: Array<Patient> = await patientService.getPatients(
      fullName as string,
      limit,
      page
    );

    const count = await patientModel.find().count();

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: patients,

        message: "",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      const user: any = JSON.parse(res.get("user")!);

      const fileContent = getViewFile(
        "adminDashboard",
        "view-patient-list.ejs"
      );
      res.send(
        ejs.render(fileContent.file, {
          message: "",
          patients,
          user,
          activeTab: "viewPatient",
          current: page,
          pages: Math.ceil(count / limit),
          filename: fileContent.templatePath,
        })
      );

      //Web Code End
    }
  } catch (error) {
    console.log(error);

    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ data: error });
  }
}

export async function createPatient(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const {
      fullName,
      email,
      dob,
      maritialStatus,
      eirCode,
      mobilenumber,
      location,
      height_unit,
      weight_unit,
      gender,
      height,
      weight,
      password,
      confirmPassword,
    } = req.body;
    if (mode == "api") {
      if (password !== confirmPassword) {
        res.status(httpStatus.BAD_REQUEST).send({
          message: "Password and confirm password doesn't matched",
          status: httpStatus.BAD_REQUEST,
        });
      }
      const patient: Patient | null = await patientService.getPatientByEmail(
        email
      );
      if (patient) {
        res.status(httpStatus.BAD_REQUEST).send({
          status: httpStatus.BAD_REQUEST,
          message: "Patient already exists with this email Id",
        });
        return;
      }
      const name: Array<string> = fullName.split(" ");
      const createPatientDto: any = {
        firstName: name.splice(0, 1).pop(),
        lastName: name.join(" "),
        email: email,
        password: password,
        dateOfBirth: dob,
        mobileNumber: mobilenumber,
        location: location,
        height: height,
        weight: weight,
        height_unit: height_unit,
        weight_unit: weight_unit,
        gender: gender,
        maritialStatus: maritialStatus,
        eirCode: eirCode,
      };
      const consultant_new: Patient = await patientService.createPatient(
        createPatientDto
      );
      res.status(httpStatus.OK).send({
        data: consultant_new,
        message: "Patient created successfully",
        status: httpStatus.OK,
      });
      return;
    } else {
      //Web Code Start
      const user: any = JSON.parse(res.get("user")!);

      if (req.method == "GET") {
        const fileContent = getViewFile("adminDashboard", "add-patient.ejs");

        res.send(
          ejs.render(fileContent.file, {
            message: "",
            fullName,
            message3: "",
            message2: "",
            message1: "",

            email,
            dob,
            activeTab: "addPatient",
            mobilenumber,
            password,
            confirmPassword,
            gender,
            maritialStatus,
            height,
            weight,
            height_unit,
            weight_unit,
            eirCode,
            location,
            user,
            patient: "",
            filename: fileContent.templatePath,
          })
        );
      } else {
        const {
          fullName,
          email,
          dob,
          mobilenumber,
          password,
          confirmPassword,
          gender,
          maritialStatus,
          height,
          weight,
          height_unit,
          weight_unit,
          eirCode,
        } = req.body;

        if (password !== confirmPassword) {
          const fileContent = getViewFile("adminDashboard", "add-patient.ejs");
          res.send(
            ejs.render(fileContent.file, {
              message: "",
              message3: "",
              message2: "Password and confirm password doesn't matched",
              message1: "",

              user: "",
              fullName,
              email,
              dob,
              activeTab: "addPatient",
              mobilenumber,
              password,
              confirmPassword,
              gender,
              maritialStatus,
              height,
              weight,
              height_unit,
              weight_unit,
              eirCode,
              location,
              filename: fileContent.templatePath,
            })
          );
        } else {
          const patient: Patient | null =
            await patientService.getPatientByEmail(email);
          if (patient) {
            const fileContent = getViewFile(
              "adminDashboard",
              "add-patient.ejs"
            );

            res.send(
              ejs.render(fileContent.file, {
                message: "",
                message3: "Patient already exists with this Email",
                message2: "",
                message1: "",

                user: "",
                patient,
                fullName,
                email,
                dob,
                location,
                mobilenumber,
                password,
                activeTab: "addPatient",
                confirmPassword,
                gender,
                maritialStatus,
                height,
                weight,
                height_unit,
                weight_unit,
                eirCode,
                filename: fileContent.templatePath,
              })
            );
            return;
          } else {
            const encryptPassword = patientService.encryptedPassword(password);

            const name: Array<string> = fullName.split(" ");
            const createPatientDto: any = {
              firstName: name.splice(0, 1).pop(),
              lastName: name.join(" "),
              email: email,
              password: encryptPassword,
              dateOfBirth: dob,
              mobileNumber: mobilenumber,
              gender: gender,
              location: location,
              maritialStatus: maritialStatus,
              height: height,
              weight: weight,
              eirCode: eirCode,
              height_unit: height_unit,
              weight_unit: weight_unit,
            };
            const consultant_new: Patient = await patientService.createPatient(
              createPatientDto
            );
            const user: any = JSON.parse(res.get("user")!);

            const fileContent = getViewFile(
              "adminDashboard",
              "add-patient.ejs"
            );
            res.send(
              ejs.render(fileContent.file, {
                message: "Patient created successfully",
                message3: "",
                message2: "",
                message1: "",
                user,
                consultant_new,
                patient: "",
                fullName,
                email: "",
                dob: "",
                activeTab: "addPatient",
                mobilenumber: "",
                password: "",
                confirmPassword: "",
                gender: "",
                maritialStatus: "",
                height: "",
                weight: "",
                location: "",
                height_unit: "",
                weight_unit: "",
                eirCode: "",
                filename: fileContent.templatePath,
              })
            );
            return;
          }
        }
      }

      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      messaage: "Internal server error",
      status: httpStatus.INTERNAL_SERVER_ERROR,
    });
  }
}

export async function updatePatient(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const patientId: Types.ObjectId = new Types.ObjectId(req.params.patientId);
    const patient = await patientService.updatePatients(patientId, req.body);

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        status: httpStatus.OK,
        message: "Patient updated successfully",
        data: patient,
      });
    } else {
      //Web Code Start
      res.redirect("/admin/web/patient/get-patient?search=&page=1&limit=10");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      messaage: "Internal server error",
      status: httpStatus.INTERNAL_SERVER_ERROR,
    });
  }
}

export async function createMultiplePatients(req: Request, res: Response) {
  try {
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      messaage: "Internal server error",
      status: httpStatus.INTERNAL_SERVER_ERROR,
    });
  }
}

export async function deletePatient(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const patientId: Types.ObjectId = new Types.ObjectId(req.params.patientId);
    const patient: Patient | null = await patientService.deletePatient(
      patientId
    );
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: patient,
        message: "Internal server error",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      res.redirect("/admin/web/patient/get-patient?search=&page=1&limit=10");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Internal server error",
      status: httpStatus.INTERNAL_SERVER_ERROR,
    });
  }
}

//sourav

export async function getfilterData(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { search, page, startDate, endDate } = req.query;
    const consultantId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const patients: Array<Booking> = await patientService.managePatients(
      search as string,
      parseInt(page as string),
      new Date(startDate as string),
      new Date(endDate as string),
      consultantId
    );

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: patients,
        message: "patients fetched successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      const fileContent = getViewFile(
        "adminDashboard",
        "view-patient-list.ejs"
      );
      res.send(
        ejs.render(fileContent.file, {
          message: "patients fetched successfully",
          patients,
          user: "",
          activeTab: "viewPatient",
          filename: fileContent.templatePath,
        })
      );
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ data: error });
  }
}
