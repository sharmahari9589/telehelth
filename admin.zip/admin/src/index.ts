import * as express from "express";
import dotenv from "dotenv";
import Exceptionhandler from "./utils/exceptionhandler";
import router from "./app.routes";
import path from "path";
import cookieParser from "cookie-parser";
import { connect } from "mongoose";
import mongoose from "mongoose";

const app = express.default();

dotenv.config({
  path: ".env",
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

mongoose.set("strictQuery", false);

connect(process.env.MONGODB_URL!);

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "assets"));
app.use("/assets", express.static(path.join(__dirname, "assets")));

app.use("/:dashboardType", router);
app.use(Exceptionhandler);

app.listen(process.env.PORT, () => {
  console.log(`Server started at ${process.env.PORT}`);
});
