import mongoose, { model, Schema, Document, Types } from "mongoose";

export interface BMI extends Document {
  bmi: string;
  weight:string;
  height:string;
  weightUnit:string;
  heightUnit:string;
  addedBy: Types.ObjectId;
 
}

const bmiSchema: Schema = new Schema<BMI>(
  {
    bmi: {
      type: String,
    },
    weight: {
      type: String,
    },
    height: {
      type: String,
    },
    weightUnit: {
      type: String,
    },
   heightUnit: {
      type: String,
    },
    addedBy: {
     type: mongoose.Schema.Types.ObjectId,
      
    },
    
  },

  {
    timestamps: true,
  }
);

export default model<BMI>("bmi", bmiSchema);
