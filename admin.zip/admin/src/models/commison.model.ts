import mongoose, { model, Schema } from "mongoose";



export interface Commison {
  doctorCommison: Number;
  doctorTax: Number;
  pharmacyCommsion: Number;
  pharmacyTax: Number;
}


const CommisonSchema: Schema = new Schema<Commison>({
  doctorCommison: {
    type: Number,
  },
  doctorTax: {
    type: Number,
  },
  pharmacyCommsion: {
    type: Number,
  },
  pharmacyTax: {
    type: Number,
  }

});




export const commisonModel = model<Commison>("commison", CommisonSchema);
