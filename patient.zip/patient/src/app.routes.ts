import { Router } from "express";
import patientRoutes from "./modules/patientDashboard/patient.routes";
import documentRoutes from "./modules/documentCenter/documentCenter.routes";
import verify from "./middleware/jwtAuth";
import bookingRouter from "./modules/booking/booking.routes";
import paymentRoutes from "./modules/payment/payment.routes";
import consultantRoutes from "./modules/consultant/consultant.routes";
import pharmacyRoutes from "./modules/pharmacy/pharmacy.routes";
import scheduleRoutes from "./modules/schedule/schedule.routes"
import chatRoutes from "./modules/chat/chat.routes"
import notificationRoutes from "./modules/notification/notification.routes"

const appRouter = Router();

appRouter.use(verify);

appRouter.use("/:mode", patientRoutes);
appRouter.use("/:mode", documentRoutes);
appRouter.use("/:mode", chatRoutes);
appRouter.use("/:mode", notificationRoutes);


appRouter.use("/:mode/documentCenter", documentRoutes);
appRouter.use("/:mode/booking", bookingRouter);
appRouter.use("/:mode/doctor", consultantRoutes);
appRouter.use("/:mode/pharmacy", pharmacyRoutes);
appRouter.use("/:mode",paymentRoutes)
appRouter.use("/:mode/booking", bookingRouter);
appRouter.use("/:mode",scheduleRoutes);






export default appRouter;
