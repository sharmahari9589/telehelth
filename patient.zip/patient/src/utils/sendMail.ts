import nodemailer from "nodemailer";

// create a function to send email
export async function sendMail(
  to: string,
  subject: string,
  html: string,
): Promise<void> {
    // replace all the keys with values in html string
    
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: "telehealthonlineconsultation@gmail.com",
        pass: "rjwmatiqakwfnnfu",
      },
    });
const mailOptions = {
  from: "telehealthonlineconsultation@gmail.com",
  to:to,
  subject:subject,
  html:html,
};
  await transporter.sendMail(mailOptions);
}

export async function getFilteredHTML(
  html: string,
  replaceObject: any
): Promise<string> {
    // replace all the keys with values in html string
    for (const key in replaceObject) {
        html = html.replace(new RegExp(`{{${key}}}`, 'g'), replaceObject[key]);
    }
    return html
}