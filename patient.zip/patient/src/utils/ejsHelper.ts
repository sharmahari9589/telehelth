import * as path from 'path';
import * as fs from 'fs';

export function getViewFile(moduleName:string,fileName:string){
    const templatePath = path.join(__dirname, `../modules/${moduleName}/views/${fileName}`);
    const file =  fs.readFileSync(templatePath,'utf-8');
    return {templatePath,file};
};