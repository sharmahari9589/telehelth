import mongoose, { model, ObjectId, Schema } from "mongoose";

export interface Service extends Document {
  name: string;
  description: string;
  cost: number;
  serviceTime:string;
  bufferTime:string;
  videoMeeting:boolean;
  doctors: Array<ObjectId>;
}

const serviceSchema: Schema = new Schema<Service>({
  name:{
    type: String,
  },
    description:{
    type: String,
    },
    cost:{
    type: Number,
    },
    serviceTime:{
    type: String,
    },
    bufferTime:{
    type: String,
    },
    videoMeeting:{
    type: Boolean,
    
    },
    doctors: [mongoose.Schema.Types.ObjectId],
});

export default model<Service>("service", serviceSchema);