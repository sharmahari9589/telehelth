import { model, Schema, Document } from "mongoose";

export interface HealthProblem extends Document {
  name: string;
  description:string;
  speciality:string;
  imageURL: string;
}

const healthProblem: Schema = new Schema<HealthProblem>(
  {
    name: {
      type: String,
    },
    description: {
      type: String,
    },
    imageURL: {
      type: String,
    },
    speciality :{
      type: String,
    }
  },

  {
    timestamps: true,
  }
);

export default model<HealthProblem>("healthproblem", healthProblem);
