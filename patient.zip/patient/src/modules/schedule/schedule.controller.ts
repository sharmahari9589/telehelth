import { Request, Response } from "express";
import httpStatus from "http-status";
import { ObjectId, Types } from "mongoose";
import * as scheduleService from "./schedule.service";
import moment from "moment";
import { sendMail } from "../../utils/sendMail";
//EJS Rendor
import ejs from "ejs";
import { getViewFile } from "../../utils/ejsHelper";
import scheduleModel from "./schedule.model";
import { log } from "console";
import { devNull, loadavg } from "os";
const availabilityData: any = {
  1: "monday",
  2: "tuesday",
  3: "wednesday",
  4: "thursday",
  5: "friday",
  6: "saturday",
  0: "sunday",
};
export async function getMySchedule(req: Request, res: Response) {
  try {
    const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const user = JSON.parse(res.get("user")!);
    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = id;
    } else {
      consultantId = user.addedBy;
    }
    const schedule = scheduleService.getMySchedule(consultantId);
    res.status(httpStatus.OK).send({
      data: schedule,
      message: "Schedule fetched successfully",
      status: httpStatus.OK,
    });
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.OK).send({
      message: err.message,
    });
  }
}

export async function updateMySchedule(req: Request, res: Response) {
  try {
    const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const user = JSON.parse(res.get("user")!);
    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = id;
    } else {
      consultantId = user.addedBy;
    }
    const schedule = scheduleService.getMySchedule(consultantId);
    res.status(httpStatus.OK).send({
      data: schedule,
      message: "Schedule fetched successfully",
      status: httpStatus.OK,
    });
  } catch (error) {
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function updateAvailabilty(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const {
      isAvailable1,
      isAvailable2,
      isAvailable3,
      isAvailable4,
      isAvailable5,
      isAvailable6,
      isAvailable7,
      startTime,
      endTime,
    } = req.body;
    const doctorId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    var value1;
    if (isAvailable1 !== undefined) {
      value1 = true;
    } else {
      value1 = false;
    }

    var value2;
    if (isAvailable2 !== undefined) {
      value2 = true;
    } else {
      value2 = false;
    }

    var value3;
    if (isAvailable3 !== undefined) {
      value3 = true;
    } else {
      value3 = false;
    }

    var value4;
    if (isAvailable4 !== undefined) {
      value4 = true;
    } else {
      value4 = false;
    }

    var value5;
    if (isAvailable5 !== undefined) {
      value5 = true;
    } else {
      value5 = false;
    }

    var value6;
    if (isAvailable6 !== undefined) {
      value6 = true;
    } else {
      value6 = false;
    }

    var value7;
    if (isAvailable7 !== undefined) {
      value7 = true;
    } else {
      value7 = false;
    }

    var start1;
    if (startTime[0] !== "") {
      const startDate1 = new Date();

      const startHours1 = startTime[0].slice(0, 2);
      const startMinutes1 = startTime[0].slice(3, 5);
      startDate1.setUTCHours(startHours1);
      startDate1.setUTCMinutes(startMinutes1);
      startDate1.setUTCSeconds(0);

      start1 = startDate1.toISOString();
    } else {
      start1 = null;
    }

    var end1;
    if (endTime[0] !== "") {
      const endDate1 = new Date();
      const endHours1 = endTime[0].slice(0, 2);
      const endMinutes1 = endTime[0].slice(3, 5);
      endDate1.setUTCHours(endHours1);
      endDate1.setUTCMinutes(endMinutes1);
      endDate1.setUTCSeconds(0);

      end1 = endDate1.toISOString();
    } else {
      end1 = null;
    }

    var start2;
    if (startTime[1] !== "") {
      const startDate2 = new Date();
      const startHours2 = startTime[1].slice(0, 2);
      const startMinutes2 = startTime[1].slice(3, 5);
      startDate2.setUTCHours(startHours2);
      startDate2.setUTCMinutes(startMinutes2);
      startDate2.setUTCSeconds(0);

      start2 = startDate2.toISOString();
    } else {
      start2 = null;
    }

    var end2;
    if (endTime[1] !== "") {
      const endDate2 = new Date();
      const endHours2 = endTime[1].slice(0, 2);
      const endMinutes2 = endTime[1].slice(3, 5);
      endDate2.setUTCHours(endHours2);
      endDate2.setUTCMinutes(endMinutes2);
      endDate2.setUTCSeconds(0);

      end2 = endDate2.toISOString();
    } else {
      end2 = null;
    }

    var start3;
    if (startTime[2] !== "") {
      const startDate3 = new Date();
      const startHours3 = startTime[2].slice(0, 2);
      const startMinutes3 = startTime[2].slice(3, 5);
      startDate3.setUTCHours(startHours3);
      startDate3.setUTCMinutes(startMinutes3);
      startDate3.setUTCSeconds(0);

      start3 = startDate3.toISOString();
    } else {
      start3 = null;
    }

    var end3;
    if (endTime[2] !== "") {
      const endDate3 = new Date();
      const endHours3 = endTime[2].slice(0, 2);
      const endMinutes3 = endTime[2].slice(3, 5);
      endDate3.setUTCHours(endHours3);
      endDate3.setUTCMinutes(endMinutes3);
      endDate3.setUTCSeconds(0);

      end3 = endDate3.toISOString();
    } else {
      end3 = null;
    }

    var start4;
    if (startTime[3] !== "") {
      const startDate4 = new Date();
      const startHours4 = startTime[3].slice(0, 2);
      const startMinutes4 = startTime[3].slice(3, 5);
      startDate4.setUTCHours(startHours4);
      startDate4.setUTCMinutes(startMinutes4);
      startDate4.setUTCSeconds(0);

      start4 = startDate4.toISOString();
    } else {
      start4 = null;
    }
    var end4;
    if (endTime[3] !== "") {
      const endDate4 = new Date();
      const endHours4 = endTime[3].slice(0, 2);
      const endMinutes4 = endTime[3].slice(3, 5);
      endDate4.setUTCHours(endHours4);
      endDate4.setUTCMinutes(endMinutes4);
      endDate4.setUTCSeconds(0);

      end4 = endDate4.toISOString();
    } else {
      end4 = null;
    }

    var start5;
    if (startTime[4] !== "") {
      const startDate5 = new Date();
      const startHours5 = startTime[4].slice(0, 2);
      const startMinutes5 = startTime[4].slice(3, 5);
      startDate5.setUTCHours(startHours5);
      startDate5.setUTCMinutes(startMinutes5);
      startDate5.setUTCSeconds(0);

      start5 = startDate5.toISOString();
    } else {
      start5 = null;
    }

    var end5;
    if (endTime[4] !== "") {
      const endDate5 = new Date();
      const endHours5 = endTime[4].slice(0, 2);
      const endMinutes5 = endTime[4].slice(3, 5);
      endDate5.setUTCHours(endHours5);
      endDate5.setUTCMinutes(endMinutes5);
      endDate5.setUTCSeconds(0);

      end5 = endDate5.toISOString();
    } else {
      end5 = null;
    }

    var start6;
    if (startTime[5] !== "") {
      const startDate6 = new Date();
      const startHours6 = startTime[5].slice(0, 2);
      const startMinutes6 = startTime[5].slice(3, 5);
      startDate6.setUTCHours(startHours6);
      startDate6.setUTCMinutes(startMinutes6);
      startDate6.setUTCSeconds(0);

      start6 = startDate6.toISOString();
    } else {
      start6 = null;
    }

    var end6;
    if (endTime[5] !== "") {
      const endDate6 = new Date();
      const endHours6 = endTime[5].slice(0, 2);
      const endMinutes6 = endTime[5].slice(3, 5);
      endDate6.setUTCHours(endHours6);
      endDate6.setUTCMinutes(endMinutes6);
      endDate6.setUTCSeconds(0);

      end6 = endDate6.toISOString();
    } else {
      end6 = null;
    }

    var start7;
    if (startTime[6] !== "") {
      const startDate7 = new Date();
      const startHours7 = startTime[6].slice(0, 2);
      const startMinutes7 = startTime[6].slice(3, 5);
      startDate7.setUTCHours(startHours7);
      startDate7.setUTCMinutes(startMinutes7);
      startDate7.setUTCSeconds(0);

      start7 = startDate7.toISOString();
    } else {
      start7 = null;
    }
    var end7;
    if (endTime[6] !== "") {
      const endDate7 = new Date();
      const endHours7 = endTime[6].slice(0, 2);
      const endMinutes7 = endTime[6].slice(3, 5);
      endDate7.setUTCHours(endHours7);
      endDate7.setUTCMinutes(endMinutes7);
      endDate7.setUTCSeconds(0);

      end7 = endDate7.toISOString();
    } else {
      end7 = null;
    }

    const data = await scheduleService.AllData(doctorId);
    const newdata: any = data?.availability;

    var timeStart1;
    var timeEnd1;
    if (newdata.monday == null) {
      timeStart1 = null;
      timeEnd1 = null;
    } else {
      timeStart1 = newdata.monday.breaks.startTime;
      timeEnd1 = newdata.monday.breaks.endTime;
    }

    var timeStart2;
    var timeEnd2;
    if (newdata.tuesday == null) {
      timeStart2 = null;
      timeEnd2 = null;
    } else {
      timeStart2 = newdata.tuesday.breaks.startTime;
      timeEnd2 = newdata.tuesday.breaks.endTime;
    }

    var timeStart3;
    var timeEnd3;
    if (newdata.wednesday == null) {
      timeStart3 = null;
      timeEnd3 = null;
    } else {
      timeStart3 = newdata.wednesday.breaks.startTime;
      timeEnd3 = newdata.wednesday.breaks.endTime;
    }

    var timeStart4;
    var timeEnd4;
    if (newdata.thursday == null) {
      timeStart4 = null;
      timeEnd4 = null;
    } else {
      timeStart4 = newdata.thursday.breaks.startTime;
      timeEnd4 = newdata.thursday.breaks.endTime;
    }

    var timeStart5;
    var timeEnd5;
    if (newdata.friday == null) {
      timeStart5 = null;
      timeEnd5 = null;
    } else {
      timeStart5 = newdata.friday.breaks.startTime;
      timeEnd5 = newdata.friday.breaks.endTime;
    }
    var timeStart6;
    var timeEnd6;
    if (newdata.saturday == null) {
      timeStart6 = null;
      timeEnd6 = null;
    } else {
      timeStart6 = newdata.saturday.breaks.startTime;
      timeEnd6 = newdata.saturday.breaks.endTime;
    }
    var timeStart7;
    var timeEnd7;
    if (newdata.sunday == null) {
      timeStart7 = null;
      timeEnd7 = null;
    } else {
      timeStart7 = newdata.sunday.breaks.startTime;
      timeEnd7 = newdata.sunday.breaks.endTime;
    }

    const item = {
      monday: {
        isAvailable: value1,
        startTime: start1,
        endTime: end1,
        breaks: {
          startTime: timeStart1,
          endTime: timeEnd1,
        },
      },
      tuesday: {
        isAvailable: value2,
        startTime: start2,
        endTime: end2,
        breaks: {
          startTime: timeStart2,
          endTime: timeEnd2,
        },
      },
      wednesday: {
        isAvailable: value3,
        startTime: start3,
        endTime: end3,
        breaks: {
          startTime: timeStart3,
          endTime: timeEnd3,
        },
      },
      thursday: {
        isAvailable: value4,
        startTime: start4,
        endTime: end4,
        breaks: {
          startTime: timeStart4,
          endTime: timeEnd4,
        },
      },
      friday: {
        isAvailable: value5,
        startTime: start5,
        endTime: end5,
        breaks: {
          startTime: timeStart5,
          endTime: timeEnd5,
        },
      },
      saturday: {
        isAvailable: value6,
        startTime: start6,
        endTime: end6,
        breaks: {
          startTime: timeStart6,
          endTime: timeEnd6,
        },
      },
      sunday: {
        isAvailable: value7,
        startTime: start7,
        endTime: end7,
        breaks: {
          startTime: timeStart7,
          endTime: timeEnd7,
        },
      },
    };

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: "",
        message: "schedule create successfully",
        status: httpStatus.OK,
      });
    } else {
      const schedule = await scheduleService.addAvailabilty(doctorId, item);

      //Web Code Start
      res.redirect("/consultant/web/setmore");
      //Web Code End
    }
  } catch (error) {
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function addSchedule(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const doctorId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const {
      duration,
      amount,
      isAvailable,
      startTime,
      endTime,
      availability,
      slotBuffer,
      timeOffs,
    } = req.body;

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: "",
        message: "schedule create successfully",
        status: httpStatus.OK,
      });
    } else {
      const newData: any = {
        durationInMin: duration.map((a: any) => {
          return parseInt(a);
        }),
        price: amount.map((b: any) => {
          return parseInt(b);
        }),
      };

      const services = [];

      for (let i = 0; i < newData.durationInMin.length; i++) {
        const convertedObject: any = {};

        for (const key in newData) {
          convertedObject[key] = newData[key][i];
        }

        services.push(convertedObject);
      }

      const scheduleExist = await scheduleService.getScheduleByDoctorId(
        doctorId
      );
      if (scheduleExist) {
        const fileContent = getViewFile("consultantDashboard", "setmore.ejs");
        const user: any = JSON.parse(res.get("user")!);

        res.send(
          ejs.render(fileContent.file, {
            message: "schedule already exist",
            user,
            filename: fileContent.templatePath,
          })
        );
      } else {
        const schedule = scheduleService.addSchedule({
          doctor: doctorId,
          services,
          availability,
          slotBuffer,
          timeOffs,
        });

        //Web Code Start
        res.redirect("/consultant/web/setmore");
        //Web Code End
      }
    }
  } catch (error) {
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function addBreak(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const doctorId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const {
      duration,
      amount,
      isAvailable,
      startTime,
      endTime,
      slotBuffer,
      timeOffs,
    } = req.body;

    var start1;
    if (startTime[0] !== "") {
      const startDate1 = new Date();

      const startHours1 = startTime[0].slice(0, 2);
      const startMinutes1 = startTime[0].slice(3, 5);
      startDate1.setUTCHours(startHours1);
      startDate1.setUTCMinutes(startMinutes1);
      startDate1.setUTCSeconds(0);

      start1 = startDate1.toISOString();
    } else {
      start1 = null;
    }

    var end1;
    if (endTime[0] !== "") {
      const endDate1 = new Date();
      const endHours1 = endTime[0].slice(0, 2);
      const endMinutes1 = endTime[0].slice(3, 5);
      endDate1.setUTCHours(endHours1);
      endDate1.setUTCMinutes(endMinutes1);
      endDate1.setUTCSeconds(0);

      end1 = endDate1.toISOString();
    } else {
      end1 = null;
    }

    var start2;
    if (startTime[1] !== "") {
      const startDate2 = new Date();
      const startHours2 = startTime[1].slice(0, 2);
      const startMinutes2 = startTime[1].slice(3, 5);
      startDate2.setUTCHours(startHours2);
      startDate2.setUTCMinutes(startMinutes2);
      startDate2.setUTCSeconds(0);

      start2 = startDate2.toISOString();
    } else {
      start2 = null;
    }

    var end2;
    if (endTime[1] !== "") {
      const endDate2 = new Date();
      const endHours2 = endTime[1].slice(0, 2);
      const endMinutes2 = endTime[1].slice(3, 5);
      endDate2.setUTCHours(endHours2);
      endDate2.setUTCMinutes(endMinutes2);
      endDate2.setUTCSeconds(0);

      end2 = endDate2.toISOString();
    } else {
      end2 = null;
    }

    var start3;
    if (startTime[2] !== "") {
      const startDate3 = new Date();
      const startHours3 = startTime[2].slice(0, 2);
      const startMinutes3 = startTime[2].slice(3, 5);
      startDate3.setUTCHours(startHours3);
      startDate3.setUTCMinutes(startMinutes3);
      startDate3.setUTCSeconds(0);

      start3 = startDate3.toISOString();
    } else {
      start3 = null;
    }

    var end3;
    if (endTime[2] !== "") {
      const endDate3 = new Date();
      const endHours3 = endTime[2].slice(0, 2);
      const endMinutes3 = endTime[2].slice(3, 5);
      endDate3.setUTCHours(endHours3);
      endDate3.setUTCMinutes(endMinutes3);
      endDate3.setUTCSeconds(0);

      end3 = endDate3.toISOString();
    } else {
      end3 = null;
    }

    var start4;
    if (startTime[3] !== "") {
      const startDate4 = new Date();
      const startHours4 = startTime[3].slice(0, 2);
      const startMinutes4 = startTime[3].slice(3, 5);
      startDate4.setUTCHours(startHours4);
      startDate4.setUTCMinutes(startMinutes4);
      startDate4.setUTCSeconds(0);

      start4 = startDate4.toISOString();
    } else {
      start4 = null;
    }
    var end4;
    if (endTime[3] !== "") {
      const endDate4 = new Date();
      const endHours4 = endTime[3].slice(0, 2);
      const endMinutes4 = endTime[3].slice(3, 5);
      endDate4.setUTCHours(endHours4);
      endDate4.setUTCMinutes(endMinutes4);
      endDate4.setUTCSeconds(0);

      end4 = endDate4.toISOString();
    } else {
      end4 = null;
    }

    var start5;
    if (startTime[4] !== "") {
      const startDate5 = new Date();
      const startHours5 = startTime[4].slice(0, 2);
      const startMinutes5 = startTime[4].slice(3, 5);
      startDate5.setUTCHours(startHours5);
      startDate5.setUTCMinutes(startMinutes5);
      startDate5.setUTCSeconds(0);

      start5 = startDate5.toISOString();
    } else {
      start5 = null;
    }

    var end5;
    if (endTime[4] !== "") {
      const endDate5 = new Date();
      const endHours5 = endTime[4].slice(0, 2);
      const endMinutes5 = endTime[4].slice(3, 5);
      endDate5.setUTCHours(endHours5);
      endDate5.setUTCMinutes(endMinutes5);
      endDate5.setUTCSeconds(0);

      end5 = endDate5.toISOString();
    } else {
      end5 = null;
    }

    var start6;
    if (startTime[5] !== "") {
      const startDate6 = new Date();
      const startHours6 = startTime[5].slice(0, 2);
      const startMinutes6 = startTime[5].slice(3, 5);
      startDate6.setUTCHours(startHours6);
      startDate6.setUTCMinutes(startMinutes6);
      startDate6.setUTCSeconds(0);

      start6 = startDate6.toISOString();
    } else {
      start6 = null;
    }

    var end6;
    if (endTime[5] !== "") {
      const endDate6 = new Date();
      const endHours6 = endTime[5].slice(0, 2);
      const endMinutes6 = endTime[5].slice(3, 5);
      endDate6.setUTCHours(endHours6);
      endDate6.setUTCMinutes(endMinutes6);
      endDate6.setUTCSeconds(0);

      end6 = endDate6.toISOString();
    } else {
      end6 = null;
    }

    var start7;
    if (startTime[6] !== "") {
      const startDate7 = new Date();
      const startHours7 = startTime[6].slice(0, 2);
      const startMinutes7 = startTime[6].slice(3, 5);
      startDate7.setUTCHours(startHours7);
      startDate7.setUTCMinutes(startMinutes7);
      startDate7.setUTCSeconds(0);

      start7 = startDate7.toISOString();
    } else {
      start7 = null;
    }
    var end7;
    if (endTime[6] !== "") {
      const endDate7 = new Date();
      const endHours7 = endTime[6].slice(0, 2);
      const endMinutes7 = endTime[6].slice(3, 5);
      endDate7.setUTCHours(endHours7);
      endDate7.setUTCMinutes(endMinutes7);
      endDate7.setUTCSeconds(0);

      end7 = endDate7.toISOString();
    } else {
      end7 = null;
    }
    const data = await scheduleService.AllData(doctorId);

    var value1;
    var timeStart1;
    var timeEnd1;
    if (data?.availability == null) {
      value1 = false;
      timeStart1 = null;
      timeEnd1 = null;
    } else {
      value1 = data?.availability.monday.isAvailable;
      timeStart1 = data?.availability.monday.startTime;
      timeEnd1 = data?.availability.monday.endTime;
    }

    var value2;
    var timeStart2;
    var timeEnd2;
    if (data?.availability == null) {
      value2 = false;
      timeStart2 = null;
      timeEnd2 = null;
    } else {
      value2 = data?.availability.tuesday.isAvailable;
      timeStart2 = data?.availability.tuesday.startTime;
      timeEnd2 = data?.availability.tuesday.endTime;
    }

    var value3;
    var timeStart3;
    var timeEnd3;
    if (data?.availability == null) {
      value3 = false;
      timeStart3 = null;
      timeEnd3 = null;
    } else {
      value2 = data?.availability.wednesday.isAvailable;
      timeStart2 = data?.availability.wednesday.startTime;
      timeEnd3 = data?.availability.wednesday.endTime;
    }

    var value4;
    var timeStart4;
    var timeEnd4;
    if (data?.availability == null) {
      value4 = false;
      timeStart4 = null;
      timeEnd4 = null;
    } else {
      value4 = data?.availability.thursday.isAvailable;
      timeStart4 = data?.availability.thursday.startTime;
      timeEnd4 = data?.availability.thursday.endTime;
    }
    var value5;
    var timeStart5;
    var timeEnd5;
    if (data?.availability == null) {
      value5 = false;
      timeStart5 = null;
      timeEnd5 = null;
    } else {
      value5 = data?.availability.friday.isAvailable;
      timeStart5 = data?.availability.friday.startTime;
      timeEnd5 = data?.availability.friday.endTime;
    }
    var value6;
    var timeStart6;
    var timeEnd6;
    if (data?.availability == null) {
      value6 = false;
      timeStart6 = null;
      timeEnd6 = null;
    } else {
      value6 = data?.availability.saturday.isAvailable;
      timeStart6 = data?.availability.saturday.startTime;
      timeEnd6 = data?.availability.saturday.endTime;
    }
    var value7;
    var timeStart7;
    var timeEnd7;
    if (data?.availability == null) {
      value7 = false;
      timeStart7 = null;
      timeEnd7 = null;
    } else {
      value7 = data?.availability.sunday.isAvailable;
      timeStart7 = data?.availability.sunday.startTime;
      timeEnd7 = data?.availability.sunday.endTime;
    }

    const breaksDto = {
      monday: {
        isAvailable: value1,
        startTime: timeStart1,
        endTime: timeEnd1,
        breaks: { startTime: start1, endTime: end1 },
      },
      tuesday: {
        isAvailable: value2,
        startTime: timeStart2,
        endTime: timeEnd2,
        breaks: {
          startTime: start2,
          endTime: end2,
        },
      },
      wednesday: {
        isAvailable: value3,
        startTime: timeStart3,
        endTime: timeEnd3,
        breaks: {
          startTime: start3,
          endTime: end3,
        },
      },
      thursday: {
        isAvailable: value4,
        startTime: timeStart4,
        endTime: timeEnd4,
        breaks: {
          startTime: start4,
          endTime: end4,
        },
      },
      friday: {
        isAvailable: value5,
        startTime: timeStart5,
        endTime: timeEnd5,
        breaks: {
          startTime: start5,
          endTime: end5,
        },
      },
      saturday: {
        isAvailable: value6,
        startTime: timeStart6,
        endTime: timeEnd6,
        breaks: {
          startTime: start6,
          endTime: end6,
        },
      },
      sunday: {
        isAvailable: value7,
        startTime: timeStart7,
        endTime: timeEnd7,
        breaks: {
          startTime: start7,
          endTime: end7,
        },
      },
    };

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: "",
        message: "schedule create successfully",
        status: httpStatus.OK,
      });
    } else {
      const schedule = await scheduleService.breaksAdd(doctorId, breaksDto);

      //Web Code Start
      res.redirect("/consultant/web/setmore");
      //Web Code End
    }
  } catch (error) {
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function addTimeoff(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const doctorId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const { startDate, endDate, startTime, endTime, description, allDay } =
      req.body;

    const dateString = startDate;
    const newStartDate = new Date(dateString);

    const stringDate = endDate;
    const newEndDate = new Date(stringDate);

    var value;
    if (allDay !== undefined) {
      value = true;
    } else {
      value = false;
    }

    var startData;
    var endData;

    if (value == true) {
      (startData = null), (endData = null);
    } else {
      (startData = newStartDate), (endData = newEndDate);
    }

    const startDate1 = new Date();

    const startHours1 = startTime.slice(0, 2);
    const startMinutes1 = startTime.slice(3, 5);
    startDate1.setUTCHours(startHours1);
    startDate1.setUTCMinutes(startMinutes1);
    startDate1.setUTCSeconds(0);

    const start1 = startDate1.toISOString();

    const endDate1 = new Date();
    const endHours1 = endTime.slice(0, 2);
    const endMinutes1 = endTime.slice(3, 5);
    endDate1.setUTCHours(endHours1);
    endDate1.setUTCMinutes(endMinutes1);
    endDate1.setUTCSeconds(0);

    const end1 = endDate1.toISOString();

    const item = {
      startDate: startData,
      endDate: endData,
      startTime: start1,
      endTime: end1,
      isAllDay: value,

      description: description,
    };

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: "",
        message: "schedule create successfully",
        status: httpStatus.OK,
      });
    } else {
      const schedule = await scheduleService.breaksAdd(doctorId, item);


      //Web Code Start
      res.redirect("/consultant/web/setmore");
      //Web Code End
    }
  } catch (error) {
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function updateSchedule(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    // const scheduleId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const { scheduleId, services, availability, slotBuffer, timeOffs } =
      req.body;
    const schedule = await scheduleService.updateMySchedule(scheduleId, {
      services,
      availability,
      slotBuffer,
      timeOffs,
    });

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: schedule,
        message: "schedule update successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      //Web Code End
    }
  } catch (error) {
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function scheduleCount(req: Request, res: Response) {
  const { mode } = req.params;
  // const schedule =  scheduleService.count()

  if (mode == "api") {
    res.status(httpStatus.OK).send({
      data: "",
      message: "pharmacy count succesfully",
      status: httpStatus.OK,
    });
  } else {
    //Web Code Start
    //Web Code End
  }
}

export async function getSlotByDate(req: Request, res: Response) {
  const { mode } = req.params;

  const userId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

  let {
    doctorId,
    date,
    timeSlot,
  }: { date: Date; doctorId: Types.ObjectId; timeSlot: string } = req.body;

  if (!date) {
    return res.json({ message: "Please Select Date First" });
  }
  date = new Date(date);

  var slotTime = parseInt(timeSlot);

  try {
    const schedule: any = await scheduleService.getScheduleByDoctorId(doctorId);

    if (!schedule) {
      return res.json({ message: "The doctor is not available on this date" });
    }

    let end = new Date(date);
    end.setHours(23, 59, 59);

    let findBookRecord = await scheduleService.findSlotIsBooked(
      doctorId,
      userId,
      date,
      end
    );

    function findSlotIsBooked(start: Date, end: Date) {
      let isBooked = false;
      findBookRecord?.forEach((item: any) => {
        if (
          moment(item.startTime).format("HHmm") < moment(end).format("HHmm") &&
          moment(item.endTime).format("HHmm") > moment(start).format("HHmm")
        ) {
          isBooked = true;
        }
      });

      return isBooked;
    }
    const dayOfWeek = date.getDay(); // 0 (Sunday) through 6 (Saturday)

    const availabilityKey = dayOfWeekToString(dayOfWeek);

    if (!schedule.availability[availabilityKey][0]) {
      return res.status(400).json({ message: "doctor not Available" });
    }

    const { isAvailable, startTime, endTime, breaks } =
      schedule.availability[availabilityKey][0];

    if (isAvailable == false) {
      return res.json({ message: "The doctor is not available on this date" });
    }

    const dates = startTime;
    const dateString = dates.toISOString();

    const timestamp = dateString;
    const milliseconds = moment.utc(timestamp).valueOf();

    // Convert start time, end time, and break times to milliseconds
    const startMs = startTime.getTime();
    const endMs = endTime.getTime();

    const breakMs = breaks?.map((breakTime: any) => ({
      start: breakTime.startTime.getTime(),
      end: breakTime.endTime.getTime(),
    }));

    //  const breakMs:any = [];

    const timeOffs = schedule.timeOffs.filter((timeOff: any) => {
      const timeOffStartDate = moment(timeOff.startDate)
        .startOf("day")
        .valueOf();
      const timeOffEndDate = moment(timeOff.endDate).endOf("day").valueOf();
      const queryDate = moment(date).startOf("day").valueOf();

      return (
        (timeOff.isAllDay &&
          queryDate >= timeOffStartDate &&
          queryDate <= timeOffEndDate) ||
        (!timeOff.isAllDay &&
          moment(timeOff.startDate).utc().toISOString() ===
            moment(date).utc().toISOString() &&
          moment(timeOff.endDate).utc().toISOString() ===
            moment(date).utc().toISOString())
      );
    });

    
    // Calculate available time slots
    const slotDuration = slotTime * 60000; // Convert minutes to milliseconds
    // const slotBuffer = schedule.slotBuffer * 60000; // Convert minutes to milliseconds
    let slotBuffer = 0;
    const availableSlots = [];
    let slotStart = startMs;
    let slotEnd = slotStart + slotDuration;

    while (slotEnd <= endMs) {
      // Check if slot is within doctor's availability and not during a break
      const isWithinAvailability =
        slotStart >= startMs + slotBuffer &&
        slotEnd <= endMs - slotBuffer &&
        !breakMs.some(
          (breakTime: any) =>
            slotStart < breakTime.end && slotEnd > breakTime.start
        );

      let isAvailable =
        slotStart >= startMs + slotBuffer &&
        slotEnd <= endMs - slotBuffer &&
        !timeOffs.some(
          (timeOff: any) =>
            timeOff.isAllDay ||
            (moment(slotStart).format("HHmm") <
              moment(timeOff.endTime).format("HHmm") &&
              moment(slotEnd).format("HHmm") >
                moment(timeOff.startTime).format("HHmm"))
        );

      if (
        isWithinAvailability &&
        isAvailable &&
        !findSlotIsBooked(slotStart, slotEnd)
      ) {
        availableSlots.push({
          start: new Date(slotStart),
          end: new Date(slotEnd),
        });
      }

      // Move on to next time slot
      slotStart += slotDuration;
      slotEnd += slotDuration;
    }

   

    if (availableSlots) {
      if (availableSlots[0]) {
        const currentTime = new Date();

        if (currentTime.toDateString() === date.toDateString()) {
          const upcomingSlots = [];

          for (let i = 0; i < availableSlots.length; i++) {
            const slot = availableSlots[i];
            const oldSlot = new Date(slot.start);

            // Extract the time portion of the current time and oldSlot
            const currentTimeTime =
              currentTime.getHours() * 60 + currentTime.getMinutes();

            const oldSlotTime =
              oldSlot.getUTCHours() * 60 + oldSlot.getUTCMinutes();

            if (currentTimeTime < oldSlotTime) {
              upcomingSlots.push(slot);
            }
          }

          return res.json({ availableSlots: upcomingSlots });
        } else {
          // Dates don't match
          return res.json({ availableSlots });
        }
      } else {
        return res.json({ message: "The Doctor is on leave on this day" });
      }
    } else {
      return res.json({ message: "No available slots" });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Internal server error" });
  }
}

// Helper function for converting day of week number to availability key
function dayOfWeekToString(dayOfWeek: number) {
  const daysOfWeek = [
    "sunday",
    "monday",
    "tuesday",
    "wednesday",
    "thursday",
    "friday",
    "saturday",
  ];
  return daysOfWeek[dayOfWeek];
}

export async function getSlot(req: Request, res: Response) {
  const { mode } = req.params;
  // const schedule =  scheduleService.count()

  try {
    const {
      date,
      timeSlot,
      doctorId,
    }: { date: any; timeSlot: string; doctorId: Types.ObjectId } = req.body;

    var duration = parseInt(timeSlot);

    const schedule: any = await scheduleService.getScheduleByDoctorId(doctorId);

    const availability = schedule.availability;
    const timeOffs = schedule.timeOffs;

    // check if the requested date falls within the availability range
    const dayOfWeek = new Date(date)
      .toLocaleDateString("en-US", { weekday: "long" })
      .toLowerCase();
    const available =
      availability[dayOfWeek] && availability[dayOfWeek].isAvailable;

    if (!available) {
    }

    // calculate the start and end times for the requested duration
    const start = new Date(date);
    const end = new Date(start.getTime() + duration * 60000);

    // iterate over the requested time range and generate slots
    const slots = [];
    let current = new Date(start);

    while (current < end) {
      // check if the current time falls within a time off
      const isTimeOff: any = timeOffs.some((timeOff: any) => {
        const startOff = new Date(timeOff.startTime);
        const endOff = new Date(timeOff.endTime);

        return current >= startOff && current < endOff;
      });

      // check if the current time falls within a break
      const isInBreak =
        availability[dayOfWeek].breaks &&
        availability[dayOfWeek].breaks.startTime &&
        availability[dayOfWeek].breaks.endTime &&
        current >= new Date(availability[dayOfWeek].breaks.startTime) &&
        current < new Date(availability[dayOfWeek].breaks.endTime);

      if (!isTimeOff && !isInBreak) {
        // add the current time to the list of slots
        slots.push(current.toISOString());
      }

      // increment the current time based on the requested duration
      current = new Date(current.getTime() + duration * 60000);
    }

    // return the list of slots
    res.json({ slots });
  } catch (error) {
    console.log(error);
  }
}
