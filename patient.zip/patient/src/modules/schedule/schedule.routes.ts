import { Router } from "express";
import * as scheduleController from "./schedule.controller";

const appRouter = Router({
  mergeParams: true,
});


appRouter.route("/count").get(scheduleController.scheduleCount);

appRouter.get("/getschedule", scheduleController.getMySchedule);

appRouter.post("/updateschedule", scheduleController.updateMySchedule);


appRouter.
route("/get-slot")
.get(scheduleController.getSlotByDate)
.post(scheduleController.getSlotByDate)







appRouter.
route("/get-slotbydate")
.get(scheduleController.getSlot)
.post(scheduleController.getSlot)




export default appRouter;
