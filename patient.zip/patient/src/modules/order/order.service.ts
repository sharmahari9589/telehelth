import { Types } from "mongoose";

export async function getOrdersByPatientId(patientId: Types.ObjectId) {}

export async function getOrdersByConsultantId(consultantId: Types.ObjectId) {}

export async function getOrdersByAdminId(adminId: Types.ObjectId) {}

export async function getOrdersByPharmacyId(pharmacyId: Types.ObjectId) {}
