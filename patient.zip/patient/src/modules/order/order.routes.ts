import { Router } from "express";
import * as orderController from "./order.controller";

const router: Router = Router();

router
  .route("/")
  .get(orderController.getOrders)
  .post(orderController.getOrders);

router
  .route("/")
  .get(orderController.updateOrders)
  .post(orderController.updateOrders);

export default router;
