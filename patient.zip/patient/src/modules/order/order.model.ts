import mongoose, { model, Schema, Document } from "mongoose";

export interface Order extends Document {

  problem: mongoose.Types.ObjectId;
  booking: mongoose.Types.ObjectId;

  pharmacy: mongoose.Types.ObjectId;
  amount: number;
  patient: mongoose.Types.ObjectId;
  consultant: mongoose.Types.ObjectId;
  rejectReason:String;
  deliveryDate: any;
  orderStatus: string;
  createdAt: Date;
  updatedAt:Date;
  invoice:Array<any>


  medicine: Array<string>;
  flowUpDate: Date;
  Diagnosys: Array<string>;
  prescription:Array<any>
}

export enum orderStatus{
  pending = "pending",
  completed = "completed",
  reject = "reject",
  inProcess = "inProcess",
  readyFordispatch="readyForDispatch"
}

export enum FollowUp{
   Between0To10= "Between 0 to 10 days",
   Between10To20= "Between 10 to 20 days",
   Between20To30= "Between 20 to 30 days",
   NoFollowUp= "No follow Up",
}

export enum Repeat{
  NORepeat= "No repeat",
  In1Month= "in 1 Month",
  In3Month= "in 3 Month",
  In6Month= "in 6 Month",
}




export enum Notes{
  BeforeFood= "Before Food",
  AfterFood= "After Food",
}


const date: any = new Date();



const medicineSchema = new mongoose.Schema({
  medicineName: String,
  frequency: String,
  preparation:String,
  quantity:String,
  duration: String,
  notes: String
},{_id:false}
);

const appointmentSchema = new mongoose.Schema({
  medicine: [medicineSchema],
  avoidSunlight: String,
  diagnosis: String,
  instructions: String,
  followUp: String,
  allergy:String,
  repeat:String,
  symptoms:String,
  icdCode: String,
},{_id:false}
);



const invoiceSchema = new mongoose.Schema({
 
  invoiceDate: {
    type: Date,
    default: Date.now()
  },

invoiceNo:{
type:String
},
patient: {
  type: mongoose.Schema.Types.ObjectId,
  ref: "patient",
},
pharmacy: {
  type: mongoose.Schema.Types.ObjectId,
  ref: "pharmacie",
},

  items:[{
    medicineName:{
   type: String
  },
  quantity: {
    type: Number,
    required: true,
    min: 1
  },

  price: {
    type: Number,
    required: true,
    min: 0
  },

  totalPrice: {
    type: Number,
    required: true,
    min: 0
  },
  
}],
},

{_id:false,timestamps:true}
)



const orderSchema: Schema = new Schema<Order>({
  problem: {
    type: mongoose.Schema.Types.ObjectId,
    
  },
  booking: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "booking",
  },
  pharmacy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "pharmacie",
  },
  patient: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "patient",
  },
  consultant: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "doctor",
  },
  amount: {
    type: Number,
    default: 0,
  },
  rejectReason:{
    type:String
  },
  deliveryDate: {
    type: Date,
    default: date.setDate(date.getDate() + 5),
  },
  orderStatus: {
    type: String,
    default:orderStatus.pending,
    enum:orderStatus
  },
  prescription:{
    type:[{type:appointmentSchema}]
  },


invoice:{
  type:[{type:invoiceSchema}]
},
},{timestamps:true});

export default model<Order>("order", orderSchema);
