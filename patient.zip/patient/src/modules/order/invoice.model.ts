import mongoose, { model, Schema } from "mongoose";

const invoiceSchema: Schema = new Schema({
  pharmacy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "pharmacy",
  },
  patient: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "patient",
  },
  consultant: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "doctor",
  },
  orderAmount: {
    type: Number,
  },
  prescription: {},
});

export default model("invoice", invoiceSchema);
