import { Request, Response } from "express";

export async function getOrders(req: Request, res: Response) {}
export async function updateOrders(req: Request, res: Response) {}
