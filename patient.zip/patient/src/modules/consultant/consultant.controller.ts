import httpStatus from "http-status";
import { Consultant } from "./consultant.model";
import * as consultantService from "./consultant.service";
import { Request, Response } from "express";
import { Types } from "mongoose";
import { Booking } from "../booking/booking.model";
import * as bookingService from "../booking/booking.service";
import { log } from "console";

export async function getConsultant(req: Request, res: Response) {
  try {
    const { search, limit, page } = req.query;
    const problemId: Types.ObjectId = new Types.ObjectId(
      req.query.problemId as string
    );
    const consultant: Array<Consultant> =
      await consultantService.findConsultants(
        search as string,
        problemId,
        parseInt(limit as string),
        parseInt(page as string)
      );

      
    res.status(httpStatus.OK).send({
      data: consultant,
      message: "Consultants fetched successfully",
      status: httpStatus.OK,
    });
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function getPreviousConsultants(req: Request, res: Response) {
  try {
    const patientId: Types.ObjectId = new Types.ObjectId(req.get("userId"));
    const { startDate, endDate, page, limit } = req.query;
    const bookings: Array<Booking> =
      await bookingService.getPatientsPreviousBookings(
        patientId,
        new Date(startDate as string),
        new Date(endDate as string),
        parseInt(page as string),
        parseInt(limit as string)
      );
    const consultant: Array<Consultant> =
      await bookingService.getConsultantsFromBookingArray(bookings);

    res.status(httpStatus.OK).send({
      data: consultant,
      message: "Consultants fetched successfully",
      status: httpStatus.OK,
    });
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}
