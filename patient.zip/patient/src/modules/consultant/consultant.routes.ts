import { Router } from "express";
import * as consultantController from "./consultant.controller";

const router = Router();

router.get("/", consultantController.getConsultant);
router.get("/previousDoctors", consultantController.getPreviousConsultants);

export default router;
