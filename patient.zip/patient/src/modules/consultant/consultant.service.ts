import { Types } from "mongoose";
import consultantModel, { Consultant } from "./consultant.model";
import scheduleModel, { Schedule } from "../../modules/schedule/schedule.model";

export async function getSchedule(
  doctorId: Types.ObjectId
): Promise<Schedule | null> {
  return scheduleModel.findOne({ doctor: doctorId });
}

export async function findConsultants(
  search: string,
  problemId: Types.ObjectId,
  limit: number,
  page: number
): Promise<Array<Consultant>> {
  return await consultantModel
    .find({
      // $or: [
      //   { firstName: { $regex: search, $options: "i" } },
      //   { firstName: { $regex: search, $options: "i" } },
      // ],
      // speciality: { $elemMatch: { $eq: problemId } },
    })
    .limit(limit)
    .skip((page - 1) * limit);
}
