import mongoose, { model, Schema, Document } from "mongoose";

export interface DocumentShare extends Document {
  documentId: mongoose.Types.ObjectId;
  userId: Array<mongoose.Types.ObjectId>;
}

const documentShare: Schema = new mongoose.Schema<DocumentShare>({
  documentId: mongoose.Schema.Types.ObjectId,
  userId: [
    {
      type: mongoose.Schema.Types.ObjectId,
    },
  ],
},
{
  timestamps: true});

export default model<DocumentShare>("documentShare", documentShare);
