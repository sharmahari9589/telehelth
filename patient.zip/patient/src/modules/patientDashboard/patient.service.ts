import { Types } from "mongoose";
import patientModel, { Patient } from "./patient.model";
import bcrypt from 'bcryptjs'
import pharmacyModel, { Pharmacy } from "../pharmacy/pharmacy.model";
import bookingModel from "../booking/booking.model";
import orderModel from "../order/order.model";
import { log } from "console";

export async function findPatientById(id: Types.ObjectId) {}

export async function findPatientByEmail(email: string) {}

export async function updateById(patientId: Types.ObjectId, updateBody: any) {
  return await patientModel.findByIdAndUpdate(patientId, updateBody);
}

export async function bookingaccepted(_id: Types.ObjectId,id:Types.ObjectId){
  var currentTime = new Date();

  // Add 5.5 hours (in milliseconds)
  var addedTime = currentTime.getTime() + (3.5 * 60 *  60 * 1000);
  
  // Create a new Date object with the added time
  var newTime = new Date(addedTime);
 
  
  
  
  var plusTime = addedTime + (3* 60 * 60 * 1000);
  var addTime = new Date(plusTime);
  
  
    return await bookingModel.aggregate([
      {
        '$match': {
          'doctor': _id
        }
      }, {
        '$match': {
          'patient': id
        }
      }, {
        '$match': {
          status: {
            $in: ["reschedule","accepted",]
          },
          startTime:{$gte:newTime,$lte:addTime},
          
        }
      },
      {
        $sort:{createdAt:1}
      }
    ])
  
}




export async function upcomingChat(_id: Types.ObjectId,id:Types.ObjectId){
  var currentTime = new Date();

  // Add 5.5 hours (in milliseconds)
  var addedTime = currentTime.getTime() + (3.5 * 60 *  60 * 1000);
  
  // Create a new Date object with the added time
  var newTime = new Date(addedTime);
 
  
  
  
  var plusTime = addedTime + (3* 60 * 60 * 1000);
  var addTime = new Date(plusTime);
  
  
    return await bookingModel.aggregate([
      {
        '$match': {
          'doctor': _id
        }
      }, {
        '$match': {
          'patient': id
        }
      }, {
        '$match': {
          status: {
            $in: ["reschedule","accepted",]
          },
          startTime:{$gte:newTime},
          
        }
      },
      {
        $sort:{createdAt:1}
      }
    ])
  
}



export async function getPharmacys(
  limit: number,
  page: number,
  patientId: Types.ObjectId
): Promise<Array<Pharmacy>> {
  return await pharmacyModel.find()
}
export async function getMyProfile(
  patientId: Types.ObjectId
): Promise<Patient|null> {
  return await patientModel.findById(patientId)
}

export async function getMyOrder(
  limit: number,
  page: number,
  patientId: Types.ObjectId
) 
{

  return await orderModel.aggregate(
    [
      {
        '$match': {
          'patient': patientId
        }
      }, {
        '$lookup': {
          'from': 'patients', 
          'localField': 'patient', 
          'foreignField': '_id', 
          'as': 'patient'
        }
      }, {
        '$unwind': {
          'path': '$patient', 
          'preserveNullAndEmptyArrays': true
        }
      },
      {
        '$lookup': {
          'from': 'bookings', 
          'localField': 'booking', 
          'foreignField': '_id', 
          'as': 'booking'
        }
      }, {
        '$unwind': {
          'path': '$booking', 
          'preserveNullAndEmptyArrays': true
        }
      },
      
      
      
      {
        '$lookup': {
          'from': 'pharmacies', 
          'localField': 'pharmacy', 
          'foreignField': '_id', 
          'as': 'pharmacy'
        }
      }, {
        '$unwind': {
          'path': '$pharmacy', 
          'preserveNullAndEmptyArrays': false
        }
      }, {
        '$unwind': {
          'path': '$invoice', 
          'preserveNullAndEmptyArrays': true
        }
      },
      {
"$sort":{
"booking.date":-1
}

      }
    ])
}





export async function updatePssaword(pharmacyId: Types.ObjectId, updateBody: any) {  
  return patientModel.findByIdAndUpdate(pharmacyId, {password:updateBody});
}



export async function getById(pharmacyId: Types.ObjectId) {
  
  return patientModel.findById(pharmacyId);
}

/**
 * @description this function is used to compare password
 * @param {String} password
 * @param {String} hashpassword
 * @author Keshav suman
 * @returns {Boolean}
 */
export function comparePassword(
  password: string,
  hashpassword: string
): boolean {
  
  return bcrypt.compareSync(password, hashpassword);
}

export function encryptPassword(
  password: string,
)  {
  return bcrypt.hashSync(password, 10);
}

export async function getUserByUserID(
  userId: Types.ObjectId,
){
  const user = await patientModel.findById(userId);  
  return user;
}


// export async function bookingGetById(_id: Types.ObjectId){
//   return await bookingModel.find({patient:_id,status:"accepted"});
// }


// export async function acceptedBooking(
//   patientId: Types.ObjectId,
//   limit: number,
//   page: number
// ) {

//   return await bookingModel
//   .aggregate(
//     [
//       {
//         $match: {
//           '$and': [
//             {
//               patient: patientId
//             }, {
//               status: 'accepted'
//             }
//           ]
//         }
//       }, {
//         '$lookup': {
//           'from': 'doctors', 
//           'localField': 'doctor', 
//           'foreignField': '_id', 
//           'as': 'doctor'
//         }
//       }, {
//         '$unwind': {
//           'path': '$doctor', 
//           'preserveNullAndEmptyArrays': true
//         }
//       }
//     ])
    
// }

export async function pastBookings(
  patientId: Types.ObjectId,
  limit: string,
  page: string
) {

  return await orderModel.aggregate(
    [
      {
        '$match': {
          'patient': patientId
        }
      }, {
        '$lookup': {
          'from': 'patients', 
          'localField': 'patient', 
          'foreignField': '_id', 
          'as': 'patient'
        }
      }, {
        '$unwind': {
          'path': '$patient', 
          'preserveNullAndEmptyArrays': true
        }
      }, {
        '$lookup': {
          'from': 'doctors', 
          'localField': 'consultant', 
          'foreignField': '_id', 
          'as': 'doctor'
        }
      }, {
        '$unwind': {
          'path': '$doctor', 
          'preserveNullAndEmptyArrays': true
        }
      }, {
        '$lookup': {
          'from': 'healthproblems', 
          'localField': 'problem', 
          'foreignField': '_id', 
          'as': 'problem'
        }
      }, {
        '$unwind': {
          'path': '$problem', 
          'preserveNullAndEmptyArrays': true
        }
      },
      {
        '$lookup': {
          'from': 'bookings', 
          'localField': 'booking', 
          'foreignField': '_id', 
          'as': 'booking'
        }
      }, {
        '$unwind': {
          'path': '$booking', 
          'preserveNullAndEmptyArrays': true
        }
      },
      {
        '$lookup': {
          'from': 'services', 
          'localField': 'booking.service', 
          'foreignField': '_id', 
          'as': 'service'
        }
      }, {
        '$unwind': {
          'path': '$service', 
          'preserveNullAndEmptyArrays': true
        }
      },
    
    ]
  ) 
}



export async function acceptedBookingOld(
  patientId: Types.ObjectId,
  limit: number,
  page: number
) {

  return await bookingModel
  .aggregate(
    [
      {
        $match: {
          '$and': [
            {
              patient: patientId
            }, {
              status: 'accepted'
            }
          ]
        }
      }, {
        '$lookup': {
          'from': 'doctors', 
          'localField': 'doctor', 
          'foreignField': '_id', 
          'as': 'doctor'
        }
      }, {
        '$unwind': {
          'path': '$doctor', 
          'preserveNullAndEmptyArrays': true
        }
      }
    ])
    
}
export async function bookingGetById(_id: Types.ObjectId,id:Types.ObjectId){
  var currentTime = new Date();

  // Add 5.5 hours (in milliseconds)
  var addedTime = currentTime.getTime() + (3.5 * 60 * 60 * 1000);
  
  // Create a new Date object with the added time
  var newTime = new Date(addedTime);

  
  
  
  var plusTime = currentTime.getTime() + (6.5 * 60 * 60 * 1000);
  var addTime = new Date(plusTime);

  
  
  
    return await bookingModel.aggregate([
      {
        '$match': {
          'doctor': _id
        }
      }, {
        '$match': {
          'patient': id
        }
      }, {
        '$match': {
          status: {
            $in: ["reschedule","accepted",]
          },
          startTime:{$gte:newTime, $lte:addTime},
          
        }
      },
      {
        $sort:{createdAt:1}
      }
    ])
  }



export async function acceptedBooking(
  patientId: Types.ObjectId,
  limit: number,
  page: number
) {

const data=  await bookingModel
.aggregate(
  [
    {
      $match: {

        patient: patientId
      }
    }
    ])



const loopData:any= data.map((a)=>{
  return a.status
})


if(loopData=="completed"){


  return await bookingModel
  .aggregate(
    [
      {
        $match: {
          '$and': [
            {
              patient: patientId
            },
            {
            status:"completed"
            
          }

          ]
        }
      }, {
        '$lookup': {
          'from': 'doctors', 
          'localField': 'doctor', 
          'foreignField': '_id', 
          'as': 'doctor'
        }
      }, {
        '$unwind': {
          'path': '$doctor', 
          'preserveNullAndEmptyArrays': true
        }
      },
      
    ])

}

  
 else{ 

 const a = new Date().getTime() + (5.5 * 60 *  60 * 1000)

 
 const d= new Date(a)

 const t = d.getTime() - (2 * 60 *  60 * 1000)

 const q= new Date(t)




 
  return await bookingModel
  .aggregate(
    [
      {
        $match: {
          '$and': [
            {
              patient: patientId
            },{
            status: {
              $in: ["reschedule","accepted","completed"]
            }
          },

          ]
        }
      }, {
        '$lookup': {
          'from': 'doctors', 
          'localField': 'doctor', 
          'foreignField': '_id', 
          'as': 'doctor'
        }
      }, {
        '$unwind': {
          'path': '$doctor', 
          'preserveNullAndEmptyArrays': true
        }
      },
      
    ])

  }
    
}
export async function acceptedUpcomingBooking(
  patientId: Types.ObjectId,
  limit: number,
  page: number
) {
  var currentTime = new Date();

  // Add 5.5 hours (in milliseconds)
  var addedTime = currentTime.getTime() + (3.5*  60 * 60 * 1000);


  var newTime = new Date(addedTime);



  return await bookingModel.aggregate([
    {
      $match: {
        patient: patientId,
      },
    },
    {
      $match: {
        status: {$in:["accepted","reschedule"]},
        startTime: { $gte: newTime },
      },
    },
    {
      $lookup: {
        from: "doctors",
        localField: "doctor",
        foreignField: "_id",
        as: "doctor",
      },
    },
    {
      $unwind: {
        path: "$doctor",
        preserveNullAndEmptyArrays: true,
      },
    },

    {
      $lookup: {
        from: "chats",
        let: { patientId: patientId, chatId: '$doctor._id' },
        pipeline: [
          {
            $match: {
              $expr: {
                $or: [
                  {
                    $and: [
                      { $eq: ["$user1", "$$chatId"] },
                      { $eq: ["$user2", "$$patientId"] }
                    ]
                  },
                  {
                    $and: [
                      { $eq: ["$user1", "$$patientId"] },
                      { $eq: ["$user2", "$$chatId"] }
                    ]
                  }
                ]
              }
            }
          }
        ],
        as: "chat"
      }
    },
    {
      $unwind: {
        path: "$chat",
        preserveNullAndEmptyArrays: true,
      },
    },
        




    {
      $sort: { startTime: 1 },
    },
  ]);
    
}










export async function getPharamcies(
  dto:any,
   page: any,
   limit: any
 ): Promise<Array<Pharmacy>> { 
      if(dto.CHO){
       return await pharmacyModel.find({cho:dto.CHO}).skip((limit * page) - limit) ;
      
   }
   else if(dto.EirCode){
     return await pharmacyModel.find({eircode:dto.EirCode}).limit(limit).skip((page-1)*limit);
   }
   else if(dto.fullName){
       return await pharmacyModel.find({storeName:{$regex:dto.fullName,$options:"i"}}).limit(limit).skip((page-1)*limit);
     }
     else if(dto.location){
           return await pharmacyModel.find({location:{$regex:dto.location,$options:"i"}}).limit(limit).skip((page-1)*limit);
         }
         else{
           return await pharmacyModel.find().limit(limit).skip((page-1)*limit);
         }
 }


