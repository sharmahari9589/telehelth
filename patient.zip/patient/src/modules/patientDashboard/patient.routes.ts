import { Router } from "express";
import * as patientController from "./patient.controller";

const appRouter: Router = Router(
    {
        mergeParams:true
    }
);

appRouter.get("/", patientController.patientDashboard);
appRouter.get("/myprofile", patientController.myprofile);
appRouter.get("/previousconsultant", patientController.previousConsultant);


appRouter.get("/Demo", patientController.Demo);
appRouter.post("/Demo", patientController.Demo);


appRouter.get("/chat", patientController.chat);
appRouter.get("/video-call/:id",patientController.videoCall);

appRouter.get("/upcomingchat", patientController.upcomingChat);

appRouter.get("/viewpharmacy", patientController.viewPharmacy);
appRouter.get("/myinvoice", patientController.myInvoice);
appRouter.get("/documentcenter_old", patientController.documentCenter);
appRouter.get("/calculatebmitool", patientController.calculateBmiTool);
appRouter.post("/calculatebmitool", patientController.calculateBmiTool);

appRouter.post("/bmi", patientController.calculateBmi);

appRouter.get("/privacypolicy", patientController.privacyPolicy);
appRouter.get("/termsofuse", patientController.termsOfUse);



appRouter.
route("/questionire1")
.get( patientController.questionire1)
.post(patientController.questionire1)

appRouter.
route("/getImage")
.get( patientController. getImage)
.post(patientController. getImage)


appRouter.get("/questionire2", patientController.questionire2);
appRouter.get("/select-date-and-time", patientController.select_date_and_time);
appRouter.get("/rescedule-time", patientController.rescheduleTimeSlot);

appRouter.get("/choose-pharmacy", patientController.choosePharmacy);
appRouter.get("/fill-your-details", patientController.fillYourDetails);
appRouter.get("/confirmation", patientController.confirmation);
appRouter.get("/viewdoctorprofile", patientController.viewDoctorProfile);
appRouter.get("/mypharmacy-order",patientController.viewMyOrders)

appRouter.get("/past-history",patientController.viewPastHistory)

appRouter.get("/voice-call/:id",patientController.voiceCall);




appRouter.
route("/payment-details")
.get( patientController.payment_details)
.post( patientController.payment_details)





appRouter
  .route("/editprofile")
  .get(patientController.editProfile)
  .post(patientController.editProfile);

  appRouter
  .route("/get-pharma")
  .get(patientController.getPharmacy)
  .post(patientController.getPharmacy);

  

  appRouter
  .route("/changepassword")
  .get(patientController.changePassword)
  .post(patientController.changePassword);





export default appRouter;
