import { Request, Response } from "express";
import httpStatus from "http-status";
import { Types } from "mongoose";
import * as patientService from "./patient.service";
import * as bookingService from "../booking/booking.service";
import { RtcRole, RtcTokenBuilder } from "agora-access-token";

//EJS Rendor
import ejs from "ejs";
import { getViewFile } from "../../utils/ejsHelper";
import { Booking } from "../booking/booking.model";
import { log } from "console";
import pharmacyModel from "../pharmacy/pharmacy.model";
import bmiModel from "../../models/bmi.model";
import patientModel, { Patient } from "./patient.model";

/**
 * @description This function is for Dashboard
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */


export async function patientDashboard(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { limit, page } = req.query;

    const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const user = JSON.parse(res.get("user")!);
    let consultantId = new Types.ObjectId(req.body.personvalue);

    let patientId;
    if (user.addedBy == undefined) {
      patientId = id;
    } else {
      patientId = new Types.ObjectId(user.addedBy);
    }
    const booking = await patientService.bookingGetById(
      consultantId,
      patientId
    );
    const bookingId = booking.map((e) => {
      return e._id;
    });
    const manageBooking: Array<Booking> =
      await patientService.acceptedUpcomingBooking(
        patientId,
        parseInt(limit as string),
        parseInt(page as string)
      );

    const patient = await patientModel.findById(patientId);

    const bmi = await bmiModel.find({ addedBy: id }).sort({ date: -1 });


    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("patientDashboard", "index.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            bmi,
            patient,
            manageBooking,
            activeTab: "patientDashboard",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for My Profile
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function myprofile(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const patientId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const patient = await patientService.getMyProfile(patientId);

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("patientDashboard", "my-profile.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            patient,
            activeTab: "patientDashboard",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for Edit Profile
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function editProfile(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { limit, page } = req.query;
    const patientId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: "",
        message: "patient update successfully",
        status: httpStatus.OK,
      });
    } else {
      if (req.method == "GET") {
        const patient = await patientModel.findById(patientId);

        const manageBooking: Array<Booking> =
          await patientService.acceptedUpcomingBooking(
            patientId,
            parseInt(limit as string),
            parseInt(page as string)
          );

        const bmi = await bmiModel
          .find({ addedBy: patientId })
          .sort({ date: -1 });

        const fileContent = getViewFile("patientDashboard", "edit-profile.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            message1: "",
            user,
            activeTab: "patientDashboard",
            patient,
            bmi,
            manageBooking,
            filename: fileContent.templatePath,
          })
        );
      } else {
        const manageBooking: Array<Booking> =
          await patientService.acceptedUpcomingBooking(
            patientId,
            parseInt(limit as string),
            parseInt(page as string)
          );

        const bmi = await bmiModel
          .find({ addedBy: patientId })
          .sort({ date: -1 });

        const newv: any = req.body.files;
        let profilePic;

        if (newv[0]) {
       
          profilePic = newv[0]?.path;
        }

        const editDto: any = {
          firstName: req.body.firstName,

          lastName: req.body.lastName,
          email: req.body.email,
          mobileNumber: req.body.mobileNumber,
          gender: req.body.gender,
          eirCode: req.body.eirCode,
          gmsNo: req.body.gmsNo,
          maritialStatus: req.body.maritialStatus,
          location: req.body.location,
          bloodGroup: req.body.bloodGroup,
          dateOfBirth: req.body.dateOfBirth,
          weight: req.body.weight,
          height: req.body.height,
          weight_unit: req.body.weight_unit,
          height_unit: req.body.height_unit,
          imageURL: profilePic,

          allergy: req.body.allergy,
        };
        const patients = await patientService.updateById(patientId, editDto);

        const patient = await patientModel.findById(patientId);
        //Web Code Start
        const fileContent = getViewFile("patientDashboard", "index.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: " ",
            message1: "",
            user,
            activeTab: "patientDashboard",
            patient,
            bmi,
            manageBooking,
            filename: fileContent.templatePath,
          })
        );
      }

      //Post Method Code

      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for Previous Consultant
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function previousConsultant(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "patientDashboard",
          "previous-consultants.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "patientDashboard",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for New Booking
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function newBooking(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("patientDashboard", "new-booking.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "newbook",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for View All Booking
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function viewAllBookings(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "patientDashboard",
          "view-all-booking.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "mybook",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for Rescheduled Booking
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function rescheduledBookings(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "patientDashboard",
          "reschedule-booking.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "resBook",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for Canceled Booking
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function cancledBookings(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const patientId: Types.ObjectId = new Types.ObjectId(res.get("userId"));
    const bookings = await bookingService.getCancelledBoking(patientId);

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: bookings,
        message: "bookings fetched successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "patientDashboard",
          "cancel-booking.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);

        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "canBook",
            bookings,
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for View Pharmacy
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function viewPharmacy(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const { fullName } = req.query;
    const limit = 10;
    const page = req.query.page || 1;

    const pharmacy = await patientService.getPharamcies(req.query, page, limit);
    const manageBooking: Array<Booking> =
      await patientService.acceptedUpcomingBooking(
        id,
        limit as any,
        page as any
      );

    const count = await pharmacyModel.find().count();
    if (mode == "api") {
    } else {
      //Web Code Start

      if (req.method == "GET") {
        const fileContent = getViewFile(
          "patientDashboard",
          "view-all-pharmacy.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            pharmacy,
            current: page,
            pages: Math.ceil(count / limit),
            manageBooking,
            activeTab: "pharma",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for My Invoice
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function myInvoice(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { page, limit } = req.query;

    const patientId: Types.ObjectId = new Types.ObjectId(res.get("userId"));
    const manageBooking: Array<Booking> =
      await patientService.acceptedUpcomingBooking(
        patientId,
        parseInt(limit as string),
        parseInt(page as string)
      );

    const invoice = await bookingService.getBookings(
      parseInt(limit as string),
      parseInt(page as string),
      patientId
    );

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("patientDashboard", "invoice.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            invoice,
            activeTab: "invoice",
            manageBooking,
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for Document Center
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function documentCenter(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "patientDashboard",
          "document-center.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "doc",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for Calculate Bmi Tool
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function calculateBmiTool(req: Request, res: Response) {
  try {
    const { limit, page } = req.query;

    const patientId: Types.ObjectId = new Types.ObjectId(res.get("userId"));
    const { mode } = req.params;
    const userId: Types.ObjectId = new Types.ObjectId(res.get("userId"));
    const manageBooking: Array<Booking> =
      await patientService.acceptedUpcomingBooking(
        userId,
        parseInt(limit as string),
        parseInt(page as string)
      );

    const bmi = await bmiModel.find({ addedBy: patientId });

    if (mode == "api") {
    } else {
      //Web Code Start
      const fileContent = getViewFile("patientDashboard", "calculate-bmi.ejs");
      const user: any = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          message: "",
          user,
          bmi,
          activeTab: "bmi",
          manageBooking,
          filename: fileContent.templatePath,
        })
      );
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function calculateBmi(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start

      const { bmi, userId, weightValue, heightValue, weightUnit, heightUnit } =
        req.body;

      const user: Types.ObjectId = new Types.ObjectId(userId);

      const bmiCount = await bmiModel.countDocuments({ addedBy: user });

      let getBmi;

      if (bmiCount >= 5) {
        const oldestBMI = await bmiModel
          .findOne({ added: user })
          .sort({ date: 1 });

        await bmiModel.findByIdAndDelete(oldestBMI?._id);
      }

      getBmi = await bmiModel.create({
        bmi: bmi,
        weight: weightValue,
        height: heightValue,
        weightUnit: weightUnit,
        heightUnit: heightUnit,
        addedBy: user,
      });

      res.json(getBmi);

      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for Privacy Policy
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function privacyPolicy(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "patientDashboard",
          "privacy-policy.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "patientDashboard",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for Terms of use
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function termsOfUse(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("patientDashboard", "terms-of-use.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "patientDashboard",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for questionire1
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function questionire1(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start

      const fileContent = getViewFile("patientDashboard", "questionaire1.ejs");
      const user: any = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          message: "",
          user,
          activeTab: "newbook",
          filename: fileContent.templatePath,
        })
      );
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for questionire2
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function questionire2(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "patientDashboard",
          "questionaire2.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "newbook",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for select-date-and-time
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */

export async function select_date_and_time(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "patientDashboard",
          "select-date-and-time.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "patientDashboard",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function rescheduleTimeSlot(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "patientDashboard",
          "reschedule.slot.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "patientDashboard",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for select-date-and-time
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function choosePharmacy(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "patientDashboard",
          "choose-pharmacy.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "patientDashboard",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function viewMyOrders(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { page, limit } = req.query;
    const patientId: Types.ObjectId = new Types.ObjectId(res.get("userId"));
    const manageBooking: Array<Booking> =
      await patientService.acceptedUpcomingBooking(
        patientId,
        parseInt(limit as string),
        parseInt(page as string)
      );

    const pharmacy = await patientService.getMyOrder(
      parseInt(limit as string),
      parseInt(page as string),
      patientId
    );

    // const obj:any = {};

    // for (let i = 0; i < orders.length; i++) {
    //   obj[i] = orders[i];
    // }

    // obj.for (let i = 0; i < obj.length; i++) {
    //   const element = array[i];

    // }

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "patientDashboard",
          "my-pharmacy-order.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "myorder",
            pharmacy,
            manageBooking,
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function viewPastHistory(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { page, limit } = req.query;
    const patientId: Types.ObjectId = new Types.ObjectId(res.get("userId"));

    const manageBooking: Array<Booking> =
      await patientService.acceptedUpcomingBooking(
        patientId,
        parseInt(limit as string),
        parseInt(page as string)
      );

    const booking = await patientService.pastBookings(
      patientId,
      page as string,
      limit as string
    );

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("patientDashboard", "past-history.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            booking,
            manageBooking,
            activeTab: "pastHistory",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for fill-your-details
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function fillYourDetails(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "patientDashboard",
          "fill-your-details.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "patientDashboard",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for payment-details
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function payment_details(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start

      const bookingData = req.body;

      const fileContent = getViewFile(
        "patientDashboard",
        "payment-details.ejs"
      );
      const user: any = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          message: "",
          user,
          activeTab: "newbook",
          bookingData,
          filename: fileContent.templatePath,
        })
      );
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for payment-details
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function confirmation(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("patientDashboard", "confirmation.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "newbook",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for payment-details
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function viewDoctorProfile(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "patientDashboard",
          "view-doctor-profile.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "patientDashboard",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function changePassword(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    let { currentPassword, password, confirmPassword } = req.body;
    let user: any = JSON.parse(res.get("user")!);
    user = await patientService.getUserByUserID(user._id);
    const isMatch = patientService.comparePassword(
      currentPassword,
      user.password
    );

    if (mode == "api") {
      //API Code Start
      if (isMatch) {
        if (password === confirmPassword) {
          const encryptPassword = patientService.encryptPassword(password);
          const data = await patientService.updatePssaword(
            user._id,
            encryptPassword
          );
          res.status(httpStatus.OK).send({
            message: "Password reset successfully",
            status: httpStatus.OK,
          });
        } else {
          res.status(httpStatus.BAD_REQUEST).send({
            message: "Password not match",
            status: httpStatus.BAD_REQUESTs,
          });
        }
      } else {
        res.status(httpStatus.BAD_REQUEST).send({
          message: "Current password not match",
          status: httpStatus.BAD_REQUESTs,
        });
      }
      //   //API Code End
    } else {
      //Web Code Start
      const fileContent = getViewFile("patientdashboard", "edit-profile.ejs");
      const isMatch = patientService.comparePassword(
        currentPassword,
        user.password
      );

      if (isMatch) {
        if (password === confirmPassword) {
          const encryptPassword = patientService.encryptPassword(password);
          const data = await patientService.updatePssaword(
            user._id,
            encryptPassword
          );
          res.send(
            ejs.render(fileContent.file, {
              message: "Password reset successfully",
              message1: "",
              user,
              activeTab: "patientDashboard",
              patient: "",
              filename: fileContent.templatePath,
            })
          );
        } else {
          res.send(
            ejs.render(fileContent.file, {
              message1: "Password not match",
              message: "",
              user,
              activeTab: "patientDashboard",
              patient: "",
              filename: fileContent.templatePath,
            })
          );
        }
      } else {
        res.send(
          ejs.render(fileContent.file, {
            message1: "Current password not match",
            message: "",
            user,
            activeTab: "patientDashboard",
            patient: "",
            filename: fileContent.templatePath,
          })
        );
      }
      //Web Code End
    }
  } catch (err) {
    console.log(err);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: err,
      message: "Internal server error",
    });
  }
}
export async function chat(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { limit, page } = req.query;
    const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const user = JSON.parse(res.get("user")!);
    let consultantId = new Types.ObjectId(req.body.personvalue);

    let patientId;
    if (user.addedBy == undefined) {
      patientId = id;
    } else {
      patientId = new Types.ObjectId(user.addedBy);
    }
    const booking = await patientService.bookingGetById(
      consultantId,
      patientId
    );
    const bookingId = booking.map((e) => {
      return e._id;
    });
    const manageBooking: Array<Booking> = await patientService.acceptedBooking(
      patientId,
      parseInt(limit as string),
      parseInt(page as string)
    );

    const newId = bookingId.toString();

    const channel = newId;
    let token;
    const uid = 0;
    const role = RtcRole.PUBLISHER;
    const expirationTimeInSeconds = 3600;
    const currentTimestamp = Math.floor(Date.now() / 1000);
    const privilegeExpiredTs = currentTimestamp + expirationTimeInSeconds;
    const appId = process.env.appId;
    const appCertificate = process.env.appCertificate;

    // Build token with uid
    if (
      appId == undefined ||
      appCertificate == undefined ||
      channel == undefined
    ) {
    } else {
      token = RtcTokenBuilder.buildTokenWithUid(
        appId,
        appCertificate,
        channel,
        uid,
        role,
        privilegeExpiredTs
      );
    }
    if (mode == "api") {
      //API Response
      res.status(httpStatus.OK).json({ token, channel, appId });
    } else {
      //Web Response

      const fileContent = getViewFile("patientDashboard", "chat.ejs");
      const user: any = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          user,
          appId,
          token,
          activeTab: "chat",
          channel,
          manageBooking,
          filename: fileContent.templatePath,
        })
      );
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function upcomingChat(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { limit, page } = req.query;
    const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const user = JSON.parse(res.get("user")!);
    let consultantId = new Types.ObjectId(req.body.personvalue);

    let patientId;
    if (user.addedBy == undefined) {
      patientId = id;
    } else {
      patientId = new Types.ObjectId(user.addedBy);
    }
    const booking = await patientService.upcomingChat(
      consultantId,
      patientId
    );
    const bookingId = booking.map((e) => {
      return e._id;
    });

    const manageBooking: Array<Booking> =
      await patientService.acceptedUpcomingBooking(
        patientId,
        parseInt(limit as string),
        parseInt(page as string)
      );

      
    const newId = bookingId.toString();

    const channel = newId;
    let token;
    const uid = 0;
    const role = RtcRole.PUBLISHER;
    const expirationTimeInSeconds = 3600;
    const currentTimestamp = Math.floor(Date.now() / 1000);
    const privilegeExpiredTs = currentTimestamp + expirationTimeInSeconds;
    const appId = process.env.appId;
    const appCertificate = process.env.appCertificate;

    // Build token with uid
    if (
      appId == undefined ||
      appCertificate == undefined ||
      channel == undefined
    ) {
    } else {
      token = RtcTokenBuilder.buildTokenWithUid(
        appId,
        appCertificate,
        channel,
        uid,
        role,
        privilegeExpiredTs
      );
    }
    if (mode == "api") {
      //API Response
      res.status(httpStatus.OK).json({ token, channel, appId });
    } else {
      //Web Response

      const fileContent = getViewFile("patientDashboard", "upcoming-chat.ejs");
      const user: any = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          user,
          appId,
          token,
          channel,
          activeTab: "chat",
          manageBooking,
          filename: fileContent.templatePath,
        })
      );
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}
/**
 * @description This function is for Chat
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function Demo(req: Request, res: Response) {
  try {
    const { mode, recieverId, rid } = req.params;
    const message = req.body.message;

    // const myId =      Types.ObjectId(req.body.value)

    let consultantId = new Types.ObjectId(req.body.personvalue);

    const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const user = JSON.parse(res.get("user")!);

    let patientId;
    if (user.addedBy == undefined) {
      patientId = id;
    } else {
      patientId = new Types.ObjectId(user.addedBy);
    }

    const booking = await patientService.bookingaccepted(
      consultantId,
      patientId
    );

    const { limit, page } = req.query;
    const manageBooking: Array<Booking> = await patientService.acceptedBooking(
      patientId,
      parseInt(limit as string),
      parseInt(page as string)
    );

    const bookings = booking[0]?._id;

    const bookingId = bookings?.toString();

    const channel: any = bookingId;
    let token;
    const uid = 0;
    const role = RtcRole.PUBLISHER;
    const expirationTimeInSeconds = 3600;
    const currentTimestamp = Math.floor(Date.now() / 1000);
    const privilegeExpiredTs = currentTimestamp + expirationTimeInSeconds;
    const appId = process.env.appId;
    const appCertificate = process.env.appCertificate;

    // Build token with uid
    if (appId == undefined || appCertificate == undefined) {
    } else {
      token = RtcTokenBuilder.buildTokenWithUid(
        appId,
        appCertificate,
        channel,
        uid,
        role,
        privilegeExpiredTs
      );
    }

    res.json({
      channel,
      appId,
      appCertificate,
      token,
      booking,
    });
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function videoCall(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const { limit, page } = req.query;
    if (mode == "api") {
    } else {
      //Web Code Start

      if (req.method == "GET") {
        let consultantId = new Types.ObjectId(req.params.id);
        const fileContent = getViewFile("patientDashboard", "video.ejs");
        const user: any = JSON.parse(res.get("user")!);
        const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
        let patientId;
        if (user.addedBy == undefined) {
          patientId = id;
        } else {
          patientId = new Types.ObjectId(user.addedBy);
        }

        const manageBooking: Array<Booking> =
          await patientService.bookingGetById(
            consultantId,
            patientId
            // parseInt(limit as string),
            // parseInt(page as string)
          );

        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "chat",
            manageBooking,
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function voiceCall(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const { limit, page } = req.query;
    if (mode == "api") {
    } else {
      //Web Code Start

      if (req.method == "GET") {
        let consultantId = new Types.ObjectId(req.params.id);
        const fileContent = getViewFile("patientDashboard", "voice.ejs");
        const user: any = JSON.parse(res.get("user")!);
        const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
        let patientId;
        if (user.addedBy == undefined) {
          patientId = id;
        } else {
          patientId = new Types.ObjectId(user.addedBy);
        }

        const manageBooking: Array<Booking> =
          await patientService.bookingGetById(
            consultantId,
            patientId
            // parseInt(limit as string),
            // parseInt(page as string)
          );

        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "chat",
            manageBooking,
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function getImage(req: Request, res: Response) {
  try {
    const userId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const { page, limit } = req.query;

    const patientImage = await patientModel.findById(userId);
    res.status(httpStatus.OK).send({
      data: patientImage,
      message: "Notifications fetched successfully",
      status: httpStatus.OK,
    });
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      status: httpStatus.INTERNAL_SERVER_ERROR,
      message: err.message,
    });
  }
}

export async function getPharmacy(req: Request, res: Response) {
  try {
    console.log(req.body, " hhh");

    const { mode } = req.params;
    const { page, limit } = req.query;

    const pharmacies = await patientService.getPharamcies(
      req.body,
      page,
      limit
    );

    res.json(pharmacies);

    //Web Code End
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.OK).send({ message: err.message });
  }
}
