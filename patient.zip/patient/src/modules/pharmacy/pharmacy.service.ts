import { Types } from "mongoose";
import pharmacyModel, { Pharmacy } from "./pharmacy.model";

/**
 * @description this function is used to create the pharmacy
 * @param {any} createPharmacyDto
 * @returns {Promise<Pharmacy>}
 * @author Keshav suman
 */
export async function createPharmacy(
  createPharmacyDto: any
): Promise<Pharmacy> {
  return await pharmacyModel.create(createPharmacyDto);
}

/**
 * @description thsi function is used to get pharmacies
 * @param {string} search
 * @param {number} page
 * @param {number} limit
 * @returns {Promise<Pharmacy>}
 * @author Keshav suman
 */
export async function getPharamcies(
  search: string,
  page: number,
  limit: number
): Promise<Array<Pharmacy>> {
  return await pharmacyModel
    .find(
       {
    //   $or: [
    //     {
    //       firstName: { $regex: search, $options: "i" },
    //     },
    //     {
    //       lastName: { $regex: search, $options: "i" },
    //     },
    //     {
    //       isDeleted: false,
    //     },
    //   ],
    }
    ) .limit(limit)
    .skip(limit * (page - 1));
    
}




export async function getPharamciesBySearch (
  cho: string,
  eircode:string,
pharmacy:string,
  page: number,
  limit: number
): Promise<Array<Pharmacy>> {
 
  if(cho){
    return await pharmacyModel.find({cho:cho}).skip((limit * page) - limit) ;
   
}

else if(eircode){
  return await pharmacyModel.find({eircode:eircode}).limit(limit).skip((page-1)*limit);
}
else if(pharmacy){
    return await pharmacyModel.find({storeName:{$regex:pharmacy,$options:"i"}}).limit(limit).skip((page-1)*limit);
  }

      else{
        return await pharmacyModel.find().limit(limit).skip((page-1)*limit);
      }
}
    



/**
 * @description this function is used to xupdate the pharmacy
 * @param {Types.ObjectId} pharmacyId
 * @param {any} updatePharmacyDto
 * @returns {Promise<Pharmacy|null>}
 * @author Keshav suman
 */
export async function updatePharmacy(
  pharmacyId: Types.ObjectId,
  updatePharmacyDto: any
): Promise<Pharmacy | null> {
  return await pharmacyModel.findByIdAndUpdate(pharmacyId, updatePharmacyDto);
}

/**
 * @description THis fucntion is used to delete the pharamcy
 * @param pharmacyId
 * @returns
 */
export async function deletePharmacy(
  pharmacyId: Types.ObjectId
): Promise<Pharmacy | null> {
  return await pharmacyModel.findByIdAndDelete(pharmacyId);
}
