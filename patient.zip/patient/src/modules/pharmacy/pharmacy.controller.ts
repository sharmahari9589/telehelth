import httpStatus from "http-status";
import { Request, Response } from "express";
import * as pharmacyService from "./pharmacy.service";
import { Types } from "mongoose";

//EJS Rendor
import ejs from "ejs";
import { getViewFile } from "../../utils/ejsHelper";

export async function createPharmacy(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const createPharmacyDto = req.body;
    const pharmacy = await pharmacyService.createPharmacy(createPharmacyDto);
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: pharmacy,
        message: "Pharmacy created succesfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const user: any = JSON.parse(res.get("user")!);
        const fileContent = getViewFile("adminDashboard", "add-pharmacy.ejs");
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code Start
        const createPharmacyDto = req.body;
        const pharmacy = await pharmacyService.createPharmacy(
          createPharmacyDto
        );
        const user: any = JSON.parse(res.get("user")!);
        const fileContent = getViewFile("adminDashboard", "add-pharmacy.ejs");
        res.send(
          ejs.render(fileContent.file, {
            message: "Pharmacy created succesfully",
            user,
            filename: fileContent.templatePath,
          })
        );
        //Post Method Code End
      }

      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.OK).send({ message: err.message });
  }
}

export async function getPharmacies(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { search, page, limit } = req.query;
    const pharmacies = await pharmacyService.getPharamcies(
      search as string,
      parseInt(page as string),
      parseInt(limit as string)
    );
    if (mode === "api") {
      res.status(httpStatus.OK).send({
        status: httpStatus.OK,
        message: "Pharmacies fetched successfully",
        data: pharmacies,
      });
    } else {
      //Web Code Start
      const user: any = JSON.parse(res.get("user")!);
      const fileContent = getViewFile(
        "adminDashboard",
        "view-all-pharmacy.ejs"
      );
      res.send(
        ejs.render(fileContent.file, {
          message: "",
          user,
          pharmacies,
          filename: fileContent.templatePath,
        })
      );
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.OK).send({ message: err.message });
  }
}

export async function updatePharamcy(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const pharmacyId: Types.ObjectId = new Types.ObjectId(req.params.id);
    const pharmacy = await pharmacyService.updatePharmacy(pharmacyId, req.body);
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: pharmacy,
        message: "Pharmacy updated successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      res.redirect("/admin/web/pharmacy/get-pharmacy?search=&page=1&limit=10");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.OK).send({ message: err.message });
  }
}

export async function deletePharmacy(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const pharmacyId: Types.ObjectId = new Types.ObjectId(req.params.id);
    const pharmacy = await pharmacyService.deletePharmacy(pharmacyId);
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: pharmacy,
        message: "Pharmacy deleted succesfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      res.redirect("/admin/web/pharmacy/get-pharmacy?search=&page=1&limit=10");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.OK).send({ message: err.message });
  }
}
