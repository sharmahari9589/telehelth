import express from "express";
import * as pharmacyController from "./pharmacy.controller";

const route = express.Router({ mergeParams: true });

route
  .route("/add-pharmacy")
  .get(pharmacyController.createPharmacy)
  .post(pharmacyController.createPharmacy);

route.get("/get-pharmacy", pharmacyController.getPharmacies);
route.post("/update-pharmacy/:id", pharmacyController.updatePharamcy);
route.post("/delete-pharmacy/:id", pharmacyController.deletePharmacy);

//Export Route
export default route;
