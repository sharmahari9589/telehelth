import { Router } from "express";

const router = Router();

router.get("/");

export default router;
