import { Types } from "mongoose";
import questionnaireModel from "./questionnaire.model";

export async function getQuestionnaire(
  problemId: Types.ObjectId,
  limit: number,
  page: number
) {
  const questionnaire = await questionnaireModel
    .find({
      problemId: problemId,
    })
    .skip((page - 1) * limit)
    .limit(limit);
  return questionnaire;
}
