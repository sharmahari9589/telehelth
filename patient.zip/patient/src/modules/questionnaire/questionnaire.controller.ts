import httpStatus from "http-status";
import { Request, Response } from "express";

export async function getQuestionnaire(req: Request, res: Response) {
  try {
    // const questionnaire = await questionnaire
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ message: err.message });
  }
}
