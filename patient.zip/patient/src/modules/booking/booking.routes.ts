import { Router } from "express";
import * as bookingController from "./booking.controller";

const router = Router({
  mergeParams: true,
});

router
  .route("/add-new-booking")
  .get(bookingController.addNewBooking)
  .post(bookingController.addNewBooking);

router
  .route("/get-questionnaire")
  .get(bookingController.getQuestionnairePre)
  .post(bookingController.getQuestionnairePre);

router
  .route("/get-questionnaire-post")
  .get(bookingController.getQuestionnairePost)
  .post(bookingController.getQuestionnairePost);




router
  .route("/select-date-and-time")
  .get(bookingController.selectDateAndTime)
  .post(bookingController.selectDateAndTime);


  router
  .route("/reschedule-date-and-time")
  .get(bookingController.rescheduleDateAndTime)
  .post(bookingController.rescheduleDateAndTime);

router
  .route("/select-pharmacy")
  .get(bookingController.selectPharmacy)
  .post(bookingController.selectPharmacy);

router
  .route("/confirm-booking")
  .get(bookingController.confirmBooking)
  .post(bookingController.confirmBooking);


  router
  .route("/booking-confirm")
  .get(bookingController.bookingConfirm)
  .post(bookingController.bookingConfirm);    


router
  .route("/get-all-bookings")
  .get(bookingController.getAllBooking)
  .post(bookingController.getAllBooking);

router
  .route("/cancel-booking/:id")
  .get(bookingController.cancelBooking)
  .post(bookingController.cancelBooking);


  router.route("/cancledbookings")
  .get(bookingController.getCancelBookings )
  .post(bookingController.getCancelBookings)

  router.route("/delete-booking")
  .get(bookingController.deleteBooking )
  .post(bookingController.deleteBooking)


router
  .route("/reschedule-booking")
  .get(bookingController.rescheduledBooking)
  .post(bookingController.rescheduledBooking);
//router.post("/getDoctors", bookingController.addNewBooking);

router
.route("/rescheduledbookings")
.get(bookingController.rescheduledBookings)
.post(bookingController.rescheduledBookings);  


router
.route("/completedbookings")
.get(bookingController.completedBookings)
.post(bookingController.completedBookings);  
 
router

  .route("/reshedulebooking")
  .get(bookingController.rescheduledBooking)
  .post(bookingController.rescheduledBooking);  



  
router
.route("/confirmation")
.get(bookingController.getConfirmPage)
.post(bookingController.getConfirmPage);

router
  .route("/unpaid")
  .get(bookingController.getUnpaidBooking)
  .post(bookingController.getUnpaidBooking);



export default router;
