import mongoose, { Document, model, Schema, Types } from "mongoose";
import { Consultant } from "../consultant/consultant.model";
import { Patient } from "../patientDashboard/patient.model";
import { Pharmacy } from "../pharmacy/pharmacy.model";

export enum BookingMode {
  Online = "Online",
  Offline = "Offline",
}

export enum Gender {
  Male = "male",
   Female = "female",
   Other = "other",
   Transgender = 'transgender' ,	
   Notdisclosed	='notDisclosed'
 }
 export enum MaritialStatus {
  Married = "married",
  Single = "single",	
Partnered	='partnered',
Divorce	='divorce',
Widow	='widow',
Others	='others',	
Notdisclosed	='notDisclosed'

}

export enum BloodGroup {
 
  OPlus = "O+",
  OMinus="O-",
  ABPlus="AB+",
  ABMinus="AB-",
  APlus = "A+",
  BPlus = "B+",
  AMinus="A-",
  BMinus="B-"
}



export enum BookingStatus {
  Pending = "pending",
  Cancelled = "cancelled",
  Accepted = "accepted",
  Reschedule="reschedule",
  completed="completed"
}
export interface Booking extends Document {
  doctor:  Types.ObjectId | Consultant;
  problem: Types.ObjectId;
  service: Types.ObjectId,
  pharmacy: Types.ObjectId;
  payment: Types.ObjectId;
  chat: Types.ObjectId;

  date: Date;
  status: BookingStatus;
   time: Date;
   bookingId:string
  startTime:Date,
  endTime:Date,
  reschedule: [{ date: Date; startTime:Date; endTime:Date}];
  isPaid: boolean;
  fess:Number
  bookingMode: BookingMode;
  patient: Types.ObjectId;
  cancelReason: string;
  htmlContent:string;
  title: string;
 questions:Array<Object>
 dynamicQuestions:Array<Object>
 bookingFor:object
 allergy:string
 gmsNo:string

}

const bookingForSchema = new mongoose.Schema({
  patientName: {
    type: String,
  },
  dateofBirth: {
    type: Date,
  },
  gender: {
    type: String,
    enum: Gender
  },
  maritalStatus: {
    type: String,
    enum: MaritialStatus,
  },
  location: {
    type: String,
  },
  eirCode: {
    type: String,
  },
 

  mobileNumber: {
    type: String,
  },
  bloodGroup: {
    type: String,
    enum: BloodGroup
  }
},{_id:false}
);





const bookingSchema = new Schema<Booking>(
  {
    doctor: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "consultant",
    },
    problem: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "healthproblem",
    },
    service: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "service",
    },
    pharmacy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "pharmacy",
    },
    payment: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "payments",
    },
    bookingId: {
      type: String,
    },

    allergy: {
      type: String,
    },
    gmsNo: {
      type: String,
    },
    date: {
      type: Date,
    },
    startTime:{
     type:Date
    },
    endTime:{
      type:Date
    },
  
    reschedule: {
      type: [{date: Date, startTime:Date, endTime:Date}],
      default: [],
    },
    status: {
      type: String,
      default: BookingStatus.Pending,
      enum: BookingStatus,
    },
    isPaid: {
      type: Boolean,
      default: false,
    },
    fess:{
      type:Number,
    },
    bookingMode: {
      type: String,
      enum: BookingMode,
    },
    patient: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "patient",
    }, 
     chat: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "chat",
    },
    cancelReason: {
      type: String,
    },
    questions:[{
      title: {
   
        type: String,
      },
      answerType: {
        type: String,
      },

      subQuestion:[ {
        type:String
      }],
      subAnswer:[{
        type:String
      }],
      _id:false
    }
  
  ],

  dynamicQuestions:[{
    title: {
 
      type: String,
    },
    answer: {
      type: String,
    },
   
  _id:false
   
  }],
  bookingFor:bookingForSchema 
},


  {
    timestamps: true,
  }
);

export default model<Booking>("booking", bookingSchema);








