import { Types } from "mongoose";
import patientModel, { Gender } from "../patientDashboard/patient.model";
import bookingModel, {
  BookingMode,
  Booking,
  BookingStatus,
} from "./booking.model";
import * as consultantService from "../consultant/consultant.service";
import consultantModel, { Consultant } from "../consultant/consultant.model";
import orderModel from "../order/order.model";
 import  pharmacyModel from "../pharmacy/pharmacy.model";
import healthProblemModel from "../../models/healthProblem.model";
import scheduleModel, { Schedule } from "../schedule/schedule.model";
import serviceModel, { Service } from "../../models/service.model";
import staticQuestionModel, { StaticQuestion } from "../../models/static.question.model";
import { Commison, commisonModel } from "../../models/commison.model";
import { promises } from "dns";
import paymentModel, { Payment } from "../payment/payment.model";
import admin from "../../models/admin";

export async function setDefaultBookingSettings(consultantId: string) {
  const data = await bookingModel.create({});
}


export async function getScheduleByDoctorId(
  doctorId: Types.ObjectId
): Promise<Schedule| null> {
  return await scheduleModel.findOne({doctor: doctorId});
}


export async function fetchDoctors(
  status: BookingMode,
  gender: Gender,
  problemId: Types.ObjectId
) {
 
  // const data = await consultantService.findConsultants(
  //     "", problemId, 20, 1
  //   );
  // return data;
  return await healthProblemModel.aggregate(
    [
      {
        '$match': {
          '_id': problemId
        }
      }, {
        '$project': {
          'speciality': 1
        }
      }, {
        '$lookup': {
          'from': 'doctors', 
          'localField': 'speciality', 
          'foreignField': 'speciality', 
          'as': 'doctor'
        }
      }, {
        '$unwind': {
          'path': '$doctor', 
          'preserveNullAndEmptyArrays': true
        }
      }, {
        '$lookup': {
          'from': 'schedules', 
          'localField': 'doctor._id', 
          'foreignField': 'doctor', 
          'as': 'data'
        }
      }, {
        '$unwind': {
          'path': '$data', 
          'preserveNullAndEmptyArrays': true
        }
      },    ]
  )
}




export async function getCommison(
  ): Promise<Array<Commison>> {
   return await commisonModel.find();
 }



 export async function getDoctorFess(doctor:Types.ObjectId
  ) {
   return await scheduleModel.findOne({doctor:doctor});
 }


 export async function getServices(serviceId:Types.ObjectId

  )

   {

   return await serviceModel.findById({_id:serviceId});
 }



/**
 * @description This function is used to create the booking
 * @param createBookingDto
 * @returns Promise<Booking>
 * @author Nikhil chouhan
 */
export async function createBooking(createBookingDto: any): Promise<Booking> {
  return await bookingModel.create(createBookingDto);
}

/**
 * @description This function is used to get the list of pharmacies
 * @param {Number} page
 * @param {Number} limit
 * @returns {Promise<Array<Booking>>}
 */
export async function getBookings(
  limit: number,
  page: number,
  patientId: Types.ObjectId
): Promise<Array<Booking>> {
  return await bookingModel.aggregate([
    {
      '$match': {
        '$and': [
          {
            'patient':patientId
          },{status: {
            $in: ["reschedule","accepted",]
          }
        }
        ]
      }
    },{
    '$match': {
      isPaid:true,
    }},
    {
      $lookup: {
        from: "doctors",
        localField: "doctor",
        foreignField: "_id",
        as: "doctor",
      },
    },
    {
      $lookup: {
        from: "healthproblems",
        localField: "problem",
        foreignField: "_id",
        as: "problem",
      },
    },
    {
      $lookup: {
        from: "pharmacies",
        localField: "pharmacy",
        foreignField: "_id",
        as: "pharmacy",
      },
    },
    {
      $lookup: {
        from: "patients",
        localField: "patient",
        foreignField: "_id",
        as: "patient",
      },
    },
    {
      $unwind: {
        path: "$doctor",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $unwind: {
        path: "$problem",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $unwind: {
        path: "$pharmacy",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $unwind: {
        path: "$patient",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $lookup: {
        from: "services",
        localField: "service",
        foreignField: "_id",
        as: "service",
      },
    },
    {
      $unwind: {
        path: "$service",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $lookup: {
        from: "payments",
        localField: "_id",
        foreignField: "bookingId",
        as: "payment",
      },
    },
    {
      $unwind: {
        path: "$payment",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      '$match': {
        "payment.status": "succeeded",
      }},
      {
        "$sort":{date:-1}
      }

  ])
}



export async function getUnpaidBookings(
  limit: number,
  page: number,
  patientId: Types.ObjectId
): Promise<Array<Booking>> {
  return await bookingModel.aggregate([
    {
      '$match': {
        '$and': [
          {
            'patient':patientId
          },{status:"pending"
          }
        
      
        ]
      }
    },{
    '$match': {
      isPaid:false,
    }},
    {
      $lookup: {
        from: "doctors",
        localField: "doctor",
        foreignField: "_id",
        as: "doctor",
      },
    },
    {
      $lookup: {
        from: "healthproblems",
        localField: "problem",
        foreignField: "_id",
        as: "problem",
      },
    },
    {
      $lookup: {
        from: "pharmacies",
        localField: "pharmacy",
        foreignField: "_id",
        as: "pharmacy",
      },
    },
    {
      $lookup: {
        from: "patients",
        localField: "patient",
        foreignField: "_id",
        as: "patient",
      },
    },
    {
      $unwind: {
        path: "$doctor",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $unwind: {
        path: "$problem",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $unwind: {
        path: "$pharmacy",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $unwind: {
        path: "$patient",
        preserveNullAndEmptyArrays: true,
      },
    },{
      $lookup: {
        from: "services",
        localField: "service",
        foreignField: "_id",
        as: "service",
      },
    },
    {
      $unwind: {
        path: "$service",
        preserveNullAndEmptyArrays: true,
      },
    },



    {
      $lookup: {
        from: "payments",
        localField: "_id",
        foreignField: "bookingId",
        as: "payment",
      },
    },
    {
      $unwind: {
        path: "$payment",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      '$match': {
        "payment.status": "pending",
      }},
      {
        "$sort":{date:-1}
      }



  ]);
}




export async function getOrders(
  patientId: Types.ObjectId,
 

  limit: number,
  page: number
) {

  return await orderModel
    .find({
     patient: patientId,

    })

    .limit(limit)
    .skip((page - 1) * limit);
}





export async function cancelBooking(
  bookingId: Types.ObjectId,status:String,cancelReason:String
): Promise<Booking | null> {
  return await bookingModel.findByIdAndUpdate(bookingId, {
    status,cancelReason
  });
}




export async function bookingupdateById(
  bookingId: Types.ObjectId,
  rescheduleDto: any,
  status:String,
  previousdata:any
) {
  
  return await
    bookingModel.findByIdAndUpdate(bookingId,{
      ...rescheduleDto,status,
      $push:{reschedule:previousdata,}
    });
  }


export async function getPatientsPreviousBookings(
  patientId: Types.ObjectId,
  startDate: Date,
  endDate: Date,
  limit: number,
  page: number
) {
  return await bookingModel
    .find({
      patient: patientId,
      createdAt: {
        $or: [
          {
            $gte: startDate,
          },
          {
            $lte: endDate,
          },
        ],
      },
    })
    .populate("doctor")
    .limit(limit)
    .skip(limit * (page - 1));
}

export async function getConsultantsFromBookingArray(
  bookings: Array<Booking>
): Promise<Array<Consultant>> {
  return bookings.map((booking: Booking) => booking.doctor as Consultant);
}


export async function getCancelledBoking(
  patientId:Types.ObjectId
) {
  return  bookingModel.findOne({id:patientId,status:"cancelled"})
}





export async function getCancelOredrs(
  patientId:Types.ObjectId,
  bookingId: Types.ObjectId,
  limit: number,
  page: number
) {

  return await bookingModel.aggregate(
[
      {
        '$match': {
          '$and': [
            {
              'patient':patientId
            }, {
              'status': 'cancelled'
            }
          ]
        }
      }, {
        '$lookup': {
          'from': 'doctors', 
          'localField': 'doctor', 
          'foreignField': '_id', 
          'as': 'doctor'
        }
      }, {
        '$unwind': {
          'path': '$doctor', 
          'preserveNullAndEmptyArrays': true
        }
      }, {
        $sort: {
          'date': -1
        }
      }
    ]
      
  )
   }

   
export async function getRescheduleBookings(
  patientId:Types.ObjectId,
  bookingId: Types.ObjectId,
  limit: number,
  page: number
) {

  return await bookingModel.aggregate(
[
      {
        '$match': {
          '$and': [
            {
              'patient':patientId
            }, {
              'status': 'reschedule'
            }
          ]
        }
      }, {
        '$lookup': {
          'from': 'doctors', 
          'localField': 'doctor', 
          'foreignField': '_id', 
          'as': 'doctor'
        }
      }, {
        '$unwind': {
          'path': '$doctor', 
          'preserveNullAndEmptyArrays': true
        }
      },
      // {
      //   '$unwind': {
      //     'path': '$reschedule', 
      //     'preserveNullAndEmptyArrays': true
      //   }
      //  },
       {
        $sort: {
          'date': -1
        }
      }
    ]
      
  )
  
   }


  /**
 * @description This function is used to find Bookings by ID
 * @param BookingID
 * @returns Promise<Booking>
 * @author Nikhil chouhan
 */
  export async function findBookingById(bookingId:Types.ObjectId) {
    return await bookingModel.findById(bookingId)
  };
  



  
   
export async function getCompletedBookings(
  patientId:Types.ObjectId,
  limit: number,
  page: number
) {

  return await orderModel.aggregate(
    [
      {
        '$match': {
          'patient':patientId,
        }
      }, {
        '$lookup': {
          'from': 'bookings', 
          'localField': 'booking', 
          'foreignField': '_id', 
          'as': 'booking'
        }
      }, {
        '$unwind': {
          'path': '$booking', 
          'preserveNullAndEmptyArrays': true
        }
      }, {
        '$match': {
          'booking.status': 'completed'
        }
      },
      {
        '$sort': {
          'booking.date': -1
        }
      },
      
      {
        '$lookup': {
          'from': 'services', 
          'localField': 'booking.service', 
          'foreignField': '_id', 
          'as': 'service'
        }
      }, {
        '$unwind': {
          'path': '$service', 
          'preserveNullAndEmptyArrays': true
        }
      },
      
      
      
      {
        '$lookup': {
          'from': 'healthproblems', 
          'localField': 'problem', 
          'foreignField': '_id', 
          'as': 'problem'
        }
      }, {
        '$unwind': {
          'path': '$problem', 
          'preserveNullAndEmptyArrays': true
        }
      }, {
        '$lookup': {
          'from': 'patients', 
          'localField': 'patient', 
          'foreignField': '_id', 
          'as': 'patient'
        }
      }, {
        '$unwind': {
          'path': '$patient', 
          'preserveNullAndEmptyArrays': true
        }
      }, {
        '$lookup': {
          'from': 'doctors', 
          'localField': 'consultant', 
          'foreignField': '_id', 
          'as': 'consultant'
        }
      }, {
        '$unwind': {
          'path': '$consultant', 
          'preserveNullAndEmptyArrays': true
        }
      }, {
        '$unwind': {
          'path': '$prescription', 
          'preserveNullAndEmptyArrays': true
        }
      }


    ]  )
  
   }

   
/**
 * @description This function is used to Get Questions On the Basis of Problem Id
 * @param 
 * @returns Promise<>
 * @author Nikhil chouhan
 */
export async function getQuestionByProblemId(getProblemName: Types.ObjectId) {
  const admins = await admin.find();
  
  const results = [];
  
  for (const adminObj of admins) {
    const loopId = adminObj._id;
  
    const aggregationResult = await healthProblemModel.aggregate([
      {
        '$match': {
          '_id': getProblemName
        }
      },
      {
        '$lookup': {
          'from': 'questions',
          'localField': 'name',
          'foreignField': 'problem',
          'as': 'questions'
        }
      },
      {
        '$unwind': {
          'path': '$questions',
          'preserveNullAndEmptyArrays': true
        }
      },
      {
        '$match': {
          'questions.addedBy': loopId
        }
      },
    ]);

    // Check if the aggregation result is not empty before pushing
    if (aggregationResult.length > 0) {
      results.push(...aggregationResult);
    }
  }
  
  return results;
}






export async function getAllService(
 ): Promise<Array<Service>> {
  return await serviceModel.find();
}


export async function fetchDoctorByService(serviceId:Types.ObjectId
  ): Promise<Array<Service>> {
   return await serviceModel.aggregate(
    [
      {
        '$match': {
          '_id': serviceId
        }
      }, {
        '$unwind': {
          'path': '$doctors', 
          'preserveNullAndEmptyArrays': true
        }
      }, {
        '$lookup': {
          'from': 'doctors', 
          'localField': 'doctors', 
          'foreignField': '_id', 
          'as': 'doctor'
        }
      }, {
        '$unwind': {
          'path': '$doctor', 
          'preserveNullAndEmptyArrays': true
        }
      }
    ]

   )
 }
 

 
export async function getStaticQuestion(
  ): Promise<Array<StaticQuestion>> {
   return await staticQuestionModel.find();
 }




 export async function createPayment(paymentDto:any){
   return await paymentModel.create(paymentDto);
 }



 export async function deleteBookingById(bookingId:Types.ObjectId) {
  return await bookingModel.findByIdAndDelete(bookingId)
};





export async function countNumber() {
    
  return await bookingModel.find().count()
  }