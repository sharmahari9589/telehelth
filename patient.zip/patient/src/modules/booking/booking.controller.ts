import { Request, Response, query } from "express";
import httpStatus from "http-status";
import * as bookingService from "./booking.service";
import * as questionnaireService from "../questionnaire/questionnaire.service";
import * as pharmacyService from "../pharmacy/pharmacy.service";
import mongoose, { Types } from "mongoose";
import * as patientService from "../patientDashboard/patient.service"
import * as notification from "../notification/notification.controller"


//EJS Rendor
import ejs from "ejs";
import { getViewFile } from "../../utils/ejsHelper";
import bookingModel, { Booking } from "./booking.model";
import { Order } from "../order/order.model";
import healthProblemModel from "../../models/healthProblem.model";
import consultantModel from "../consultant/consultant.model";
import questionnaireModel from "../questionnaire/questionnaire.model";
import { log } from "console";
import { start } from "repl";
import dotenv from "dotenv";

dotenv.config({
  path: ".env",
});

import Stripe from "stripe";
import patientModel from "../patientDashboard/patient.model";
import pharmacyModel from "../pharmacy/pharmacy.model";

const key = process.env.PUBLISHABLE_KEY;

export async function createBooking(req: Request, res: Response) {
  try {
    const user = JSON.parse(res.get("user")!);
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function addNewBooking(req: Request, res: Response) {
  try {
    const user = JSON.parse(res.get("user")!);


    const patient= await patientModel.findById(user._id);
    
    
    const { mode } = req.params;

    const {limit,page} = req.query
    const manageBooking: Array<Booking> = await patientService.acceptedUpcomingBooking(user._id,
      parseInt(limit as string),
      parseInt(page as string)
    );

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: "",
        message: "Doctors fetched successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      const bookingData = req.body;

      const commison = await bookingService.getCommison();

      if (req.method == "GET") {
        const fileContent = getViewFile("patientDashboard", "new-booking.ejs");
        const problemListing = await healthProblemModel.find();
        const allServices = await bookingService.getAllService();

        res.send(
          ejs.render(fileContent.file, {
            user,
            bookingData,
            problemListing,
            allServices,patient,
            commison,manageBooking,activeTab:'newbook',
            filename: fileContent.templatePath,
          })
        );
      } else {
        const { status, gender } = req.body;
        let doctors;
        let services;
        let problemId;
        let message;

        //Post Method Code
        const bookingData = req.body;

        if (req.body.problemId !== "") {
          problemId = new Types.ObjectId(req.body.problemId);

          doctors = await bookingService.fetchDoctors(
            status,
            gender,
            problemId
          );
          
        } else if (req.body.service !== "") {
          const AllServices = new Types.ObjectId(req.body.service);

          services = await bookingService.fetchDoctorByService(AllServices);
        } else {
          message = "please select any field";
        }

        const fileContent = getViewFile(
          "patientDashboard",
          "select-doctor.ejs"
        );

        res.send(
          ejs.render(fileContent.file, {
            doctors,
            problemId,
            user,patient,
            services,
            bookingData,
            message,activeTab:'newbook',
            commison,manageBooking,
            filename: fileContent.templatePath,
          })
        );
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function getQuestionnairePre(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const user = JSON.parse(res.get("user")!);
    const { page, limit } = req.query;

    const staticQuestion = await bookingService.getStaticQuestion();

    const doctorId = new Types.ObjectId(req.body["doctor-id"]);
    
    const getDoctorQuestionnaire = await questionnaireModel.find({
      addedBy: doctorId,
    });


    const problemId: Types.ObjectId = new Types.ObjectId(req.body.problemId);

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: "",
        message: "Questionnaire fetched successfully",
        status: httpStatus.OK,
      });
    } else {
      if (req.body["problem-id"] !== undefined) {
        const getProblemName = new Types.ObjectId(req.body["problem-id"]);
        const getAdminQuestionnaire =
          await bookingService.getQuestionByProblemId(getProblemName);



        const data = await questionnaireService.getQuestionnaire(
          problemId,
          parseInt(page as string),
          parseInt(limit as string)
        );
        //Web Code Start
        if (req.method == "GET") {
          const bookingData = req.body;

          const fileContent = getViewFile(
            "patientDashboard",
            "questionaire1.ejs"
          );
          res.send(
            ejs.render(fileContent.file, {
              data,
              user,activeTab:'newbook',
              bookingData,
              staticQuestion,
              getDoctorQuestionnaire,
              getAdminQuestionnaire,
              filename: fileContent.templatePath,
            })
          );
        }

        //Web Code End
        else {
          //Post Method Code

          const bookingData = req.body;

          const getProblemName = new Types.ObjectId(req.body["problem-id"]);
          const getAdminQuestionnaire =
            await bookingService.getQuestionByProblemId(getProblemName);




          const data = await questionnaireService.getQuestionnaire(
            problemId,
            parseInt(page as string),
            parseInt(limit as string)
          );

          const fileContent = getViewFile(
            "patientDashboard",
            "questionaire1.ejs"
          );
          res.send(
            ejs.render(fileContent.file, {
              data,
              user,activeTab:'newbook',
              bookingData,
              problemId,
              staticQuestion,
              getDoctorQuestionnaire,
              getAdminQuestionnaire,

              filename: fileContent.templatePath,
            })
          );
        }
        //Web Code End
      } else {
        if (req.method == "GET") {
          const bookingData = req.body;

          const fileContent = getViewFile(
            "patientDashboard",
            "questionaire1.ejs"
          );
          res.send(
            ejs.render(fileContent.file, {
              user,
              bookingData,activeTab:'newbook',
              getDoctorQuestionnaire,
              staticQuestion,
              filename: fileContent.templatePath,
            })
          );
        }

        //Web Code End
        else {
          //Post Method Code

          const bookingData = req.body;

          const serviceId = new Types.ObjectId(bookingData.service);

          const services = await bookingService.getServices(serviceId);

          const fileContent = getViewFile(
            "patientDashboard",
            "questionaire1.ejs"
          );
          res.send(
            ejs.render(fileContent.file, {
              user,
              bookingData,
              problemId,
              services,activeTab:'newbook',
              getDoctorQuestionnaire,
              staticQuestion,

              filename: fileContent.templatePath,
            })
          );
        }
      }
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function getQuestionnairePost(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const user = JSON.parse(res.get("user")!);

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        message: "Questionnaire fetched successfully",
        status: httpStatus.OK,
      });
    } else {
      //Post Method Code
      const bookingData = req.body;
      
      const staticQuestion = await bookingService.getStaticQuestion();

      const fileContent = getViewFile("patientDashboard", "questionaire2.ejs");
      res.send(
        ejs.render(fileContent.file, {
          user,
          bookingData,
          staticQuestion,activeTab:'newbook',
          filename: fileContent.templatePath,
        })
      );
    } //Web Code Start

    //Web Code End
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function selectDateAndTime(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const user = JSON.parse(res.get("user")!);
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        message: "Slot Booked Successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      const bookingData = req.body;

      if (bookingData["service"]) {
        const doc = bookingData["doctor-id"];
        const doctor = new Types.ObjectId(doc);

        const service = bookingData["service"];
        const serviceId = new Types.ObjectId(service);

        const services = await bookingService.getServices(serviceId);

        const doctorFess = await bookingService.getDoctorFess(doctor);

        const adminCommison = await bookingService.getCommison();

        const fileContent = getViewFile(
          "patientDashboard",
          "select-date-and-time.ejs"
        );
        res.send(
          ejs.render(fileContent.file, {
            user,
            message:"",
            bookingData,activeTab:'newbook',
            doctorFess,
            adminCommison,
            services,
            filename: fileContent.templatePath,
          })
        );
        //Web Code End
      } else {
        const doc = bookingData["doctor-id"];

        const doctor = new Types.ObjectId(doc);

        const doctorFess = await bookingService.getDoctorFess(doctor);

        const adminCommison = await bookingService.getCommison();

        const fileContent = getViewFile(
          "patientDashboard",
          "select-date-and-time.ejs"
        );
        res.send(
          ejs.render(fileContent.file, {
            user,
            message:"",
            bookingData,
            doctorFess,activeTab:'newbook',
            adminCommison,
            filename: fileContent.templatePath,
          })
        );
      }
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function selectPharmacy(req: Request, res: Response) {
  try {
    const bookingData = req.body;
    let booking;

    let payment;

    
    if (req.body.slot && bookingData["problemId"] !== "") {

      const slot = req.body.slot;

      const slotTime = Number(req.body.slotTime);

      const time = slot[slotTime];

      let startTime = time.slice(1, 6);

      let endTime = time.slice(7, 12);

      const [startHour, startMinute] = startTime.split(":");
      const [endHour, endMinute] = endTime.split(":");

      const startDates = new Date();
      startDates.setHours(startHour);
      startDates.setMinutes(startMinute);

      const endDates = new Date();
      endDates.setHours(endHour);
      endDates.setMinutes(endMinute);

      const start = startDates;
      const end = endDates;
      const diffInMilliseconds = end.getTime() - start.getTime();
      const diffInSeconds = diffInMilliseconds / 1000;
      const diff = diffInSeconds / 60;

      const diffInMinutes = Number(diff.toFixed(0));

      let charges;

      if (diffInMinutes == 15) {
        charges = Number(req.body.fees1);
      }
      if (diffInMinutes == 30) {
        charges = Number(req.body.fees2);
      }
      if (diffInMinutes == 60) {
        charges = Number(req.body.fess3);

     
      }

      const {
        doctorId,
        problemId,
        pharmacyId,
        service,
        fullName,
        maritialStatus,
        bloodGroup,
        eirCode,
        dob,
        mobileNumber,
        gender,
        location,
        bookingDate,
        orderdate,
        allergy ,
      gmsNo
  
  
      } = req.body;



      
    const count = await bookingService.countNumber();

    const patientDob = new Date(dob);
    // const bookDate = new Date(bookingDate);
     
    const date = new Date(bookingDate);
    const startDate = new Date(bookingDate);
  
    const endDate = new Date(bookingDate);
  
  
    const formattedDate = date.toISOString();
    
    const bookDate = formattedDate.replace("Z", "+00:00");
  
  
  
    const [hours, minutes] = startTime.split(":");
  
    startDate.setHours(hours);
    startDate.setMinutes(minutes);
    
    // Adding delay of 5.30 hours
    const delayHours = 5;
    const delayMinutes = 30;
    
    startDate.setHours(startDate.getHours() + delayHours);
    startDate.setMinutes(startDate.getMinutes() + delayMinutes);
    
    const newStartTime = startDate
  
    const [endHours,endMinutes] = endTime.split(":");
  
    endDate.setHours(endHours);
    endDate.setMinutes(endMinutes);
    
    const delayHoursEnd = 5;
    const delayMinutesEnd = 30;
    
    endDate.setHours(endDate.getHours() + delayHoursEnd);
    endDate.setMinutes(endDate.getMinutes() + delayMinutesEnd);
    
    const newEndTime = endDate
     


    let patientBooking = {
      patientName: fullName,
      dateofBirth: patientDob,
      gender: gender,
      maritalStatus: maritialStatus,
      location: location,
      mobileNumber: mobileNumber,
      eirCode: eirCode,
    
    };

    let questionDto = [
      {
        title: req.body.question1,
        answerType: req.body.answerType1,
        subQuestion: [
          req.body?.["subquestion1.1"],
          req.body?.["subquestion1.2"],
          req.body?.["subquestion1.3"],
          req.body?.["subquestion1.4"],
          req.body?.["subquestion1.5"],
          req.body?.["subquestion1.6"],
        ],
        subAnswer: [
          req.body?.["subanswer1.1"],
          req.body?.["subanswer1.2"],
          req.body?.["subanswer1.3"],
          req.body?.["subanswer1.4"],
          req.body?.["subanswer1.5"],
          req.body?.["subanswer1.6"],
        ],
      },
      {
        title: req.body.question2,
        answerType: req.body.answerType2,
        subQuestion: [
          req.body?.["subquestion2.1"],
          req.body?.["subquestion2.2"],
          req.body?.["subquestion2.3"],
          req.body?.["subquestion2.4"],
        ],
        subAnswer: [
          req.body?.["subanswer2.1"],
          req.body?.["subanswer2.2"],
          req.body?.["subanswer2.3"],
          req.body?.["subanswer2.4"],
        ],
      },
      {
        title: req.body.question3,
        answerType: req.body.answerType3,
        subQuestion: [
          req.body?.["subquestion3.1"],
          req.body?.["subquestion3.2"],
          req.body?.["subquestion3.3"],
          req.body?.["subquestion3.4"],
          req.body?.["subquestion3.5"],
          req.body?.["subquestion3.6"],
        ],
        subAnswer: [
          req.body?.["subanswer3.1"],
          req.body?.["subanswer3.2"],
          req.body?.["subanswer3.3"],
          req.body?.["subanswer3.4"],
          req.body?.["subanswer3.5"],
          req.body?.["subanswer3.6"],
        ],
      },
      {
        title: req.body.question4,
        answerType: req.body.answerType4,
        subQuestion: [
          req.body?.["subquestion4.1"],
          req.body?.["subquestion4.2"],
          req.body?.["subquestion4.3"],
          req.body?.["subquestion4.4"],
          req.body?.["subquestion4.5"],
          req.body?.["subquestion4.6"],
        ],
        subAnswer: [
          req.body?.["subanswer4.1"],
          req.body?.["subanswer4.2"],
          req.body?.["subanswer4.3"],
          req.body?.["subanswer4.4"],
          req.body?.["subanswer4.5"],
          req.body?.["subanswer4.6"],
        ],
      },
      {
        title: req.body.question5,
        answerType: req.body.answerType5,
        subQuestion: [
          req.body?.["subquestion5.1"],
          req.body?.["subquestion5.2"],
          req.body?.["subquestion5.3"],
          req.body?.["subquestion5.1.1"],
          req.body?.["subquestion5.1.2"],
          req.body?.["subquestion5.1.3"],
          req.body?.["subquestion5.1.4"],
          req.body?.["subquestion5.1.5"],
          req.body?.["subquestion5.1.6"],
          req.body?.["subquestion5.1.7"],
          req.body?.["subquestion5.1.8"],
          req.body?.["subquestion5.1.9"],
          req.body?.["subquestion5.1.10"],
          req.body?.["subquestion5.1.11"],
        ],

        subAnswer: [
          req.body?.["subanswer5.1.1_A"],
          req.body?.["subanswer5.1.1_B"],
          req.body?.["subanswer5.1.2_A"],
          req.body?.["subanswer5.1.2_B"],
          req.body?.["subanswer5.1.3_A"],
          req.body?.["subanswer5.1.3_B"],
          req.body?.["subanswer5.1.4_A"],
          req.body?.["subanswer5.1.4_B"],
          req.body?.["subanswer5.1.5_A"],
          req.body?.["subanswer5.1.5_B"],
          req.body?.["subanswer5.1.6_A"],
          req.body?.["subanswer5.1.6_B"],
          req.body?.["subanswer5.1.7_A"],
          req.body?.["subanswer5.1.7_B"],
          req.body?.["subanswer5.1.8_A"],
          req.body?.["subanswer5.1.8_B"],
          req.body?.["subanswer5.1.9_A"],
          req.body?.["subanswer5.1.9_B"],
          req.body?.["subanswer5.1.10_A"],
          req.body?.["subanswer5.1.10_B"],
          req.body?.["subanswer5.1.11_A"],
          req.body?.["subanswer5.1.11_B"],
        ],
      },
      {
        title: req.body.question6,
        answerType: req.body.answerType6,
        subQuestion: [
          req.body?.["subquestion6.1"],
          req.body?.["subquestion6.2"],
          req.body?.["subquestion6.3"],
          req.body?.["subquestion6.4"],
        ],
        subAnswer: [
          req.body?.["subanswer6.1"],
          req.body?.["subanswer6.2"],
          req.body?.["subanswer6.3"],
          req.body?.["subanswer6.4"],
        ],
      },
      {
        title: req.body.question7,
        answerType: req.body.answerType7,
        subQuestion: [
          req.body?.["subquestion7.1"],
          req.body?.["subquestion7.2"],
          req.body?.["subquestion7.3"],
          req.body?.["subquestion7.4"],
        ],
        subAnswer: [
          req.body?.["subanswer7.1"],
          req.body?.["subanswer7.2"],
          req.body?.["subanswer7.3"],
          req.body?.["subanswer7.4"],
        ],
      },
      {
        title: req.body.question8,
        answerType: req.body.answerType8,
        subQuestion: [
          req.body?.["subquestion8.1"],
          req.body?.["subquestion8.2"],
          req.body?.["subquestion8.3"],
          req.body?.["subquestion8.4"],
        ],
        subAnswer: [
          req.body?.["subanswer8.1"],
          req.body?.["subanswer8.2"],
          req.body?.["subanswer8.3"],
          req.body?.["subanswer8.4"],
        ],
      },
      {
        title: req.body.question9,
        answerType: req.body.answerType9,
        subQuestion: [
          req.body?.["subquestion9.1"],
          req.body?.["subquestion9.2"],
          req.body?.["subquestion9.3"],
          req.body?.["subquestion9.4"],
        ],
        subAnswer: [
          req.body?.["subanswer9.1"],
          req.body?.["subanswer9.2"],
          req.body?.["subanswer9.3"],
          req.body?.["subanswer9.4"],
        ],
      },
      {
        title: req.body.question10,
        answerType: req.body.answerType10,
        subQuestion: [
          req.body?.["subquestion10.1"],
          req.body?.["subquestion10.2"],
          req.body?.["subquestion10.3"],
          req.body?.["subquestion10.4"],
        ],
        subAnswer: [
          req.body?.["subanswer10.1"],
          req.body?.["subanswer10.2"],
          req.body?.["subanswer10.3"],
          req.body?.["subanswer10.4"],
        ],
      },
      // {
      //   title:req.body.questionAdmin,
      //     answerType:req.body.answer,
      //   }
      {
        title: req.body.question11,
        answerType: req.body.answerType11,
      },
      {
        title: req.body.question12,
        answerType: req.body.answerType12,
      },
      {
        title: req.body.question13,
        answerType: req.body.answerType13,
        answer: req.body?.["answer13.1"],
      },
      {
        title: req.body.question14,
        answerType: req.body.answerType14,
      },
      {
        title: req.body.question15,
        answerType: req.body.answerType15,
      },
      {
        title: req.body.question16,
        answerType: req.body.answerType16,
        answer: req.body?.["answer16.1"],
      },
      {
        title: req.body.question17,
        answerType: req.body.answerType17,
        subQuestion: [req.body?.["subquestion17.1"]],
        subAnswer: [req.body?.["subanswer17.1"]],
      },
      {
        title: req.body.question18,
        answerType: req.body.answerType18,
        subQuestion: [req.body?.["subquestion18.1"]],
        subAnswer: [req.body?.["subanswer18.1"]],
      },
      {
        title: req.body.question19,
        answerType: req.body.answerType19,
        answer: req.body?.["answer19.1"],
      },
      {
        title: req.body.question20,
        answerType: req.body.answerType20,
        answer: req.body?.["answer20.1"],
      },
      {
        title: req.body.question21,
        answerType: req.body.answerType21,
      },
      {
        title: req.body.question22,
        answerType: req.body.answerType22,
      },
      {
        title: req.body.question23,
        answerType: req.body.answerType23,
      },
      {
        title: req.body.question24,
        answerType: req.body.answerType24,
      },
      {
        title: req.body.question25,
        answerType: req.body.answerType25,
      },

      // {
      //    title:req.body.questionDoctor0,
      //      answerType:req.body.answer,
      //   }
    ];

    let dynamicDto = [
      {
        title: req.body.questionDoctor0,
        answer: req.body.doctorAnswer0,
      },
      {
        title: req.body.questionDoctor1,
        answer: req.body.doctorAnswer1,
      },
      {
        title: req.body.questionDoctor2,
        answer: req.body.doctorAnswer2,
      },
      {
        title: req.body.questionDoctor3,
        answer: req.body.doctorAnswer3,
      },
      {
        title: req.body.questionDoctor4,
        answer: req.body.doctorAnswer4,
      },
      {
        title: req.body.questionDoctor5,
        answer: req.body.doctorAnswer5,
      },
      {
        title: req.body.questionDoctor6,
        answer: req.body.doctorAnswer6,
      },
      {
        title: req.body.questionDoctor7,
        answer: req.body.doctorAnswer7,
      },
      {
        title: req.body.questionDoctor8,
        answer: req.body.doctorAnswer8,
      },
      {
        title: req.body.questionDoctor9,
        answer: req.body.doctorAnswer9,
      },
      {
        title: req.body.questionDoctor10,
        answer: req.body.doctorAnswer10,
      },
      {
        title: req.body.questionDoctor11,
        answer: req.body.doctorAnswer11,
      },
      {
        title: req.body.questionDoctor12,
        answer: req.body.doctorAnswer12,
      },
      {
        title: req.body.questionDoctor13,
        answer: req.body.doctorAnswer13,
      },
      {
        title: req.body.questionDoctor14,
        answer: req.body.doctorAnswer14,
      },
      {
        title: req.body.questionDoctor15,
        answer: req.body.doctorAnswer15,
      },
      {
        title: req.body.questionDoctor16,
        answer: req.body.doctorAnswer16,
      },
      {
        title: req.body.questionDoctor17,
        answer: req.body.doctorAnswer17,
      },
      {
        title: req.body.questionDoctor18,
        answer: req.body.doctorAnswer18,
      },
      {
        title: req.body.questionDoctor19,
        answer: req.body.doctorAnswer19,
      },
      {
        title: req.body.questionDoctor20,
        answer: req.body.doctorAnswer20,
      },
      {
        title: req.body.questionDoctor21,
        answer: req.body.doctorAnswer21,
      },
      {
        title: req.body.questionDoctor22,
        answer: req.body.doctorAnswer22,
      },

      {
        title: req.body.questionDoctor23,
        answer: req.body.doctorAnswer23,
      },
      {
        title: req.body.questionDoctor24,
        answer: req.body.doctorAnswer24,
      },
      {
        title: req.body.questionDoctor25,
        answer: req.body.doctorAnswer25,
      },

      //admin answer start

      {
        title: req.body.questionAdmin0,
        answer: req.body.adminAnswer0,
      },

      {
        title: req.body.questionAdmin1,
        answer: req.body.adminAnswer1,
      },
      {
        title: req.body.questionAdmin2,
        answer: req.body.adminAnswer2,
      },
      {
        title: req.body.questionAdmin3,
        answer: req.body.adminAnswer3,
      },
      {
        title: req.body.questionAdmin4,
        answer: req.body.adminAnswer4,
      },
      {
        title: req.body.questionAdmin5,
        answer: req.body.adminAnswer5,
      },

      {
        title: req.body.questionAdmin6,
        answer: req.body.adminAnswer6,
      },
      {
        title: req.body.questionAdmin7,
        answer: req.body.adminAnswer7,
      },
      {
        title: req.body.questionAdmin8,
        answer: req.body.adminAnswer8,
      },
      {
        title: req.body.questionAdmin9,
        answer: req.body.adminAnswer9,
      },
      {
        title: req.body.questionAdmin10,
        answer: req.body.adminAnswer10,
      },
      {
        title: req.body.questionAdmin11,
        answer: req.body.adminAnswer11,
      },
      {
        title: req.body.questionAdmin12,
        answer: req.body.adminAnswer12,
      },
      {
        title: req.body.questionAdmin13,
        answer: req.body.adminAnswer13,
      },
      {
        title: req.body.questionAdmin14,
        answer: req.body.adminAnswer14,
      },
      {
        title: req.body.questionAdmin15,
        answer: req.body.adminAnswer15,
      },
      {
        title: req.body.questionAdmin16,
        answer: req.body.adminAnswer16,
      },
      {
        title: req.body.questionAdmin17,
        answer: req.body.adminAnswer17,
      },
      {
        title: req.body.questionAdmin18,
        answer: req.body.adminAnswer18,
      },
      {
        title: req.body.questionAdmin19,
        answer: req.body.adminAnswer19,
      },
      {
        title: req.body.questionAdmin20,
        answer: req.body.adminAnswer20,
      },
      {
        title: req.body.questionAdmin21,
        answer: req.body.adminAnswer21,
      },
      {
        title: req.body.questionAdmin22,
        answer: req.body.adminAnswer22,
      },
      {
        title: req.body.questionAdmin23,
        answer: req.body.adminAnswer23,
      },
      {
        title: req.body.questionAdmin24,
        answer: req.body.adminAnswer24,
      },
      {
        title: req.body.questionAdmin25,
        answer: req.body.adminAnswer25,
      },
    ];




      const bookingProblemDto = {
      
        problem: new Types.ObjectId(problemId),
        doctor: new Types.ObjectId(doctorId),
        date: bookDate,
        bookingId: count,
        startTime: newStartTime,
        endTime: newEndTime,
        fess: charges,
        bookingFor: patientBooking,
        allergy:allergy,
        gmsNo:gmsNo,

        
        patient: new Types.ObjectId(res.get("userId")!),
        questions: questionDto,
        dynamicQuestions: dynamicDto,
      };

      booking = await bookingService.createBooking(bookingProblemDto);
      const paymentDto = {
        bookingId: booking.id,
        patientId: bookingProblemDto.patient,
        amount: bookingProblemDto.fess,
      };

      
      payment = await bookingService.createPayment(paymentDto);
   
    


      const { mode } = req.params;
      const { search, } = req.query;

      const limit = 10;
    const page = req.query.page || 1;

    const counts= await pharmacyModel.find().count()

      const pharmacies = await pharmacyService.getPharamcies(
        search as string,
       page as any,
        limit as any
      );

      const user = JSON.parse(res.get("user")!);
      
       
        //Web Code Start
        const bookingId= booking._id;
        const bookingData = req.body;
        const fileContent = getViewFile(
          "patientDashboard",
          "choose-pharmacy.ejs"
        );
        res.send(
          ejs.render(fileContent.file, {
            user,
            message:"",
            bookingData,bookingId,
            startTime,
            endTime,activeTab:'newbook',
            current: page,
            pages: Math.ceil(counts / limit),
            pharmacies,
            charges, booking,
            filename: fileContent.templatePath,
          })
        );
      }
  
   
  

    else if (req.body.slot && bookingData["service"] !== "") {
      const slot = req.body.slot;



      
      const {
        doctorId,
        problemId,
        pharmacyId,
        service,
        fullName,
        maritialStatus,
        bloodGroup,
        eirCode,
        dob,
        mobileNumber,
        gender,
        location,
        bookingDate,
        orderdate,
        allergy ,
      gmsNo
  
  
      } = req.body;

      
    const date = new Date(bookingDate);

    const startDate = new Date(bookingDate);
  
    const endDate = new Date(bookingDate);
    const formattedDate = date.toISOString();
    
    const bookDate = formattedDate.replace("Z", "+00:00");
  

      const slotTime = Number(req.body.slotTime);

      const time = slot[slotTime];

      let startTime = time.slice(1, 6);
      

      let endTime = time.slice(7, 12);




      const [hours, minutes] = startTime.split(":");
  
      startDate.setHours(hours);
      startDate.setMinutes(minutes);
      
      // Adding delay of 5.30 hours
      const delayHours = 5;
      const delayMinutes = 30;
      
      startDate.setHours(startDate.getHours() + delayHours);
      startDate.setMinutes(startDate.getMinutes() + delayMinutes);
      
      const newStartTime = startDate
    
      const [endHours,endMinutes] = endTime.split(":");
    
      endDate.setHours(endHours);
      endDate.setMinutes(endMinutes);
      
      const delayHoursEnd = 5;
      const delayMinutesEnd = 30;
      
      endDate.setHours(endDate.getHours() + delayHoursEnd);
      endDate.setMinutes(endDate.getMinutes() + delayMinutesEnd);
      
      const newEndTime = endDate
       
      const charges = Number(req.body.fess);


    const count = await bookingService.countNumber();

    const patientDob = new Date(dob);


    let patientBooking = {
      patientName: fullName,
      dateofBirth: patientDob,
      gender: gender,
      maritalStatus: maritialStatus,
      location: location,
      mobileNumber: mobileNumber,
      eirCode: eirCode,
    
    };

    let questionDto = [
      {
        title: req.body.question1,
        answerType: req.body.answerType1,
        subQuestion: [
          req.body?.["subquestion1.1"],
          req.body?.["subquestion1.2"],
          req.body?.["subquestion1.3"],
          req.body?.["subquestion1.4"],
          req.body?.["subquestion1.5"],
          req.body?.["subquestion1.6"],
        ],
        subAnswer: [
          req.body?.["subanswer1.1"],
          req.body?.["subanswer1.2"],
          req.body?.["subanswer1.3"],
          req.body?.["subanswer1.4"],
          req.body?.["subanswer1.5"],
          req.body?.["subanswer1.6"],
        ],
      },
      {
        title: req.body.question2,
        answerType: req.body.answerType2,
        subQuestion: [
          req.body?.["subquestion2.1"],
          req.body?.["subquestion2.2"],
          req.body?.["subquestion2.3"],
          req.body?.["subquestion2.4"],
        ],
        subAnswer: [
          req.body?.["subanswer2.1"],
          req.body?.["subanswer2.2"],
          req.body?.["subanswer2.3"],
          req.body?.["subanswer2.4"],
        ],
      },
      {
        title: req.body.question3,
        answerType: req.body.answerType3,
        subQuestion: [
          req.body?.["subquestion3.1"],
          req.body?.["subquestion3.2"],
          req.body?.["subquestion3.3"],
          req.body?.["subquestion3.4"],
          req.body?.["subquestion3.5"],
          req.body?.["subquestion3.6"],
        ],
        subAnswer: [
          req.body?.["subanswer3.1"],
          req.body?.["subanswer3.2"],
          req.body?.["subanswer3.3"],
          req.body?.["subanswer3.4"],
          req.body?.["subanswer3.5"],
          req.body?.["subanswer3.6"],
        ],
      },
      {
        title: req.body.question4,
        answerType: req.body.answerType4,
        subQuestion: [
          req.body?.["subquestion4.1"],
          req.body?.["subquestion4.2"],
          req.body?.["subquestion4.3"],
          req.body?.["subquestion4.4"],
          req.body?.["subquestion4.5"],
          req.body?.["subquestion4.6"],
        ],
        subAnswer: [
          req.body?.["subanswer4.1"],
          req.body?.["subanswer4.2"],
          req.body?.["subanswer4.3"],
          req.body?.["subanswer4.4"],
          req.body?.["subanswer4.5"],
          req.body?.["subanswer4.6"],
        ],
      },
      {
        title: req.body.question5,
        answerType: req.body.answerType5,
        subQuestion: [
          req.body?.["subquestion5.1"],
          req.body?.["subquestion5.2"],
          req.body?.["subquestion5.3"],
          req.body?.["subquestion5.1.1"],
          req.body?.["subquestion5.1.2"],
          req.body?.["subquestion5.1.3"],
          req.body?.["subquestion5.1.4"],
          req.body?.["subquestion5.1.5"],
          req.body?.["subquestion5.1.6"],
          req.body?.["subquestion5.1.7"],
          req.body?.["subquestion5.1.8"],
          req.body?.["subquestion5.1.9"],
          req.body?.["subquestion5.1.10"],
          req.body?.["subquestion5.1.11"],
        ],

        subAnswer: [
          req.body?.["subanswer5.1.1_A"],
          req.body?.["subanswer5.1.1_B"],
          req.body?.["subanswer5.1.2_A"],
          req.body?.["subanswer5.1.2_B"],
          req.body?.["subanswer5.1.3_A"],
          req.body?.["subanswer5.1.3_B"],
          req.body?.["subanswer5.1.4_A"],
          req.body?.["subanswer5.1.4_B"],
          req.body?.["subanswer5.1.5_A"],
          req.body?.["subanswer5.1.5_B"],
          req.body?.["subanswer5.1.6_A"],
          req.body?.["subanswer5.1.6_B"],
          req.body?.["subanswer5.1.7_A"],
          req.body?.["subanswer5.1.7_B"],
          req.body?.["subanswer5.1.8_A"],
          req.body?.["subanswer5.1.8_B"],
          req.body?.["subanswer5.1.9_A"],
          req.body?.["subanswer5.1.9_B"],
          req.body?.["subanswer5.1.10_A"],
          req.body?.["subanswer5.1.10_B"],
          req.body?.["subanswer5.1.11_A"],
          req.body?.["subanswer5.1.11_B"],
        ],
      },
      {
        title: req.body.question6,
        answerType: req.body.answerType6,
        subQuestion: [
          req.body?.["subquestion6.1"],
          req.body?.["subquestion6.2"],
          req.body?.["subquestion6.3"],
          req.body?.["subquestion6.4"],
        ],
        subAnswer: [
          req.body?.["subanswer6.1"],
          req.body?.["subanswer6.2"],
          req.body?.["subanswer6.3"],
          req.body?.["subanswer6.4"],
        ],
      },
      {
        title: req.body.question7,
        answerType: req.body.answerType7,
        subQuestion: [
          req.body?.["subquestion7.1"],
          req.body?.["subquestion7.2"],
          req.body?.["subquestion7.3"],
          req.body?.["subquestion7.4"],
        ],
        subAnswer: [
          req.body?.["subanswer7.1"],
          req.body?.["subanswer7.2"],
          req.body?.["subanswer7.3"],
          req.body?.["subanswer7.4"],
        ],
      },
      {
        title: req.body.question8,
        answerType: req.body.answerType8,
        subQuestion: [
          req.body?.["subquestion8.1"],
          req.body?.["subquestion8.2"],
          req.body?.["subquestion8.3"],
          req.body?.["subquestion8.4"],
        ],
        subAnswer: [
          req.body?.["subanswer8.1"],
          req.body?.["subanswer8.2"],
          req.body?.["subanswer8.3"],
          req.body?.["subanswer8.4"],
        ],
      },
      {
        title: req.body.question9,
        answerType: req.body.answerType9,
        subQuestion: [
          req.body?.["subquestion9.1"],
          req.body?.["subquestion9.2"],
          req.body?.["subquestion9.3"],
          req.body?.["subquestion9.4"],
        ],
        subAnswer: [
          req.body?.["subanswer9.1"],
          req.body?.["subanswer9.2"],
          req.body?.["subanswer9.3"],
          req.body?.["subanswer9.4"],
        ],
      },
      {
        title: req.body.question10,
        answerType: req.body.answerType10,
        subQuestion: [
          req.body?.["subquestion10.1"],
          req.body?.["subquestion10.2"],
          req.body?.["subquestion10.3"],
          req.body?.["subquestion10.4"],
        ],
        subAnswer: [
          req.body?.["subanswer10.1"],
          req.body?.["subanswer10.2"],
          req.body?.["subanswer10.3"],
          req.body?.["subanswer10.4"],
        ],
      },
      // {
      //   title:req.body.questionAdmin,
      //     answerType:req.body.answer,
      //   }
      {
        title: req.body.question11,
        answerType: req.body.answerType11,
      },
      {
        title: req.body.question12,
        answerType: req.body.answerType12,
      },
      {
        title: req.body.question13,
        answerType: req.body.answerType13,
        answer: req.body?.["answer13.1"],
      },
      {
        title: req.body.question14,
        answerType: req.body.answerType14,
      },
      {
        title: req.body.question15,
        answerType: req.body.answerType15,
      },
      {
        title: req.body.question16,
        answerType: req.body.answerType16,
        answer: req.body?.["answer16.1"],
      },
      {
        title: req.body.question17,
        answerType: req.body.answerType17,
        subQuestion: [req.body?.["subquestion17.1"]],
        subAnswer: [req.body?.["subanswer17.1"]],
      },
      {
        title: req.body.question18,
        answerType: req.body.answerType18,
        subQuestion: [req.body?.["subquestion18.1"]],
        subAnswer: [req.body?.["subanswer18.1"]],
      },
      {
        title: req.body.question19,
        answerType: req.body.answerType19,
        answer: req.body?.["answer19.1"],
      },
      {
        title: req.body.question20,
        answerType: req.body.answerType20,
        answer: req.body?.["answer20.1"],
      },
      {
        title: req.body.question21,
        answerType: req.body.answerType21,
      },
      {
        title: req.body.question22,
        answerType: req.body.answerType22,
      },
      {
        title: req.body.question23,
        answerType: req.body.answerType23,
      },
      {
        title: req.body.question24,
        answerType: req.body.answerType24,
      },
      {
        title: req.body.question25,
        answerType: req.body.answerType25,
      },

      // {
      //    title:req.body.questionDoctor0,
      //      answerType:req.body.answer,
      //   }
    ];

    let dynamicDto = [
      {
        title: req.body.questionDoctor0,
        answer: req.body.doctorAnswer0,
      },
      {
        title: req.body.questionDoctor1,
        answer: req.body.doctorAnswer1,
      },
      {
        title: req.body.questionDoctor2,
        answer: req.body.doctorAnswer2,
      },
      {
        title: req.body.questionDoctor3,
        answer: req.body.doctorAnswer3,
      },
      {
        title: req.body.questionDoctor4,
        answer: req.body.doctorAnswer4,
      },
      {
        title: req.body.questionDoctor5,
        answer: req.body.doctorAnswer5,
      },
      {
        title: req.body.questionDoctor6,
        answer: req.body.doctorAnswer6,
      },
      {
        title: req.body.questionDoctor7,
        answer: req.body.doctorAnswer7,
      },
      {
        title: req.body.questionDoctor8,
        answer: req.body.doctorAnswer8,
      },
      {
        title: req.body.questionDoctor9,
        answer: req.body.doctorAnswer9,
      },
      {
        title: req.body.questionDoctor10,
        answer: req.body.doctorAnswer10,
      },
      {
        title: req.body.questionDoctor11,
        answer: req.body.doctorAnswer11,
      },
      {
        title: req.body.questionDoctor12,
        answer: req.body.doctorAnswer12,
      },
      {
        title: req.body.questionDoctor13,
        answer: req.body.doctorAnswer13,
      },
      {
        title: req.body.questionDoctor14,
        answer: req.body.doctorAnswer14,
      },
      {
        title: req.body.questionDoctor15,
        answer: req.body.doctorAnswer15,
      },
      {
        title: req.body.questionDoctor16,
        answer: req.body.doctorAnswer16,
      },
      {
        title: req.body.questionDoctor17,
        answer: req.body.doctorAnswer17,
      },
      {
        title: req.body.questionDoctor18,
        answer: req.body.doctorAnswer18,
      },
      {
        title: req.body.questionDoctor19,
        answer: req.body.doctorAnswer19,
      },
      {
        title: req.body.questionDoctor20,
        answer: req.body.doctorAnswer20,
      },
      {
        title: req.body.questionDoctor21,
        answer: req.body.doctorAnswer21,
      },
      {
        title: req.body.questionDoctor22,
        answer: req.body.doctorAnswer22,
      },

      {
        title: req.body.questionDoctor23,
        answer: req.body.doctorAnswer23,
      },
      {
        title: req.body.questionDoctor24,
        answer: req.body.doctorAnswer24,
      },
      {
        title: req.body.questionDoctor25,
        answer: req.body.doctorAnswer25,
      },

      //admin answer start

      {
        title: req.body.questionAdmin0,
        answer: req.body.adminAnswer0,
      },

      {
        title: req.body.questionAdmin1,
        answer: req.body.adminAnswer1,
      },
      {
        title: req.body.questionAdmin2,
        answer: req.body.adminAnswer2,
      },
      {
        title: req.body.questionAdmin3,
        answer: req.body.adminAnswer3,
      },
      {
        title: req.body.questionAdmin4,
        answer: req.body.adminAnswer4,
      },
      {
        title: req.body.questionAdmin5,
        answer: req.body.adminAnswer5,
      },

      {
        title: req.body.questionAdmin6,
        answer: req.body.adminAnswer6,
      },
      {
        title: req.body.questionAdmin7,
        answer: req.body.adminAnswer7,
      },
      {
        title: req.body.questionAdmin8,
        answer: req.body.adminAnswer8,
      },
      {
        title: req.body.questionAdmin9,
        answer: req.body.adminAnswer9,
      },
      {
        title: req.body.questionAdmin10,
        answer: req.body.adminAnswer10,
      },
      {
        title: req.body.questionAdmin11,
        answer: req.body.adminAnswer11,
      },
      {
        title: req.body.questionAdmin12,
        answer: req.body.adminAnswer12,
      },
      {
        title: req.body.questionAdmin13,
        answer: req.body.adminAnswer13,
      },
      {
        title: req.body.questionAdmin14,
        answer: req.body.adminAnswer14,
      },
      {
        title: req.body.questionAdmin15,
        answer: req.body.adminAnswer15,
      },
      {
        title: req.body.questionAdmin16,
        answer: req.body.adminAnswer16,
      },
      {
        title: req.body.questionAdmin17,
        answer: req.body.adminAnswer17,
      },
      {
        title: req.body.questionAdmin18,
        answer: req.body.adminAnswer18,
      },
      {
        title: req.body.questionAdmin19,
        answer: req.body.adminAnswer19,
      },
      {
        title: req.body.questionAdmin20,
        answer: req.body.adminAnswer20,
      },
      {
        title: req.body.questionAdmin21,
        answer: req.body.adminAnswer21,
      },
      {
        title: req.body.questionAdmin22,
        answer: req.body.adminAnswer22,
      },
      {
        title: req.body.questionAdmin23,
        answer: req.body.adminAnswer23,
      },
      {
        title: req.body.questionAdmin24,
        answer: req.body.adminAnswer24,
      },
      {
        title: req.body.questionAdmin25,
        answer: req.body.adminAnswer25,
      },
    ];


    

      




      const bookingServcieDto = {
        service: new Types.ObjectId(service),
        doctor: new Types.ObjectId(doctorId),
        date: bookDate,
        bookingId: count,
        startTime: startDate,
        endTime:endDate,
        fess: charges,
        allergy:allergy,
        gmsNo:gmsNo,
        bookingFor: patientBooking,
        patient: new Types.ObjectId(res.get("userId")!),
        questions: questionDto,
        dynamicQuestions: dynamicDto,
      };
     
      

      booking = await bookingService.createBooking(bookingServcieDto);




      

      const paymentDto = {
        bookingId: booking.id,
        patientId: bookingServcieDto.patient,
      
      
        amount: bookingServcieDto.fess,
      };

      payment = await bookingService.createPayment(paymentDto);
    
    
      const { mode } = req.params;
      const { search, } = req.query;

      const limit = 10;
      const page = req.query.page || 1;

      const counts= await pharmacyModel.find().count()
      const pharmacies = await pharmacyService.getPharamcies(
        search as string,
        page as any,
        limit as any
      );

      const user = JSON.parse(res.get("user")!);
      const bookingId= booking._id;

      
      
        const bookingData = req.body;
        const fileContent = getViewFile(
          "patientDashboard",
          "choose-pharmacy.ejs"
        );
        res.send(
          ejs.render(fileContent.file, {
            user,
            message:"",
            bookingData,
            startTime,activeTab:'newbook',
            endTime,
            pharmacies,bookingId,
            charges,booking,
            current: page,
            pages: Math.ceil(counts / limit),
            filename: fileContent.templatePath,
          })
        );
      }
 
    //Web Code End
    else {
      const user = JSON.parse(res.get("user")!);

      const bookingData = req.body;
      


      if(req.query){


        const limit = 10;
        const page = req.query.page || 1;
  
        const counts= await pharmacyModel.find().count()
      
       
        const { search,eirCode,pharmacy,bookingId, } = req.query;
      const pharmacies = await pharmacyService.getPharamciesBySearch (
        search as string,
        eirCode as string,
        pharmacy as string,
       page  as any,
        limit as any
      );
        const bookingData = req.body;
        const fileContent = getViewFile(
          "patientDashboard",
          "choose-pharmacy.ejs"
        );
        res.send(
          ejs.render(fileContent.file, {
            user,
            message:"",
            bookingData,booking,bookingId,
            startTime:"",endTime:"",charges:"",
            pharmacies ,activeTab:'newbook',
            current: page,
            pages: Math.ceil(counts / limit),
            
            filename: fileContent.templatePath,
          })
        );
      

      }



      
      else {

        
        
        const user = JSON.parse(res.get("user")!);

        const doc = bookingData["doctor-id"];

        const doctor = new Types.ObjectId(doc);

        const doctorFess = await bookingService.getDoctorFess(doctor);

        const adminCommison = await bookingService.getCommison();

        const fileContent = getViewFile(
          "patientDashboard",
          "select-date-and-time.ejs"
        );
        res.send(
          ejs.render(fileContent.file, {
            user,
            message:"Select Date and Time First",
            bookingData,activeTab:'newbook',
            doctorFess,
            
            adminCommison,booking,bookingId:``,
            filename: fileContent.templatePath,
          })
        );
      }
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function confirmBooking(req: Request, res: Response) {
  try {
  
 


 let bookingId= req.body.bookingId


 const addedParmacy= await bookingModel.findByIdAndUpdate({_id:bookingId},{pharmacy:req.body.pharmacyId})


 const bookingData =await bookingModel.findById(addedParmacy?._id)
 .populate({ path: "patient", model: patientModel })










    

      const user = JSON.parse(res.get("user")!);

      const fileContent = getViewFile("patientDashboard", "card.payment.ejs");
      res.send(
        ejs.render(fileContent.file, {
          key,
          user,
          bookingData,
          booking:"",
          payment:"",activeTab:'newbook',
          filename: fileContent.templatePath,
        })
      );

  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function bookingConfirm(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        message: "Slot Booked Successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start

      if (req.method == "GET") {
        const fileContent = getViewFile("patientDashboard", "confirmation.ejs");

        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            filename: fileContent.templatePath,
          })
        );
      }

       else {
        

        let bookingId= req.body.bookingId


       
       
        const bookingData =await bookingModel.findById({_id:bookingId})
        .populate({ path: "patient", model: patientModel })
       

       


        
        const user = JSON.parse(res.get("user")!);

        
        const fileContent = getViewFile("patientDashboard", "card.payment.ejs");
        res.send(
          ejs.render(fileContent.file, {
            user,
            key,
            bookingData,activeTab:'newbook',
            payment:"",
            booking:"",
            filename: fileContent.templatePath,
          })
        );
        //Web Code End
        }
   
  } 
}catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function getAllBooking(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { page, limit } = req.query;
    const patientId: Types.ObjectId = new Types.ObjectId(res.get("userId"));

 
    const manageBooking: Array<Booking> = await patientService.acceptedUpcomingBooking(patientId,
      parseInt(limit as string),
      parseInt(page as string)
    );
    const bookings = await bookingService.getBookings(
      parseInt(limit as string),
      parseInt(page as string),
      patientId
    );

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: bookings,
        message: "bookings fetched successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      
    
      const { page, limit } = req.query;


      const fileContent = getViewFile(
        "patientDashboard",
        "view-all-booking.ejs"
      );
      const user = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          user,
          message:"", activeTab:'mybook',
          bookings,manageBooking,
          filename: fileContent.templatePath,
        })
      );
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function cancelBooking(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const bookingId: Types.ObjectId = new Types.ObjectId(req.params.id);

    const status = "cancelled";
    const booking = await bookingService.cancelBooking(
      bookingId,
      status,
      req.body.cancelReason
    );

    if (booking) {
      //Create Notification
      const createNotificationDto = {
        notificationTitle: "Booking canceled Sucessfully ",
        notificationDescription: "Notification Description",
        notificationBy: booking?.patient,
        notificationTo: [booking?.doctor,booking?.patient,], //booking?.doctor
        notificationType : "booking_notification",
        notificationTypeId: booking?._id
      }
      await notification.createNotification(createNotificationDto);
    }


    if (mode == "api") {

      res.status(httpStatus.OK).send({
        data: booking,
        message: "Booking Canceled successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      res.redirect("/patient/web/booking/cancledbookings");
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ 
      message: err.message,
    });
  }
}

export async function getCancelBookings(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const patientId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const bookingId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const { limit, page } = req.query;

    const manageBooking: Array<Booking> = await patientService.acceptedUpcomingBooking(patientId,
      parseInt(limit as string),
      parseInt(page as string)
    );
    const booking: Array<Booking> = await bookingService.getCancelOredrs(
      patientId,
      bookingId,
      parseInt(limit as string),
      parseInt(page as string)
    );

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: booking,
        message: "Booking Canceled successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      const fileContent = getViewFile("patientDashboard", "cancel-booking.ejs");
      const user = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          user,
          booking,manageBooking, activeTab:'canBook',
          filename: fileContent.templatePath,
        })
      );
      //Web Code End

      //Web Code Start

      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function rescheduledBooking(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const { bookingDate, id, slot } = req.body;
    const patientId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const { limit, page } = req.query;


    const manageBooking: Array<Booking> = await patientService.acceptedUpcomingBooking(patientId,
      parseInt(limit as string),
      parseInt(page as string)
    );

    // const bookDate = new Date(bookingDate);


    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: "",
        message: "booking update successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start

if(req.body.slotTime){
      
    const slotTime = Number(req.body.slotTime);

    const time = slot[slotTime];

     let startTime = time.slice(1, 6);

    let endTime = time.slice(7, 12);


    const date = new Date(bookingDate);
    const startDate = new Date(bookingDate);

    const endDate = new Date(bookingDate);

  
  
    const formattedDate = date.toISOString();
    
    const bookDate = formattedDate.replace("Z", "+00:00");
  
  
  
    const [hours, minutes] = startTime.split(":");
  
    startDate.setHours(hours);
    startDate.setMinutes(minutes);
    
    // Adding delay of 5.30 hours

    const delayHours = 5;
    const delayMinutes = 30;
    
    startDate.setHours(startDate.getHours() + delayHours);
    startDate.setMinutes(startDate.getMinutes() + delayMinutes);
    
    const newStartTime = startDate
  
    const [endHours,endMinutes] = endTime.split(":");
  
    endDate.setHours(endHours);
    endDate.setMinutes(endMinutes);
    
    const delayHoursEnd = 5;
    const delayMinutesEnd = 30;
    
    endDate.setHours(endDate.getHours() + delayHoursEnd);
    endDate.setMinutes(endDate.getMinutes() + delayMinutesEnd);
    
    const newEndTime = endDate
     
    const bookingId: Types.ObjectId = new Types.ObjectId(id);

    const data = await bookingService.findBookingById(bookingId);

    const previousdata = {
      date: data?.date,
      startTime: data?.startTime,
      endTime: data?.endTime,
    };

    const rescheduleDto = {
      date: bookDate,
      startTime: newStartTime,
      endTime: newEndTime 
    };

    const status = "reschedule";
    const booking = await bookingService.bookingupdateById(
      bookingId,
      rescheduleDto,
      status,
      previousdata
    );

    if (booking) {
      //Create Notification
      const createNotificationDto = {
        notificationTitle: "Booking Reschedule Sucessfully",
        notificationDescription: "Notification Description",
        notificationBy: booking?.patient,
        notificationTo:[ booking?.doctor, booking?.patient], //booking?.doctor
        notificationType : "booking_notification",
        notificationTypeId: booking?._id
      }
      await notification.createNotification(createNotificationDto);
    }






      res.redirect("/patient/web/booking/get-all-bookings?limit=10&page=1");
    }
    
   

    else{

      const bookingData = req.body;

      const booking = new Types.ObjectId(bookingData.id);

      const updateBooking = await bookingModel.findById(booking);


      const startTime = updateBooking?.startTime;
      const endTime = updateBooking?.endTime;

      const startTimestamp:any = startTime?.getTime();

      const endTimestamp:any = endTime?.getTime();


      const timeDifference = endTimestamp - startTimestamp;
      

      const time = Math.floor(timeDifference / (1000 * 60));
      
      const user = JSON.parse(res.get("user")!);
      const fileContent = getViewFile(
        "patientDashboard",
        "reschedule-date-time.ejs"
      );
      res.send(
        ejs.render(fileContent.file, {
          user,
          message:"Doctor is Not Available On this Date",
          bookingData,activeTab:'mybook',
          updateBooking,
          time,
          filename: fileContent.templatePath,
        })
      );
    }
      }
      //Web Code End
}
  catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function rescheduledBookings(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const patientId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const bookingId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const { limit, page } = req.query;
    const booking: Array<Booking> = await bookingService.getRescheduleBookings(
      patientId,
      bookingId,
      parseInt(limit as string),
      parseInt(page as string)
    );
    //  const booking={...data}
    //  let data =booking[0].reschedule.pop()

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "patientDashboard",
          "reschedule-booking.ejs"
        );

        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            booking, activeTab:'resBook',
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function completedBookings(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const patientId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    // const bookingId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const { limit, page } = req.query;


 
    const manageBooking: Array<Booking> = await patientService.acceptedUpcomingBooking(patientId,
      parseInt(limit as string),
      parseInt(page as string)
    );
    const booking: Array<Order> = await bookingService.getCompletedBookings(
      patientId,
      parseInt(limit as string),
      parseInt(page as string)
    );

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "patientDashboard",
          "completed-booking.ejs"
        );

        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user, activeTab:'comBook',
            booking,manageBooking,
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function getConfirmPage(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { page, limit } = req.query;
    const patientId: Types.ObjectId = new Types.ObjectId(res.get("userId"));

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: "",
        message: "bookings fetched successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start

      const fileContent = getViewFile("patientDashboard", "confirmation.ejs");
      const user = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          user,activeTab:'newbook',
          filename: fileContent.templatePath,
        })
      );
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function getUnpaidBooking(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { page, limit } = req.query;
    const patientId: Types.ObjectId = new Types.ObjectId(res.get("userId"));


 
    const manageBooking: Array<Booking> = await patientService.acceptedUpcomingBooking(patientId,
      parseInt(limit as string),
      parseInt(page as string)
    );
    const bookings = await bookingService.getUnpaidBookings(
      parseInt(limit as string),
      parseInt(page as string),
      patientId
    );

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: bookings,
        message: "bookings fetched successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start

      const fileContent = getViewFile("patientDashboard", "unpaid.ejs");
      const user = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          user,activeTab : 'unpBook',
          bookings, manageBooking,
          filename: fileContent.templatePath,
        })
      );
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function deleteBooking(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const patientId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const bookingId: Types.ObjectId = new Types.ObjectId(req.body.id);

    const { limit, page } = req.query;
    const booking: any = await bookingService.deleteBookingById(bookingId);

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: "",
        message: "Booking Deleted successfully",
        status: httpStatus.OK,
      });
    } else {
    

      res.redirect("/patient/web/booking/unpaid");
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function rescheduleDateAndTime(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { page, limit } = req.query;

    const user = JSON.parse(res.get("user")!);
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        message: "Slot Booked Successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      const bookingData = req.body;

      const booking = new Types.ObjectId(bookingData.id);

      const updateBooking = await bookingModel.findById(booking);


      if(updateBooking){

        const timeDiff =updateBooking.startTime?.getTime() - Date.now();
  
        // Check if it's within the allowed rescheduling period (24 hours)
        const hoursDiff = timeDiff / (1000 * 60 * 60);
  
        
         if (hoursDiff < 24) {

          const patientId: Types.ObjectId = new Types.ObjectId(res.get("userId"));

          const bookings = await bookingService.getBookings(
            parseInt(limit as string),
            parseInt(page as string),
            patientId
          );
      

          const fileContent = getViewFile(
            "patientDashboard",
            "view-all-booking.ejs"
          );
          res.send(
            ejs.render(fileContent.file, {
              user,
              message:"Booking cannot be reschedule within 24 hours",
              bookingData,
              bookings,activeTab:'mybook',
              updateBooking,
              
              filename: fileContent.templatePath,
            })
          );
        }

  
         else{


      const startTime = updateBooking?.startTime;
      const endTime = updateBooking?.endTime;

      const startTimestamp:any = startTime?.getTime();

      const endTimestamp:any = endTime?.getTime();


      const timeDifference = endTimestamp - startTimestamp;
      

      const time = Math.floor(timeDifference / (1000 * 60));



      

      const fileContent = getViewFile(
        "patientDashboard",
        "reschedule-date-time.ejs"
      );
      res.send(
        ejs.render(fileContent.file, {
          user,
          message:"",
          bookingData,
          updateBooking,
          time,activeTab:'mybook',
          filename: fileContent.templatePath,
        })
      );
    }
  }
}
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}
