import { Request, Response } from "express";
import httpStatus from "http-status";
import * as paymentService from "./payment.service";
import { Types } from "mongoose";
import dotenv from "dotenv";
import Stripe from "stripe";
dotenv.config({
  path: ".env",
});
const key = process.env.PUBLISHABLE_KEY;

var stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);

//EJS Rendor
import ejs from "ejs";
import { getViewFile } from "../../utils/ejsHelper";
import { log } from "console";
import paymentModel from "./payment.model";
import bookingModel from "../booking/booking.model";
import * as notification from "../notification/notification.controller"
import { sendMail } from "../../utils/sendMail";
import consultantModel from "../consultant/consultant.model";
import patientModel from "../patientDashboard/patient.model";


/**
 * @description This function is for create payment
 * @param req
 * @param res
 * @author Meet Gajera
 */
export async function 
createPayment(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const {
      paymentMethodId,
      amount,
      currency,
      problemId,
      doctorId,
      bookingDate,
      startTime,
      serviceId,
      email,
      fullName,
    } = req.body;


    const paymentIntent = await stripe.paymentIntents.create({
      amount,
      currency,
      payment_method: paymentMethodId,
      confirm: true,
    });
    
    

    if (paymentIntent.status === "succeeded") {
    

      res.json({ success: true, paymentIntent });
    } else if (
      paymentIntent.status === "requires_action" &&
      paymentIntent.next_action.type === "use_stripe_sdk"
    ) {
     

      res.json({ requiresAction: true, paymentIntent });
    } else {
      res.json({ success: false, error: "Payment failed." });
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function confirm(req: Request, res: Response) {

  try {
  
    
  

  const {
    paymentIntentId,
    problemId,
    doctorId,
    bookingDate,
    startTime,
    serviceId,
    email,
    fullName,
    bookingId
  } = req.body;

  

 
 


    
    if (bookingId) {

      

      const bookingId = new Types.ObjectId(req.body.bookingId)




      if (!bookingId) {
        const fileContent = getViewFile("patientDashboard", "new-booking.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "please enter your booking detail properly",
            user,activeTab :'newbook',
            filename: fileContent.templatePath,
          })
        );
      }

      const paymentIntent = await stripe.paymentIntents.retrieve(
        paymentIntentId
      );


      if (paymentIntent.status === "requires_confirmation") {
        const confirmedPaymentIntent = await stripe.paymentIntents.confirm(
          paymentIntentId
        );

        if (confirmedPaymentIntent.status === "succeeded") {
          res.json({ success: true, paymentIntent: confirmedPaymentIntent });
        } else {
          res.json({
            success: false,
            error: "Payment confirmation failed.",
          });
        }
      }
       else if (paymentIntent.status === "succeeded") {


        const booking = await paymentService.getPaymentId(bookingId);

        
        

        const pay = paymentIntent.payment_method_types;
        const paymentTypes = pay[0];

        const paymentDto = {
          status: paymentIntent.status,
          paymentId: paymentIntent.id,
          paymentMethod: paymentIntent.payment_method,
          paymentMethodType: paymentTypes,
        };

        

        const paymentData = await paymentService.updatePayment(
          booking?._id,
          paymentDto
        );


        const payment= await paymentModel.findById(paymentData?._id)


        if (payment?.status == "succeeded") {

          const dataBooking = await paymentService.updateBooking(bookingId);

          if (dataBooking) {
            //Create Notification
            const createNotificationDto = {
              notificationTitle: "Booking created Sucessfully",
              notificationDescription: "Notification Description",
              notificationBy: dataBooking?.patient,
              notificationTo: [dataBooking?.patient], //booking?.doctor
              notificationType : "booking_notification",
              notificationTypeId:dataBooking?._id
            }
            await notification.createNotification(createNotificationDto);
         


          const createNotificationDtos = {
            notificationTitle: "New Booking Recived ",
            notificationDescription: "Notification Description",
            notificationBy: dataBooking?.patient,
            notificationTo: [dataBooking?.doctor], //booking?.doctor
            notificationType : "booking_notification",
            notificationTypeId:dataBooking?._id
          }
          await notification.createNotification(createNotificationDtos);
       
      

        
          
        }
      }

        res.json({ success: true, paymentIntent });

      } else {
        res.json({ success: false, error: "Payment confirmation failed." });
      }
    }





    if (problemId) {
      const patientId: Types.ObjectId = new Types.ObjectId(res.get("userId"));
      const problem: Types.ObjectId = new Types.ObjectId(problemId);
      const doctor: Types.ObjectId = new Types.ObjectId(doctorId);


   
   const  bookDate=  bookingDate;
   const bookingTime = startTime;
    
    
   
    
    
    
     
    

    

      const booking = await paymentService.findBookings(
        patientId,
        problem,
        doctor,
        bookDate,
        bookingTime
      );

      


      

      const bookingId = booking[booking.length - 1]?._id;



      if (!bookingId) {
        const fileContent = getViewFile("patientDashboard", "new-booking.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "please enter your booking detail properly",
            user,activeTab :'newbook',
            filename: fileContent.templatePath,
          })
        );
      }

      const paymentIntent = await stripe.paymentIntents.retrieve(
        paymentIntentId
      );


      if (paymentIntent.status === "requires_confirmation") {
        const confirmedPaymentIntent = await stripe.paymentIntents.confirm(
          paymentIntentId
        );

        if (confirmedPaymentIntent.status === "succeeded") {
          res.json({ success: true, paymentIntent: confirmedPaymentIntent });
        } else {
          res.json({
            success: false,
            error: "Payment confirmation failed.",
          });
        }
      } else if (paymentIntent.status === "succeeded") {
        

        const booking = await paymentService.getPaymentId(bookingId);

        const pay = paymentIntent.payment_method_types;
        const paymentTypes = pay[0];

        const paymentDto = {
          status: paymentIntent.status,
          paymentId: paymentIntent.id,
          paymentMethod: paymentIntent.payment_method,
          paymentMethodType: paymentTypes,
        };


        const paymentData = await paymentService.updatePayment(
          booking?._id,
          paymentDto
        );

  const payment= await paymentModel.findById(paymentData?._id)

        if (payment?.status == 'succeeded') {
          const dataBooking = await paymentService.updateBooking(bookingId);

          if (dataBooking) {
            //Create Notification
            const createNotificationDto = {
              notificationTitle: "Booking created Sucessfully",
              notificationDescription: "Notification Description",
              notificationBy: dataBooking?.patient,
              notificationTo: [dataBooking?.patient], //booking?.doctor
              notificationType : "booking_notification",
              notificationTypeId:dataBooking?._id
            }
            await notification.createNotification(createNotificationDto);


            const createNotificationDtos = {
              notificationTitle: "New Booking Recieved",
              notificationDescription: "Notification Description",
              notificationBy: dataBooking?.patient,
              notificationTo: [dataBooking?.doctor], //booking?.doctor
              notificationType : "booking_notification",
              notificationTypeId:dataBooking?._id
            }
            await notification.createNotification(createNotificationDtos);



            const bookingDetailDoctor = await consultantModel.findById(dataBooking.doctor)
            const bookingDetailPatient = await patientModel.findById(dataBooking.patient)

const subjectDetail = "New booking created successfully"
const subjectDetails = "New Booking Recieved"


const editorPatient = `New booking created. Scheduled on${JSON.stringify(dataBooking.startTime).slice(1,11)}}  with ${bookingDetailDoctor?.firstName}&nbsp;${bookingDetailDoctor?.lastName}`;  
const editorDoctor = `New booking created. Scheduled on${JSON.stringify(dataBooking.startTime).slice(1,11)}}  with ${bookingDetailPatient?.firstName}&nbsp;${bookingDetailPatient?.lastName}`;  


if( bookingDetailDoctor){
            const to = bookingDetailDoctor?.email;
            const subject =subjectDetails ;
            const html = editorPatient;
        
            await sendMail(to,subject,html);
}


if(  bookingDetailPatient){
  const to =  bookingDetailPatient?.email;
  const subject = subjectDetail;
  const html = editorDoctor;

  await sendMail(to,subject,html);
}


          }


        }

        res.json({ success: true, paymentIntent });

      } 
    }

    if (serviceId) {

     
      
      const patientId: Types.ObjectId = new Types.ObjectId(res.get("userId"));
      const service: Types.ObjectId = new Types.ObjectId(serviceId);
      const doctor: Types.ObjectId = new Types.ObjectId(doctorId);
      const status="pending"


      const bookingTime=req.body.startTime

  const startDate = new Date(bookingDate);


  
  const bookDate = bookingDate;




      const booking = await paymentService.findServicveBookings(
        patientId,
        service,
        doctor,
        bookDate,
        bookingTime ,
        status
      );


      const bookingId = booking?._id;



      if (!bookingId) {
        const fileContent = getViewFile("patientDashboard", "new-booking.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "please enter your booking detail properly",
            user,
            filename: fileContent.templatePath,
          })
        );
      }

      const paymentIntent = await stripe.paymentIntents.retrieve(
        paymentIntentId
      );


      if (paymentIntent.status === "requires_confirmation") {
        const confirmedPaymentIntent = await stripe.paymentIntents.confirm(
          paymentIntentId
        );

        if (confirmedPaymentIntent.status === "succeeded") {
          res.json({ success: true, paymentIntent: confirmedPaymentIntent });
        } else {
          res.json({
            success: false,
            error: "Payment confirmation failed.",
          });
        }
      } else if (paymentIntent.status === "succeeded") {


        const booking = await paymentService.getPaymentId(bookingId);

        const pay = paymentIntent.payment_method_types;
        const paymentTypes = pay[0];

        const paymentDto = {
          status: paymentIntent.status,
          paymentId: paymentIntent.id,
          paymentMethod: paymentIntent.payment_method,
          paymentMethodType: paymentTypes,
        };

        const paymentData = await paymentService.updatePayment(
          booking?._id,
          paymentDto
        );


        const payment= await paymentModel.findById(paymentData?._id)
        


        if (payment?.status == "succeeded") {
          const dataBooking = await paymentService.updateBooking(bookingId);
          if (dataBooking) {
            //Create Notification
            const createNotificationDto = {
              notificationTitle: "Booking created Sucessfully",
              notificationDescription: "Notification Description",
              notificationBy: dataBooking?.patient,
              notificationTo: [dataBooking?.patient,], //booking?.doctor
              notificationType : "booking_notification",
              notificationTypeId:dataBooking?._id
            }
            await notification.createNotification(createNotificationDto);
          }

          const createNotificationDtos = {
            notificationTitle: "New Booking Recieved",
            notificationDescription: "Notification Description",
            notificationBy: dataBooking?.patient,
            notificationTo: [dataBooking?.doctor], //booking?.doctor
            notificationType : "booking_notification",
            notificationTypeId:dataBooking?._id
          }
          await notification.createNotification(createNotificationDtos);
       
        
          
        }

        res.json({ success: true, paymentIntent });

      } else {
        res.json({ success: false, error: "Payment confirmation failed." });
      }
    }




  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}



/**
 * @description This function is for get payment
 * @param req
 * @param res
 * @author Meet Gajera
 */
export async function getPayment(req: Request, res: Response) {
  try {
    const user = JSON.parse(res.get("user")!);
    const { mode } = req.params;
    const { userId, bookingId } = req.body;
    const userData = await paymentService.fetchUser(userId);
    if (!userData) {
      res.status(httpStatus.BAD_REQUEST).send({
        message: "User not found",
        status: httpStatus.BAD_REQUEST,
      });
    }
    const data = {
      userId,
      bookingId,
    };
    const paymentData = await paymentService.getPayment(data);
    if (!paymentData) {
      res.status(httpStatus.BAD_REQUEST).send({
        message: "Payment not found",
        status: httpStatus.BAD_REQUEST,
      });
    } else {
      res.status(httpStatus.OK).send({
        data: paymentData,
        message: "Payment fetched successfully",
        status: httpStatus.OK,
      });
    }
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: paymentData,
        message: "Payment fetch successfully",
        status: httpStatus.OK,
      });
    } else {
      
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

/**
 * @description This function is for refund payment
 * @param req
 * @param res
 * @author Meet Gajera
 */
export async function refundPayment(req: Request, res: Response) {
  try {
    const user = JSON.parse(res.get("user")!);
    const { mode } = req.params;
    const { userId, bookingId } = req.body;
    const userData = await paymentService.fetchUser(userId);
    if (!userData) {
      res.status(httpStatus.BAD_REQUEST).send({
        message: "User not found",
        status: httpStatus.BAD_REQUEST,
      });
    }
    const data = {
      userId,
      bookingId,
    };
    const paymentData = await paymentService.getPayment(data);
    if (!paymentData) {
      res.status(httpStatus.BAD_REQUEST).send({
        message: "Payment not found",
        status: httpStatus.BAD_REQUEST,
      });
    }
    
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

/**
 * @description This function is for Edit Profile
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function cardPaymentDetail(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        message: "",
        status: httpStatus.OK,
      });
    } else {
      const patientId: Types.ObjectId = new Types.ObjectId(res.get("userId"));

      
      //Web Code Start
      const bookingData = req.body;
      const fileContent = getViewFile("patientDashboard", "card.payment.ejs");
      const user: any = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          message: "",
          user,activeTab :'newbook',
          bookingData,
          filename: fileContent.templatePath,
        })
      );

      //Post Method Code

      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}





export async function unpaidBooking(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        message: "",
        status: httpStatus.OK,
      });
    } else {
      const patientId: Types.ObjectId = new Types.ObjectId(res.get("userId"));

      const bookingId:Types.ObjectId = new Types.ObjectId(req.params.id);
      
const bookingData=await bookingModel.findById(bookingId);
      
      
      //Web Code Start
      // const bookingData = req.body;
      const fileContent = getViewFile("patientDashboard", "unpaid-card.ejs");
      const user: any = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          message: "",
          user,activeTab :'unpBook',
          bookingData,
          filename: fileContent.templatePath,
        })
      );

      //Post Method Code

      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

