import { Types } from "mongoose";
import paymentModel, {
  Payment,
  PaymentStatus,
} from "./payment.model";
import bookingModel from "../booking/booking.model";

/**
 * @description This function is used to find the user
 * @param userId
 * @returns Promise<Payment>
 * @author Meet Gajera
 */
export async function fetchUser(
  userId: Types.ObjectId,
) {
  const data = await paymentModel.findOne({ userId });
  return data;
}

/**
 * @description This function is used to create the payment
 * @param createPaymentDto
 * @returns Promise<Payment>
 * @author Meet Gajera
 */
export async function createPayment(createPaymentDto: any): Promise<Payment> {
  return await paymentModel.create({
    userId: createPaymentDto.userId,
    bookingId: createPaymentDto.bookingId,
    amount: createPaymentDto.amount,
    paymentId: createPaymentDto.paymentId,
    status: PaymentStatus.Succeeded,
  });
}

/**
 * @description This function is used to get the payment
 * @param getPaymentDto
 * @returns Promise<Payment>
 * @author Meet Gajera
 */
export async function getPayment(getPaymentDto: any){
  return await paymentModel.findOne({userId: getPaymentDto.userId, bookingId: getPaymentDto.bookingId});
}

/**
 * @description This function is used to get the payment
 * @param refundPaymentDto
 * @returns Promise<Payment>
 * @author Meet Gajera
 */
export async function refundPayment(refundPaymentDto: any){
  return await paymentModel.findOneAndUpdate({userId: refundPaymentDto.userId, bookingId: refundPaymentDto.bookingId}, {status: PaymentStatus.Refunded},{new:true});
}


export async function findBookings(patientId: Types.ObjectId, problemId: Types.ObjectId, doctorId: Types.ObjectId,bookingDate:string,startTime:string){

  return await bookingModel.
  // findOne({patient:patientId, problem: problemId, doctor:doctorId, date:bookingDate, startTime:startTime})
aggregate(
[
  {
    '$match': {
      'problem': problemId
    }
  }, {
    '$match': {
      'doctor':doctorId
    }
  }, {
    '$match': {
      'status': 'pending'
    }
  }, {
    '$match': {
      'patient': patientId
    }
  }, {              
    '$match': {
      'date': new Date(bookingDate)
    }
  }, {
    '$match': {
      'startTime': new Date(startTime)
    }
  }
])

}


export async function findServicveBookings(patientId: Types.ObjectId, serviceId: Types.ObjectId, doctorId: Types.ObjectId,bookingDate:string,startTime:string,status:string){
  return await bookingModel.findOne({patient:patientId, service:serviceId, doctor:doctorId, date:new Date(bookingDate), startTime:new Date(startTime),status:status});
}


export async function findBooking(patientId: Types.ObjectId, problemId: Types.ObjectId, doctorId: Types.ObjectId,bookingDate:Date,startTime:string){
  return await bookingModel.aggregate(

    [
      {
        '$match': {
          'patient':patientId
        }
      }, {
        '$match': {
          'doctor': doctorId
        }
      }, {
        '$match': {
          'problem': problemId
        }
      }, {
        '$match': {
          'date': bookingDate
        }
      }, {
        '$match': {
          'startTime': startTime
        }
      }
    ]
  )
}


export async function getPaymentId(_id: Types.ObjectId){
  return await paymentModel.findOne({bookingId:_id});
}



export async function updatePayment(bookingId: Types.ObjectId,paymentDto:any){
  return await paymentModel.findByIdAndUpdate(bookingId,paymentDto)
}





export async function updateBooking(bookingId: Types.ObjectId){
  return await bookingModel.findByIdAndUpdate(bookingId,{isPaid:true,status:"accepted"})
}


