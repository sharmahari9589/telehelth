import { Router } from "express";
import * as paymentController from "./payment.controller";

const router = Router({
  mergeParams: true,
});

router
  .route("/unpaid-booking/:id")
  .get(paymentController.unpaidBooking)
  .post(paymentController.unpaidBooking);




router
  .route("/card-payment")
  .get(paymentController.cardPaymentDetail)
  .post(paymentController.cardPaymentDetail);

router
  .route("/create-payment")
  .get(paymentController.createPayment)
  .post(paymentController.createPayment);


  router
  .route("/confirm")
  .get(paymentController.confirm)
  .post(paymentController.confirm);


router
  .route("/get-payment")
  .get(paymentController.getPayment)
  .post(paymentController.getPayment);

router
  .route("/refund-payment")
  .get(paymentController.refundPayment)
  .post(paymentController.refundPayment);
  
export default router;
