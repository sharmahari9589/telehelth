import mongoose, { Document, model, Schema, Types } from "mongoose";
import { Patient } from "../patientDashboard/patient.model";
import { Booking } from "../booking/booking.model";

export enum PaymentStatus {
  Pending = "pending",
  Cancelled = "cancelled",
  Refunded = "refunded",
  Succeeded = "succeeded",
}

export interface Payment extends Document {
  patientId: Types.ObjectId | Patient;
  bookingId: Types.ObjectId | Booking;
  status: PaymentStatus;
  amount: number;
  paymentId: string;
  paymentMethod:string
  paymentMethodType:string
}

const paymentSchema = new Schema<Payment>(
  {
    patientId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "patient",
    },
    bookingId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "booking",
    },
    status: {
      type: String,
      default: PaymentStatus.Pending,
      enum: PaymentStatus,
    },
    amount: {
      type: Number,
      required: true,
    },
    paymentId: {
      type: String,
      
    },

    paymentMethod: {
      type: String,
    
    },
    paymentMethodType: {
      type: String,
    
    }
  },
  {
    timestamps: true,
  }
);

export default model<Payment>("payment", paymentSchema);
