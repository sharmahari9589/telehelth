import { Router } from "express";
import * as chatController from "./chat.controller"
const router: Router = Router();

router.post('/create-chat',chatController.SaveMessage)

router.post("/get-chat",chatController.GetMeessage)

router.post("/delete-chat/:id",chatController.deleteChat)
router.post("/get-recieved-chat",chatController.GetRecievedMessage)

router.get("/get-patient",chatController.getPatient)

router.post("/update-status",chatController.updateCallStatus)


export default router;
