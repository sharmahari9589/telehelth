import multer from "multer";
import { Request } from "express";
/**
 * @description this function is use for upload document
 * @returns {Promise<User>}
 * @author aakrti satle
 */
const storage = multer.diskStorage({
  destination: function (req: Request, file, cb: Function) {
    cb(null, "uploads");
  },
  filename: function (req: Request, file, cb: Function) {
    cb(null, +Date.now() + "_" + file.originalname);
  },
});

const upload = multer({ storage: storage });

export default upload;
