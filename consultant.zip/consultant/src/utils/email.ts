import nodemailer from "nodemailer";

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "telehealthonlineconsultation@gmail.com",
      pass: "rjwmatiqakwfnnfu",
  },
});

export default transporter;
