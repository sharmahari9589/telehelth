import multer from "multer";



const fileUpload = multer({
  storage: multer.diskStorage({
    destination: "../../../assets",
    filename: function (req, file, cb) {
      const extension = file.originalname.split(".").pop();
      const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
      cb(null, uniqueSuffix + "." + extension);
    },
  }),
});

export default fileUpload;
