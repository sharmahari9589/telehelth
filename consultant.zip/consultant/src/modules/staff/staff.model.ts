import mongoose, { Schema, Document, Types } from "mongoose";


export enum Gender {
  Male = "male",
   Female = "female",
   Other = "other",
   Transgender = 'transgender' ,	
   Notdisclosed	='notDisclosed'
 }
 
 export enum MaritialStatus {
   Married = "married",
   Single = "single",	
 Partnered	='partnered',
 Divorce	='divorce',
 Widow	='widow',
 Others	='others',	
 Notdisclosed	='notDisclosed'
 
 }
 


export interface Staff extends Document {
  firstName: string;
  lastName: string;
  email: string;
  gender: Gender;
  maritialStatus:MaritialStatus;
  password?: string;
  mobileNumber: string;
  isDeleted: boolean;
  dateOfBirth: Date;
  location:string


  addedBy: Types.ObjectId;
  role: Types.ObjectId;
  profilePic:string;
}

const staffSchema: Schema = new Schema<Staff>({
  firstName: {
    type: String,
  },
  lastName: {
    type: String,
  },
  profilePic: {
    type: String,
  },
  dateOfBirth: {
    type: Date,
  },
  gender: {
    type: String,
    enum: Gender,
  },
 maritialStatus: {
    type: String,
    enum: MaritialStatus,
  },
  email: {
    type: String,
    unique: true,
  },
  password: {
    type: String,
  },
  mobileNumber: {
    type: String,
  },
  location: {
    type: String,
  },

  isDeleted: {
    type: Boolean,
    default: false,
  },
  addedBy: {
    type: mongoose.Schema.Types.ObjectId,
  },
  role: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "role",
  }
});


export default mongoose.model<Staff>("staff", staffSchema);