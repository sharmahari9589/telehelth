import { Types } from "mongoose";
import staffAndPermissionModel, { Staff } from "./staff.model";

export async function createStaff(createStaffDto: any): Promise<Staff> {
  return await staffAndPermissionModel.create({
    email: createStaffDto.email,
    password: createStaffDto.password,
    firstName: createStaffDto.firstname,
    lastName: createStaffDto.lastname,
    mobileNumber: createStaffDto.mobileNumber,
    role: createStaffDto.roleid,
    addedBy: createStaffDto.addedBy,
    gender: createStaffDto.gender,
    dateOfBirth: createStaffDto.date_of_birth,
    location: createStaffDto.location,
    maritialStatus: createStaffDto.maritialStatus,

  });
}

export async function getStaffs(query:any,name:string,role:string): Promise<Array<Staff>> {


  if(name){

    const fullNameParts = name.split(' ');
    const firstNameRegex = new RegExp(fullNameParts[0], 'i');
    const lastNameRegex = new RegExp(fullNameParts.slice(1).join(' '), 'i');
    return await staffAndPermissionModel.aggregate(
      [
        {
          '$match': {
            'addedBy': query
          }
        }, {
          '$match': {
            'isDeleted': false
          }
        },
        {
        
          $match: {
          
            firstName:firstNameRegex,
       lastName: lastNameRegex, 
              }


        }, {
          '$lookup': {
            'from': 'roles', 
            'localField': 'role', 
            'foreignField': '_id', 
            'as': 'role'
          }
        },
        {
          '$unwind': {
            'path': '$role', 
            'preserveNullAndEmptyArrays': true
          }
        }, {
          '$unwind': {
            'path': '$firstName', 
            'preserveNullAndEmptyArrays': true
          }
        }
      ]
    )

  }
  if(role=="all"){
    return await staffAndPermissionModel.aggregate(
      [
        {
          '$match': {
            'addedBy': query
          }
        }, {
          '$match': {
            'isDeleted': false
          }
        }, {
          '$lookup': {
            'from': 'roles', 
            'localField': 'role', 
            'foreignField': '_id', 
            'as': 'role'
          }
        },
        {
          '$unwind': {
            'path': '$role', 
            'preserveNullAndEmptyArrays': true
          }
        }, {
          '$unwind': {
            'path': '$firstName', 
            'preserveNullAndEmptyArrays': true
          }
        }
      ]
    )


  }

  if(role){


    return await staffAndPermissionModel.aggregate(
      [
        {
          '$match': {
            'addedBy': query
          }
        }, {
          '$match': {
            'isDeleted': false
          }
        }, {
          '$lookup': {
            'from': 'roles', 
            'localField': 'role', 
            'foreignField': '_id', 
            'as': 'role'
          }
        },
        {
          '$unwind': {
            'path': '$role', 
            'preserveNullAndEmptyArrays': true
          }
        },
        {
          '$match': {
            "role.name":role
          }
        },

         {
          '$unwind': {
            'path': '$firstName', 
            'preserveNullAndEmptyArrays': true
          }
        }
      ]
    )


  }


  else{
  return await staffAndPermissionModel.aggregate(
    [
      {
        '$match': {
          'addedBy': query
        }
      }, {
        '$match': {
          'isDeleted': false
        }
      }, {
        '$lookup': {
          'from': 'roles', 
          'localField': 'role', 
          'foreignField': '_id', 
          'as': 'role'
        }
      },
      {
        '$unwind': {
          'path': '$role', 
          'preserveNullAndEmptyArrays': true
        }
      }, {
        '$unwind': {
          'path': '$firstName', 
          'preserveNullAndEmptyArrays': true
        }
      }
    ]
  )
  }
}

export async function updateStaff(
  staffId:any,
  updateStaffDto: any
): Promise<Staff | null> {
  return await staffAndPermissionModel.findByIdAndUpdate(staffId, updateStaffDto, {new: true});
}

export async function deleteStaff(staffId:any): Promise<Staff | null> {
  return await staffAndPermissionModel.findByIdAndUpdate(staffId,{isDeleted:true});
}
