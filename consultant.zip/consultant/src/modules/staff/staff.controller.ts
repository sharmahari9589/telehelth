import bcrypt from "bcryptjs";
import httpStatus from "http-status";
import { Request, Response } from "express";
import * as staffService from "./staff.service";
import staffModel, { Staff } from "./staff.model";
import { Types } from "mongoose";
import { Role } from "../roleAndPermission/roleAndPermission.model";
import { getViewFile } from "../../utils/ejsHelper";
import { Booking } from "../booking/booking.model";
import ejs from "ejs";

import * as consultantservices from "../consultantDashboard/consultant.services"

import * as roleService from "../roleAndPermission/roleAndPermission.service"


const generateHash = (password: string) => {
  const salt = bcrypt.genSaltSync();
  return bcrypt.hashSync(password, salt);
};
export async function createStaff(req: Request, res: Response) {
  try {
    const addedBy: Types.ObjectId = new Types.ObjectId(res.get("userId"));
    const { email, firstname, lastname,date_of_birth,mobileNumber, roleid,gender,location,maritialStatus} = req.body;
    
      const password = generateHash(req.body.password);

      


 
  const id: Types.ObjectId = new Types.ObjectId(res.get("userId"));
  const user = (JSON.parse(res.get("user")!));
  let consultantId;
  if (user.addedBy == undefined) {
    consultantId = id
  }
  else {
    consultantId = new Types.ObjectId(user.addedBy)
  }


  let alreadyEmail=await  staffModel.findOne({email: email,
    addedBy:consultantId }); 

 
    
  const manageBooking: Array<Booking> = await consultantservices.myUpcomingBooking(consultantId,

  );
 
  const roles: Array<Role> = await roleService.getRoles(consultantId);
 

  if(alreadyEmail){
      const fileContent = getViewFile("consultantDashboard", "add-user.ejs");
      res.send(
        ejs.render(fileContent.file, {
          message: "User already exisits with this email",
 email, firstname, lastname,date_of_birth,mobileNumber, roleid,gender,location,maritialStatus,
    user,  message1:"",activeTab :'addUser',
          roles, manageBooking,
          filename: fileContent.templatePath,
        })
      );
 

return
 }

 else{

    const data: Staff = await staffService.createStaff({ email, password, firstname, lastname, mobileNumber, roleid, addedBy,date_of_birth,gender,location,maritialStatus });
   
    const fileContent = getViewFile("consultantDashboard", "add-user.ejs");
      res.send(
        ejs.render(fileContent.file, {
          message1: "User Created Succssefully",
          message:"",
            email:"", firstname:"", lastname:"",date_of_birth:"",mobileNumber:"", roleid:"",gender:"",location:"",maritialStatus:"",
            user,activeTab :'addUser',
          roles, manageBooking,
          filename: fileContent.templatePath,
        })
      );
    
  }

}catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err,
    });
  }
}

export async function getStaffs(req: Request, res: Response) {
  const { addedBy,name,role } = req.query;
  try {
    let query: any = {};
    if(addedBy) query.addedBy = addedBy;
    const staffs: Array<Staff> = await staffService.getStaffs(query,name as string,role as string);
    res.status(httpStatus.OK).send({
      data: staffs,
      message: "Staff fetched successfully",
      status: httpStatus.OK,
    });
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err,
    });
  }
}

export async function updateStaff(req: Request, res: Response) {
  try {
    const staffId = req.params.id
    const staff: Staff | null = await staffService.updateStaff(staffId, req.body);
    res.redirect("/admin/web/viewuser")
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err,
    });
  }
}

export async function deleteStaff(req: Request, res: Response) {
  try {
    const staffId=req.params.id;
    const staff: Staff | null = await staffService.deleteStaff(staffId);
    res.redirect("/admin/web/viewuser")
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err,
    });
  }
}
