import { Router } from "express";
import * as staffController from "./staff.controller";

const router = Router();

router.post("/createStaff", staffController.createStaff);
router.get("/createStaff", staffController.createStaff);

router.post("/get-staffs", staffController.getStaffs);
router.post("/updatestaff/:id", staffController.updateStaff);
router.post("/deletestaff/:id", staffController.deleteStaff);

export default router;
