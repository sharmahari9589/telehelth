import { Router } from "express";
import * as questionnaireController from "./questionnaire.controller";

const router: Router = Router({
  mergeParams: true,
});

router
  .route("/create-questions")
  .get(questionnaireController.createQuestionnaire)
  .post(questionnaireController.createQuestionnaire);

router.get("/get-question", questionnaireController.getQuestionnaires);

router
  .route("/updateQuestion/:id")
  .get(questionnaireController.updateQuestinaire)
  .post(questionnaireController.updateQuestinaire);

router
  .route("/deleteQuestion/:id")
  .get(questionnaireController.deleteQuestionnaire)
  .post(questionnaireController.deleteQuestionnaire);

export default router;
