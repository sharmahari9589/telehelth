import { Request, Response } from "express";
import httpStatus from "http-status";
import { Types } from "mongoose";
import * as questionnaireServies from "./questionnaire.service";

//EJS Rendor
import ejs from "ejs";
import Paths from "../../utils/path";
import { getViewFile } from "../../utils/ejsHelper";
import { mode } from "crypto-js";
import Mode from "../../utils/mode";
import healthProblemModel from "./healthProblem.model";
import { log } from "console";
import { Booking } from "../booking/booking.model";
import * as consultantservices from "../consultantDashboard/consultant.services";

export async function createQuestionnaire(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const addedBy: Types.ObjectId = new Types.ObjectId(res.get("userId"));

    const manageBooking: Array<Booking> =
      await consultantservices.myUpcomingBooking(addedBy);

    const health = await healthProblemModel.find();

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "consultantDashboard",
          "add-questionaire.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            activeTab: "addQues",
            user,
            health,
            manageBooking,
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
        const addedBy: Types.ObjectId = new Types.ObjectId(res.get("userId"));

        const { title, problem } = req.body;
        const questionnaire = await questionnaireServies.createQuestion({
          addedBy,
          title,
          problem,
        });

        const user: any = JSON.parse(res.get("user")!);

        const fileContent = getViewFile(
          "consultantDashboard",
          "add-questionaire.ejs"
        );
        res.send(
          ejs.render(fileContent.file, {
            message: "Questionnaire created successfully",
            message1: "",
            user,
            questionnaire,
            health,
            activeTab: "addQues",
            filename: fileContent.templatePath,
          })
        );
        return;
      }
    }
    //Web Code End
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function getQuestionnaires(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const consultantId: Types.ObjectId = new Types.ObjectId(res.get("userId"));

    const manageBooking: Array<Booking> =
      await consultantservices.myUpcomingBooking(consultantId);

    const health = await healthProblemModel.find();

    const questions = await questionnaireServies.getQuestionnaire(consultantId);

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: questions,
        message: "Questionnaire fetched successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "consultantDashboard",
          "view-all-questionaire-list.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            message1: "",
            activeTab: "viewQues",
            user,
            questions,
            health,
            manageBooking,
            filename: fileContent.templatePath,
          })
        );
      }
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Questionnaire fetched successfully",
      status: httpStatus.INTERNAL_SERVER_ERROR,
    });
  }
}

export async function updateQuestinaire(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const questionnaireId: Types.ObjectId = new Types.ObjectId(req.params.id);

    const questionaaire = await questionnaireServies.updateQuestionById(
      questionnaireId,
      req.body
    );
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: questionaaire,
        message: "Questionnaire updated successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start

      const consultantId: Types.ObjectId = new Types.ObjectId(
        res.get("userId")
      );

      const manageBooking: Array<Booking> =
        await consultantservices.myUpcomingBooking(consultantId);

      const health = await healthProblemModel.find();

      const questions = await questionnaireServies.getQuestionnaire(
        consultantId
      );

      const fileContent = getViewFile(
        "consultantDashboard",
        "view-all-questionaire-list.ejs"
      );
      const user: any = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          message1: "",
          message: "Questionaire Updated Sucessfully",
          user,
          questions,
          health,
          manageBooking,
          activeTab: "viewQues",
          filename: fileContent.templatePath,
        })
      );
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Internal server error",
      status: httpStatus.INTERNAL_SERVER_ERROR,
    });
  }
}

export async function deleteQuestionnaire(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const questionnaireId: Types.ObjectId = new Types.ObjectId(req.params.id);

    const questionaaire = await questionnaireServies.deleteQuestionById(
      questionnaireId
    );

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: questionaaire,
        message: "Questionnaire deleted successfully",
        status: httpStatus.OK,
      });
    } else {
      const consultantId: Types.ObjectId = new Types.ObjectId(
        res.get("userId")
      );

      const manageBooking: Array<Booking> =
        await consultantservices.myUpcomingBooking(consultantId);

      const health = await healthProblemModel.find();

      const questions = await questionnaireServies.getQuestionnaire(
        consultantId
      );

      const fileContent = getViewFile(
        "consultantDashboard",
        "view-all-questionaire-list.ejs"
      );
      const user: any = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          message: "",
          message1: "Questionaire Deleted Sucessfully",
          user,
          questions,
          health,
          manageBooking,
          filename: fileContent.templatePath,
          activeTab: "viewQues",
        })
      );
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Internal server error",
      status: httpStatus.INTERNAL_SERVER_ERROR,
    });
  }
}
