import { Types } from "mongoose";
import questionModel, { Question } from "./questionnaire.model";
import questionnaireModel from "./questionnaire.model";

export async function createQuestion(
  createQuestionDto: any
): Promise<Question> {
  return await questionModel.create(createQuestionDto);
}

export async function getQuestionnaire(consultantId: Types.ObjectId) {
  return await questionModel.aggregate([
    {
      $match: {
        addedBy: consultantId,
      },
    },
  ]);
}

export async function updateQuestionById(
  questionId: Types.ObjectId,
  updateQuestionDto: any
): Promise<Question | null> {
  return await questionnaireModel.findByIdAndUpdate(
    questionId,
    updateQuestionDto
  );
}

export async function deleteQuestionById(
  questionId: Types.ObjectId
): Promise<Question | null> {
  return await questionModel.findByIdAndDelete(questionId);
}
