import { model, Schema, Document } from "mongoose";

export interface HealthProblem extends Document {
  name: string;
  imageURL: string;
}

const healthProblem: Schema = new Schema<HealthProblem>(
  {
    name: {
      type: String,
    },
    imageURL: {
      type: String,
    },
  },

  {
    timestamps: true,
  }
);

export default model<HealthProblem>("healthproblem", healthProblem);
