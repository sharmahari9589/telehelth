import { Request, Response } from "express";
import httpStatus from "http-status";
import { Types } from "mongoose";

//EJS Rendor
import ejs from "ejs";
import { getViewFile } from "../../utils/ejsHelper";





export async function servicesCategory(req: Request, res: Response) {
    try {
      const { mode } = req.params;
      if (mode == "api") {
        
      } else {
        //Web Code Start
        if (req.method == "GET") {
          const fileContent = getViewFile(
            "consultantDashboard",
            "services-category.ejs"
          );
          const user: any = JSON.parse(res.get("user")!);
          res.send(
            ejs.render(fileContent.file, {
              message: "",
              user,activeTab :'doctorDashboard',
              filename: fileContent.templatePath,
            })
          );
        } else {
          //Post Method Code
        }
        //Web Code End
      }
    } catch (error) {
      console.log(error);
      res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
    }
  }
  
  export async function addServices(req: Request, res: Response) {
    try {
      const { mode } = req.params;

      const consultantId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
      const {duration,charge}=req.body
      if (mode == "api") {
      } else {
        //Web Code Start
        if (req.method == "GET") {
          const fileContent = getViewFile(
            "consultantDashboard",
            "setmore.ejs"
          );
          const user: any = JSON.parse(res.get("user")!);
          res.send(
            ejs.render(fileContent.file, {
              message: "",
              user,activeTab :'avail',
              filename: fileContent.templatePath,
            })
          );
        } else {
          //Post Method Code
        }
        //Web Code End
      }
    } catch (error) {
      console.log(error);
      res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
    }
  }
  
  
  