import { Router } from "express";
import * as serviceController from "./services.controller";

const router: Router = Router({ mergeParams: true });

router
  .route("/service")
  .get(serviceController.addServices)
  .post(serviceController.addServices);

export default router;
