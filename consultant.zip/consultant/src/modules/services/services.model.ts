import mongoose, { Schema, model, Document, Types } from "mongoose";

export interface Service extends Document {
  duration: Date;
  charge: Number;
  doctor: Types.ObjectId;
}

const serviceSchema: Schema = new Schema<Service>({
  duration: { type: Date, required: true },
  charge: { type: Number, required: true },

  doctor: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "consultant",
  },
});

export default model<Service>("service", serviceSchema);
