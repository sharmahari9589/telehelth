import { Router } from "express";
import { consultantDashboard } from "../consultantDashboard/consultant.controller";
import * as consultantController from "./consultant.controller";

const appRouter = Router({
  mergeParams: true,
});

appRouter.get("/getschedule", consultantController.getMySchedule);

appRouter.post("/updateschedule", consultantController.updateMySchedule);

export default appRouter;
