import { Types } from "mongoose";
import consultantModel, { Consultant } from "./consultant.model";

export async function getMySchedule(
  consultantId: Types.ObjectId
): Promise<Array<Consultant>> {
  return await consultantModel.find({
    consultantId: consultantId,
  });
}

export async function updateMySchedule(consultantId: Types.ObjectId) {}

export async function getConsultantById(
  consultantId: Types.ObjectId
): Promise<Consultant | null> {
  return await consultantModel.findById(consultantId);
}


