import { Request, Response } from "express";
import httpStatus from "http-status";
import { Types } from "mongoose";
import * as consultantService from "./consultant.service";

//EJS Rendor
import ejs from "ejs";
import { getViewFile } from "../../utils/ejsHelper";

export async function getMySchedule(req: Request, res: Response) {
  try {
    const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const user= (JSON.parse(res.get("user")!)); 
    let consultantId;
    if (user.addedBy== undefined){
      consultantId = id
    }
    else{
      consultantId =new Types.ObjectId( user.addedBy)
    }
    const schedule =await  consultantService.getMySchedule(consultantId);
    res.status(httpStatus.OK).send({
      data: schedule,
      message: "Schedule fetched successfully",
      status: httpStatus.OK,
    });
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.OK).send({
      message: err.message,
    });
  }
}

export async function updateMySchedule(req: Request, res: Response) {
  try {
    const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!)
    const user= (JSON.parse(res.get("user")!)); 
    let consultantId;
    if (user.addedBy== undefined){
      consultantId = id
    }
    else{
      consultantId =new Types.ObjectId( user.addedBy)
    };
    const schedule = consultantService.getMySchedule(consultantId);
    res.status(httpStatus.OK).send({
      data: schedule,
      message: "Schedule fetched successfully",
      status: httpStatus.OK,
    });
  } catch (error) {
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function consultantCount(req: Request, res: Response) {
  const { mode } = req.params;

   if (mode == "api") {
  res.status(httpStatus.OK).send({
       data: "",
     message: "pharmacy count succesfully",
       status: httpStatus.OK,
     });
  } else {
    
  }
}



