import { Schema, model, Document } from "mongoose";
export enum Gender {
  Male = "male",
  Female = "female",
  Other = "other",
  Transgender = "transgender",
  Notdisclosed = "notDisclosed",
}
export enum MaritialStatus {
  Married = "married",
  Single = "single",
  Partnered = "partnered",
  Divorce = "divorce",
  Widow = "widow",
  Others = "others",
  Notdisclosed = "notDisclosed",
}

export enum BloodGroup {
  APlus = "A+",
  BPlus = "B+",
  AMinus = "A-",
  BMinus = "B-",
  OPlus = "O+",
  OMinus = "O-",
  ABPlus = "AB+",
  ABMinus = "AB-",
}

export interface Patient extends Document {
  firstName: string;
  lastName: string;
  email: string;
  password?: string;
  mobileNumber: string;
  gender: Gender;
  eirCode: string;
  maritialStatus: MaritialStatus;
  location: any;
  bloodGroup: BloodGroup;
  dateOfBirth: Date;
  weight: number;
  height: number;
  isAllow: Boolean;
  securityQuestion: string;
  securityAnswer: string;
  callStatus: string;
  imageURL: string;
  height_unit: string;
  weight_unit: string;
  allergy: string;

  gmsNo: string;
}

const patientSchema: Schema = new Schema<Patient>(
  {
    firstName: {
      type: String,
    },
    lastName: {
      type: String,
    },
    email: {
      type: String,
      unique: true,
      required: true,
    },
    password: {
      type: String,
      required: true,
    },
    mobileNumber: {
      type: String,
    },
    gender: {
      type: String,
      enum: Gender,
    },
    maritialStatus: {
      type: String,
      enum: MaritialStatus,
    },
    imageURL: {
      type: String,
    },

    gmsNo: {
      type: String,
    },
    eirCode: {
      type: String,
    },
    allergy: {
      type: String,
    },
    location: {
      type: String, // Don't do `{ location: { type: String } }`
    },
    callStatus: {
      type: String,
    },
    bloodGroup: {
      type: String,
      enum: BloodGroup,
    },
    dateOfBirth: {
      type: Date,
    },
    weight: {
      type: Number,
    },
    height: {
      type: Number,
    },
    weight_unit: {
      type: String,
    },
    height_unit: {
      type: String,
    },
    isAllow: {
      type: Boolean,
      default: false,
    },
    securityQuestion: {
      type: String,
    },
    securityAnswer: {
      type: String,
    },
  },
  {
    timestamps: true,
  }
);

export default model<Patient>("patient", patientSchema);
