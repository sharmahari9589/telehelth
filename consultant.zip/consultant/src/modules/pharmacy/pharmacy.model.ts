import { Schema, model, Document } from "mongoose";

export enum Gender {
  Male = "male",
  Female = "female",
  Other = "other",
  Transgender = "transgender",
  Notdisclosed = "notDisclosed",
}

export enum MaritialStatus {
  Married = "married",
  Single = "single",
  Partnered = "partnered",
  Divorce = "divorce",
  Widow = "widow",
  Others = "others",
  Notdisclosed = "notDisclosed",
}

export interface Pharmacy extends Document {
  firstName: string;
  lastName: string;
  storeName: string;
  gender: Gender;
  maritialStatus: MaritialStatus;

  email: string;
  password: string;
  dlNumber: string;
  mobileNumber: string;
  description: string;
  location: string;
  cho: string;
  country: string;
  eircode: string;
  isDeleted: boolean;
  opening_Hours: any;
}

const pharmacySchema: Schema = new Schema<Pharmacy>({
  firstName: {
    type: String,
  },
  lastName: {
    type: String,
  },
  storeName: {
    type: String,
  },
  email: {
    type: String,
    unique: false,
    
  },
  password: {
    type: String,
    
  },
  dlNumber: {
    type: String,
  },
  mobileNumber: {
    type: String,
  },
  description: {
    type: String,
  },
  location: {
    type: String,
  },
  cho: {
    type: String,
  },
  country: {
    type: String,
  },
  eircode: {
    type: String,
  },
  isDeleted: {
    type: Boolean,
    default: false,
  },
  opening_Hours: {
    type: Schema.Types.Mixed,
  },
});

export default model<Pharmacy>("pharmacie", pharmacySchema);
