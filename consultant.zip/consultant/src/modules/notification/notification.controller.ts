import { Request, Response, NextFunction } from "express";
import httpStatus from "http-status";
import { Types } from "mongoose";
import { Notification } from "./notification.model";
import * as notificationService from "./notification.service";

export async function createNotification(createNotificationDto: Object) {
  try {
    const notification: Notification =
      await notificationService.createNotification(createNotificationDto);
  } catch (error) {
    console.log(error);
  }
}

export async function getNotifications(req: Request, res: Response) {
  try {
    const doctorId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const user: any = JSON.parse(res.get("user")!);

    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = doctorId;
    } else {
      consultantId = new Types.ObjectId(user.addedBy);
    }
    const { page, limit } = req.query;
    const notifications: Array<Notification> =
      await notificationService.getNotifications(
        consultantId,
        parseInt(limit as string),
        parseInt(page as string)
      );
    res.status(httpStatus.OK).send({
      data: notifications,
      message: "Notifications fetched successfully",
      status: httpStatus.OK,
    });
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      status: httpStatus.INTERNAL_SERVER_ERROR,
      message: err.message,
    });
  }
}

export async function updateNotification(req: Request, res: Response) {
  try {
    const notificationId: Types.ObjectId = new Types.ObjectId(req.params.id);
    const notification: Notification | null =
      await notificationService.updateNotificationById(
        notificationId,
        req.body
      );
    res.status(httpStatus.OK).send({
      data: notification,
      status: httpStatus.OK,
      message: "Notification updated successfully",
    });
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      status: httpStatus.INTERNAL_SERVER_ERROR,
      message: err.message,
    });
  }
}

export async function deleteNotification(req: Request, res: Response) {
  try {
    const notificationId: Types.ObjectId = new Types.ObjectId(req.params.id);
    const notification: Notification | null =
      await notificationService.deleteNotificationById(notificationId);
    res.status(httpStatus.OK).send({
      data: notification,
      status: httpStatus.OK,
      message: "Notification updated successfully",
    });
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      status: httpStatus.INTERNAL_SERVER_ERROR,
      message: err.message,
    });
  }
}

export async function getNotificationById(req: Request, res: Response) {
  try {
    const notificationId: Types.ObjectId = new Types.ObjectId(req.params.id);
    const notification: Notification | null =
      await notificationService.getNotificationById(notificationId);
    res.status(httpStatus.OK).send({
      data: notification,
      status: httpStatus.OK,
      message: "Notification fetched successfully",
    });
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      status: httpStatus.INTERNAL_SERVER_ERROR,
      message: err.message,
    });
  }
}
