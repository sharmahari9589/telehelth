import { Router } from "express";
import * as documentController from "./document.controller";
import fileUpload from "../../middleware/fileUpload";


const documentRoute: Router = Router(
  {
    mergeParams: true,
  }
);

documentRoute.route("/document-center")
.get(documentController.getDocuments)
.post(documentController.getDocuments)

documentRoute.route("/document-center/me")
.get(documentController.shareByMe)

documentRoute
.route("/document-center/update/:id")
.get(documentController.updateDocument)
.post(documentController.updateDocument);

documentRoute
  .route("/document-center/delete/:id")
  .get(documentController.deleteDocument)
  .post(documentController.deleteDocument);

documentRoute
  .route("/document-center/share")
  .get(documentController.shareDocuments)
  .post(documentController.shareDocuments);

// documentRoute
//   .route("/document-center/sharedfiles")
//   .get(documentController.sharedFiles)
//   .post(documentController.sharedFiles);


  documentRoute
  .route("/document-center/sharedwithme")
  .get(documentController.sharedWithMe)
  .post(documentController.sharedWithMe);

documentRoute
  .route("/document-center/users")
  .get(documentController.filterSharedDocument)
  .post(documentController.filterSharedDocument)


  documentRoute.get("/document-center/unshare/users/:documentId",documentController.filterUnharedDocument);

documentRoute
  .route("/document-center/unshare/:id")
  .get(documentController.unshareMyDocument)
  .post(documentController.unshareMyDocument);

  documentRoute
  .get("/document-center/check-status",documentController.checkStatus)

  documentRoute
  .post("/document-center/update-true",documentController.updateAllowStatus)

  documentRoute.post("/document-center/update-false",documentController.updateNotAllowStatus)

export default documentRoute;









