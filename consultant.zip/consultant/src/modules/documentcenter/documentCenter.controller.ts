import { Response, Request } from "express";
import httpStatus from "http-status";
import { Types } from "mongoose";
import * as documentService from "./documentCenter.service";

//EJS Rendor
import ejs from "ejs";
import { getViewFile } from "../../utils/ejsHelper";
import { TH_Document } from "./documentCenter.model";
import consultantModel from "../../models/consultant.model";
import pharmacyModel from "../pharmacy/pharmacy.model";
import patientModel from "../../models/patient.model";
import adminModel from "../../models/admin.model";
import documentShareModels from "./documentShare.models";

export async function getDocuments(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { search, page, limit, newDocumentType } = req.query;

    if (mode == "api") {
      //API Code Start
      const userId: Types.ObjectId = new Types.ObjectId(res.get("userId"));
      const documents = await documentService.getDocuments(
        userId,
        (search as string) ?? "",
        newDocumentType as string,
        parseInt(page as string),
        parseInt(limit as string)
      );
      res.status(httpStatus.OK).send({
        data: documents,
        message: "Documents fetched successfully",
        stauts: httpStatus.OK,
      });
      //API Code End
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const user = JSON.parse(res.get("user")!);
        const userId: Types.ObjectId = new Types.ObjectId(res.get("userId"));
        const documents = await documentService.getDocuments(
          userId,
          (search as string) ?? "",
          newDocumentType as string,
          parseInt(page as string),
          parseInt(limit as string)
        );

        const fileContent = getViewFile("dashboard", "document-center.ejs");

        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            type: "",
            activeTab: "documentCenter",
            filename: fileContent.templatePath,
            documents: documents,
          })
        );
      } else {
        //Post Method Code
        const user = JSON.parse(res.get("user")!);
        const userId: Types.ObjectId = new Types.ObjectId(res.get("userId"));
        const documentURL = "/" + req.body.files[0]?.path;
        const documentCreateDto: any = {
          document_name: req.body.documentName,
          documentDescription: req.body.documentDescription,
          documentType: req.body.documentType,
          documentURL: documentURL,
          userId: userId,
        };
        const doc: TH_Document = await documentService.createDocument(
          documentCreateDto
        );
        const documents = await documentService.getDocuments(
          userId,
          (search as string) ?? "",
          newDocumentType as string,
          parseInt(page as string),
          parseInt(limit as string)
        );

        const fileContent = getViewFile("dashboard", "document-center.ejs");

        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            type: "",
            activeTab: "documentCenter",
            filename: fileContent.templatePath,
            documents: documents,
          })
        );
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: "error",
    });
  }
}

export async function shareDocuments(req: Request, res: Response) {
  try {
    const documentId: Types.ObjectId = req.body.documentId;
    const userId: Types.ObjectId = req.body.shareDoc;

    if (userId == undefined) {
      res.redirect("/pharmacy/web/document-center");
    } else {
      let doc = await documentService.shareDocument(documentId, userId);

      res.redirect("/pharmacy/web/document-center");
    }
  } catch (error) {
    console.log(error);
  }
}

export async function updateDocument(req: Request, res: Response) {
  try {
    const documentId: Types.ObjectId = new Types.ObjectId(req.body.documentId);
    const document = await documentService.updateDocument(documentId, req.body);
    res.status(httpStatus.OK).send({
      data: document,
      message: "Document updated successfully",
      status: httpStatus.OK,
    });
  } catch (error) {
    console.log(error);
    res.send(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: error,
      message: "Internal server error",
      status: httpStatus.INTERNAL_SERVER_ERROR,
    });
  }
}

export async function deleteDocument(req: Request, res: Response) {
  try {
    const documentId: Types.ObjectId = new Types.ObjectId(req.params.id);
    const document = await documentService.deleteMyDocument(documentId);

    res.redirect("/pharmacy/web/document-center");
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: "error",
    });
  }
}

/**
 * @description This function is for Shared With Me
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function sharedWithMe(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { search, page, limit, newDocumentType } = req.query;
    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const user = JSON.parse(res.get("user")!);
        const userId: Types.ObjectId = new Types.ObjectId(res.get("userId"));
        const documents = await documentService.getSharedwithMeDocuments(
          userId,
          search as string,
          newDocumentType as string
        );

        const fileContent = getViewFile("dashboard", "share-with-me.ejs");
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "documentCenter",
            type: "",
            filename: fileContent.templatePath,
            documents: documents,
          })
        );
      } else {
        const user = JSON.parse(res.get("user")!);
        const userId: Types.ObjectId = new Types.ObjectId(res.get("userId"));
        const documentURL = "/" + req.body.files[0]?.path;
        const documentCreateDto: any = {
          document_name: req.body.documentName,
          documentDescription: req.body.documentDescription,
          documentType: req.body.documentType,
          documentURL: documentURL,
          userId: userId,
        };
        const doc: TH_Document = await documentService.createDocument(
          documentCreateDto
        );
        const documents = await documentService.getSharedwithMeDocuments(
          userId,
          search as string,
          newDocumentType as string
        );


        const fileContent = getViewFile("dashboard", "share-with-me.ejs");

        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            type: "",
            activeTab: "documentCenter",
            filename: fileContent.templatePath,
            documents: documents,
          })
        );
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function shareByMe(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { search, page, limit, newDocumentType } = req.query;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const user = JSON.parse(res.get("user")!);
        const userId: Types.ObjectId = new Types.ObjectId(res.get("userId"));
        const documents = await documentService.shareByMeDocuments(
          userId,
          search as string,
          newDocumentType as string
        );
        const fileContent = getViewFile("dashboard", "share-by-me.ejs");
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            type: "",
            activeTab: "documentCenter",
            filename: fileContent.templatePath,
            documents: documents,
          })
        );
      } else {
        const user = JSON.parse(res.get("user")!);
        const userId: Types.ObjectId = new Types.ObjectId(res.get("userId"));
        const documentURL = "/" + req.body.files[0]?.path;
        const documentCreateDto: any = {
          document_name: req.body.documentName,
          documentDescription: req.body.documentDescription,
          documentType: req.body.documentType,
          documentURL: documentURL,
          userId: userId,
        };
        const doc: TH_Document = await documentService.createDocument(
          documentCreateDto
        );
        const documents = await documentService.shareByMeDocuments(
          userId,
          search as string,
          newDocumentType as string
        );


        const fileContent = getViewFile("dashboard", "share-by-me.ejs");

        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "documentCenter",
            type: "",
            filename: fileContent.templatePath,
            documents: documents,
          })
        );
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function filterSharedDocument(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    let search = req.query.search;
    let role = req.query.role;
    let data;
    const project = {
      firstName: 1,
      lastName: 1,
      _id: 1,
      email: 1,
    };
    let limit = 30;

    const match = {
      $or: [
        {
          firstName: { $regex: search, $options: "i" },
        },
        {
          lastName: { $regex: search, $options: "i" },
        },
      ],
    };

    switch (role) {
      case "doctor":
        data = await consultantModel
          .find({ isAllow: true, ...match }, project)
          .limit(limit);
        break;
      case "pharmacy":
        data = await pharmacyModel
          .find({ isAllow: true, ...match }, project)
          .limit(limit);
        break;
      case "admin":
        data = await adminModel
          .find({ isAllow: true, ...match }, project)
          .limit(limit);
        break;
      case "patient":
        data = await patientModel
          .find({ isAllow: true, ...match }, project)
          .limit(limit);
        break;
    }

    res.status(httpStatus.OK).send({
      data: data,
      message: "Users fetcehd successfully",
      status: httpStatus.OK,
    });
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function unshareMyDocument(req: Request, res: Response) {
  try {
    const documentId: Types.ObjectId = new Types.ObjectId(req.params.id);
    const userId: Types.ObjectId = new Types.ObjectId(req.body.unshareDoc);

    const document = await documentService.unshareDocument(documentId, userId);

    res.redirect("/pharmacy/web/document-center/me");
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: "error",
    });
  }
}

export async function filterUnharedDocument(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    let doc = req.params.documentId;
    const document = await documentShareModels.findById(doc);
    let userarray = document?.userId;

    document?.userId.map(async (p) => {
      let c = await patientModel.findById(p);
      let d = await consultantModel.findById(p);
      let e = await adminModel.findById(p);
      let f = await pharmacyModel.findById(p);

      
    });

    let search = req.query.search;
    let role = req.query.role;

    const project = {
      firstName: 1,
      lastName: 1,
      _id: 1,
      email: 1,
    };
    let limit = 30;

    const match = {
      $or: [
        {
          firstName: { $regex: search, $options: "i" },
        },
        {
          lastName: { $regex: search, $options: "i" },
        },
      ],
    };
    let data: any;

    switch (role) {
      case "doctor":
        data = document?.userId.map(async (a) => {
          return await consultantModel.findById(a);
        });
        break;
      case "pharmacy":
        data = document?.userId.map(async (a) => {
          data = await pharmacyModel.findById(a);
        });
        break;
      case "admin":
        data = document?.userId.map(async (a) => {
          return await adminModel.findById(a);
        });
        break;
      case "patient":
        data = document?.userId.map(async (a) => {
          return await patientModel.findById(a);
        });
        break;
    }

    let resolveData = await Promise.all(data);

    res.status(httpStatus.OK).send({
      data: resolveData,
      message: "Users fetcehd successfully",
      status: httpStatus.OK,
    });
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function updateAllowStatus(req: Request, res: Response) {
  try {
    const userId: Types.ObjectId = new Types.ObjectId(res.get("userId"));

    if (userId == undefined) {
      res.redirect("/pharmacy/web/document-center");
    } else {
      let doc = await documentService.updateStatus(userId);
      res.redirect("/pharmacy/web/document-center");
    }
  } catch (error) {
    console.log(error);
  }
}

export async function updateNotAllowStatus(req: Request, res: Response) {
  try {
    const userId: Types.ObjectId = new Types.ObjectId(res.get("userId"));

    if (userId == undefined) {
      res.redirect("/pharmacy/web/document-center");
    } else {
      let doc = await documentService.updateNotStatus(userId);
      res.redirect("/pharmacy/web/document-center");
    }
  } catch (error) {
    console.log(error);
  }
}

export async function ckeckStatus(req: Request, res: Response) {
  try {
    const userId: Types.ObjectId = new Types.ObjectId(res.get("userId"));

    let doc = await documentService.checkStatus(userId);

    res.send(doc);
  } catch (error) {
    console.log(error);
  }
}
