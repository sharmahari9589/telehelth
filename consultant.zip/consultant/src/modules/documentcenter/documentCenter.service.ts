import { Types } from "mongoose";
import documentModel, { TH_Document } from "./documentCenter.model";
import documentShareModels, { DocumentShare } from "./documentShare.models";
import pharmacyModel from "../pharmacy/pharmacy.model";

export async function getSharedwithMeDocuments(
  id: Types.ObjectId,
  search: string,
  documentType: string
): Promise<Array<DocumentShare>> {
  if (search) {
    return await documentShareModels.aggregate([
      {
        $match: {
          userId: id,
        },
      },
      {
        $lookup: {
          from: "documents",
          localField: "documentId",
          foreignField: "_id",
          as: "documentId",
        },
      },
      {
        $unwind: {
          path: "$documentId",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $match: {
          "documentId.document_name": { $regex: search, $options: "i" },
        },
      },
      {
        $lookup: {
          from: "doctors",
          localField: "documentId.userId",
          foreignField: "_id",
          as: "user1",
        },
      },
      {
        $unwind: {
          path: "$user1",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "patients",
          localField: "documentId.userId",
          foreignField: "_id",
          as: "user2",
        },
      },
      {
        $unwind: {
          path: "$user2",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "pharmacies",
          localField: "documentId.userId",
          foreignField: "_id",
          as: "user3",
        },
      },
      {
        $unwind: {
          path: "$user3",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "admins",
          localField: "documentId.userId",
          foreignField: "_id",
          as: "user4",
        },
      },
      {
        $unwind: {
          path: "$user4",
          preserveNullAndEmptyArrays: true,
        },
      },
    ]);
  }
  if (documentType) {
    return await documentShareModels.aggregate([
      {
        $match: {
          userId: id,
        },
      },
      {
        $lookup: {
          from: "documents",
          localField: "documentId",
          foreignField: "_id",
          as: "documentId",
        },
      },
      {
        $unwind: {
          path: "$documentId",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $match: {
          "documentId.documentType": documentType,
        },
      },
      {
        $lookup: {
          from: "doctors",
          localField: "documentId.userId",
          foreignField: "_id",
          as: "user1",
        },
      },
      {
        $unwind: {
          path: "$user1",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "patients",
          localField: "documentId.userId",
          foreignField: "_id",
          as: "user2",
        },
      },
      {
        $unwind: {
          path: "$user2",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "pharmacies",
          localField: "documentId.userId",
          foreignField: "_id",
          as: "user3",
        },
      },
      {
        $unwind: {
          path: "$user3",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "admins",
          localField: "documentId.userId",
          foreignField: "_id",
          as: "user4",
        },
      },
      {
        $unwind: {
          path: "$user4",
          preserveNullAndEmptyArrays: true,
        },
      },
    ]);
  } else {
    return await documentShareModels.aggregate([
      {
        $match: {
          userId: id,
        },
      },
      {
        $lookup: {
          from: "documents",
          localField: "documentId",
          foreignField: "_id",
          as: "documentId",
        },
      },
      {
        $unwind: {
          path: "$documentId",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "doctors",
          localField: "documentId.userId",
          foreignField: "_id",
          as: "user1",
        },
      },
      {
        $unwind: {
          path: "$user1",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "patients",
          localField: "documentId.userId",
          foreignField: "_id",
          as: "user2",
        },
      },
      {
        $unwind: {
          path: "$user2",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "pharmacies",
          localField: "documentId.userId",
          foreignField: "_id",
          as: "user3",
        },
      },
      {
        $unwind: {
          path: "$user3",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "admins",
          localField: "documentId.userId",
          foreignField: "_id",
          as: "user4",
        },
      },
      {
        $unwind: {
          path: "$user4",
          preserveNullAndEmptyArrays: true,
        },
      },
    ]);
  }
}

export async function shareByMeDocuments(
  id: Types.ObjectId,
  search: string,
  documentType: string
) {
  if (search) {
    return await documentShareModels.aggregate([
      {
        $lookup: {
          from: "documents",
          localField: "documentId",
          foreignField: "_id",
          as: "documentId",
        },
      },
      {
        $unwind: {
          path: "$documentId",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $match: {
          "documentId.userId": id,
          "documentId.document_name": { $regex: search, $options: "i" },
        },
      },
    ]);
  }
  if (documentType) {
    return await documentShareModels.aggregate([
      {
        $lookup: {
          from: "documents",
          localField: "documentId",
          foreignField: "_id",
          as: "documentId",
        },
      },
      {
        $unwind: {
          path: "$documentId",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $match: {
          "documentId.userId": id,
          "documentId.documentType": documentType,
        },
      },
    ]);
  } else {
    return await documentShareModels.aggregate([
      {
        $lookup: {
          from: "documents",
          localField: "documentId",
          foreignField: "_id",
          as: "documentId",
        },
      },
      {
        $unwind: {
          path: "$documentId",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $match: {
          "documentId.userId": id,
        },
      },
    ]);
  }
}

export async function createDocument(
  createDocumentDto: any
): Promise<TH_Document> {
  const data = new documentModel({ ...createDocumentDto });
  return await data.save();
}

export async function shareDocument(
  documentId: Types.ObjectId,
  userId: Types.ObjectId
): Promise<DocumentShare | null> {
  const isExists = await documentShareModels.findOne({
    documentId,
    // $in: {
    //   userId: userId,
    // },
  });
  if (isExists) {
    const document = await documentShareModels.findOne({
      userId: userId,
    });
    if (document) {
      return document;
    } else {
      return await documentShareModels.findOneAndUpdate(
        { documentId },
        {
          $push: {
            userId,
          },
        }
      );
    }
  } else {
    return await documentShareModels.create({ documentId, userId: [userId] });
  }
}

export async function unshareDocument(
  documentId: Types.ObjectId,
  userId: Types.ObjectId
): Promise<DocumentShare | null> {
  return await documentShareModels.findByIdAndUpdate(documentId, {
    $pull: {
      userId: userId,
    },
  });
}

export async function updateDocument(
  documentId: Types.ObjectId,
  documentBody: any
): Promise<TH_Document | null> {
  return await documentModel.findByIdAndUpdate(documentId, documentBody);
}

export async function getDocuments(
  userId: Types.ObjectId,
  search: string,
  documentType: string,
  page: number,
  limit: number
) {
  if (search) {
    return await documentModel.aggregate([
      {
        $match: {
          userId: userId,
          isDeleted: false,
          document_name: { $regex: search, $options: "i" },
        },
      },
    ]);
  } else {
    return await documentModel.aggregate([
      {
        $match: {
          userId: userId,
          isDeleted: false,
        },
      },
    ]);
  }
}

export async function getUsers(role: string, search: string) {}

// export async

export async function deleteMyDocument(
  documentId: Types.ObjectId
): Promise<TH_Document | null> {
  return await documentModel.findByIdAndUpdate(documentId, { isDeleted: true });
}

export async function updateStatus(userId: Types.ObjectId) {
  return await pharmacyModel.findByIdAndUpdate(userId, { isAllow: true });
}

export async function updateNotStatus(userId: Types.ObjectId) {
  return await pharmacyModel.findByIdAndUpdate(userId, { isAllow: false });
}

export async function checkStatus(userId: Types.ObjectId) {
  return await pharmacyModel.findById(userId);
}
