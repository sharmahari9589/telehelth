import { Types } from "mongoose";
import documentModel, { TH_Document } from "./document.model";
import documentShareModels, { DocumentShare } from "./documentShare.models";
import consultantModel from "../consultant/consultant.model";

export async function getSharedwithMeDocuments(
  id: Types.ObjectId,
  name: string
): Promise<Array<DocumentShare>> {
  if (name) {
    return await documentShareModels.aggregate([
      {
        $match: {
          userId: id,
        },
      },
      {
        $lookup: {
          from: "documents",
          localField: "documentId",
          foreignField: "_id",
          as: "documentId",
        },
      },
      {
        $unwind: {
          path: "$documentId",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $match: {
          "documentId.document_name": {
            $regex: name,
            $options: "i",
          },
        },
      },
      {
        $lookup: {
          from: "doctors",
          localField: "documentId.userId",
          foreignField: "_id",
          as: "user1",
        },
      },
      {
        $unwind: {
          path: "$user1",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "patients",
          localField: "documentId.userId",
          foreignField: "_id",
          as: "user2",
        },
      },
      {
        $unwind: {
          path: "$user2",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "pharmacies",
          localField: "documentId.userId",
          foreignField: "_id",
          as: "user3",
        },
      },
      {
        $unwind: {
          path: "$user3",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "admins",
          localField: "documentId.userId",
          foreignField: "_id",
          as: "user4",
        },
      },
      {
        $unwind: {
          path: "$user4",
          preserveNullAndEmptyArrays: true,
        },
      },
    ]);
  } else {
    return await documentShareModels.aggregate([
      {
        $match: {
          userId: id,
        },
      },
      {
        $lookup: {
          from: "documents",
          localField: "documentId",
          foreignField: "_id",
          as: "documentId",
        },
      },
      {
        $unwind: {
          path: "$documentId",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "doctors",
          localField: "documentId.userId",
          foreignField: "_id",
          as: "user1",
        },
      },
      {
        $unwind: {
          path: "$user1",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "patients",
          localField: "documentId.userId",
          foreignField: "_id",
          as: "user2",
        },
      },
      {
        $unwind: {
          path: "$user2",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "pharmacies",
          localField: "documentId.userId",
          foreignField: "_id",
          as: "user3",
        },
      },
      {
        $unwind: {
          path: "$user3",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "admins",
          localField: "documentId.userId",
          foreignField: "_id",
          as: "user4",
        },
      },
      {
        $unwind: {
          path: "$user4",
          preserveNullAndEmptyArrays: true,
        },
      },
    ]);
  }
}

export async function shareByMeDocuments(id: Types.ObjectId, name: string) {
  if (name) {
    const documents = await documentShareModels.aggregate([
      {
        $lookup: {
          from: "documents",
          localField: "documentId",
          foreignField: "_id",
          as: "documentId",
        },
      },
      {
        $unwind: {
          path: "$documentId",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $match: {
          "documentId.userId": id,
        },
      },
      {
        $match: {
          "documentId.document_name": {
            $regex: name,
            $options: "i",
          },
        },
      },
    ]);
    return documents;
  } else {
    const documents = await documentShareModels.aggregate([
      {
        $lookup: {
          from: "documents",
          localField: "documentId",
          foreignField: "_id",
          as: "documentId",
        },
      },
      {
        $unwind: {
          path: "$documentId",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $match: {
          "documentId.userId": id,
        },
      },
    ]);
    return documents;
  }
}

export async function createDocument(
  createDocumentDto: any
): Promise<TH_Document> {
  const data = new documentModel({ ...createDocumentDto });
  return await data.save();
}

export async function shareDocument(
  documentId: Types.ObjectId,
  userId: Types.ObjectId
): Promise<DocumentShare | null> {
  const isExists = await documentShareModels.findOne({
    documentId,
    // $in: {
    //   userId: userId,
    // },
  });
  if (isExists) {
    const document = await documentShareModels.findOne({
      userId: userId,
    });
    if (document) {
      return document;
    } else {
      return await documentShareModels.findOneAndUpdate(
        { documentId },
        {
          $push: {
            userId,
          },
        }
      );
    }
  } else {
    return await documentShareModels.create({ documentId, userId: [userId] });
  }
}

export async function unshareDocument(
  documentId: Types.ObjectId,
  userId: Types.ObjectId
): Promise<DocumentShare | null> {
  return await documentShareModels.findByIdAndUpdate(documentId, {
    $pull: {
      userId: userId,
    },
  });
}

export async function updateDocument(
  documentId: Types.ObjectId,
  documentBody: any
): Promise<TH_Document | null> {
  return await documentModel.findByIdAndUpdate(documentId, documentBody);
}

export async function getDocuments(
  userId: Types.ObjectId,
  search: string,
  page: number,
  limit: number,
  startDate: string,
  endDate: string
) {
  if (search && startDate == "" && endDate == "") {
    return await documentModel.aggregate([
      {
        $match: {
          userId: userId,
          isDeleted: false,
        },
      },
      {
        $match: {
          $or: [
            {
              documentDescription: {
                $regex: search,
                $options: "i",
              },
            },
            {
              document_name: {
                $regex: search,
                $options: "i",
              },
            },
          ],
        },
      },

      {
        $limit: 100,
      },
      {
        $skip: 0,
      },
    ]);
  }
  if (search == "" && startDate && endDate == "") {
    return await documentModel.aggregate([
      {
        $match: {
          userId: userId,
          isDeleted: false,
        },
      },
      {
        $match: {
          createdAt: {
            $gte: new Date(startDate),
          },
        },
      },

      {
        $limit: 100,
      },
      {
        $skip: 0,
      },
    ]);
  }

  if (search == "" && startDate == "" && endDate) {
    return await documentModel.aggregate([
      {
        $match: {
          userId: userId,
          isDeleted: false,
        },
      },
      {
        $match: {
          createdAt: {
            $lte: new Date(startDate),
          },
        },
      },

      {
        $limit: 100,
      },
      {
        $skip: 0,
      },
    ]);
  }

  if (search && startDate && endDate) {
    return await documentModel.aggregate([
      {
        $match: {
          userId: userId,
          isDeleted: false,
        },
      },
      {
        $match: {
          $and: [
            {
              document_name: {
                $regex: search,
                $options: "i",
              },
            },
            {
              date: {
                $gte: new Date(startDate),
                $lte: new Date(endDate),
              },
            },
          ],
        },
      },

      {
        $limit: 100,
      },
      {
        $skip: 0,
      },
    ]);
  } else {
    return await documentModel.aggregate([
      {
        $match: {
          userId: userId,
          isDeleted: false,
        },
      },
      {
        $limit: 100,
      },
      {
        $skip: 0,
      },
    ]);
  }
}

export async function getUsers(role: string, search: string) {}

// export async

export async function deleteMyDocument(
  documentId: Types.ObjectId
): Promise<TH_Document | null> {
  return await documentModel.findByIdAndUpdate(documentId, { isDeleted: true });
}

export async function updateStatus(userId: Types.ObjectId) {
  return await consultantModel.findByIdAndUpdate(userId, { isAllow: true });
}

export async function updateNotStatus(userId: Types.ObjectId) {
  return await consultantModel.findByIdAndUpdate(userId, { isAllow: false });
}

export async function checkStatus(userId: Types.ObjectId) {
  return await consultantModel.findById(userId);
}
