import { Types } from "mongoose";
import scheduleModel, { Schedule } from "./schedule.model";
import bookingModel, { Booking } from "../booking/booking.model";

export async function getMySchedule(
  scheduleId: Types.ObjectId
): Promise<Array<Schedule>> {
  return await scheduleModel.find({
    scheduleId: scheduleId,
  });
}

export async function updateMySchedule(scheduleId: Types.ObjectId, body: any) {
  return await scheduleModel.findByIdAndUpdate(scheduleId, body, { new: true });
}

export async function getUpdateSchedule(scheduleId: Types.ObjectId, body: any) {
  return await scheduleModel.findByIdAndUpdate(
    scheduleId,
    { $set: { services: body } },
    { new: true }
  );
}

export async function getScheduleById(
  scheduleId: Types.ObjectId
): Promise<Schedule | null> {
  return await scheduleModel.findById(scheduleId);
}

export async function getScheduleByDoctorId(
  doctorId: Types.ObjectId
): Promise<Schedule | null> {
  return await scheduleModel.findOne({ doctor: doctorId });
}

export async function addSchedule(body: any) {
  return await scheduleModel.create(body);
}

export async function addAvailabilty(
  doctorId: Types.ObjectId,
  availability: any
) {
  const data: any = await scheduleModel.findOne({ doctor: doctorId });

  if (data) {
    return await scheduleModel.findByIdAndUpdate(data._id, { availability });
  } else {
    return null;
  }
}

export async function breaksAdd(doctorId: Types.ObjectId, availability: any) {
  const data: any = await scheduleModel.findOne({ doctor: doctorId });

  return await scheduleModel.findByIdAndUpdate(data._id, { availability });
}

export async function timeOffsAdd(doctorId: Types.ObjectId, allData: any) {
  const data: any = await scheduleModel.findOne({ doctor: doctorId });

  if (data) {
    return await scheduleModel.findByIdAndUpdate(
      data._id,
      { $push: { timeOffs: allData } },
      { new: true }
    );
  } else {
    return null;
  }
}

export async function AllData(doctorId: Types.ObjectId) {
  const data: any = await scheduleModel.findOne({ doctor: doctorId });

  if (data) {
    return await scheduleModel.findById(data._id);
  } else {
    return null;
  }
}

export async function findSlotIsBooked(
  doctorId: Types.ObjectId,
  userId: Types.ObjectId,
  start: Date,
  end: Date
): Promise<Booking[] | null> {
  return await bookingModel.find({
    date: { $gte: start },
    time: { $lte: end },
    $or: [{ doctor: doctorId }, { patient: userId }],
  });
}
