import { Request, Response } from "express";
import httpStatus from "http-status";
import { ObjectId, Types } from "mongoose";
import * as scheduleService from "./schedule.service";
import { sendMail } from "../../utils/sendMail";
import * as consultantservices from "../consultantDashboard/consultant.services";

//EJS Rendor
import ejs from "ejs";
import { getViewFile } from "../../utils/ejsHelper";
import scheduleModel from "./schedule.model";
import { log } from "console";
import { devNull } from "os";
import moment from "moment";
import moments from "moment-timezone";
import consultantModel from "../consultant/consultant.model";
import { Booking } from "../booking/booking.model";
const availabilityData: any = {
  1: "monday",
  2: "tuesday",
  3: "wednesday",
  4: "thursday",
  5: "friday",
  6: "saturday",
  0: "sunday",
};
export async function getMySchedule(req: Request, res: Response) {
  try {
    const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const user = JSON.parse(res.get("user")!);
    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = id;
    } else {
      consultantId = user.addedBy;
    }
    const schedule = scheduleService.getMySchedule(consultantId);
    res.status(httpStatus.OK).send({
      data: schedule,
      message: "Schedule fetched successfully",
      status: httpStatus.OK,
    });
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.OK).send({
      message: err.message,
    });
  }
}

export async function updateMySchedule(req: Request, res: Response) {
  try {
    const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const user = JSON.parse(res.get("user")!);
    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = id;
    } else {
      consultantId = user.addedBy;
    }
    const schedule = scheduleService.getMySchedule(consultantId);
    res.status(httpStatus.OK).send({
      data: schedule,
      message: "Schedule fetched successfully",
      status: httpStatus.OK,
    });
  } catch (error) {
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function updateAvailabilty(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const {
      isAvailable1,
      isAvailable2,
      isAvailable3,
      isAvailable4,
      isAvailable5,
      isAvailable6,
      isAvailable7,
      startTime,
      endTime,
    } = req.body;
    const doctorId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const user: any = JSON.parse(res.get("user")!);

    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = doctorId;
    } else {
      consultantId = new Types.ObjectId(user.addedBy);
    }

    const doctorName = await consultantModel.findById(consultantId);

    var value1;
    if (isAvailable1 !== undefined) {
      value1 = true;
    } else {
      value1 = false;
    }

    var value2;
    if (isAvailable2 !== undefined) {
      value2 = true;
    } else {
      value2 = false;
    }

    var value3;
    if (isAvailable3 !== undefined) {
      value3 = true;
    } else {
      value3 = false;
    }

    var value4;
    if (isAvailable4 !== undefined) {
      value4 = true;
    } else {
      value4 = false;
    }

    var value5;
    if (isAvailable5 !== undefined) {
      value5 = true;
    } else {
      value5 = false;
    }

    var value6;
    if (isAvailable6 !== undefined) {
      value6 = true;
    } else {
      value6 = false;
    }

    var value7;
    if (isAvailable7 !== undefined) {
      value7 = true;
    } else {
      value7 = false;
    }

    var start1;
    if (startTime[0] !== "") {
      const startDate1 = new Date("2023-06-12T00:00:00.000Z");

      const startHours1 = startTime[0].slice(0, 2);
      const startMinutes1 = startTime[0].slice(3, 5);
      startDate1.setUTCHours(startHours1);
      startDate1.setUTCMinutes(startMinutes1);
      startDate1.setUTCSeconds(0);

      start1 = startDate1.toISOString();
    } else {
      start1 = "";
    }

    var end1;
    if (endTime[0] !== "") {
      const endDate1 = new Date("2023-06-12T00:00:00.000Z");
      const endHours1 = endTime[0].slice(0, 2);
      const endMinutes1 = endTime[0].slice(3, 5);
      endDate1.setUTCHours(endHours1);
      endDate1.setUTCMinutes(endMinutes1);
      endDate1.setUTCSeconds(0);

      end1 = endDate1.toISOString();
    } else {
      end1 = "";
    }

    var start2;
    if (startTime[1] !== "") {
      const startDate2 = new Date("2023-06-13T00:00:00.000Z");
      const startHours2 = startTime[1].slice(0, 2);
      const startMinutes2 = startTime[1].slice(3, 5);
      startDate2.setUTCHours(startHours2);
      startDate2.setUTCMinutes(startMinutes2);
      startDate2.setUTCSeconds(0);

      start2 = startDate2.toISOString();
    } else {
      start2 = "";
    }

    var end2;
    if (endTime[1] !== "") {
      const endDate2 = new Date("2023-06-13T00:00:00.000Z");
      const endHours2 = endTime[1].slice(0, 2);
      const endMinutes2 = endTime[1].slice(3, 5);
      endDate2.setUTCHours(endHours2);
      endDate2.setUTCMinutes(endMinutes2);
      endDate2.setUTCSeconds(0);

      end2 = endDate2.toISOString();
    } else {
      end2 = "";
    }

    var start3;
    if (startTime[2] !== "") {
      const startDate3 = new Date("2023-06-14T00:00:00.000Z");
      const startHours3 = startTime[2].slice(0, 2);
      const startMinutes3 = startTime[2].slice(3, 5);
      startDate3.setUTCHours(startHours3);
      startDate3.setUTCMinutes(startMinutes3);
      startDate3.setUTCSeconds(0);

      start3 = startDate3.toISOString();
    } else {
      start3 = "";
    }

    var end3;
    if (endTime[2] !== "") {
      const endDate3 = new Date("2023-06-14T00:00:00.000Z");
      const endHours3 = endTime[2].slice(0, 2);
      const endMinutes3 = endTime[2].slice(3, 5);
      endDate3.setUTCHours(endHours3);
      endDate3.setUTCMinutes(endMinutes3);
      endDate3.setUTCSeconds(0);

      end3 = endDate3.toISOString();
    } else {
      end3 = "";
    }

    var start4;
    if (startTime[3] !== "") {
      const startDate4 = new Date("2023-06-15T00:00:00.000Z");
      const startHours4 = startTime[3].slice(0, 2);
      const startMinutes4 = startTime[3].slice(3, 5);
      startDate4.setUTCHours(startHours4);
      startDate4.setUTCMinutes(startMinutes4);
      startDate4.setUTCSeconds(0);

      start4 = startDate4.toISOString();
    } else {
      start4 = "";
    }

    var end4;
    if (endTime[3] !== "") {
      const endDate4 = new Date("2023-06-15T00:00:00.000Z");
      const endHours4 = endTime[3].slice(0, 2);
      const endMinutes4 = endTime[3].slice(3, 5);
      endDate4.setUTCHours(endHours4);
      endDate4.setUTCMinutes(endMinutes4);
      endDate4.setUTCSeconds(0);

      end4 = endDate4.toISOString();
    } else {
      end4 = "";
    }

    var start5;
    if (startTime[4] !== "") {
      const startDate5 = new Date("2023-06-16T00:00:00.000Z");
      const startHours5 = startTime[4].slice(0, 2);
      const startMinutes5 = startTime[4].slice(3, 5);
      startDate5.setUTCHours(startHours5);
      startDate5.setUTCMinutes(startMinutes5);
      startDate5.setUTCSeconds(0);

      start5 = startDate5.toISOString();
    } else {
      start5 = "";
    }

    var end5;
    if (endTime[4] !== "") {
      const endDate5 = new Date("2023-06-16T00:00:00.000Z");
      const endHours5 = endTime[4].slice(0, 2);
      const endMinutes5 = endTime[4].slice(3, 5);
      endDate5.setUTCHours(endHours5);
      endDate5.setUTCMinutes(endMinutes5);
      endDate5.setUTCSeconds(0);

      end5 = endDate5.toISOString();
    } else {
      end5 = "";
    }

    var start6;
    if (startTime[5] !== "") {
      const startDate6 = new Date("2023-06-17T00:00:00.000Z");
      const startHours6 = startTime[5].slice(0, 2);
      const startMinutes6 = startTime[5].slice(3, 5);
      startDate6.setUTCHours(startHours6);
      startDate6.setUTCMinutes(startMinutes6);
      startDate6.setUTCSeconds(0);

      start6 = startDate6.toISOString();
    } else {
      start6 = "";
    }

    var end6;
    if (endTime[5] !== "") {
      const endDate6 = new Date("2023-06-17T00:00:00.000Z");
      const endHours6 = endTime[5].slice(0, 2);
      const endMinutes6 = endTime[5].slice(3, 5);
      endDate6.setUTCHours(endHours6);
      endDate6.setUTCMinutes(endMinutes6);
      endDate6.setUTCSeconds(0);

      end6 = endDate6.toISOString();
    } else {
      end6 = "";
    }

    var start7;
    if (startTime[6] !== "") {
      const startDate7 = new Date("2023-06-18T00:00:00.000Z");
      const startHours7 = startTime[6].slice(0, 2);
      const startMinutes7 = startTime[6].slice(3, 5);
      startDate7.setUTCHours(startHours7);
      startDate7.setUTCMinutes(startMinutes7);
      startDate7.setUTCSeconds(0);

      start7 = startDate7.toISOString();
    } else {
      start7 = "";
    }

    var end7;
    if (endTime[6] !== "") {
      const endDate7 = new Date("2023-06-18T00:00:00.000Z");
      const endHours7 = endTime[6].slice(0, 2);
      const endMinutes7 = endTime[6].slice(3, 5);
      endDate7.setUTCHours(endHours7);
      endDate7.setUTCMinutes(endMinutes7);
      endDate7.setUTCSeconds(0);

      end7 = endDate7.toISOString();
    } else {
      end7 = "";
    }

    const data = await consultantservices.getMySchedule(consultantId);

    const newdata: any = data[0]?.availability[0]?.monday?.breaks[0]?.startTime;

    let item;

    if (newdata) {
      item = {
        monday: {
          isAvailable: value1,
          startTime: start1,
          endTime: end1,
          breaks: [
            {
              startTime: data[0]?.availability[0]?.monday.breaks[0].startTime,
              endTime: data[0]?.availability[0]?.monday.breaks[0].endTime,
            },
          ],
        },
        tuesday: {
          isAvailable: value2,
          startTime: start2,
          endTime: end2,
          breaks: [
            {
              startTime: data[0]?.availability[0]?.tuesday.breaks[0].startTime,
              endTime: data[0]?.availability[0]?.tuesday.breaks[0].endTime,
            },
          ],
        },
        wednesday: {
          isAvailable: value3,
          startTime: start3,
          endTime: end3,
          breaks: [
            {
              startTime:
                data[0]?.availability[0]?.wednesday.breaks[0].startTime,
              endTime: data[0]?.availability[0]?.wednesday.breaks[0].endTime,
            },
          ],
        },
        thursday: {
          isAvailable: value4,
          startTime: start4,
          endTime: end4,
          breaks: [
            {
              startTime: data[0]?.availability[0]?.thursday.breaks[0].startTime,
              endTime: data[0]?.availability[0]?.thursday.breaks[0].endTime,
            },
          ],
        },
        friday: {
          isAvailable: value5,
          startTime: start5,
          endTime: end5,
          breaks: [
            {
              startTime: data[0]?.availability[0]?.friday.breaks[0].startTime,
              endTime: data[0]?.availability[0]?.friday.breaks[0].endTime,
            },
          ],
        },
        saturday: {
          isAvailable: value6,
          startTime: start6,
          endTime: end6,
          breaks: [
            {
              startTime: data[0]?.availability[0]?.saturday.breaks[0].startTime,
              endTime: data[0]?.availability[0]?.saturday.breaks[0].endTime,
            },
          ],
        },
        sunday: {
          isAvailable: value7,
          startTime: start7,
          endTime: end7,
          breaks: [
            {
              startTime: data[0]?.availability[0]?.sunday.breaks[0].startTime,
              endTime: data[0]?.availability[0]?.sunday.breaks[0].endTime,
            },
          ],
        },
      };
    } else {
      item = {
        monday: {
          isAvailable: value1,
          startTime: start1,
          endTime: end1,
          breaks: [
            {
              startTime: new Date("2023-06-12T00:00:00.000Z"),
              endTime: new Date("2023-06-12T00:00:00.000Z"),
            },
          ],
        },
        tuesday: {
          isAvailable: value2,
          startTime: start2,
          endTime: end2,
          breaks: [
            {
              startTime: new Date("2023-06-13T00:00:00.000Z"),
              endTime: new Date("2023-06-13T00:00:00.000Z"),
            },
          ],
        },
        wednesday: {
          isAvailable: value3,
          startTime: start3,
          endTime: end3,
          breaks: [
            {
              startTime: new Date("2023-06-14T00:00:00.000Z"),
              endTime: new Date("2023-06-14T00:00:00.000Z"),
            },
          ],
        },
        thursday: {
          isAvailable: value4,
          startTime: start4,
          endTime: end4,
          breaks: [
            {
              startTime: new Date("2023-06-15T00:00:00.000Z"),
              endTime: new Date("2023-06-15T00:00:00.000Z"),
            },
          ],
        },
        friday: {
          isAvailable: value5,
          startTime: start5,
          endTime: end5,
          breaks: [
            {
              startTime: new Date("2023-06-16T00:00:00.000Z"),
              endTime: new Date("2023-06-16T00:00:00.000Z"),
            },
          ],
        },
        saturday: {
          isAvailable: value6,
          startTime: start6,
          endTime: end6,
          breaks: [
            {
              startTime: new Date("2023-06-17T00:00:00.000Z"),
              endTime: new Date("2023-06-17T00:00:00.000Z"),
            },
          ],
        },
        sunday: {
          isAvailable: value7,
          startTime: start7,
          endTime: end7,
          breaks: [
            {
              startTime: new Date("2023-06-18T00:00:00.000Z"),
              endTime: new Date("2023-06-18T00:00:00.000Z"),
            },
          ],
        },
      };
    }

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: "",
        message: "Schedule Create Successfully",
        status: httpStatus.OK,
      });
    } else {
      const schedule = await scheduleService.addAvailabilty(consultantId, item);

      if (schedule !== null) {
        if (schedule.availability) {
          const updateSchedule = await consultantservices.getMySchedule(
            consultantId
          );

          const fileContent = getViewFile("consultantDashboard", "setmore.ejs");
          const user: any = JSON.parse(res.get("user")!);

          res.send(
            ejs.render(fileContent.file, {
              message: "Availabilty Added Sucessfully",
              message1: "",
              user,
              updateSchedule,
              doctorName,
              activeTab: "avail",
              filename: fileContent.templatePath,
            })
          );
        } else {
          const updateSchedule = await consultantservices.getMySchedule(
            consultantId
          );

          const fileContent = getViewFile("consultantDashboard", "setmore.ejs");
          const user: any = JSON.parse(res.get("user")!);

          res.send(
            ejs.render(fileContent.file, {
              message1: "Add Service First",
              message: "",
              user,
              updateSchedule,
              doctorName,
              activeTab: "avail",
              filename: fileContent.templatePath,
            })
          );
        }
      } else {
        const updateSchedule = await consultantservices.getMySchedule(
          consultantId
        );

        const fileContent = getViewFile("consultantDashboard", "setmore.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message1: "Create Service First",
            message: "",
            user,
            updateSchedule,
            doctorName,
            activeTab: "avail",

            filename: fileContent.templatePath,
          })
        );
      }
    }
  } catch (error) {
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function addSchedule(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const doctorId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const user: any = JSON.parse(res.get("user")!);

    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = doctorId;
    } else {
      consultantId = new Types.ObjectId(user.addedBy);
    }

    const doctorName = await consultantModel.findById(consultantId);

    const {
      duration,
      amount,
      isAvailable,
      startTime,
      endTime,
      availability,
      slotBuffer,
      timeOffs,
    } = req.body;

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: "",
        message: "schedule create successfully",
        status: httpStatus.OK,
      });
    } else {
      const newData: any = {
        durationInMin: duration.map((a: any) => {
          return parseInt(a);
        }),
        price: amount.map((b: any) => {
          return parseInt(b);
        }),
      };

      const services = [];

      for (let i = 0; i < newData.durationInMin.length; i++) {
        const convertedObject: any = {};

        for (const key in newData) {
          convertedObject[key] = newData[key][i];
        }

        services.push(convertedObject);
      }

      const scheduleExist = await scheduleService.getScheduleByDoctorId(
        consultantId
      );

      if (scheduleExist) {
        const getUpdateSchedule = await scheduleService.getUpdateSchedule(
          scheduleExist._id,
          services
        );

        const updateSchedule = await consultantservices.getMySchedule(
          consultantId
        );

        const fileContent = getViewFile("consultantDashboard", "setmore.ejs");
        const user: any = JSON.parse(res.get("user")!);

        res.send(
          ejs.render(fileContent.file, {
            message: "Schedule Updated Successfully",
            message1: "",
            user,
            updateSchedule,
            getUpdateSchedule,
            doctorName,
            filename: fileContent.templatePath,
            activeTab: "avail",
          })
        );
      } else {
        const schedule = scheduleService.addSchedule({
          doctor: consultantId,
          services,
          availability,
          slotBuffer,
          timeOffs,
        });

        const updateSchedule = await consultantservices.getMySchedule(
          consultantId
        );

        const fileContent = getViewFile("consultantDashboard", "setmore.ejs");
        const user: any = JSON.parse(res.get("user")!);

        res.send(
          ejs.render(fileContent.file, {
            message: "Schedule Updated Successfully",
            message1: "",
            user,
            updateSchedule,
            getUpdateSchedule: "",
            doctorName,
            filename: fileContent.templatePath,
            activeTab: "avail",
          })
        );
      }
    }
  } catch (error) {
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function addBreak(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const doctorId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const user: any = JSON.parse(res.get("user")!);

    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = doctorId;
    } else {
      consultantId = new Types.ObjectId(user.addedBy);
    }

    const doctorName = await consultantModel.findById(consultantId);

    const available = await scheduleService.AllData(consultantId);

    if (available?.availability !== null && available !== null) {
      const {
        duration,
        amount,
        isAvailable,
        startTime,
        endTime,
        slotBuffer,
        timeOffs,
      } = req.body;

      var start1;
      if (startTime[0] !== "") {
        const startDate1 = new Date("2023-06-12T00:00:00.000Z");

        const startHours1 = startTime[0].slice(0, 2);
        const startMinutes1 = startTime[0].slice(3, 5);
        startDate1.setUTCHours(startHours1);
        startDate1.setUTCMinutes(startMinutes1);
        startDate1.setUTCSeconds(0);

        start1 = startDate1;
      } else {
        start1 = new Date("2023-06-12T00:00:00.000Z");
      }

      var end1;
      if (endTime[0] !== "") {
        const endDate1 = new Date("2023-06-12T00:00:00.000Z");
        const endHours1 = endTime[0].slice(0, 2);
        const endMinutes1 = endTime[0].slice(3, 5);
        endDate1.setUTCHours(endHours1);
        endDate1.setUTCMinutes(endMinutes1);
        endDate1.setUTCSeconds(0);

        end1 = endDate1;
      } else {
        end1 = new Date("2023-06-12T00:00:00.000Z");
      }

      var start2;
      if (startTime[1] !== "") {
        const startDate2 = new Date("2023-06-13T00:00:00.000Z");
        const startHours2 = startTime[1].slice(0, 2);
        const startMinutes2 = startTime[1].slice(3, 5);
        startDate2.setUTCHours(startHours2);
        startDate2.setUTCMinutes(startMinutes2);
        startDate2.setUTCSeconds(0);

        start2 = startDate2;
      } else {
        start2 = new Date("2023-06-13T00:00:00.000Z");
      }

      var end2;
      if (endTime[1] !== "") {
        const endDate2 = new Date("2023-06-13T00:00:00.000Z");
        const endHours2 = endTime[1].slice(0, 2);
        const endMinutes2 = endTime[1].slice(3, 5);
        endDate2.setUTCHours(endHours2);
        endDate2.setUTCMinutes(endMinutes2);
        endDate2.setUTCSeconds(0);

        end2 = endDate2;
      } else {
        end2 = new Date("2023-06-13T00:00:00.000Z");
      }

      var start3;
      if (startTime[2] !== "") {
        const startDate3 = new Date("2023-06-14T00:00:00.000Z");
        const startHours3 = startTime[2].slice(0, 2);
        const startMinutes3 = startTime[2].slice(3, 5);
        startDate3.setUTCHours(startHours3);
        startDate3.setUTCMinutes(startMinutes3);
        startDate3.setUTCSeconds(0);

        start3 = startDate3;
      } else {
        start3 = new Date("2023-06-14T00:00:00.000Z");
      }

      var end3;
      if (endTime[2] !== "") {
        const endDate3 = new Date("2023-06-14T00:00:00.000Z");
        const endHours3 = endTime[2].slice(0, 2);
        const endMinutes3 = endTime[2].slice(3, 5);
        endDate3.setUTCHours(endHours3);
        endDate3.setUTCMinutes(endMinutes3);
        endDate3.setUTCSeconds(0);

        end3 = endDate3;
      } else {
        end3 = new Date("2023-06-14T00:00:00.000Z");
      }

      var start4;
      if (startTime[3] !== "") {
        const startDate4 = new Date("2023-06-15T00:00:00.000Z");
        const startHours4 = startTime[3].slice(0, 2);
        const startMinutes4 = startTime[3].slice(3, 5);
        startDate4.setUTCHours(startHours4);
        startDate4.setUTCMinutes(startMinutes4);
        startDate4.setUTCSeconds(0);

        start4 = startDate4;
      } else {
        start4 = new Date("2023-06-15T00:00:00.000Z");
      }

      var end4;
      if (endTime[3] !== "") {
        const endDate4 = new Date("2023-06-15T00:00:00.000Z");
        const endHours4 = endTime[3].slice(0, 2);
        const endMinutes4 = endTime[3].slice(3, 5);
        endDate4.setUTCHours(endHours4);
        endDate4.setUTCMinutes(endMinutes4);
        endDate4.setUTCSeconds(0);

        end4 = endDate4;
      } else {
        end4 = new Date("2023-06-15T00:00:00.000Z");
      }

      var start5;
      if (startTime[4] !== "") {
        const startDate5 = new Date("2023-06-16T00:00:00.000Z");
        const startHours5 = startTime[4].slice(0, 2);
        const startMinutes5 = startTime[4].slice(3, 5);
        startDate5.setUTCHours(startHours5);
        startDate5.setUTCMinutes(startMinutes5);
        startDate5.setUTCSeconds(0);

        start5 = startDate5;
      } else {
        start5 = new Date("2023-06-16T00:00:00.000Z");
      }

      var end5;
      if (endTime[4] !== "") {
        const endDate5 = new Date("2023-06-16T00:00:00.000Z");
        const endHours5 = endTime[4].slice(0, 2);
        const endMinutes5 = endTime[4].slice(3, 5);
        endDate5.setUTCHours(endHours5);
        endDate5.setUTCMinutes(endMinutes5);
        endDate5.setUTCSeconds(0);

        end5 = endDate5;
      } else {
        end5 = new Date("2023-06-16T00:00:00.000Z");
      }

      var start6;
      if (startTime[5] !== "") {
        const startDate6 = new Date("2023-06-17T00:00:00.000Z");
        const startHours6 = startTime[5].slice(0, 2);
        const startMinutes6 = startTime[5].slice(3, 5);
        startDate6.setUTCHours(startHours6);
        startDate6.setUTCMinutes(startMinutes6);
        startDate6.setUTCSeconds(0);

        start6 = startDate6;
      } else {
        start6 = new Date("2023-06-17T00:00:00.000Z");
      }

      var end6;
      if (endTime[5] !== "") {
        const endDate6 = new Date("2023-06-17T00:00:00.000Z");
        const endHours6 = endTime[5].slice(0, 2);
        const endMinutes6 = endTime[5].slice(3, 5);
        endDate6.setUTCHours(endHours6);
        endDate6.setUTCMinutes(endMinutes6);
        endDate6.setUTCSeconds(0);

        end6 = endDate6;
      } else {
        end6 = new Date("2023-06-17T00:00:00.000Z");
      }

      var start7;
      if (startTime[6] !== "") {
        const startDate7 = new Date("2023-06-18T00:00:00.000Z");
        const startHours7 = startTime[6].slice(0, 2);
        const startMinutes7 = startTime[6].slice(3, 5);
        startDate7.setUTCHours(startHours7);
        startDate7.setUTCMinutes(startMinutes7);
        startDate7.setUTCSeconds(0);

        start7 = startDate7;
      } else {
        start7 = new Date("2023-06-18T00:00:00.000Z");
      }

      var end7;
      if (endTime[6] !== "") {
        const endDate7 = new Date("2023-06-18T00:00:00.000Z");
        const endHours7 = endTime[6].slice(0, 2);
        const endMinutes7 = endTime[6].slice(3, 5);
        endDate7.setUTCHours(endHours7);
        endDate7.setUTCMinutes(endMinutes7);
        endDate7.setUTCSeconds(0);

        end7 = endDate7;
      } else {
        end7 = new Date("2023-06-18T00:00:00.000Z");
      }

      const data = await consultantservices.getMySchedule(consultantId);

      var value1;
      var timeStart1;
      var timeEnd1;

      if (
        data[0]?.availability[0]?.monday == null ||
        data[0]?.availability[0]?.monday == undefined
      ) {
        value1 = false;
        timeStart1 == "";
        timeEnd1 == "";
      } else {
        value1 = data[0]?.availability[0].monday.isAvailable;
        timeStart1 = data[0]?.availability[0].monday.startTime;
        timeEnd1 = data[0]?.availability[0].monday.endTime;
      }

      var value2;
      var timeStart2;
      var timeEnd2;
      if (
        data[0]?.availability[0]?.tuesday == null ||
        data[0]?.availability[0]?.tuesday == undefined
      ) {
        value2 = false;
        timeStart2 == "";
        timeEnd2 == "";
      } else {
        value2 = data[0]?.availability[0].tuesday.isAvailable;
        timeStart2 = data[0]?.availability[0].tuesday.startTime;
        timeEnd2 = data[0]?.availability[0].tuesday.endTime;
      }

      var value3;
      var timeStart3;
      var timeEnd3;
      if (
        data[0]?.availability[0]?.wednesday == null ||
        data[0]?.availability[0]?.wednesday == undefined
      ) {
        value3 = false;
        timeStart3 == "";
        timeEnd3 == "";
      } else {
        value3 = data[0]?.availability[0].wednesday.isAvailable;
        timeStart3 = data[0]?.availability[0].wednesday.startTime;
        timeEnd3 = data[0]?.availability[0].wednesday.endTime;
      }

      var value4;
      var timeStart4;
      var timeEnd4;
      if (
        data[0]?.availability[0]?.thursday == null ||
        data[0]?.availability[0]?.thursday == undefined
      ) {
        value4 = false;
        timeStart4 == "";
        timeEnd4 == "";
      } else {
        value4 = data[0]?.availability[0].thursday.isAvailable;
        timeStart4 = data[0]?.availability[0].thursday.startTime;
        timeEnd4 = data[0]?.availability[0].thursday.endTime;
      }
      var value5;
      var timeStart5;
      var timeEnd5;
      if (
        data[0]?.availability[0]?.friday == null ||
        data[0]?.availability[0]?.friday == undefined
      ) {
        value5 = false;
        timeStart5 == "";
        timeEnd5 == "";
      } else {
        value5 = data[0]?.availability[0].friday.isAvailable;
        timeStart5 = data[0]?.availability[0].friday.startTime;
        timeEnd5 = data[0]?.availability[0].friday.endTime;
      }
      var value6;
      var timeStart6;
      var timeEnd6;
      if (
        data[0]?.availability[0]?.saturday == null ||
        data[0]?.availability[0]?.saturday == undefined
      ) {
        value6 = false;
        timeStart6 = "";
        timeEnd6 = "";
      } else {
        value6 = data[0]?.availability[0].saturday.isAvailable;
        timeStart6 = data[0]?.availability[0].saturday.startTime;
        timeEnd6 = data[0]?.availability[0].saturday.endTime;
      }
      var value7;
      var timeStart7;
      var timeEnd7;
      if (
        data[0]?.availability[0]?.sunday == null ||
        data[0]?.availability[0]?.sunday == undefined
      ) {
        value7 = false;
        timeStart7 == "";
        timeEnd7 == "";
      } else {
        value7 = data[0]?.availability[0].sunday.isAvailable;
        timeStart7 = data[0]?.availability[0]?.sunday.startTime;
        timeEnd7 = data[0]?.availability[0]?.sunday.endTime;
      }

      const breaksDto = [
        {
          monday: {
            isAvailable: value1,
            startTime: timeStart1,
            endTime: timeEnd1,
            breaks: [
              {
                startTime: start1,
                endTime: end1,
              },
            ],
          },
          tuesday: {
            isAvailable: value2,
            startTime: timeStart2,
            endTime: timeEnd2,
            breaks: [
              {
                startTime: start2,
                endTime: end2,
              },
            ],
          },
          wednesday: {
            isAvailable: value3,
            startTime: timeStart3,
            endTime: timeEnd3,
            breaks: [
              {
                startTime: start3,
                endTime: end3,
              },
            ],
          },
          thursday: {
            isAvailable: value4,
            startTime: timeStart4,
            endTime: timeEnd4,
            breaks: [
              {
                startTime: start4,
                endTime: end4,
              },
            ],
          },
          friday: {
            isAvailable: value5,
            startTime: timeStart5,
            endTime: timeEnd5,
            breaks: [
              {
                startTime: start5,
                endTime: end5,
              },
            ],
          },
          saturday: {
            isAvailable: value6,
            startTime: timeStart6,
            endTime: timeEnd6,
            breaks: [
              {
                startTime: start6,
                endTime: end6,
              },
            ],
          },
          sunday: {
            isAvailable: value7,
            startTime: timeStart7,
            endTime: timeEnd7,
            breaks: [
              {
                startTime: start7,
                endTime: end7,
              },
            ],
          },
        },
      ];

      if (mode == "api") {
        res.status(httpStatus.OK).send({
          data: "",
          message: "schedule create successfully",
          status: httpStatus.OK,
        });
      } else {
        const schedule = await scheduleService.breaksAdd(
          consultantId,
          breaksDto
        );

        const updateSchedule = await consultantservices.getMySchedule(
          consultantId
        );

        const manageBooking: Array<Booking> =
          await consultantservices.myUpcomingBooking(
            doctorId
            // parseInt(limit as string),
            // parseInt(page as string)
          );

        const fileContent = getViewFile("consultantDashboard", "setmore.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "Break Added Sucessfully",
            message1: "",
            user,
            doctorName,
            updateSchedule,
            manageBooking,

            filename: fileContent.templatePath,
            activeTab: "avail",
          })
        );
      }
    } else {
      const updateSchedule = await consultantservices.getMySchedule(
        consultantId
      );

      const manageBooking: Array<Booking> =
        await consultantservices.myUpcomingBooking(
          doctorId
          // parseInt(limit as string),
          // parseInt(page as string)
        );

      const fileContent = getViewFile("consultantDashboard", "setmore.ejs");
      const user: any = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          message1: "Add Working Hours First",
          message: "",
          user,
          doctorName,
          updateSchedule,
          manageBooking,
          activeTab: "avail",

          filename: fileContent.templatePath,
        })
      );
    }
  } catch (error) {
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function addTimeoff(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const doctorId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const user: any = JSON.parse(res.get("user")!);

    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = doctorId;
    } else {
      consultantId = new Types.ObjectId(user.addedBy);
    }

    const doctorName = await consultantModel.findById(consultantId);

    const { startDate, endDate, startTime, endTime, description, allDay } =
      req.body;

    const dateString = startDate;
    const newStartDate = new Date(dateString);

    const stringDate = endDate;
    const newEndDate = new Date(stringDate);

    var value;
    if (allDay !== undefined) {
      value = true;
    } else {
      value = false;
    }

    const startDate1 = newStartDate;

    const startHours1 = startTime.slice(0, 2);
    const startMinutes1 = startTime.slice(3, 5);
    startDate1.setUTCHours(startHours1);
    startDate1.setUTCMinutes(startMinutes1);
    startDate1.setUTCSeconds(0);

    const start1 = startDate1.toISOString();

    const endDate1 = newEndDate;
    const endHours1 = endTime.slice(0, 2);
    const endMinutes1 = endTime.slice(3, 5);
    endDate1.setUTCHours(endHours1);
    endDate1.setUTCMinutes(endMinutes1);
    endDate1.setUTCSeconds(0);

    const end1 = endDate1.toISOString();

    const item = {
      startDate: newStartDate,
      endDate: newEndDate,
      startTime: start1,
      endTime: end1,
      isAllDay: value,

      description: description,
    };

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: "",
        message: "schedule create successfully",
        status: httpStatus.OK,
      });
    } else {
      const schedule = await scheduleService.timeOffsAdd(consultantId, item);

      if (schedule !== null) {
        const updateSchedule = await consultantservices.getMySchedule(
          consultantId
        );

        const manageBooking: Array<Booking> =
          await consultantservices.myUpcomingBooking(
            doctorId
            // parseInt(limit as string),
            // parseInt(page as string)
          );

        const fileContent = getViewFile("consultantDashboard", "setmore.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "Time Offs Added Succesfully",
            message1: "",
            user,
            doctorName,
            updateSchedule,
            manageBooking,
            activeTab: "avail",

            filename: fileContent.templatePath,
          })
        );
      } else {
        const updateSchedule = await consultantservices.getMySchedule(
          consultantId
        );

        const manageBooking: Array<Booking> =
          await consultantservices.myUpcomingBooking(
            consultantId
            // parseInt(limit as string),
            // parseInt(page as string)
          );
        const fileContent = getViewFile("consultantDashboard", "setmore.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message1: "Create Services  First",
            message: "",
            activeTab: "avail",
            user,
            doctorName,
            updateSchedule,
            manageBooking,

            filename: fileContent.templatePath,
          })
        );
      }
    }
  } catch (error) {
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function deleteTimeoff(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const doctorId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const user: any = JSON.parse(res.get("user")!);

    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = doctorId;
    } else {
      consultantId = new Types.ObjectId(user.addedBy);
    }

    const doctorName = await consultantModel.findById(consultantId);

    const { index } = req.body;

    const indexNumber = Number(index);

    const getSchedule = await scheduleModel.find({ doctor: consultantId });

    const d: any = getSchedule[0]?.timeOffs;

    const deleteSchedule = await scheduleModel.updateOne(
      { _id: getSchedule[0]?._id },
      { $unset: { [`timeOffs.${indexNumber}`]: 1 } }
    );

    await scheduleModel.updateOne(
      { _id: getSchedule[0]?._id },
      { $pull: { timeOffs: null } }
    );

    // Optional: If you want to reindex the remaining elements
    await scheduleModel.updateOne(
      { _id: getSchedule[0]?._id },
      { $push: { timeOffs: { $each: [], $position: indexNumber } } }
    );

    const updateSchedule = await scheduleModel.find({ doctor: consultantId });

    const manageBooking: Array<Booking> =
      await consultantservices.myUpcomingBooking(
        consultantId
        // parseInt(limit as string),
        // parseInt(page as string)
      );
    const fileContent = getViewFile("consultantDashboard", "setmore.ejs");
    res.send(
      ejs.render(fileContent.file, {
        message1: "Time Offs Delete Successfully",
        message: "",
        user,
        doctorName,
        updateSchedule,
        manageBooking,
        activeTab: "avail",

        filename: fileContent.templatePath,
      })
    );
  } catch (error) {
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function updateSchedule(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    // const scheduleId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const { scheduleId, services, availability, slotBuffer, timeOffs } =
      req.body;
    const schedule = await scheduleService.updateMySchedule(scheduleId, {
      services,
      availability,
      slotBuffer,
      timeOffs,
    });

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: schedule,
        message: "schedule update successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      //Web Code End
    }
  } catch (error) {
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function scheduleCount(req: Request, res: Response) {
  const { mode } = req.params;
  // const schedule =  scheduleService.count()

  if (mode == "api") {
    res.status(httpStatus.OK).send({
      data: "",
      message: "pharmacy count succesfully",
      status: httpStatus.OK,
    });
  } else {
    //Web Code Start
    //Web Code End
  }
}

export async function getSlotByDate(req: Request, res: Response) {
  const { mode } = req.params;
  // const schedule =  scheduleService.count()
  try {
    let {
      doctorId,
      date,
      slotTime,
    }: { date: any; doctorId: Types.ObjectId; slotTime: number } = req.body;
    date = new Date(date);
    const schedule: any = await scheduleService.getScheduleByDoctorId(doctorId);
    if (!schedule) {
      return res.status(404).json({ message: "Schedule not found" });
    }
    const dayOfWeek = new Date(date).getDay();

    const availability = schedule.availability[availabilityData[dayOfWeek]];
    if (!availability.isAvailable) {
      return res
        .status(404)
        .json({ message: "Doctor is not available on this day" });
    }
    const { startTime, endTime, breaks } = availability;
    const timeOffs = schedule.timeOffs.filter(
      (timeOff: {
        startDate: Date;
        endDate: Date;
        isAllDay: any;
        startTime: Date;
        endTime: Date;
      }) => {
        return (
          timeOff.startDate <= date &&
          timeOff.endDate >= date &&
          (timeOff.isAllDay ||
            (timeOff.startTime >= startTime && timeOff.endTime <= endTime))
        );
      }
    );
    const slots = generateSlots(slotTime, startTime, endTime, breaks, timeOffs);
    res.json(slots);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal server error" });
  }
  if (mode == "api") {
    res.status(httpStatus.OK).send({
      data: "",
      message: "pharmacy count succesfully",
      status: httpStatus.OK,
    });
  } else {
    //Web Code Start
    //Web Code End
  }
}

function generateSlots(
  slotTime: number,
  startTime: Date,
  endTime: Date,
  breaks: any[],
  timeOffs: any[]
): Date[] {
  const slots: Date[] = [];
  let currentSlot = startTime;
  while (currentSlot < endTime) {
    const isBreakTime = breaks.some((breakTime) => {
      return (
        currentSlot >= breakTime.startTime && currentSlot < breakTime.endTime
      );
    });
    const isTimeOff = timeOffs.some((timeOff) => {
      return (
        timeOff.isAllDay ||
        (currentSlot >= timeOff.startTime && currentSlot < timeOff.endTime)
      );
    });
    if (!isBreakTime && !isTimeOff) {
      slots.push(currentSlot);
    }
  }
  return slots;
}

export async function getSlotByReDate(req: Request, res: Response) {
  const { mode } = req.params;

  const userId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

  let {
    doctorId,
    date,
    timeSlot,
  }: { date: Date; doctorId: Types.ObjectId; timeSlot: string } = req.body;
  date = new Date(date);
  var slotTime = parseInt(timeSlot);

  try {
    const schedule: any = await scheduleService.getScheduleByDoctorId(doctorId);

    if (!schedule) {
      return res.json({ message: "Schedule not found" });
    }

    let end = new Date(date);
    end.setHours(23, 59, 59);

    let findBookRecord = await scheduleService.findSlotIsBooked(
      doctorId,
      userId,
      date,
      end
    );

    function findSlotIsBooked(start: Date, end: Date) {
      let isBooked = false;
      findBookRecord?.forEach((item: any) => {
        if (
          moment(item.startTime).format("HHmm") < moment(end).format("HHmm") &&
          moment(item.endTime).format("HHmm") > moment(start).format("HHmm")
        ) {
          isBooked = true;
        }
      });

      return isBooked;
    }
    const dayOfWeek = date.getDay(); // 0 (Sunday) through 6 (Saturday)

    const availabilityKey = dayOfWeekToString(dayOfWeek);

    if (!schedule.availability[0][availabilityKey]) {
      return res.json({ message: "Invalid date" });
    }

    const { isAvailable, startTime, endTime, breaks } =
      schedule.availability[0][availabilityKey];

    if (isAvailable == false) {
      return res.json({ message: "Doctor is not available on this date" });
    }

    const dates = startTime;
    const dateString = dates.toISOString();

    const timestamp = dateString;
    const milliseconds = moment.utc(timestamp).valueOf();

    // Convert start time, end time, and break times to milliseconds
    const startMs = startTime.getTime();
    const endMs = endTime.getTime();

    const breakMs = breaks?.map((breakTime: any) => ({
      start: breakTime.startTime.getTime(),
      end: breakTime.endTime.getTime(),
    }));

    // const breakMs:any = [];

    const timeOffs = schedule.timeOffs.filter((timeOff: any) => {
      const timeOffStartDate = moment(timeOff.startDate)
        .startOf("day")
        .valueOf();
      const timeOffEndDate = moment(timeOff.endDate).endOf("day").valueOf();
      const queryDate = moment(date).startOf("day").valueOf();

      return (
        (timeOff.isAllDay &&
          queryDate >= timeOffStartDate &&
          queryDate <= timeOffEndDate) ||
        (!timeOff.isAllDay &&
          moment(timeOff.startDate).utc().toISOString() ===
            moment(date).utc().toISOString() &&
          moment(timeOff.endDate).utc().toISOString() ===
            moment(date).utc().toISOString())
      );
    });

    // Calculate available time slots
    const slotDuration = slotTime * 60000; // Convert minutes to milliseconds
    // const slotBuffer = schedule.slotBuffer * 60000; // Convert minutes to milliseconds
    let slotBuffer = 0;
    const availableSlots = [];
    let slotStart = startMs;
    let slotEnd = slotStart + slotDuration;

    while (slotEnd <= endMs) {
      // Check if slot is within doctor's availability and not during a break
      const isWithinAvailability =
        slotStart >= startMs + slotBuffer &&
        slotEnd <= endMs - slotBuffer &&
        !breakMs.some(
          (breakTime: any) =>
            slotStart < breakTime.end && slotEnd > breakTime.start
        );

      let isAvailable =
        slotStart >= startMs + slotBuffer &&
        slotEnd <= endMs - slotBuffer &&
        !timeOffs.some(
          (timeOff: any) =>
            timeOff.isAllDay ||
            (moment(slotStart).format("HHmm") <
              moment(timeOff.endTime).format("HHmm") &&
              moment(slotEnd).format("HHmm") >
                moment(timeOff.startTime).format("HHmm"))
        );

      if (
        isWithinAvailability &&
        isAvailable &&
        !findSlotIsBooked(slotStart, slotEnd)
      ) {
        availableSlots.push({
          start: new Date(slotStart),
          end: new Date(slotEnd),
        });
      }

      // Move on to next time slot
      slotStart += slotDuration;
      slotEnd += slotDuration;
    }

    if (availableSlots) {
      if (availableSlots[0]) {
        const currentTime = new Date();

        if (currentTime.toDateString() === date.toDateString()) {
          const upcomingSlots = [];

          for (let i = 0; i < availableSlots.length; i++) {
            const slot = availableSlots[i];
            const oldSlot = new Date(slot.start);

            // Extract the time portion of the current time and oldSlot
            const currentTimeTime =
              currentTime.getHours() * 60 + currentTime.getMinutes();

            const oldSlotTime =
              oldSlot.getUTCHours() * 60 + oldSlot.getUTCMinutes();

            if (currentTimeTime < oldSlotTime) {
              upcomingSlots.push(slot);
            }
          }

          return res.json({ availableSlots: upcomingSlots });
        } else {
          // Dates don't match
          return res.json({ availableSlots });
        }
      } else {
        return res.json({ message: "The Doctor is on leave on this day" });
      }
    } else {
      return res.json({ message: "No available slots" });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Internal server error" });
  }
}

function dayOfWeekToString(dayOfWeek: number) {
  const daysOfWeek = [
    "sunday",
    "monday",
    "tuesday",
    "wednesday",
    "thursday",
    "friday",
    "saturday",
  ];
  return daysOfWeek[dayOfWeek];
}
