import mongoose, { Schema, model, Document } from "mongoose";

interface Services {
  durationInMin: number;
  price: number;
}

interface Breaks {
  startTime: Date;
  endTime: Date;
}

interface Availability {
  isAvailable: boolean;
  startTime: Date;
  endTime: Date;
  breaks: Array<Breaks>;
}
interface TimeOffs {
  startDate: Date;
  endDate: Date;
  startTime: Date;
  endTime: Date;
  isAllDay: boolean;
  description: string;
}

export interface Schedule extends Document {
  doctor: mongoose.Types.ObjectId;
  services: Array<Services>;
  availability: {
    monday: Availability;
    tuesday: Availability;
    wednesday: Availability;
    thursday: Availability;
    friday: Availability;
    saturday: Availability;
    sunday: Availability;
  };
  slotBuffer: number;

  timeOffs: Array<TimeOffs>;
}

const availabilitySchema: Schema = new Schema<Availability>(
  {
    isAvailable: mongoose.Schema.Types.Boolean,
    startTime: Date,
    endTime: Date,
    breaks: [{ startTime: Date, endTime: Date }],
  },
  {
    _id: false,
  }
);

const timeOffsSchema: Schema = new Schema({
  startDate: Date,
  endDate: Date,
  startTime: Date,
  endTime: Date,
  isAllDay: mongoose.Schema.Types.Boolean,
  description: String,
});



const scheduleSchema: Schema = new Schema<Schedule>({
  doctor: {
    type: mongoose.Schema.Types.ObjectId,
  },
  services: [
    { durationInMin: Number, price: Number },
    {
      _id: false,
    },
  ],
  availability: [
    {
      monday: availabilitySchema,
      tuesday: availabilitySchema,
      wednesday: availabilitySchema,
      thursday: availabilitySchema,
      friday: availabilitySchema,
      saturday: availabilitySchema,
      sunday: availabilitySchema,
    },
  ],

  timeOffs: [timeOffsSchema, { id: false }],
});

export default model<Schedule>("schedule", scheduleSchema);
