import { Router } from "express";
import * as scheduleController from "./schedule.controller";

const appRouter = Router({
  mergeParams: true,
});

appRouter.route("/count").get(scheduleController.scheduleCount);

appRouter.get("/getschedule", scheduleController.getMySchedule);

appRouter.post("/updateschedule", scheduleController.updateMySchedule);

appRouter
  .route("/add-schedule")
  .get(scheduleController.addSchedule)
  .post(scheduleController.addSchedule);

appRouter
  .route("/add-availability")
  .get(scheduleController.updateAvailabilty)
  .post(scheduleController.updateAvailabilty);

appRouter
  .route("/add-break")
  .get(scheduleController.addBreak)
  .post(scheduleController.addBreak);

appRouter
  .route("/add-timeoff")
  .get(scheduleController.addTimeoff)
  .post(scheduleController.addTimeoff);

appRouter
  .route("/delete-timeoff")
  .get(scheduleController.deleteTimeoff)
  .post(scheduleController.deleteTimeoff);

appRouter
  .route("/get-slot")
  .get(scheduleController.getSlotByReDate)
  .post(scheduleController.getSlotByReDate);

export default appRouter;
