import mongoose, { Document, model, Schema, Types } from "mongoose";

export interface Chat extends Document {
  user1: Types.ObjectId;
  user2: Types.ObjectId;
  date: Date;
  message: Array<Object>;
  isDeleted: Boolean;
}

const messageScahema = new Schema(
  {
    msg: {
      type: String,
    },
    sendBy: {
      type: mongoose.Schema.Types.ObjectId,
    },
    recievedBy: { type: mongoose.Schema.Types.ObjectId },
    date: {
      type: Date,
      default: Date.now(),
    },
  },
  {
    _id: false,
  }
);

const bookingSchema = new Schema<Chat>({
  user1: {
    type: mongoose.Schema.Types.ObjectId,
  },
  user2: {
    type: mongoose.Schema.Types.ObjectId,
  },
  message: [messageScahema],
  isDeleted: {
    type: Boolean,
    default: false,
  },
});

export default model<Chat>("chat", bookingSchema);
