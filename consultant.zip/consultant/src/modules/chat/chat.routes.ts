import { Router } from "express";
import * as chatController from "./chat.controller";
const router: Router = Router();

router.post("/create-chat", chatController.SaveMessage);

router.post("/get-chat", chatController.GetMeessage);

router.post("/get-recieved-chat", chatController.GetRecievedMessage);

router.post("/delete-chat/:id", chatController.deleteChat);

router.post("/update-status", chatController.updateCallStatus);

router.get("/get-consultant", chatController.getDoctor);

export default router;
