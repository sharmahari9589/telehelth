import { Types } from "mongoose";
import bookingModel, { Booking, BookingStatus } from "../booking/booking.model";
import consultantModel, { Consultant } from "../consultant/consultant.model";
import patientModel, { Patient } from "../patient/patient.model";
import pharmacyModel from "../pharmacy/pharmacy.model";
import bcrypt from "bcryptjs";
import ordersModel, { Order } from "../orders/orders.model";
import scheduleModel, { Schedule } from "../schedule/schedule.model";
import slotModel from "../models/slot.model";
import staffModel from "../staff/staff.model";

export async function profileUpdateById(
  consultantId: Types.ObjectId,
  updateBody: any
) {
  return await consultantModel.findByIdAndUpdate(consultantId, updateBody);
}
export async function getMyProfile(consultantId: Types.ObjectId) {
  let data = await consultantModel.findById(consultantId);
  if (data) {
    return data;
  } else {
    return await staffModel.findById(consultantId);
  }
}

export async function updateById(pharmacyId: Types.ObjectId, updateBody: any) {
  return consultantModel.findByIdAndUpdate(pharmacyId, {
    password: updateBody,
  });
}

export async function updateStaffById(
  pharmacyId: Types.ObjectId,
  updateBody: any
) {
  return staffModel.findByIdAndUpdate(pharmacyId, { password: updateBody });
}

export function comparePassword(
  password: string,
  hashpassword: string
): boolean {
  return bcrypt.compareSync(password, hashpassword);
}

export function encryptPassword(password: string) {
  return bcrypt.hashSync(password, 10);
}

export async function getUserByUserID(userId: Types.ObjectId) {
  const user = await consultantModel.findById(userId);
  return user;
}

export async function getStaffByUserID(userId: Types.ObjectId) {
  const user = await staffModel.findById(userId);
  return user;
}

export async function patientManeger(
  consultantId: Types.ObjectId
): Promise<Array<Booking>> {
  return await bookingModel.aggregate([
    {
      $match: {
        doctor: consultantId,
      },
    },
    {
      $lookup: {
        from: "patients",
        localField: "patient",
        foreignField: "_id",
        as: "patient",
      },
    },
    {
      $unwind: {
        path: "$patient",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $sort: {
        date: 1,
      },
    },
  ]);
}
export async function consultantcount(consultantId: Types.ObjectId) {
  return await consultantModel.countDocuments({ doctor: consultantId });
}
export async function patientcount(consultantId: Types.ObjectId) {
  return await bookingModel.aggregate([
    {
      $match: {
        $and: [
          {
            doctor: consultantId,
          },

          {
            status: "completed",
          },
        ],
      },
    },
    {
      $lookup: {
        from: "healthproblems",
        localField: "problem",
        foreignField: "_id",
        as: "problem",
      },
    },
    {
      $unwind: {
        path: "$problem",
        preserveNullAndEmptyArrays: true,
      },
    },
  ]);
}

export async function pharmacycount() {
  return await pharmacyModel.countDocuments();
}

export async function confirmedBookingCount(consultantId: Types.ObjectId) {
  return await bookingModel.aggregate([
    {
      $match: {
        $and: [
          {
            doctor: consultantId,
          },

          {
            status: "accepted",
          },
        ],
      },
    },
  ]);
}

export async function upcomingBookingCount(consultantId: Types.ObjectId) {
  return await bookingModel.aggregate([
    {
      $match: {
        $and: [
          {
            doctor: consultantId,
          },
          {
            isAccepted: false,
          },
          {
            status: "pending",
          },
        ],
      },
    },
  ]);
}
export async function cancelBookingCount(consultantId: Types.ObjectId) {
  return await bookingModel.aggregate([
    {
      $match: {
        $and: [
          {
            doctor: consultantId,
          },

          {
            status: "cancelled",
          },
        ],
      },
    },
  ]);
}

export async function reschduleBookingCount(consultantId: Types.ObjectId) {
  return await bookingModel.aggregate([
    {
      $match: {
        $and: [
          {
            doctor: consultantId,
          },
          {
            status: "reschedule",
          },
        ],
      },
    },
  ]);
}

export async function allAppointmentscount(consultantId: Types.ObjectId) {
  return await bookingModel.countDocuments({
    doctor: consultantId,
  });
}

export async function getFilterPatients(
  consultantId: Types.ObjectId
  
): Promise<Array<Booking>> {
  return await bookingModel.aggregate([
    {
      $match: {
        $and: [
          {
            doctor: consultantId,
          },
          {
            status: {
              $in: ["accepted", "completed"],
            },
          },
        ],
      },
    },
    {
      $lookup: {
        from: "patients",
        localField: "patient",
        foreignField: "_id",
        as: "patient",
      },
    },
    {
      $unwind: {
        path: "$patient",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $sort: {
        date: 1,
      },
    },
  ]);
}

export async function editPatientById(
  bookingId: Types.ObjectId,
  bookingStatus: any
) {
  return await bookingModel.findByIdAndUpdate(bookingId, { ...bookingStatus });
}

export async function updatebooking(
  bookingId: Types.ObjectId,
  status: string
): Promise<Booking | null> {
  return await bookingModel.findByIdAndUpdate(bookingId, { status });
}

export async function getConfirmOrders(
  consultantId: Types.ObjectId,
  bookingId: Types.ObjectId,
  limit: any,
  page: any,
  name: string,
  startDate: string,
  endDate: string
) {
  if (name && startDate == "" && endDate == "") {
    return await bookingModel
      .aggregate([
        {
          $match: {
            $and: [
              {
                doctor: consultantId,
              },
              {
                status: {
                  $in: ["accepted", "reschedule"],
                },
              },
            ],
          },
        },

        {
          $sort: {
            date: -1,
          },
        },
        {
          $match: {
            "bookingFor.patientName": {
              $regex: name,
              $options: "i",
            },
          },
        },

        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit);
  }
  if (startDate && endDate == "" && name == "") {
    return await bookingModel
      .aggregate([
        {
          $match: {
            $and: [
              {
                doctor: consultantId,
              },
              {
                status: {
                  $in: ["accepted", "reschedule"],
                },
              },
            ],
          },
        },

        {
          $sort: {
            date: -1,
          },
        },
        {
          $match: {
            date: { $gte: new Date(startDate) },
          },
        },

        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit);
  }
  if (endDate && startDate == "" && name == "") {
    return await bookingModel.aggregate([
      {
        $match: {
          $and: [
            {
              doctor: consultantId,
            },
            {
              status: {
                $in: ["accepted", "reschedule"],
              },
            },
          ],
        },
      },

      {
        $sort: {
          date: -1,
        },
      },
      {
        $match: {
          date: { $lte: new Date(endDate) },
        },
      },

      {
        $lookup: {
          from: "healthproblems",
          localField: "problem",
          foreignField: "_id",
          as: "problem",
        },
      },
      {
        $unwind: {
          path: "$problem",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "services",
          localField: "service",
          foreignField: "_id",
          as: "service",
        },
      },
      {
        $unwind: {
          path: "$service",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "patients",
          localField: "patient",
          foreignField: "_id",
          as: "patient",
        },
      },
      {
        $unwind: {
          path: "$patient",
          preserveNullAndEmptyArrays: true,
        },
      },
    ]);
  }
  if (startDate && endDate && name == "") {
    return await bookingModel
      .aggregate([
        {
          $match: {
            $and: [
              {
                doctor: consultantId,
              },
              {
                status: {
                  $in: ["accepted", "reschedule"],
                },
              },
            ],
          },
        },

        {
          $sort: {
            date: -1,
          },
        },
        {
          $match: {
            date: {
              $gte: new Date(startDate),
              $lte: new Date(endDate),
            },
          },
        },

        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit);
  }
  if (startDate && endDate == "" && name) {
    return await bookingModel
      .aggregate([
        {
          $match: {
            $and: [
              {
                doctor: consultantId,
              },
              {
                status: {
                  $in: ["accepted", "reschedule"],
                },
              },
            ],
          },
        },

        {
          $sort: {
            date: -1,
          },
        },

        {
          $match: {
            $and: [
              {
                "bookingFor.patientName": {
                  $regex: name,
                  $options: "i",
                },
              },
              {
                date: {
                  $gte: new Date(startDate),
                },
              },
            ],
          },
        },

        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit);
  }
  if (endDate && startDate == "" && name) {
    return await bookingModel
      .aggregate([
        {
          $match: {
            $and: [
              {
                doctor: consultantId,
              },
              {
                status: {
                  $in: ["accepted", "reschedule"],
                },
              },
            ],
          },
        },

        {
          $sort: {
            date: -1,
          },
        },
        {
          $match: {
            $and: [
              {
                "bookingFor.patientName": {
                  $regex: name,
                  $options: "i",
                },
              },
              {
                date: {
                  $lte: new Date(endDate),
                },
              },
            ],
          },
        },

        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit);
  }
  if (endDate && startDate && name) {
    return await bookingModel
      .aggregate([
        {
          $match: {
            $and: [
              {
                doctor: consultantId,
              },
              {
                status: {
                  $in: ["accepted", "reschedule"],
                },
              },
            ],
          },
        },

        {
          $sort: {
            date: -1,
          },
        },
        {
          $match: {
            $and: [
              {
                "bookingFor.patientName": {
                  $regex: name,
                  $options: "i",
                },
              },
              {
                date: {
                  $gte: new Date(startDate),
                  $lte: new Date(endDate),
                },
              },
            ],
          },
        },

        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit);
  } else {
    return await bookingModel.aggregate([
      {
        $match: {
          $and: [
            {
              doctor: consultantId,
            },
            {
              status: {
                $in: ["accepted", "reschedule"],
              },
            },
          ],
        },
      },

      {
        $sort: {
          date: 1,
        },
      },

      {
        $lookup: {
          from: "healthproblems",
          localField: "problem",
          foreignField: "_id",
          as: "problem",
        },
      },
      {
        $unwind: {
          path: "$problem",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "services",
          localField: "service",
          foreignField: "_id",
          as: "service",
        },
      },
      {
        $unwind: {
          path: "$service",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "patients",
          localField: "patient",
          foreignField: "_id",
          as: "patient",
        },
      },
      {
        $unwind: {
          path: "$patient",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $skip: (page - 1) * limit, // Replace `page` and `limit` with your desired values
      },
      {
        $limit: limit, // Replace `limit` with your desired value
      },
    ]);
  }
}

export async function cancelBooking(
  bookingId: Types.ObjectId,
  status: String,
  cancelReason: String
): Promise<Booking | null> {
  return await bookingModel.findByIdAndUpdate(bookingId, {
    status,
    cancelReason,
  });
}

export async function getCancelOredrs(
  consultantId: Types.ObjectId,
  bookingId: Types.ObjectId,
  limit: any,
  page: any,
  name: string,
  startDate: string,
  endDate: string
) {
  if (name && startDate == "" && endDate == "") {
    return await bookingModel
      .aggregate([
        {
          $match: {
            $and: [
              {
                doctor: consultantId,
              },
              {
                status: "cancelled",
              },
            ],
          },
        },
        {
          $sort: {
            date: -1,
          },
        },
        {
          $match: {
            "bookingFor.patientName": {
              $regex: name,
              $options: "i",
            },
          },
        },

        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },

        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
  }
  if (startDate && endDate == "" && name == "") {
    return await bookingModel
      .aggregate([
        {
          $match: {
            $and: [
              {
                doctor: consultantId,
              },
              {
                status: "cancelled",
              },
            ],
          },
        },
        {
          $sort: {
            date: 1,
          },
        },
        {
          $match: {
            date: { $gte: new Date(startDate) },
          },
        },

        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },

        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
  }
  if (endDate && startDate == "" && name == "") {
    return await bookingModel
      .aggregate([
        {
          $match: {
            $and: [
              {
                doctor: consultantId,
              },
              {
                status: "cancelled",
              },
            ],
          },
        },
        {
          $sort: {
            date: -1,
          },
        },
        {
          $match: {
            date: { $lte: new Date(endDate) },
          },
        },

        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },

        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
  }
  if (endDate && startDate && name == "") {
    return await bookingModel
      .aggregate([
        {
          $match: {
            $and: [
              {
                doctor: consultantId,
              },
              {
                status: "cancelled",
              },
            ],
          },
        },
        {
          $sort: {
            date: 1,
          },
        },
        {
          $match: {
            date: {
              $gte: new Date(startDate),
              $lte: new Date(endDate),
            },
          },
        },

        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },

        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
  }
  if (name && startDate && endDate == "") {
    return await bookingModel
      .aggregate([
        {
          $match: {
            $and: [
              {
                doctor: consultantId,
              },
              {
                status: "cancelled",
              },
            ],
          },
        },
        {
          $sort: {
            date: 1,
          },
        },
        {
          $match: {
            $and: [
              {
                "bookingFor.patientName": {
                  $regex: name,
                  $options: "i",
                },
              },
              {
                date: {
                  $gte: new Date(startDate),
                },
              },
            ],
          },
        },

        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },

        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
  }
  if (name && startDate == "" && endDate) {
    return await bookingModel
      .aggregate([
        {
          $match: {
            $and: [
              {
                doctor: consultantId,
              },
              {
                status: "cancelled",
              },
            ],
          },
        },
        {
          $sort: {
            date: -1,
          },
        },
        {
          $match: {
            $and: [
              {
                "bookingFor.patientName": {
                  $regex: name,
                  $options: "i",
                },
              },
              {
                date: {
                  $lte: new Date(endDate),
                },
              },
            ],
          },
        },

        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },

        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
  }
  if (name && startDate && endDate) {
    return await bookingModel
      .aggregate([
        {
          $match: {
            $and: [
              {
                doctor: consultantId,
              },
              {
                status: "cancelled",
              },
            ],
          },
        },
        {
          $sort: {
            date: 1,
          },
        },
        {
          $match: {
            $and: [
              {
                "bookingFor.patientName": {
                  $regex: name,
                  $options: "i",
                },
              },
              {
                date: {
                  $gte: new Date(startDate),
                  $lte: new Date(endDate),
                },
              },
            ],
          },
        },

        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },

        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
  } else {
    return await bookingModel.aggregate([
      {
        $match: {
          $and: [
            {
              doctor: consultantId,
            },
            {
              status: "cancelled",
            },
          ],
        },
      },
      {
        $sort: {
          date: -1,
        },
      },

      {
        $lookup: {
          from: "healthproblems",
          localField: "problem",
          foreignField: "_id",
          as: "problem",
        },
      },
      {
        $unwind: {
          path: "$problem",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "services",
          localField: "service",
          foreignField: "_id",
          as: "service",
        },
      },
      {
        $unwind: {
          path: "$service",
          preserveNullAndEmptyArrays: true,
        },
      },

      {
        $lookup: {
          from: "patients",
          localField: "patient",
          foreignField: "_id",
          as: "patient",
        },
      },
      {
        $unwind: {
          path: "$patient",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $skip: (page - 1) * limit, // Replace `page` and `limit` with your desired values
      },
      {
        $limit: limit, // Replace `limit` with your desired value
      },
    ]);
  }
}

export async function getRescheduleBookings(
  consultantId: Types.ObjectId,
  bookingId: Types.ObjectId,
  limit: any,
  page: any,
  name: string,
  startDate: string,
  endDate: string
) {
  if (name && startDate == "" && endDate == "") {
    return await bookingModel
      .aggregate([
        {
          $match: {
            $and: [
              {
                doctor: consultantId,
              },
              {
                status: "reschedule",
              },
            ],
          },
        },
        {
          $sort: {
            date: -1,
          },
        },
        {
          $match: {
            "bookingFor.patientName": {
              $regex: name,
              $options: "i",
            },
          },
        },

        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
  }
  if (name == "" && startDate && endDate == "") {
    return await bookingModel
      .aggregate([
        {
          $match: {
            $and: [
              {
                doctor: consultantId,
              },
              {
                status: "reschedule",
              },
            ],
          },
        },
        {
          $sort: {
            date: -1,
          },
        },
        {
          $match: {
            date: { $gte: new Date(startDate) },
          },
        },

        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
  }

  if (name == "" && startDate == "" && endDate) {
    return await bookingModel
      .aggregate([
        {
          $match: {
            $and: [
              {
                doctor: consultantId,
              },
              {
                status: "reschedule",
              },
            ],
          },
        },
        {
          $sort: {
            date: -1,
          },
        },
        {
          $match: {
            date: { $lte: new Date(endDate) },
          },
        },

        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
  }

  if (name == "" && startDate && endDate) {
    return await bookingModel
      .aggregate([
        {
          $match: {
            $and: [
              {
                doctor: consultantId,
              },
              {
                status: "reschedule",
              },
            ],
          },
        },
        {
          $sort: {
            date: 1,
          },
        },
        {
          $match: {
            date: {
              $gte: new Date(startDate),

              $lte: new Date(endDate),
            },
          },
        },

        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
  }

  if (name && startDate && endDate == "") {
    return await bookingModel
      .aggregate([
        {
          $match: {
            $and: [
              {
                doctor: consultantId,
              },
              {
                status: "reschedule",
              },
            ],
          },
        },
        {
          $sort: {
            date: 1,
          },
        },
        {
          $match: {
            $and: [
              {
                "bookingFor.patientName": {
                  $regex: name,
                  $options: "i",
                },
              },
              {
                date: {
                  $gte: new Date(startDate),
                },
              },
            ],
          },
        },

        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
  }

  if (name && startDate == "" && endDate) {
    return await bookingModel
      .aggregate([
        {
          $match: {
            $and: [
              {
                doctor: consultantId,
              },
              {
                status: "reschedule",
              },
            ],
          },
        },
        {
          $sort: {
            date: -1,
          },
        },
        {
          $match: {
            $and: [
              {
                "bookingFor.patientName": {
                  $regex: name,
                  $options: "i",
                },
              },
              {
                date: {
                  $lte: new Date(endDate),
                },
              },
            ],
          },
        },

        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
  }

  if (name && startDate && endDate) {
    return await bookingModel
      .aggregate([
        {
          $match: {
            $and: [
              {
                doctor: consultantId,
              },
              {
                status: "reschedule",
              },
            ],
          },
        },
        {
          $sort: {
            date: -1,
          },
        },
        {
          $match: {
            $and: [
              {
                "bookingFor.patientName": {
                  $regex: name,
                  $options: "i",
                },
              },
              {
                date: {
                  $gte: new Date(startDate),
                  $lte: new Date(endDate),
                },
              },
            ],
          },
        },

        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
  } else {
    return await bookingModel
      .aggregate([
        {
          $match: {
            $and: [
              {
                doctor: consultantId,
              },
              {
                status: "reschedule",
              },
            ],
          },
        },
        {
          $sort: {
            date: -1,
          },
        },

        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $skip: (page - 1) * limit, // Replace `page` and `limit` with your desired values
        },
        {
          $limit: limit, // Replace `limit` with your desired value
        },
      ])
      .sort({ createdAt: -1 });
  }

  // .limit(limit)
  // .skip((page - 1) * limit);
}

export async function getManageBooking(
  consultantId: Types.ObjectId,
  limit: any,
  page: any,
  name: string,
  startDate: string,
  endDate: string
) {
  if (name && startDate == "" && endDate == "") {
    return await bookingModel
      .aggregate([
        {
          $match: {
            $and: [
              {
                doctor: consultantId,
              },
              {
                status: {
                  $in: ["accepted", "reschedule"],
                },
              },
            ],
          },
        },
        {
          $sort: {
            date: -1,
          },
        },
        {
          $match: {
            "bookingFor.patientName": {
              $regex: name,
              $options: "i",
            },
          },
        },

        {
          $lookup: {
            from: "doctors",
            localField: "doctor",
            foreignField: "_id",
            as: "doctor",
          },
        },
        {
          $unwind: {
            path: "$doctor",
            preserveNullAndEmptyArrays: true,
          },
        },

        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "pharmacies",
            localField: "pharmacy",
            foreignField: "_id",
            as: "pharmacy",
          },
        },
        {
          $unwind: {
            path: "$pharmacy",
            preserveNullAndEmptyArrays: true,
          },
        },

        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "orders",
            localField: "_id",
            foreignField: "booking",
            as: "order",
          },
        },
        {
          $unwind: {
            path: "$order",
            preserveNullAndEmptyArrays: true,
          },
        },

        {
          $lookup: {
            from: "emailmanagements",
            localField: "doctor._id",
            foreignField: "userId",
            as: "emailKey",
          },
        },
        {
          $unwind: {
            path: "$emailKey",
            preserveNullAndEmptyArrays: true,
          },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
  }

  if (name == "" && startDate && endDate == "") {
    return await bookingModel
      .aggregate([
        {
          $match: {
            $and: [
              {
                doctor: consultantId,
              },
              {
                status: {
                  $in: ["accepted", "reschedule"],
                },
              },
            ],
          },
        },
        {
          $sort: {
            date: -1,
          },
        },
        {
          $match: {
            date: {
              $gte: new Date(startDate),
            },
          },
        },

        {
          $lookup: {
            from: "doctors",
            localField: "doctor",
            foreignField: "_id",
            as: "doctor",
          },
        },
        {
          $unwind: {
            path: "$doctor",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "pharmacies",
            localField: "pharmacy",
            foreignField: "_id",
            as: "pharmacy",
          },
        },
        {
          $unwind: {
            path: "$pharmacy",
            preserveNullAndEmptyArrays: true,
          },
        },

        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },

        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "orders",
            localField: "_id",
            foreignField: "booking",
            as: "order",
          },
        },
        {
          $unwind: {
            path: "$order",
            preserveNullAndEmptyArrays: true,
          },
        },

        {
          $lookup: {
            from: "emailmanagements",
            localField: "doctor._id",
            foreignField: "userId",
            as: "emailKey",
          },
        },
        {
          $unwind: {
            path: "$emailKey",
            preserveNullAndEmptyArrays: true,
          },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
  }

  if (name == "" && startDate == "" && endDate) {
    return await bookingModel
      .aggregate([
        {
          $match: {
            $and: [
              {
                doctor: consultantId,
              },
              {
                status: {
                  $in: ["accepted", "reschedule"],
                },
              },
            ],
          },
        },
        {
          $sort: {
            date: -1,
          },
        },
        {
          $match: {
            date: {
              $lte: new Date(endDate),
            },
          },
        },

        {
          $lookup: {
            from: "doctors",
            localField: "doctor",
            foreignField: "_id",
            as: "doctor",
          },
        },
        {
          $unwind: {
            path: "$doctor",
            preserveNullAndEmptyArrays: true,
          },
        },

        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "pharmacies",
            localField: "pharmacy",
            foreignField: "_id",
            as: "pharmacy",
          },
        },
        {
          $unwind: {
            path: "$pharmacy",
            preserveNullAndEmptyArrays: true,
          },
        },

        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "orders",
            localField: "_id",
            foreignField: "booking",
            as: "order",
          },
        },
        {
          $unwind: {
            path: "$order",
            preserveNullAndEmptyArrays: true,
          },
        },

        {
          $lookup: {
            from: "emailmanagements",
            localField: "doctor._id",
            foreignField: "userId",
            as: "emailKey",
          },
        },
        {
          $unwind: {
            path: "$emailKey",
            preserveNullAndEmptyArrays: true,
          },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
  }

  if (name && startDate && endDate) {
    return await bookingModel.aggregate([
      {
        $match: {
          $and: [
            {
              doctor: consultantId,
            },
            {
              status: {
                $in: ["accepted", "reschedule"],
              },
            },
          ],
        },
      },
      {
        $sort: {
          date: -1,
        },
      },
      {
        $match: {
          $and: [
            {
              "bookingFor.patientName": {
                $regex: name,
                $options: "i",
              },
            },
            {
              date: {
                $gte: new Date(startDate),
                $lte: new Date(endDate),
              },
            },
          ],
        },
      },

      {
        $lookup: {
          from: "doctors",
          localField: "doctor",
          foreignField: "_id",
          as: "doctor",
        },
      },
      {
        $unwind: {
          path: "$doctor",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "pharmacies",
          localField: "pharmacy",
          foreignField: "_id",
          as: "pharmacy",
        },
      },
      {
        $unwind: {
          path: "$pharmacy",
          preserveNullAndEmptyArrays: true,
        },
      },

      {
        $lookup: {
          from: "healthproblems",
          localField: "problem",
          foreignField: "_id",
          as: "problem",
        },
      },
      {
        $unwind: {
          path: "$problem",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "services",
          localField: "service",
          foreignField: "_id",
          as: "service",
        },
      },
      {
        $unwind: {
          path: "$service",
          preserveNullAndEmptyArrays: true,
        },
      },

      {
        $lookup: {
          from: "patients",
          localField: "patient",
          foreignField: "_id",
          as: "patient",
        },
      },
      {
        $unwind: {
          path: "$patient",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "orders",
          localField: "_id",
          foreignField: "booking",
          as: "order",
        },
      },
      {
        $unwind: {
          path: "$order",
          preserveNullAndEmptyArrays: true,
        },
      },

      {
        $lookup: {
          from: "emailmanagements",
          localField: "doctor._id",
          foreignField: "userId",
          as: "emailKey",
        },
      },
      {
        $unwind: {
          path: "$emailKey",
          preserveNullAndEmptyArrays: true,
        },
      },
    ]);
  }

  if (name && startDate && endDate == "") {
    return await bookingModel
      .aggregate([
        {
          $match: {
            $and: [
              {
                doctor: consultantId,
              },
              {
                status: {
                  $in: ["accepted", "reschedule"],
                },
              },
            ],
          },
        },
        {
          $sort: {
            date: 1,
          },
        },
        {
          $match: {
            $and: [
              {
                "bookingFor.patientName": {
                  $regex: name,
                  $options: "i",
                },
              },
              {
                date: {
                  $gte: new Date(startDate),
                },
              },
            ],
          },
        },

        {
          $lookup: {
            from: "doctors",
            localField: "doctor",
            foreignField: "_id",
            as: "doctor",
          },
        },
        {
          $unwind: {
            path: "$doctor",
            preserveNullAndEmptyArrays: true,
          },
        },

        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "pharmacies",
            localField: "pharmacy",
            foreignField: "_id",
            as: "pharmacy",
          },
        },
        {
          $unwind: {
            path: "$pharmacy",
            preserveNullAndEmptyArrays: true,
          },
        },

        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "orders",
            localField: "_id",
            foreignField: "booking",
            as: "order",
          },
        },
        {
          $unwind: {
            path: "$order",
            preserveNullAndEmptyArrays: true,
          },
        },

        {
          $lookup: {
            from: "emailmanagements",
            localField: "doctor._id",
            foreignField: "userId",
            as: "emailKey",
          },
        },
        {
          $unwind: {
            path: "$emailKey",
            preserveNullAndEmptyArrays: true,
          },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
  }

  if (name && startDate == "" && endDate) {
    return await bookingModel
      .aggregate([
        {
          $match: {
            $and: [
              {
                doctor: consultantId,
              },
              {
                status: {
                  $in: ["accepted", "reschedule"],
                },
              },
            ],
          },
        },
        {
          $sort: {
            date: 1,
          },
        },
        {
          $match: {
            $and: [
              {
                "bookingFor.patientName": {
                  $regex: name,
                  $options: "i",
                },
              },
              {
                date: {
                  $lte: new Date(endDate),
                },
              },
            ],
          },
        },

        {
          $lookup: {
            from: "doctors",
            localField: "doctor",
            foreignField: "_id",
            as: "doctor",
          },
        },
        {
          $unwind: {
            path: "$doctor",
            preserveNullAndEmptyArrays: true,
          },
        },

        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "pharmacies",
            localField: "pharmacy",
            foreignField: "_id",
            as: "pharmacy",
          },
        },
        {
          $unwind: {
            path: "$pharmacy",
            preserveNullAndEmptyArrays: true,
          },
        },

        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "orders",
            localField: "_id",
            foreignField: "booking",
            as: "order",
          },
        },
        {
          $unwind: {
            path: "$order",
            preserveNullAndEmptyArrays: true,
          },
        },

        {
          $lookup: {
            from: "emailmanagements",
            localField: "doctor._id",
            foreignField: "userId",
            as: "emailKey",
          },
        },
        {
          $unwind: {
            path: "$emailKey",
            preserveNullAndEmptyArrays: true,
          },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
  }

  if (name == "" && startDate && endDate) {
    return await bookingModel
      .aggregate([
        {
          $match: {
            $and: [
              {
                doctor: consultantId,
              },
              {
                status: {
                  $in: ["accepted", "reschedule"],
                },
              },
            ],
          },
        },
        {
          $sort: {
            date: 1,
          },
        },
        {
          $match: {
            date: {
              $gte: new Date(startDate),
              $lte: new Date(endDate),
            },
          },
        },

        {
          $lookup: {
            from: "doctors",
            localField: "doctor",
            foreignField: "_id",
            as: "doctor",
          },
        },
        {
          $unwind: {
            path: "$doctor",
            preserveNullAndEmptyArrays: true,
          },
        },

        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },

        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "orders",
            localField: "_id",
            foreignField: "booking",
            as: "order",
          },
        },
        {
          $unwind: {
            path: "$order",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "pharmacies",
            localField: "pharmacy",
            foreignField: "_id",
            as: "pharmacy",
          },
        },
        {
          $unwind: {
            path: "$pharmacy",
            preserveNullAndEmptyArrays: true,
          },
        },

        {
          $lookup: {
            from: "emailmanagements",
            localField: "doctor._id",
            foreignField: "userId",
            as: "emailKey",
          },
        },
        {
          $unwind: {
            path: "$emailKey",
            preserveNullAndEmptyArrays: true,
          },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
  } else {
    return await bookingModel
      .aggregate([
        {
          $match: {
            $and: [
              {
                doctor: consultantId,
              },
              {
                status: {
                  $in: ["accepted", "reschedule"],
                },
              },
            ],
          },
        },
        {
          $sort: {
            date: -1,
          },
        },

        {
          $lookup: {
            from: "doctors",
            localField: "doctor",
            foreignField: "_id",
            as: "doctor",
          },
        },
        {
          $unwind: {
            path: "$doctor",
            preserveNullAndEmptyArrays: true,
          },
        },

        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },

        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "pharmacies",
            localField: "pharmacy",
            foreignField: "_id",
            as: "pharmacy",
          },
        },
        {
          $unwind: {
            path: "$pharmacy",
            preserveNullAndEmptyArrays: true,
          },
        },

        {
          $lookup: {
            from: "orders",
            localField: "_id",
            foreignField: "booking",
            as: "order",
          },
        },
        {
          $unwind: {
            path: "$order",
            preserveNullAndEmptyArrays: true,
          },
        },

        {
          $lookup: {
            from: "emailmanagements",
            localField: "doctor._id",
            foreignField: "userId",
            as: "emailKey",
          },
        },
        {
          $unwind: {
            path: "$emailKey",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $skip: (page - 1) * limit, // Replace `page` and `limit` with your desired values
        },
        {
          $limit: limit, // Replace `limit` with your desired value
        },
      ])
      .sort({ createdAt: -1 });
  }
}

export async function editPrescription(consultantId: Types.ObjectId) {
  return await ordersModel.aggregate([
    {
      $match: {
        consultant: consultantId,
      },
    },
    {
      $lookup: {
        from: "bookings",
        localField: "booking",
        foreignField: "_id",
        as: "booking",
      },
    },
    {
      $unwind: {
        path: "$booking",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $match: {
        "booking.status": "accepted",
      },
    },
    {
      $lookup: {
        from: "doctors",
        localField: "consultant",
        foreignField: "_id",
        as: "doctor",
      },
    },
    {
      $unwind: {
        path: "$doctor",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $lookup: {
        from: "healthproblems",
        localField: "problem",
        foreignField: "_id",
        as: "problem",
      },
    },
    {
      $unwind: {
        path: "$problem",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $lookup: {
        from: "patients",
        localField: "patient",
        foreignField: "_id",
        as: "patient",
      },
    },
    {
      $unwind: {
        path: "$patient",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $unwind: {
        path: "$prescription",
        preserveNullAndEmptyArrays: true,
      },
    },
  ]);
}

export async function rescheduleBookingById(
  bookingId: Types.ObjectId,
  rescheduleDto: any,
  status: String,
  previousdata: any
) {
  return await bookingModel.findByIdAndUpdate(bookingId, {
    ...rescheduleDto,
    status,
    $push: { reschedule: previousdata },
  });
}

export async function acceptbooking(
  bookingId: Types.ObjectId,
  status: String
): Promise<Booking | null> {
  return await bookingModel.findByIdAndUpdate(bookingId, { status });
}

export async function getAcceptedBooking(
  consultantId: Types.ObjectId,

  limit: any,
  page: any,
  name: string,
  startDate: string,
  endDate: string
) {
  if (name && startDate == "" && endDate == "") {
    return await bookingModel
      .aggregate([
        {
          $match: {
            doctor: consultantId,
          },
        },
        {
          $match: {
            status: "completed",
          },
        },
        {
          $match: {
            "bookingFor.patientName": {
              $regex: name,
              $options: "i",
            },
          },
        },

        {
          $lookup: {
            from: "orders",
            localField: "_id",
            foreignField: "booking",
            as: "booking",
          },
        },
        {
          $unwind: {
            path: "$booking",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $unwind: {
            path: "$booking.prescription",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "doctor",
            foreignField: "_id",
            as: "consultant",
          },
        },
        {
          $unwind: {
            path: "$consultant",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $sort: { date: -1 },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
  }

  if (name == "" && startDate && endDate == "") {
    return await bookingModel
      .aggregate([
        {
          $match: {
            doctor: consultantId,
          },
        },
        {
          $match: {
            status: "completed",
          },
        },
        {
          $match: {
            date: {
              $gte: new Date(startDate),
            },
          },
        },

        {
          $lookup: {
            from: "orders",
            localField: "_id",
            foreignField: "booking",
            as: "booking",
          },
        },
        {
          $unwind: {
            path: "$booking",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $unwind: {
            path: "$booking.prescription",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "doctor",
            foreignField: "_id",
            as: "consultant",
          },
        },
        {
          $unwind: {
            path: "$consultant",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $sort: { date: -1 },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
  }

  if (name == "" && startDate == "" && endDate) {
    return await bookingModel
      .aggregate([
        {
          $match: {
            doctor: consultantId,
          },
        },
        {
          $match: {
            status: "completed",
          },
        },
        {
          $match: {
            date: {
              $lte: new Date(endDate),
            },
          },
        },

        {
          $lookup: {
            from: "orders",
            localField: "_id",
            foreignField: "booking",
            as: "booking",
          },
        },
        {
          $unwind: {
            path: "$booking",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $unwind: {
            path: "$booking.prescription",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "doctor",
            foreignField: "_id",
            as: "consultant",
          },
        },
        {
          $unwind: {
            path: "$consultant",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $sort: { date: -1 },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
  }

  if (name == "" && startDate && endDate) {
    return await bookingModel
      .aggregate([
        {
          $match: {
            doctor: consultantId,
          },
        },
        {
          $match: {
            status: "completed",
          },
        },
        {
          $match: {
            date: {
              $gte: new Date(startDate),
              $lte: new Date(endDate),
            },
          },
        },

        {
          $lookup: {
            from: "orders",
            localField: "_id",
            foreignField: "booking",
            as: "booking",
          },
        },
        {
          $unwind: {
            path: "$booking",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $unwind: {
            path: "$booking.prescription",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "doctor",
            foreignField: "_id",
            as: "consultant",
          },
        },
        {
          $unwind: {
            path: "$consultant",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $sort: { date: -1 },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
  }

  if (name && startDate && endDate) {
    return await bookingModel
      .aggregate([
        {
          $match: {
            doctor: consultantId,
          },
        },
        {
          $match: {
            status: "completed",
          },
        },
        {
          $match: {
            $and: [
              {
                "bookingFor.patientName": {
                  $regex: name,
                  $options: "i",
                },
              },
              {
                date: {
                  $gte: new Date(startDate),
                  $lte: new Date(endDate),
                },
              },
            ],
          },
        },

        {
          $lookup: {
            from: "orders",
            localField: "_id",
            foreignField: "booking",
            as: "booking",
          },
        },
        {
          $unwind: {
            path: "$booking",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $unwind: {
            path: "$booking.prescription",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "doctor",
            foreignField: "_id",
            as: "consultant",
          },
        },
        {
          $unwind: {
            path: "$consultant",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $sort: { date: -1 },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
  }
  if (name && startDate && endDate == "") {
    return await bookingModel
      .aggregate([
        {
          $match: {
            doctor: consultantId,
          },
        },
        {
          $match: {
            status: "completed",
          },
        },
        {
          $match: {
            $and: [
              {
                "bookingFor.patientName": {
                  $regex: name,
                  $options: "i",
                },
              },
              {
                date: {
                  $gte: new Date(startDate),
                },
              },
            ],
          },
        },

        {
          $lookup: {
            from: "orders",
            localField: "_id",
            foreignField: "booking",
            as: "booking",
          },
        },
        {
          $unwind: {
            path: "$booking",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $unwind: {
            path: "$booking.prescription",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "doctor",
            foreignField: "_id",
            as: "consultant",
          },
        },
        {
          $unwind: {
            path: "$consultant",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $sort: { date: -1 },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
  }

  if (name && startDate == "" && endDate) {
    return await bookingModel
      .aggregate([
        {
          $match: {
            doctor: consultantId,
          },
        },
        {
          $match: {
            status: "completed",
          },
        },
        {
          $match: {
            $and: [
              {
                "bookingFor.patientName": {
                  $regex: name,
                  $options: "i",
                },
              },
              {
                date: {
                  $lte: new Date(endDate),
                },
              },
            ],
          },
        },

        {
          $lookup: {
            from: "orders",
            localField: "_id",
            foreignField: "booking",
            as: "booking",
          },
        },
        {
          $unwind: {
            path: "$booking",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $unwind: {
            path: "$booking.prescription",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "patients",
            localField: "patient",
            foreignField: "_id",
            as: "patient",
          },
        },
        {
          $unwind: {
            path: "$patient",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "doctors",
            localField: "doctor",
            foreignField: "_id",
            as: "consultant",
          },
        },
        {
          $unwind: {
            path: "$consultant",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "healthproblems",
            localField: "problem",
            foreignField: "_id",
            as: "problem",
          },
        },
        {
          $unwind: {
            path: "$problem",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "services",
            localField: "service",
            foreignField: "_id",
            as: "service",
          },
        },
        {
          $unwind: {
            path: "$service",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $sort: { date: -1 },
        },
      ])
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });
  } else {
    return await bookingModel.aggregate([
      {
        $match: {
          doctor: consultantId,
        },
      },
      {
        $match: {
          status: "completed",
        },
      },
      {
        $lookup: {
          from: "orders",
          localField: "_id",
          foreignField: "booking",
          as: "booking",
        },
      },
      {
        $unwind: {
          path: "$booking",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $unwind: {
          path: "$booking.prescription",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "patients",
          localField: "patient",
          foreignField: "_id",
          as: "patient",
        },
      },
      {
        $unwind: {
          path: "$patient",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "doctors",
          localField: "doctor",
          foreignField: "_id",
          as: "consultant",
        },
      },
      {
        $unwind: {
          path: "$consultant",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "healthproblems",
          localField: "problem",
          foreignField: "_id",
          as: "problem",
        },
      },
      {
        $unwind: {
          path: "$problem",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "services",
          localField: "service",
          foreignField: "_id",
          as: "service",
        },
      },
      {
        $unwind: {
          path: "$service",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $sort: { date: -1 },
      },
      {
        $skip: (page - 1) * limit, // Replace `page` and `limit` with your desired values
      },
      {
        $limit: limit, // Replace `limit` with your desired value
      },
    ]);
  }
}

export async function rescheduleBooking(
  bookingId: Types.ObjectId,
  status: String,
  bookingStatus: any
) {
  return await bookingModel.findByIdAndUpdate(bookingId, {
    status,
    ...bookingStatus,
  });
}

export async function getBookingDetail(consultantId: Types.ObjectId) {
  return await bookingModel.aggregate([
    {
      $match: {
        _id: consultantId,
      },
    },

    {
      $lookup: {
        from: "orders",
        localField: "_id",
        foreignField: "booking",
        as: "booking",
      },
    },
    {
      $unwind: {
        path: "$booking",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $unwind: {
        path: "$booking.prescription",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $lookup: {
        from: "patients",
        localField: "patient",
        foreignField: "_id",
        as: "patient",
      },
    },
    {
      $unwind: {
        path: "$patient",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $lookup: {
        from: "doctors",
        localField: "doctor",
        foreignField: "_id",
        as: "consultant",
      },
    },
    {
      $unwind: {
        path: "$consultant",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $lookup: {
        from: "healthproblems",
        localField: "problem",
        foreignField: "_id",
        as: "problem",
      },
    },
    {
      $unwind: {
        path: "$problem",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $lookup: {
        from: "services",
        localField: "service",
        foreignField: "_id",
        as: "service",
      },
    },
    {
      $unwind: {
        path: "$service",
        preserveNullAndEmptyArrays: true,
      },
    },
  ]);
}

export async function updatePrescription(bookingId: Types.ObjectId, data: any) {
  return await ordersModel.findByIdAndUpdate(bookingId, {
    $set: { prescription: data },
  });
}

export async function getScheduleByBookingId(
  bookingId: Types.ObjectId
): Promise<Booking | null> {
  return await ordersModel.findOne({ booking: bookingId });
}

export async function bookimgGetById(_id: Types.ObjectId) {
  return await bookingModel.find({ doctor: _id, status: "accepted" });
}

export async function filterData(
  consultantId: Types.ObjectId,
  search: String,
  startDate: Date,
  endDate: Date
) {
  return await bookingModel.aggregate([
    {
      $match: {
        $and: [
          {
            doctor: consultantId,
          },
          {
            isAccepted: true,
          },
          {
            status: {
              $in: ["pending", "reschedule"],
            },
          },
        ],
      },
    },
    {
      $sort: {
        date: 1,
      },
    },
    {
      $lookup: {
        from: "patients",
        localField: "patient",
        foreignField: "_id",
        as: "patient",
      },
    },
    {
      $unwind: {
        path: "$patient",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $match: {
        $or: [
          {
            "patient.firstName": {
              $regex: search,
              $options: "i",
            },
          },
          {
            createdAt: {
              $gte: startDate,
              $lte: endDate,
            },
          },
        ],
      },
    },
  ]);
}

export async function findBookingById(bookingId: Types.ObjectId) {
  return await bookingModel.findById(bookingId);
}

export async function getNewBooking(
  _id: Types.ObjectId,
  limit: number,
  page: number
) {
  return await bookingModel
    .findById({
      _id,
      status: "completed",
    })

    .populate({ path: "doctor", model: consultantModel })
    .populate({ path: "patient", model: patientModel })
    .limit(limit)
    .skip((page - 1) * limit);
}

export async function createOrder(createOrderDto: any): Promise<Order> {
  return await ordersModel.create(createOrderDto);
}

export async function getMySchedule(doctorId: Types.ObjectId) {
  return await scheduleModel.aggregate([
    {
      $match: {
        doctor: doctorId,
      },
    },
  ]);
}

export async function acceptedBooking(
  consultantId: Types.ObjectId,

  limit: number,
  page: number
) {
  return await ordersModel.aggregate([
    {
      $match: {
        consultant: consultantId,
      },
    },
    {
      $lookup: {
        from: "bookings",
        localField: "booking",
        foreignField: "_id",
        as: "booking",
      },
    },
    {
      $unwind: {
        path: "$booking",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $match: {
        "booking.status": "completed",
      },
    },
    {
      $lookup: {
        from: "healthproblems",
        localField: "problem",
        foreignField: "_id",
        as: "problem",
      },
    },
    {
      $unwind: {
        path: "$problem",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $lookup: {
        from: "patients",
        localField: "patient",
        foreignField: "_id",
        as: "patient",
      },
    },
    {
      $unwind: {
        path: "$patient",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $sort: {
        "booking.date": 1,
      },
    },
    {
      $unwind: {
        path: "$prescription",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $lookup: {
        from: "doctors",
        localField: "consultant",
        foreignField: "_id",
        as: "consultant",
      },
    },
    {
      $unwind: {
        path: "$consultant",
        preserveNullAndEmptyArrays: true,
      },
    },
  ]);
}

export async function bookingGetById(_id: Types.ObjectId, id: Types.ObjectId) {
  var currentTime = new Date();

  // Add 5.5 hours (in milliseconds)
  var addedTime = currentTime.getTime() + 3.5 * 60 * 60 * 1000;

  // Create a new Date object with the added time
  var newTime = new Date(addedTime);

  var plusTime = currentTime.getTime() + 6.5 * 60 * 60 * 1000;
  var addTime = new Date(plusTime);

  return await bookingModel.aggregate([
    {
      $match: {
        doctor: _id,
      },
    },
    {
      $match: {
        patient: id,
      },
    },
    {
      $match: {
        status: {
          $in: ["reschedule", "accepted"],
        },
        startTime: { $gte: newTime, $lte: addTime },
      },
    },
    {
      $sort: { createdAt: 1 },
    },
  ]);
}

export async function upComingBooking(_id: Types.ObjectId, id: Types.ObjectId) {
  var currentTime = new Date();

  // Add 5.5 hours (in milliseconds)
  var addedTime = currentTime.getTime() + 3.5 * 60 * 60 * 1000;

  // Create a new Date object with the added time
  var newTime = new Date(addedTime);

  var plusTime = currentTime.getTime() + 6.5 * 60 * 60 * 1000;
  var addTime = new Date(plusTime);

  return await bookingModel.aggregate([
    {
      $match: {
        doctor: _id,
      },
    },
    {
      $match: {
        patient: id,
      },
    },
    {
      $match: {
        status: {
          $in: ["reschedule", "accepted"],
        },
        startTime: { $gte: newTime },
      },
    },
    {
      $sort: { createdAt: 1 },
    },
  ]);
}

export async function myBooking(_id: Types.ObjectId) {
  const data = await bookingModel.aggregate([
    {
      $match: {
        doctor: _id,
      },
    },
  ]);

  const loopData: any = data.map((a) => {
    return a.status;
  });

  if (loopData == "completed") {
    return await bookingModel.aggregate([
      {
        $match: {
          doctor: _id,
        },
      },
      {
        $match: {
          status: "completed",
        },
      },
      {
        $lookup: {
          from: "patients",
          localField: "patient",
          foreignField: "_id",
          as: "patient",
        },
      },
      {
        $unwind: {
          path: "$patient",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $sort: { createdAt: -1 },
      },
    ]);
  } else {
    const a = new Date().getTime() + 5.5 * 60 * 60 * 1000;

    const d = new Date(a);

    const t = d.getTime() - 2 * 60 * 60 * 1000;

    const q = new Date(t);

    return await bookingModel.aggregate([
      {
        $match: {
          doctor: _id,
        },
      },
      {
        $match: {
          $and: [
            {
              status: {
                $in: ["reschedule", "accepted","completed"],
              },
            },
            
          ],
        },
      },
      {
        $lookup: {
          from: "patients",
          localField: "patient",
          foreignField: "_id",
          as: "patient",
        },
      },
      {
        $unwind: {
          path: "$patient",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $sort: { createdAt: -1 },
      },
    ]);
  }
}
export async function myUpcomingBooking(_id: Types.ObjectId) {
  // Get the current time
  var currentTime = new Date();

  // Add 5.5 hours (in milliseconds)
  var addedTime = currentTime.getTime() + 3.5 * 60 * 60 * 1000;

  // Create a new Date object with the added time
  var newTime = new Date(addedTime);

  

  return await bookingModel.aggregate([
    {
      $match: {
        doctor: _id,
      },
    },
    {
      $match: {
        status: {$in:["accepted","reschedule"]},
        startTime: { $gte: newTime },
      },
    },
    {
      $lookup: {
        from: "patients",
        localField: "patient",
        foreignField: "_id",
        as: "patient",
      },
    },
    {
      $unwind: {
        path: "$patient",
        preserveNullAndEmptyArrays: true,
      },
    },

    {
      $lookup: {
        from: "chats",
        let: { patientId: "$patient._id", chatId: _id },
        pipeline: [
          {
            $match: {
              $expr: {
                $or: [
                  {
                    $and: [
                      { $eq: ["$user1", "$$chatId"] },
                      { $eq: ["$user2", "$$patientId"] }
                    ]
                  },
                  {
                    $and: [
                      { $eq: ["$user1", "$$patientId"] },
                      { $eq: ["$user2", "$$chatId"] }
                    ]
                  }
                ]
              }
            }
          }
        ],
        as: "chat"
      }
    },
    {
      $unwind: {
        path: "$chat",
        preserveNullAndEmptyArrays: true,
      },
    },
        



    // {
    //   $lookup: {
    //     from: "chats",
    //     localField: "patient._id",
    //     foreignField: "user2",
    //     as: "chat1",
    //   },
    // },
    // {
    //   $unwind: {
    //     path: "$chat1",
    //     preserveNullAndEmptyArrays: true,
    //   },
    // },


    {
      $sort: { startTime: 1 },
    },
  ]);
}

export async function pastBookings(patientId: any) {
  return await ordersModel.aggregate([
    {
      $match: {
        patient: patientId,
      },
    },
    {
      $lookup: {
        from: "patients",
        localField: "patient",
        foreignField: "_id",
        as: "patient",
      },
    },
    {
      $unwind: {
        path: "$patient",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $lookup: {
        from: "doctors",
        localField: "consultant",
        foreignField: "_id",
        as: "doctor",
      },
    },
    {
      $unwind: {
        path: "$doctor",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $lookup: {
        from: "healthproblems",
        localField: "problem",
        foreignField: "_id",
        as: "problem",
      },
    },
    {
      $unwind: {
        path: "$problem",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $lookup: {
        from: "bookings",
        localField: "booking",
        foreignField: "_id",
        as: "booking",
      },
    },
    {
      $unwind: {
        path: "$booking",
        preserveNullAndEmptyArrays: true,
      },
    },
  ]);
}

export async function pastPrescription(orderId: Types.ObjectId) {
  return await ordersModel.aggregate([
    {
      $match: {
        _id: orderId,
      },
    },
    {
      $lookup: {
        from: "patients",
        localField: "patient",
        foreignField: "_id",
        as: "patient",
      },
    },
    {
      $unwind: {
        path: "$patient",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $lookup: {
        from: "doctors",
        localField: "consultant",
        foreignField: "_id",
        as: "doctor",
      },
    },
    {
      $unwind: {
        path: "$doctor",
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $lookup: {
        from: "healthproblems",
        localField: "problem",
        foreignField: "_id",
        as: "problem",
      },
    },
    {
      $unwind: {
        path: "$problem",
        preserveNullAndEmptyArrays: true,
      },
    },
  ]);
}

export async function bookingupdateById(
  bookingId: Types.ObjectId,
  rescheduleDto: any,
  status: String,
  previousdata: any
) {
  return await bookingModel.findByIdAndUpdate(bookingId, {
    ...rescheduleDto,
    status,
    $push: { reschedule: previousdata },
  });
}

export async function getPharmacyOrders(
  pharmacyId: Types.ObjectId,
  limit: any,
  page: any
) {
  return await ordersModel
    .aggregate([
      {
        $match: {
          pharmacy: pharmacyId,
          orderStatus: "pending",
        },
      },
      {
        $lookup: {
          from: "bookings",
          localField: "booking",
          foreignField: "_id",
          as: "booking",
        },
      },
      {
        $unwind: {
          path: "$booking",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "healthproblems",
          localField: "problem",
          foreignField: "_id",
          as: "problem",
        },
      },
      {
        $unwind: {
          path: "$problem",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "patients",
          localField: "patient",
          foreignField: "_id",
          as: "patient",
        },
      },
      {
        $unwind: {
          path: "$patient",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "doctors",
          localField: "consultant",
          foreignField: "_id",
          as: "consultant",
        },
      },
      {
        $unwind: {
          path: "$consultant",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $unwind: {
          path: "$prescription",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $sort: {
          "booking.date": 1,
        },
      },
    ])
    .skip(limit * page - limit);
}

export async function orderStatus(bookingId: Types.ObjectId) {
  return await bookingModel.aggregate([
    {
      $match: {
        _id: bookingId,
      },
    },
    {
      $lookup: {
        from: "orders",
        localField: "_id",
        foreignField: "booking",
        as: "orders",
      },
    },
  ]);
}


export async function updateBookings(consultantId:Types.ObjectId) {

  return await bookingModel.aggregate([
    {
      $match: {
        $and: [
          {
            doctor: consultantId,
          },
          {
            status: {
              $in: ["accepted", "reschedule"],
            },
          },
        ],
      },
    },
  ])
  
}