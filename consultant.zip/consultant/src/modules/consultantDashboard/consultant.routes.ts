import { Router } from "express";
import * as consultantController from "./consultant.controller";
import verify from "../../middleware/jwtAuth";

const appRouter: Router = Router({
  mergeParams: true,
});
appRouter.get("/chat", consultantController.chat);
appRouter.post("/chat", consultantController.chat);

appRouter.get("/upcomingchat", consultantController.upcomigChat);

appRouter.get("/", verify, consultantController.consultantDashboard);
appRouter
  .route("/managepatient")
  .get(consultantController.managePatient)
  .post(consultantController.managePatient);

appRouter.post("/filter", consultantController.managePatientBySerch);

appRouter
  .route("/editpatient/:id")
  .get(consultantController.editPatient)
  .post(consultantController.editPatient);

appRouter.post("/getpasthistory/:id", consultantController.pastHistory);
appRouter.get("/getpasthistory/:id", consultantController.pastHistory);

appRouter.get("/confirmedBooking", consultantController.confirmedAllBooking);

appRouter
  .route("/reschedule-date-and-time")
  .get(consultantController.rescheduleDateAndTime)
  .post(consultantController.rescheduleDateAndTime);

appRouter.get("/manageprescription", consultantController.managePrescription);
appRouter.get("/newbooking", consultantController.newBooking);

appRouter
  .route("/confirm/:id")
  .get(consultantController.confirmedBooking)
  .post(consultantController.confirmedBooking);

appRouter.get("/canceledbooking", consultantController.cancelBookings);

appRouter
  .route("/Decline/:id")
  .get(consultantController.canceledBooking)
  .post(consultantController.canceledBooking);

appRouter.get("/managebooking", consultantController.manageBooking);

appRouter.post(
  "/managebookingbyid/:id",
  consultantController.manageBookingById
);

appRouter.post("/getpasthistory/:id", consultantController.pastHistory);
appRouter.get("/getpasthistory/:id", consultantController.pastHistory);

appRouter
  .route("/complete/:id")
  .get(consultantController.completedBookingById)
  .post(consultantController.completedBookingById);

appRouter
  .route("/get-refer-value/:id")
  .get(consultantController.getReferData)
  .post(consultantController.getReferData);

appRouter
  .route("/complete-booking/:id")
  .get(consultantController.bookingCompleted)
  .post(consultantController.bookingCompleted);

appRouter
  .route("/changepassword")
  .get(consultantController.changePassword)
  .post(consultantController.changePassword);

appRouter.get("/reschedulebooking", consultantController.rescheduleBooking);

appRouter.post("/reschedule-booking", consultantController.bookingReSchedule);
appRouter.get("/chat", consultantController.chat);
appRouter.get("/doctortemplete", consultantController.doctorTemplete);
appRouter.get("/viewtemplete", consultantController.viewDoctorTemplete);
appRouter.get("/admintemplete", consultantController.viewAdminTemplete);

appRouter.get("/Demo", consultantController.Demo);
appRouter.post("/Demo", consultantController.Demo);

appRouter.get("/viewclender", consultantController.calender);

appRouter.get("/get-refer-deatil", consultantController.getReferdetail);

appRouter.get("/calculatebmi", consultantController.calculateBmi);
appRouter.get("/myprofile", consultantController.myProfile);

appRouter
  .route("/editprofile")
  .get(consultantController.editProfile)
  .post(consultantController.editProfile);

appRouter
  .route("/getImage")
  .get(consultantController.getImage)
  .post(consultantController.getImage);

appRouter.get("/privacypolicy", consultantController.privacyPolicy);
appRouter.get("/termsofuse", consultantController.termsOfUse);
appRouter.get("/setmore", consultantController.setmore);
appRouter.get("/completedbooking", consultantController.completedBooking);
appRouter.get("/roleaccess", consultantController.roleAccess);
appRouter.get("/addrole", consultantController.addRole);
appRouter.get("/adduser", consultantController.addUser);
appRouter.get("/viewuser", consultantController.viewUser);
appRouter.get("/viewemail", consultantController.viewEmail);

appRouter.get("/servicescategory", consultantController.servicesCategory);
appRouter.get("/addservicescategory", consultantController.addServicesCategory);
appRouter.get("/viewcalender", consultantController.viewcalender);
appRouter.get("/video-call/:id", consultantController.videoCall);

appRouter.get("/voice-call/:id", consultantController.voiceCall);

appRouter
  .route("/icd-suggestion")
  .get(consultantController.icdSuggestion)
  .post(consultantController.icdSuggestion);

appRouter
  .route("/medicine-suggestion")
  .get(consultantController.medicineSuggestion)
  .post(consultantController.medicineSuggestion);

appRouter
  .route("/getrole-access")
  .get(consultantController.getRole)
  .post(consultantController.getRole);

appRouter
  .route("/get-booking")
  .get(consultantController.getBooking)
  .post(consultantController.getBooking);

  

  appRouter
  .route("/update-Bookings")
  .get(consultantController.updateBooking)
  .post(consultantController.updateBooking);

export default appRouter;
