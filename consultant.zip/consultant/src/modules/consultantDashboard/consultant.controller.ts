import { Request, Response } from "express";
import httpStatus from "http-status";
import { RtcRole, RtcTokenBuilder } from "agora-access-token";
import * as chatService from "../chat/chat.service";

//EJS Rendor
import ejs from "ejs";
import { getViewFile } from "../../utils/ejsHelper";
import { Types } from "mongoose";
import bookingModel, { Booking } from "../booking/booking.model";
import { json } from "stream/consumers";
import { count, log } from "console";
import ordersModel, { Order } from "../orders/orders.model";
import * as notification from "../notification/notification.controller";
import * as templateService from "../emailTemplate/template.service";
import * as consultantservices from "./consultant.services";

import * as roleService from "../roleAndPermission/roleAndPermission.service";
import roleAndPermissionModel, {
  Role,
} from "../roleAndPermission/roleAndPermission.model";
import staffModel, { Staff } from "../staff/staff.model";
import * as staffService from "../staff/staff.service";
import referModel from "../models/refer.model";
import icdCodeModel from "../models/icdCode.model";
import medicineModel from "../models/medicine.model";
import adminModel from "../admin/admin.model";
import templateModel from "../emailTemplate/template.model";
import specialityModel from "../models/speciality.model";
import consultantModel from "../consultant/consultant.model";
import patientModel from "../patient/patient.model";
import chatModel from "../chat/chat.model";

/**
 * @description This function is for Dashboard
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */

export async function consultantDashboard(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const seg2 = req.params.seg2 || "";

    const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const user = JSON.parse(res.get("user")!);
    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = id;
    } else {
      consultantId = new Types.ObjectId(user.addedBy);
    }
    const manageBooking: Array<Booking> =
      await consultantservices.myUpcomingBooking(
        consultantId
        // parseInt(limit as string),
        // parseInt(page as string)
      );
    const consultant = await consultantservices.consultantcount(consultantId);

    const patients = await consultantservices.patientcount(consultantId);
    const patient = patients.length;

    const pharmacy = await consultantservices.pharmacycount();
    const confirmBooking = await consultantservices.confirmedBookingCount(
      consultantId
    );
    const confirmedBooking = confirmBooking.length;

    const upcomingAppoitment = await consultantservices.upcomingBookingCount(
      consultantId
    );
    const upcomingBooking = upcomingAppoitment.length;
    const cancelAppoitment = await consultantservices.cancelBookingCount(
      consultantId
    );
    const cancelBooking = cancelAppoitment.length;
    const rescheduleAppotment = await consultantservices.reschduleBookingCount(
      consultantId
    );
    const rescheduleBooking = rescheduleAppotment.length;

    const allAppointment = await consultantservices.allAppointmentscount(
      consultantId
    );

    const consultants = await consultantservices.getMyProfile(consultantId);

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("consultantDashboard", "index.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            patient,
            consultant,
            pharmacy,
            confirmedBooking,
            upcomingBooking,
            cancelBooking,
            rescheduleBooking,
            allAppointment,
            consultants,
            seg2,
            manageBooking,
            activeTab: "doctorDashboard",
            filename: fileContent.templatePath,
            // permission:user.role.permission
          })
        );
      } else {
        //Post Method Code
      }
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for Manage Patient
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function managePatient(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { search, startDate, endDate } = req.body;

    const searchvalue = search ?? "";
    const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const user = JSON.parse(res.get("user")!);
    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = id;
    } else {
      consultantId = new Types.ObjectId(user.addedBy);
    }

    const bookings: Array<Booking> = await consultantservices.getFilterPatients(
      consultantId
      // searchvalue as string,
      // new Date(startDate as Date),
      // new Date(endDate as Date),
    );

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: bookings,
        message: "patients fetched successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start

      const fileContent = getViewFile(
        "consultantDashboard",
        "view-patient-list.ejs"
      );
      const user: any = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          user,
          activeTab: "doctorDashboard",
          bookings,
          filename: fileContent.templatePath,
        })
      );
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ data: error });
  }
}

export async function editPatient(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const bookingId: Types.ObjectId = new Types.ObjectId(req.params.id);
    const patient: Booking | null = await consultantservices.editPatientById(
      bookingId,
      req.body
    );

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: patient,
        message: "patient update successfully",
        status: httpStatus.OK,
      });
    } else {
      //web code

      res.redirect("/consultant/web/managepatient");
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

// /**
//  * @description This function is for Manage Prescription
//  * @param req
//  * @param res
//  * @author Nikhil Chouhan
//  */
export async function managePatientBySerch(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const { search, startDate, endDate } = req.body;

    const searchvalue = search ?? "";

    const consultantId: Types.ObjectId = new Types.ObjectId(req.params.id);

    const patients: Array<Booking> = await consultantservices.filterData(
      consultantId,
      searchvalue as string,
      new Date(startDate as Date),
      new Date(endDate as Date)
    );

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: patients,
        message: "Booking fetch successfully",
        status: httpStatus.OK,
      });
    } else {
      //web code

      res.redirect("/consultant/web/managepatient");
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function managePrescription(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const user = JSON.parse(res.get("user")!);
    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = id;
    } else {
      consultantId = new Types.ObjectId(user.addedBy);
    }
    const bookingId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const { name, startDate, endDate } = req.query;
    const limit = 20;
    const page = req.query.page || 1;
    const booking: Array<Booking> = await consultantservices.getAcceptedBooking(
      consultantId,
      limit,
      page,
      name as string,
      startDate as string,
      endDate as string
    );

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "consultantDashboard",
          "manage-priscription.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            booking,
            activeTab: "doctorDashboard",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for Patient Past Medical History
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */

export async function pastHistory(req: Request, res: Response) {
  const patientId = new Types.ObjectId(req.params.id);

  const booking = await consultantservices.pastBookings(patientId);

  res.send(booking);
}

/**
 * @description This function is for New Booking
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function newBooking(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "consultantDashboard",
          "new-booking.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "doctorDashboard",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for Confirmed Booking
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function confirmedBooking(req: Request, res: Response) {
  try {
    const { limit, page } = req.query;

    const { mode } = req.params;

    const bookingId: Types.ObjectId = new Types.ObjectId(req.params.id);

    const status = "accepted";

    const booking: Booking | null = await consultantservices.updatebooking(
      bookingId,
      status
    );

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: booking,
        message: "Booking update successfully",
        status: httpStatus.OK,
      });
    } else {
      res.redirect("/consultant/web/confirmedBooking");
      //Web Code Start
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for Canceled Booking
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function cancelBookings(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const manageBooking: Array<Booking> =
      await consultantservices.myUpcomingBooking(
        id
        // parseInt(limit as string),
        // parseInt(page as string)
      );
    const user = JSON.parse(res.get("user")!);
    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = id;
    } else {
      consultantId = new Types.ObjectId(user.addedBy);
    }
    const bookingId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    // const { limit, page } = req.query;
    const { name, startDate, endDate } = req.query;
    const limit = 10;
    const page = Number(req.query.page) || 1;

    const booking: Array<Booking> = await consultantservices.getCancelOredrs(
      consultantId,
      bookingId,
      limit,
      page,
      name as string,
      startDate as string,
      endDate as string
    );

    const count = await bookingModel
      .find({ doctor: consultantId, status: "cancelled" })
      .count();

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "consultantDashboard",
          "cancel-booking.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            booking,
            activeTab: "canBook",
            current: page,
            pages: Math.ceil(count / limit),
            filename: fileContent.templatePath,
            manageBooking,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function canceledBooking(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const bookingId: Types.ObjectId = new Types.ObjectId(req.params.id);

    const status = "cancelled";

    const booking: Booking | null = await consultantservices.cancelBooking(
      bookingId,
      status,
      req.body.cancelReason
    );

    if (booking) {
      //Create Notification
      const createNotificationDto = {
        notificationTitle: "Booking Canclled Sucessfully",
        notificationDescription: "Notification Description",
        notificationBy: booking?.doctor,
        notificationTo: [booking?.doctor, booking?.patient], //booking?.doctor
        notificationType: "booking_notification",
        notificationTypeId: booking?._id,
      };
      await notification.createNotification(createNotificationDto);
    }

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: booking,
        message: "Booking update successfully",
        status: httpStatus.OK,
      });
    } else {
      //web code

      res.redirect("/consultant/web/canceledbooking");
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}
export async function confirmedAllBooking(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const seg2 = req.params.seg2 || "";

    const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const user = JSON.parse(res.get("user")!);

    let consultantId;

    const manageBooking: Array<Booking> =
      await consultantservices.myUpcomingBooking(id);
    if (user.addedBy == undefined) {
      consultantId = id;
    } else {
      consultantId = new Types.ObjectId(user.addedBy);
    }
    const bookingId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const { name, startDate, endDate } = req.query;
    const limit = 10;
    const page = Number(req.query.page) || 1;

    const booking: Array<Booking> = await consultantservices.getConfirmOrders(
      consultantId,
      bookingId,
      limit,
      page,
      name as string,
      startDate as string,
      endDate as string
    );

    let data = booking.map(async (a) => {
      return await consultantservices.pastBookings(a?.patient?._id);
    });

    let prescription = await Promise.all(data);

    // let c = new Types.ObjectId(k)

    const counts = await bookingModel
      .find({
        doctor: consultantId,
        status: {
          $in: ["accepted", "reschedule"],
        },
      })
      .count();

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "consultantDashboard",
          "confirmed-all-booking.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            message1: "",
            activeTab: "confBook",
            user,
            booking,
            count,
            prescription,
            manageBooking,
            current: page,
            consultantId,
            id,
            seg2,
            pages: Math.ceil(counts / limit),
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for Manage Booking
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function manageBooking(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const user = JSON.parse(res.get("user")!);

    const { name, startDate, endDate } = req.query;
    let uId;
    if (user.addedBy == undefined) {
      uId = id;
    } else {
      uId = new Types.ObjectId(user.addedBy);
    }

    const templates = await templateService.getAllTemplate(
      uId,);

    const doctorDetial = await consultantModel.findById(uId);

    const manageBooking: Array<Booking> =
      await consultantservices.myUpcomingBooking(
        id );

    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = id;
    } else {
      consultantId = new Types.ObjectId(user.addedBy);
    }

    const limit = 10;
    const page = Number(req.query.page) || 1;

    const manageBookings: Array<Booking> =
      await consultantservices.getManageBooking(
        consultantId,
        limit,
        page,
        name as string,
        startDate as string,
        endDate as string
      );

    const count = await bookingModel
      .find({
        doctor: consultantId,
        status: {
          $in: ["accepted", "reschedule"],
        },
      })
      .count();

    const editprescriptions: Array<Order> =
      await consultantservices.editPrescription(consultantId);

    const referals = await referModel.find({});

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "consultantDashboard",
          "manage-booking.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            activeTab: "mangBook",
            user,
            manageBookings,
            editprescriptions,
            referals,
            manageBooking,
            templates,
            current: page,
            doctorDetial,
            pages: Math.ceil(count / limit),
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}
export async function manageBookingById(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const status = "reschedule";
    const bookingId: Types.ObjectId = new Types.ObjectId(req.params.id);

    const data = await consultantservices.findBookingById(bookingId);

    const previousdata = {
      date: data?.date,
      time: data?.startTime,
    };

    const { date, time } = req.body;
    const originalDate = new Date(date);
    const hours = time.slice(0, 2);
    const minutes = time.slice(3, 5);

    // set the desired UTC time
    originalDate.setUTCHours(hours);
    originalDate.setUTCMinutes(minutes);
    originalDate.setUTCSeconds(0);

    const isoString = originalDate.toISOString();

    const rescheduleDto = {
      date: date,
      time: isoString,
    };

    const manageBooking: Booking | null =
      await consultantservices.rescheduleBookingById(
        bookingId,
        rescheduleDto,
        status,
        previousdata
      );

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: manageBooking,
        message: "Booking Reschedule successfully",
        status: httpStatus.OK,
      });
    } else {
      //web code

      res.redirect("/consultant/web/managebooking");
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for Reschedule Booking
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function rescheduleBooking(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const user = JSON.parse(res.get("user")!);

    const manageBooking: Array<Booking> =
      await consultantservices.myUpcomingBooking(
        id
        // parseInt(limit as string),
        // parseInt(page as string)
      );

    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = id;
    } else {
      consultantId = new Types.ObjectId(user.addedBy);
    }
    const { name, startDate, endDate } = req.query;
    const limit = 10;
    const page = Number(req.query.page) || 1;
    const booking: Array<Booking> =
      await consultantservices.getRescheduleBookings(
        consultantId,
        consultantId,
        limit,
        page,
        name as string,
        startDate as string,
        endDate as string
      );
    const count = await bookingModel
      .find({ doctor: consultantId, status: "reschedule" })
      .count();

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "consultantDashboard",
          "reschedule-booking.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            activeTab: "resBook",
            current: page,
            pages: Math.ceil(count / limit),

            user,
            booking,
            manageBooking,
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function bookingReSchedule(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const { name, startDate, endDate } = req.query;

    const startDates = startDate;
    const endDates = endDate;

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: "",
        message: "booking update successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      const { bookingDate, id, slot } = req.body;

      if (slot) {
        // const bookDate = new Date(bookingDate);

        const slotTime = Number(req.body.slotTime);

        const time = slot[slotTime];

        let startTime = time.slice(1, 6);

        let endTime = time.slice(7, 12);

        const date = new Date(bookingDate);

        const startDate = new Date(bookingDate);

        const endDate = new Date(bookingDate);

        const formattedDate = date.toISOString();

        const formattedDateWithOffset = formattedDate.replace("Z", "+00:00");

        const [hours, minutes] = startTime.split(":");

        startDate.setHours(hours);
        startDate.setMinutes(minutes);

        // Adding delay of 5.30 hours

        const delayHours = 5;
        const delayMinutes = 30;

        startDate.setHours(startDate.getHours() + delayHours);
        startDate.setMinutes(startDate.getMinutes() + delayMinutes);

        const newStartTime = startDate;

        const [endHours, endMinutes] = endTime.split(":");

        endDate.setHours(endHours);
        endDate.setMinutes(endMinutes);

        const delayHoursEnd = 5;
        const delayMinutesEnd = 30;

        endDate.setHours(endDate.getHours() + delayHoursEnd);
        endDate.setMinutes(endDate.getMinutes() + delayMinutesEnd);

        const newEndTime = endDate;

        const bookingId: Types.ObjectId = new Types.ObjectId(id);

        const data = await consultantservices.findBookingById(bookingId);

        const previousdata = {
          date: data?.date,
          startTime: data?.startTime,
          endTime: data?.endTime,
        };

        const rescheduleDto = {
          date: formattedDateWithOffset,
          startTime: newStartTime,
          endTime: newEndTime,
        };

        const status = "reschedule";
        const bookings = await consultantservices.bookingupdateById(
          bookingId,
          rescheduleDto,
          status,
          previousdata
        );

        if (bookings) {
          //Create Notification
          const createNotificationDto = {
            notificationTitle: "Booking Reschedule Sucessfully",
            notificationDescription: "Notification Description",
            notificationBy: bookings?.doctor,
            notificationTo: [bookings?.doctor, bookings?.patient], //booking?.doctor
            notificationType: "booking_notification",
            notificationTypeId: bookings?._id,
          };

          await notification.createNotification(createNotificationDto);

          const ids: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

          const user = JSON.parse(res.get("user")!);

          let consultantId;

          const manageBooking: Array<Booking> =
            await consultantservices.myUpcomingBooking(ids);

          if (user.addedBy == undefined) {
            consultantId = ids;
          } else {
            consultantId = new Types.ObjectId(user.addedBy);
          }
          const bookingid: Types.ObjectId = new Types.ObjectId(
            res.get("userId")!
          );

          const limit = 10;
          const page = Number(req.query.page) || 1;

          const booking: Array<Booking> =
            await consultantservices.getConfirmOrders(
              consultantId,
              bookingid,
              limit,
              page,
              name as string,
              startDates as string,
              endDates as string
            );

          let datas = booking.map(async (a) => {
            return await consultantservices.pastBookings(a.patient._id);
          });

          let prescription = await Promise.all(datas);

          const count = await bookingModel
            .find({
              doctor: consultantId,
              status: {
                $in: ["accepted", "reschedule"],
              },
            })
            .count();

          const fileContent = getViewFile(
            "consultantDashboard",
            "confirmed-all-booking.ejs"
          );
          res.send(
            ejs.render(fileContent.file, {
              message: "Booking Reschedule Sucessfully",
              message1: "",
              user,
              booking,
              count,
              prescription,
              manageBooking,
              activeTab: "confBook",
              current: page,
              consultantId,
              id,
              pages: Math.ceil(count / limit),
              filename: fileContent.templatePath,
            })
          );
        }
      } else {
        const bookingData = req.body;

        const booking = new Types.ObjectId(bookingData.id);

        const updateBooking = await bookingModel.findById(booking);

        const startTime = updateBooking?.startTime;
        const endTime = updateBooking?.endTime;

        const startTimestamp: any = startTime?.getTime();

        const endTimestamp: any = endTime?.getTime();

        const timeDifference = endTimestamp - startTimestamp;

        const time = Math.floor(timeDifference / (1000 * 60));

        const user = JSON.parse(res.get("user")!);

        const fileContent = getViewFile(
          "consultantDashboard",
          "reschedule-date-time.ejs"
        );
        res.send(
          ejs.render(fileContent.file, {
            user,
            message1: "Doctor is Not Available on this Date ",
            message: "",
            bookingData,
            activeTab: "confBook",
            updateBooking,
            time,
            filename: fileContent.templatePath,
          })
        );
      }
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

/**
 * @description This function is for Chat
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function chat(req: Request, res: Response) {
  try {
    const { mode, recieverId, rid } = req.params;
    const message = req.body.message;

    let patientId = new Types.ObjectId(req.body.personvalue);

    const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const user = JSON.parse(res.get("user")!);
    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = id;
    } else {
      consultantId = new Types.ObjectId(user.addedBy);
    }

    const booking = await consultantservices.bookingGetById(
      consultantId,
      patientId
    );

    const { limit, page } = req.query;
    const manageBooking: Array<Booking> = await consultantservices.myBooking(
      consultantId
      // parseInt(limit as string),
      // parseInt(page as string)
    );

    const bookings = booking.map((e) => {
      return e?._id;
    });

    const bookingId = bookings.toString();

    const channel: any = bookingId;
    let token;
    const uid = 0;
    const role = RtcRole.PUBLISHER;
    const expirationTimeInSeconds = 3600;
    const currentTimestamp = Math.floor(Date.now() / 1000);
    const privilegeExpiredTs = currentTimestamp + expirationTimeInSeconds;
    const appId = process.env.appId;
    const appCertificate = process.env.appCertificate;

    // Build token with uid
    if (appId == undefined || appCertificate == undefined) {
    } else {
      token = RtcTokenBuilder.buildTokenWithUid(
        appId,
        appCertificate,
        channel,
        uid,
        role,
        privilegeExpiredTs
      );
    }
    if (mode == "api") {
      //API Response
      res.status(httpStatus.OK).json({ token, channel, appId });
    } else {
      //Web Response
      const fileContent = getViewFile("consultantDashboard", "chat.ejs");
      const user: any = JSON.parse(res.get("user")!);
      res.json(
        ejs.render(fileContent.file, {
          user,
          appId,
          token,
          activeTab: "chat",
          channel,
          recieverId,
          message,
          manageBooking,
          filename: fileContent.templatePath,
        })
      );
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function upcomigChat(req: Request, res: Response) {
  try {
    const { mode, recieverId, rid } = req.params;
    const message = req.body.message;

    let patientId = new Types.ObjectId(req.body.personvalue);

    const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const user = JSON.parse(res.get("user")!);

    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = id;
    } else {
      consultantId = new Types.ObjectId(user.addedBy);
    }

    const booking = await consultantservices.upComingBooking(
      consultantId,
      patientId
    );




    const { limit, page } = req.query;
    const manageBooking: Array<Booking> =
      await consultantservices.myUpcomingBooking(consultantId);


      

      const doc = manageBooking.map((e) => {
        return {
            doctor: e.doctor,
            patient: e.patient
        };
    });
let c = doc.map(async(a)=>{
  return await chatService.getPreviousMessages(a.doctor,a.patient)
})
    let chatData = await Promise.all(c)
    
      
      
    const bookings = booking.map((e) => {
      return e._id;
    });

    const bookingId = bookings.toString();

    const channel: any = bookingId;
    let token;
    const uid = 0;
    const role = RtcRole.PUBLISHER;
    const expirationTimeInSeconds = 3600;
    const currentTimestamp = Math.floor(Date.now() / 1000);
    const privilegeExpiredTs = currentTimestamp + expirationTimeInSeconds;
    const appId = process.env.appId;
    const appCertificate = process.env.appCertificate;

    // Build token with uid
    if (appId == undefined || appCertificate == undefined) {
    } else {
      token = RtcTokenBuilder.buildTokenWithUid(
        appId,
        appCertificate,
        channel,
        uid,
        role,
        privilegeExpiredTs
      );
    }
    if (mode == "api") {
      //API Response

      res.status(httpStatus.OK).json({ token, channel, appId });
    } else {
      //Web Response

      const fileContent = getViewFile(
        "consultantDashboard",
        "upcoming-chat.ejs"
      );
      const user: any = JSON.parse(res.get("user")!);
      res.json(
        ejs.render(fileContent.file, {
          user,
          appId,
          token,
          activeTab: "chat",
          channel,
          recieverId,
          message,
          manageBooking,
          chatData,
          filename: fileContent.templatePath,
        })
      );
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}
// chat demo code

export async function Demo(req: Request, res: Response) {
  try {
    const { mode, recieverId, rid } = req.params;
    const message = req.body.message;

    // const myId =      Types.ObjectId(req.body.value)

    let patientId = new Types.ObjectId(req.body.personvalue);

    const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const user = JSON.parse(res.get("user")!);

    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = id;
    } else {
      consultantId = new Types.ObjectId(user.addedBy);
    }

    const booking = await consultantservices.bookingGetById(
      consultantId,
      patientId
    );

    const { limit, page } = req.query;
    const manageBooking: Array<Booking> = await consultantservices.myBooking(
      consultantId
      // parseInt(limit as string),
      // parseInt(page as string)
    );

    const bookings = booking[0]?._id;

    const bookingId = bookings?.toString();

    const channel: any = bookingId;
    let token;
    const uid = 0;
    const role = RtcRole.PUBLISHER;
    const expirationTimeInSeconds = 3600;
    const currentTimestamp = Math.floor(Date.now() / 1000);
    const privilegeExpiredTs = currentTimestamp + expirationTimeInSeconds;
    const appId = process.env.appId;
    const appCertificate = process.env.appCertificate;

    // Build token with uid
    if (appId == undefined || appCertificate == undefined) {
    } else {
      token = RtcTokenBuilder.buildTokenWithUid(
        appId,
        appCertificate,
        channel,
        uid,
        role,
        privilegeExpiredTs
      );
    }

    res.json({
      channel,
      appId,
      appCertificate,
      token,
      booking,
    });
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for Document Center
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */

export async function doctorTemplete(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "consultantDashboard",
          "doctor-templete.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "viewTemp",
            type: "",
            document: "",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function viewDoctorTemplete(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "consultantDashboard",
          "view-templete.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            message1: "",
            user,
            type: "",
            activeTab: "viewTemp",
            document: "",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function viewAdminTemplete(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      const { name } = req.query;

      const admin: any = await adminModel.find();

      const data: Types.ObjectId = admin.map((e: any) => {
        return e._id;
      });

      let adminTemplete;

      if (name) {
        adminTemplete = await templateModel
          .find({ addedBy: data, name: { $regex: name, $options: "i" } })
          .sort({ createdAt: -1 });
      } else {
        adminTemplete = await templateModel
          .find({ addedBy: data })
          .sort({ createdAt: -1 });
      }

      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "consultantDashboard",
          "admin-templete.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            adminTemplete,
            type: "",
            activeTab: "viewTemp",
            document: "",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for Add Questionaire
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function addQuestionaire(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "consultantDashboard",
          "add-questionaire.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "addQues",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for View Questionaire
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function viewQuestionaire(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "consultantDashboard",
          "view-all-questionaire-list.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "viewQues",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function calender(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("consultantDashboard", "celnder.html");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "avail",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}
export async function getReferdetail(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start

      //Post Method Code

      const consultant = req.query.consultant;

      const data = referModel.find({ doctor: consultant });

      res.json(data);
    }
    //Web Code End
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for Calculate Bmi
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function calculateBmi(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "consultantDashboard",
          "calculate-bmi.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "avail",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for My Profile
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function myProfile(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const user = JSON.parse(res.get("user")!);
    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = id;
    } else {
      consultantId = new Types.ObjectId(user._id);
    }

    const consultant = await consultantservices.getMyProfile(consultantId);

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: consultant,
        message: "consultant fetched successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("consultantDashboard", "profile.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            activeTab: "doctorDashboard",
            user,
            consultant,
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for Edit Profile
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function editProfile(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const user = JSON.parse(res.get("user")!);

    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = id;
    } else {
      consultantId = new Types.ObjectId(user._id);
    }

    const speciality = await specialityModel.find();
    let consultant;
    consultant = await consultantModel.findById(consultantId);
    if (consultant) {
      consultant = await consultantModel.findById(consultantId);
    } else {
      consultant = await staffModel.findById(consultantId);
    }

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: consultant,
        message: "patient update successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start

      if (req.method == "GET") {
        const fileContent = getViewFile(
          "consultantDashboard",
          "profile-edit.ejs"
        );
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            message1: "",
            user,
            consultant,
            speciality,
            activeTab: "doctorDashboard",
            filename: fileContent.templatePath,
          })
        );
      } else {
        let editDto;

        if (user.addedBy) {
          const newv: any = req.body.files;
          let profilePic;

          if (newv[0]) {
            profilePic = newv[0]?.path;
          } else {
            const d = await staffModel.findById(consultantId);
            profilePic = d?.profilePic;
          }

          editDto = {
            profilePic: profilePic,
            firstName: req.body.firstName,
            lastName: req.body.lastName,
            email: req.body.email,
            mobileNumber: req.body.mobileNumber,
            gender: req.body.gender,
            maritialStatus: req.body.maritialStatus,
            dateOfBirth: req.body.dateOfBirth,
            location: req.body.location,
          };

          const staff = await staffModel.findByIdAndUpdate(
            consultantId,
            editDto
          );

          consultant = await staffModel.findById(consultantId);
        } else {
          const newv: any = req.body.files;
          let profilePic;
          let medicalDegree;
          let specialistDegree;
          let indemnityCertificate;
          let medicalCouncilCertificate;
          let cctCertification;
          let signature;

          if (newv[0]) {
            if (newv[0].fieldname === "profile_image") {
              profilePic = newv[0]?.path;
            }

            if (newv[0].fieldname === "medicalDegree") {
              medicalDegree = newv[0]?.path;
            }

            if (newv[0].fieldname === "specialistDegree") {
              specialistDegree = newv[0]?.path;
            }
            if (newv[0].fieldname === "indemnityCertificate") {
              indemnityCertificate = newv[0]?.path;
            }
            if (newv[0].fieldname === "medicalCouncilCertificate") {
              medicalCouncilCertificate = newv[0]?.path;
            }
            if (newv[0].fieldname === "cctCertification") {
              cctCertification = newv[0]?.path;
            }

            if (newv[0].fieldname === "signature") {
              signature = newv[0]?.path;
            }
          }

          if (newv[1]) {
            if (newv[1].fieldname === "medicalDegree") {
              medicalDegree = newv[1]?.path;
            }

            if (newv[1].fieldname === "specialistDegree") {
              specialistDegree = newv[1]?.path;
            }
            if (newv[1].fieldname === "indemnityCertificate") {
              indemnityCertificate = newv[1]?.path;
            }
            if (newv[1].fieldname === "medicalCouncilCertificate") {
              medicalCouncilCertificate = newv[1]?.path;
            }
            if (newv[1].fieldname === "cctCertification") {
              cctCertification = newv[1]?.path;
            }

            if (newv[1].fieldname === "signature") {
              signature = newv[1]?.path;
            }
          }

          if (newv[2]) {
            if (newv[2].fieldname === "medicalDegree") {
              medicalDegree = newv[2]?.path;
            }

            if (newv[2].fieldname === "specialistDegree") {
              specialistDegree = newv[2]?.path;
            }

            if (newv[2].fieldname === "medicalCouncilCertificate") {
              medicalCouncilCertificate = newv[2]?.path;
            }
            if (newv[2].fieldname === "cctCertification") {
              cctCertification = newv[2]?.path;
            }
            if (newv[2].fieldname === "signature") {
              signature = newv[2]?.path;
            }
          }

          if (newv[3]) {
            if (newv[3].fieldname === "medicalDegree") {
              medicalDegree = newv[3]?.path;
            }

            if (newv[3].fieldname === "specialistDegree") {
              specialistDegree = newv[3]?.path;
            }
            if (newv[3].fieldname === "medicalCouncilCertificate") {
              medicalCouncilCertificate = newv[3]?.path;
            }

            if (newv[3].fieldname === "cctCertification") {
              cctCertification = newv[3]?.path;
            }

            if (newv[3].fieldname === "signature") {
              signature = newv[3]?.path;
            }
          }

          if (newv[4]) {
            if (newv[4].fieldname === "medicalDegree") {
              medicalDegree = newv[4]?.path;
            }

            if (newv[4].fieldname === "specialistDegree") {
              specialistDegree = newv[4]?.path;
            }

            if (newv[4].fieldname === "cctCertification") {
              cctCertification = newv[4]?.path;
            }

            if (newv[4].fieldname === "signature") {
              signature = newv[4]?.path;
            }
          }

          if (newv[5]) {
            if (newv[5].fieldname === "medicalDegree") {
              medicalDegree = newv[5]?.path;
            }
            if (newv[5].fieldname === "specialistDegree") {
              specialistDegree = newv[5]?.path;
            }
            if (newv[5].fieldname === "signature") {
              signature = newv[5]?.path;
            }
          }

          if (newv[6]) {
            if (newv[6].fieldname === "medicalDegree") {
              medicalDegree = newv[6]?.path;
            }
            if (newv[6].fieldname === "signature") {
              signature = newv[6]?.path;
            }
          }

          if (newv[7]) {
            if (newv[7].fieldname === "signature") {
              signature = newv[7]?.path;
            }
          }

          editDto = {
            profilePic: profilePic,

            medicalDegree: medicalDegree,
            specialistDegree: specialistDegree,
            indemnityCertificate: indemnityCertificate,
            medicalCouncilCertificate: medicalCouncilCertificate,
            cctCertification: cctCertification,
            firstName: req.body.firstName,
            lastName: req.body.lastName,
            email: req.body.email,
            mobileNumber: req.body.mobileNumber,
            gender: req.body.gender,
            maritialStatus: req.body.maritialStatus,
            dateOfBirth: req.body.dateOfBirth,
            experience: req.body.experience,
            speciality: req.body.speciality,
            description: req.body.description,
            location: req.body.location,
            indemnityExpiryDate: req.body.indemnityExpiryDate,
            medicalCouncilExpiryDate: req.body.medicalCouncilExpiryDate,
            signature: signature,
            medicalPhoneNo: req.body.medicalPhone,
            medicalEmail: req.body.medicalEmail,
            medicalCouncilNo: req.body.councilNumber,
            medicalAddress: req.body.medicalAddress,
            qualification: req.body.qualification,
          };

          const consultants = await consultantservices.profileUpdateById(
            consultantId,
            editDto
          );

          consultant = await consultantModel.findById(consultantId);
        }

        const fileContent = getViewFile(
          "consultantDashboard",
          "profile-edit.ejs"
        );

        res.send(
          ejs.render(fileContent.file, {
            message: "Profile  Updated Successfully",
            message1: "",
            user,
            consultant,
            speciality,
            activeTab: "doctorDashboard",
            filename: fileContent.templatePath,
          })
        );
      }
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for Privacy Policy
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function privacyPolicy(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "consultantDashboard",
          "privacy-policy.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "doctorDashboard",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for Terms Of Use
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function termsOfUse(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "consultantDashboard",
          "terms-of-use.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "doctorDashboard",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for Setmore
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function setmore(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("consultantDashboard", "setmore.ejs");
        const user: any = JSON.parse(res.get("user")!);
        const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

        let consultantId;
        if (user.addedBy == undefined) {
          consultantId = id;
        } else {
          consultantId = new Types.ObjectId(user.addedBy);
        }

        const doctorName = await consultantModel.findById(consultantId);

        const updateSchedule = await consultantservices.getMySchedule(
          consultantId
        );

        const manageBooking: Array<Booking> =
          await consultantservices.myUpcomingBooking(id);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            message1: "",
            activeTab: "avail",
            user,
            manageBooking,
            updateSchedule,
            doctorName,
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}
/**
 * @description This function is for Completed Booking
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function completedBooking(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const user = JSON.parse(res.get("user")!);

    const manageBooking: Array<Booking> =
      await consultantservices.myUpcomingBooking(id);
    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = id;
    } else {
      consultantId = new Types.ObjectId(user.addedBy);
    }

    const { name, startDate, endDate } = req.query;
    const limit = 10;
    const page = Number(req.query.page) || 1;

    const booking: Array<Booking> = await consultantservices.getAcceptedBooking(
      consultantId,
      limit,
      page,
      name as string,
      startDate as string,
      endDate as string
    );

    const count = await bookingModel
      .find({ doctor: consultantId, status: "completed" })
      .count();

    if (mode == "api") {
    } else {
      const manageBooking: Array<Booking> =
        await consultantservices.myUpcomingBooking(consultantId);
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "consultantDashboard",
          "completed.booking.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            current: page,
            pages: Math.ceil(count / limit),
            user,
            booking,
            manageBookings: "",
            manageBooking,
            filename: fileContent.templatePath,
            activeTab: "comBook",
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function completedBookingById(req: Request, res: Response) {
  try {
    const { name, startDate, endDate } = req.query;
    const limit = 20;
    const page = req.query.page || 1;

    const { mode } = req.params;
    const bookingId: Types.ObjectId = new Types.ObjectId(req.params.id);

    const bookingData = req.body;

    const OrderDto: any = {
      medicineName: bookingData.medicineName,
      frequency: bookingData.frequency,
      preparation: bookingData.preparation,
      quantity: bookingData.quantity,
      duration: bookingData.duration,

      notes: bookingData.notes,
    };

    let medicine;
    if (Array.isArray(OrderDto.medicineName)) {
      medicine = [];

      for (let i = 0; i < bookingData.medicineName.length; i++) {
        const convertedObject: any = {};

        for (const key in OrderDto) {
          convertedObject[key] = OrderDto[key][i];
        }

        medicine.push(convertedObject);
      }
    } else {
      medicine = OrderDto;
    }

    const data = {
      medicine,
      avoidSunlight: bookingData.avoidSunlight,
      diagnosis: bookingData.diagnosis,
      instructions: bookingData.instructions,
      followUp: bookingData.followUp,
      allergy: bookingData.allergy,
      repeat: bookingData.repeat,
      icdCode: bookingData.icdCode,
      symptoms: bookingData.Symptoms,
    };

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: bookingId,
        bookingData,
        message: "Booking update successfully",
        status: httpStatus.OK,
      });
    } else {
      //web code
      const consultantId: Types.ObjectId = new Types.ObjectId(
        res.get("userId")!
      );

      const templates = await templateService.getTemplateByAddedBy(
        consultantId,
        name as string
      );

      const doctorDetial = await consultantModel.findById(consultantId);

      let manageBookings: Array<Booking> =
        await consultantservices.getManageBooking(
          consultantId,

          limit,
          page,
          name as string,
          startDate as string,
          endDate as string
        );

      const manageBooking: Array<Booking> =
        await consultantservices.myUpcomingBooking(consultantId);

      const editprescriptions: Array<Order> =
        await consultantservices.editPrescription(consultantId);
      const referals = await referModel.find({});

      const prescriptionExist = await consultantservices.getScheduleByBookingId(
        bookingId
      );

      if (prescriptionExist) {
        const order = await consultantservices.updatePrescription(
          prescriptionExist._id,
          data
        );

        let manageBookings: Array<Booking> =
          await consultantservices.getManageBooking(
            consultantId,
            limit,
            page,
            name as string,
            startDate as string,
            endDate as string
          );

        const count = await bookingModel
          .find({
            doctor: consultantId,
            status: {
              $in: ["accepted", "reschedule"],
            },
          })
          .count();

        const fileContent = getViewFile(
          "consultantDashboard",
          "manage-booking.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);

        res.send(
          ejs.render(fileContent.file, {
            message: "Prescription  Updated successfully",
            user,
            order,
            current: page,
            activeTab: "mangBook",
            pages: Math.ceil(count / limit),
            manageBooking,
            manageBookings,
            referals,
            editprescriptions,
            doctorDetial,
            templates,
            filename: fileContent.templatePath,
          })
        );
      } else {
        const pharmacyBooking = await consultantservices.getNewBooking(
          bookingId,
          limit,
          parseInt(page as string)
        );

        if (data.medicine.medicineName == "") {
          const newData = {
            medicine,
            avoidSunlight: bookingData.avoidSunlight,
            diagnosis: bookingData.diagnosis,
            instructions: bookingData.instructions,
            followUp: bookingData.followUp,
            icdCode: bookingData.icdCode,
            allergy: bookingData.allergy,
            repeat: bookingData.repeat,
            symptoms: bookingData.Symptoms,
          };

          const createOrderDto = {
            booking: bookingId,
            problem: pharmacyBooking?.problem,
            patient: pharmacyBooking?.patient,
            prescription: newData,

            consultant: pharmacyBooking?.doctor,
          };

          const orders = await consultantservices.createOrder(createOrderDto);

          res.redirect("/consultant/web/managebooking");
        } else {
          const createOrderDto = {
            booking: bookingId,
            problem: pharmacyBooking?.problem,
            patient: pharmacyBooking?.patient,
            prescription: data,
            pharmacy: pharmacyBooking?.pharmacy,
            consultant: pharmacyBooking?.doctor,
          };

          if (createOrderDto.pharmacy !== null) {
            const orders: any = await consultantservices.createOrder(
              createOrderDto
            );
          }

          res.redirect("/consultant/web/managebooking");
        }
      }
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function bookingCompleted(req: Request, res: Response) {
  try {
    const { limit, page } = req.query;

    const { mode } = req.params;
    const bookingId: Types.ObjectId = new Types.ObjectId(req.params.id);

    const status = "completed";

    const booking: Booking | null = await consultantservices.acceptbooking(
      bookingId,
      status
    );

    if (booking) {
      //Create Notification
      const createNotificationDto = {
        notificationTitle: "Booking Completed Sucessfully",
        notificationDescription: "Notification Description",
        notificationBy: booking?.doctor,
        notificationTo: [booking?.doctor, booking?.patient], //booking?.doctor
        notificationType: "booking_notification",
        notificationTypeId: booking?._id,
      };
      await notification.createNotification(createNotificationDto);
    }

    const orderCreated = await consultantservices.orderStatus(bookingId);

    if (orderCreated[0].pharmacy) {
      const createNotificationDto = {
        notificationTitle: "Order Created Sucessfully",
        notificationDescription: "Notification Description",
        notificationBy: orderCreated[0]?.doctor,
        notificationTo: [orderCreated[0]?.patient, orderCreated[0]?.pharmacy], //booking?.doctor
        notificationType: "booking_notification",
        notificationTypeId: booking?._id,
      };
      await notification.createNotification(createNotificationDto);
    }

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: booking,
        message: "Booking update successfully",
        status: httpStatus.OK,
      });
    } else {
      //web code

      res.redirect("/consultant/web/completedbooking");
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

/**
 * @description This function is for Role Access
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function roleAccess(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const id: Types.ObjectId = new Types.ObjectId(res.get("userId"));
    const user = JSON.parse(res.get("user")!);
    const manageBooking: Array<Booking> =
      await consultantservices.myUpcomingBooking(
        id
        // parseInt(limit as string),
        // parseInt(page as string)
      );
    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = id;
    } else {
      consultantId = new Types.ObjectId(user.addedBy);
    }
    const roles: Array<Role> = await roleService.getRoles(consultantId);
    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "consultantDashboard",
          "role-access.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "accessCnt",
            roles,
            manageBooking,
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function addUser(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const {
      email,
      firstname,
      lastname,
      date_of_birth,
      mobileNumber,
      roleid,
      gender,
      location,
      maritialStatus,
    } = req.body;

    const id: Types.ObjectId = new Types.ObjectId(res.get("userId"));
    const user = JSON.parse(res.get("user")!);
    const manageBooking: Array<Booking> =
      await consultantservices.myUpcomingBooking(
        id
        // parseInt(limit as string),
        // parseInt(page as string)
      );
    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = id;
    } else {
      consultantId = new Types.ObjectId(user.addedBy);
    }
    const roles: Array<Role> = await roleService.getRoles(id);
    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("consultantDashboard", "add-user.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            message1: "",
            activeTab: "addUser",
            email: "",
            firstname: "",
            lastname: "",
            date_of_birth: "",
            mobileNumber: "",
            roleid: "",
            gender: "",
            location: "",
            maritialStatus: "",
            roles,
            manageBooking,
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function viewUser(req: Request, res: Response) {
  try {
    const id: Types.ObjectId = new Types.ObjectId(res.get("userId"));
    const user = JSON.parse(res.get("user")!);
    const manageBooking: Array<Booking> =
      await consultantservices.myUpcomingBooking(
        id
        // parseInt(limit as string),
        // parseInt(page as string)
      );
    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = id;
    } else {
      consultantId = new Types.ObjectId(user.addedBy);
    }
    const { mode } = req.params;
    const { name, role } = req.query;
    const roles: Array<Role> = await roleService.getRoles(consultantId);

    const staffs: Array<Staff> = await staffService.getStaffs(
      consultantId,
      name as string,
      role as string
    );
    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "consultantDashboard",
          "view-all-user.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            staffs,
            activeTab: "viewUser",
            roles,
            manageBooking,
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function servicesCategory(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "consultantDashboard",
          "services-category.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "doctorDashboard",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function addServicesCategory(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "consultantDashboard",
          "add-services-category.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "doctorDashboard",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

// cahnge password
/**
 * @description This function is for Change Profile Password
 * @param req
 * @param res
 * @author Nikhil Chouhan
 */
export async function changePassword(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    let user: any = JSON.parse(res.get("user")!);

    const speciality = await specialityModel.find();

    if (user.addedBy) {
      user = await consultantservices.getStaffByUserID(user._id);
      let { currentPassword, password, confirmPassword } = req.body;

      const isMatch = consultantservices.comparePassword(
        currentPassword,
        user.password
      );
      if (mode == "api") {
        //API Code Start
        if (isMatch) {
          if (password === confirmPassword) {
            const encryptPassword =
              consultantservices.encryptPassword(password);
            const data = await consultantservices.updateStaffById(
              user._id,
              encryptPassword
            );
            res.status(httpStatus.OK).send({
              message: "Password reset successfully",
              status: httpStatus.OK,
            });
          } else {
            res.status(httpStatus.BAD_REQUEST).send({
              message1: "Password not match",
              message: "",
              status: httpStatus.BAD_REQUESTs,
            });
          }
        } else {
          res.status(httpStatus.BAD_REQUEST).send({
            message: "Current password not match",
            status: httpStatus.BAD_REQUESTs,
          });
        }
        //API Code End
      } else {
        //Web Code Start
        const fileContent = getViewFile(
          "consultantDashboard",
          "profile-edit.ejs"
        );

        const isMatch = consultantservices.comparePassword(
          currentPassword,
          user.password
        );
        const consultant = await staffModel.findById(user._id);
        if (isMatch) {
          if (password === confirmPassword) {
            const encryptPassword =
              consultantservices.encryptPassword(password);
            const data = await consultantservices.updateStaffById(
              user._id,
              encryptPassword
            );

            res.send(
              ejs.render(fileContent.file, {
                message: "Password reset successfully",
                message1: "",
                user,
                data,
                speciality,
                consultant,
                activeTab: "doctorDashboard",
                filename: fileContent.templatePath,
              })
            );
          } else {
            res.send(
              ejs.render(fileContent.file, {
                message1: "Password not match",
                message: "",
                user,
                speciality,
                activeTab: "doctorDashboard",
                pharmacy: "",
                consultant,
                filename: fileContent.templatePath,
              })
            );
          }
        } else {
          res.send(
            ejs.render(fileContent.file, {
              message1: "Current password not match",
              message: "",
              user,
              speciality,
              activeTab: "doctorDashboard",
              pharmacy: "",
              consultant,
              filename: fileContent.templatePath,
            })
          );
        }
        //Web Code End
      }
    } else {
      user = await consultantservices.getUserByUserID(user._id);
      let { currentPassword, password, confirmPassword } = req.body;

      const isMatch = consultantservices.comparePassword(
        currentPassword,
        user.password
      );
      if (mode == "api") {
        //API Code Start
        if (isMatch) {
          if (password === confirmPassword) {
            const encryptPassword =
              consultantservices.encryptPassword(password);
            const data = await consultantservices.updateById(
              user._id,
              encryptPassword
            );
            res.status(httpStatus.OK).send({
              message: "Password reset successfully",
              status: httpStatus.OK,
            });
          } else {
            res.status(httpStatus.BAD_REQUEST).send({
              message: "Password not match",
              status: httpStatus.BAD_REQUESTs,
            });
          }
        } else {
          res.status(httpStatus.BAD_REQUEST).send({
            message: "Current password not match",
            status: httpStatus.BAD_REQUESTs,
          });
        }
        //API Code End
      } else {
        //Web Code Start
        const fileContent = getViewFile(
          "consultantDashboard",
          "profile-edit.ejs"
        );
        const isMatch = consultantservices.comparePassword(
          currentPassword,
          user.password
        );
        const consultant = await consultantModel.findById(user._id);

        if (isMatch) {
          if (password === confirmPassword) {
            const encryptPassword =
              consultantservices.encryptPassword(password);
            const data = await consultantservices.updateById(
              user._id,
              encryptPassword
            );
            res.send(
              ejs.render(fileContent.file, {
                message: "Password reset successfully",
                message1: "",
                user,
                speciality,
                consultant,
                activeTab: "doctorDashboard",
                filename: fileContent.templatePath,
              })
            );
          } else {
            res.send(
              ejs.render(fileContent.file, {
                message1: "Password not match",
                message: "",
                user,
                speciality,
                activeTab: "doctorDashboard",
                pharmacy: "",
                consultant,
                filename: fileContent.templatePath,
              })
            );
          }
        } else {
          res.send(
            ejs.render(fileContent.file, {
              message1: "Current password not match",
              message: "",
              user,
              speciality,
              activeTab: "doctorDashboard",
              pharmacy: "",
              consultant,
              filename: fileContent.templatePath,
            })
          );
        }
        //Web Code End
      }
    }
  } catch (err) {
    console.log(err);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: err,
      message: "Internal server error",
    });
  }
}

export async function addRole(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const id: Types.ObjectId = new Types.ObjectId(res.get("userId"));
    const user = JSON.parse(res.get("user")!);
    const manageBooking: Array<Booking> =
      await consultantservices.myUpcomingBooking(
        id
        // parseInt(limit as string),
        // parseInt(page as string)
      );
    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = id;
    } else {
      consultantId = new Types.ObjectId(user.addedBy);
    }
    const roles: Array<Role> = await roleService.getRoles(consultantId);
    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("consultantDashboard", "add-role.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            activeTab: "addRole",
            roles,
            manageBooking,
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function viewcalender(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const id: Types.ObjectId = new Types.ObjectId(res.get("userId"));
    const user = JSON.parse(res.get("user")!);
    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = id;
    } else {
      consultantId = new Types.ObjectId(user.addedBy);
    }
    const roles: Array<Role> = await roleService.getRoles(consultantId);
    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile("consultantDashboard", "calender.ejs");
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            user,
            roles,
            activeTab: "avail",
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function videoCall(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const { limit, page } = req.query;
    if (mode == "api") {
    } else {
      //Web Code Start

      if (req.method == "GET") {
        let patientId = new Types.ObjectId(req.params.id);
        const fileContent = getViewFile("consultantDashboard", "video.ejs");
        const user: any = JSON.parse(res.get("user")!);
        const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
        let consultantId;
        if (user.addedBy == undefined) {
          consultantId = id;
        } else {
          consultantId = new Types.ObjectId(user.addedBy);
        }

        const manageBooking: Array<Booking> =
          await consultantservices.bookingGetById(
            consultantId,
            patientId
            // parseInt(limit as string),
            // parseInt(page as string)
          );

        res.send(
          ejs.render(fileContent.file, {
            message: "",
            activeTab: "chat",
            user,
            manageBooking,
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function rescheduleDateAndTime(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const user = JSON.parse(res.get("user")!);
    if (mode == "api") {
      res.status(httpStatus.OK).send({
        message: "Slot Booked Successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      const bookingData = req.body;

      const booking = new Types.ObjectId(bookingData.id);

      const updateBooking = await bookingModel.findById(booking);

      const startTime = updateBooking?.startTime;
      const endTime = updateBooking?.endTime;

      const startTimestamp: any = startTime?.getTime();

      const endTimestamp: any = endTime?.getTime();

      const timeDifference = endTimestamp - startTimestamp;

      const time = Math.floor(timeDifference / (1000 * 60));

      const fileContent = getViewFile(
        "consultantDashboard",
        "reschedule-date-time.ejs"
      );
      res.send(
        ejs.render(fileContent.file, {
          user,
          message: "",
          activeTab: "resBook",
          bookingData,
          updateBooking,
          time,
          filename: fileContent.templatePath,
        })
      );
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function icdSuggestion(req: Request, res: Response) {
  try {
    const { limit, page } = req.query;

    const { mode } = req.params;

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: "",
        message: "Booking update successfully",
        status: httpStatus.OK,
      });
    } else {
      //web code

      const medicineName = req.body.medicineName;

      const suggestions: any = await icdCodeModel.find(
        { description: { $regex: medicineName, $options: "i" } },
        "name"
      );

      const Id: Types.ObjectId = suggestions.map((e: any) => {
        return e._id;
      });

      const medicineNames = await icdCodeModel.find({ _id: Id });

      res.json({ suggestions: medicineNames });
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function medicineSuggestion(req: Request, res: Response) {
  try {
    const { limit, page } = req.query;

    const { mode } = req.params;

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: "",
        message: "Booking update successfully",
        status: httpStatus.OK,
      });
    } else {
      //web code

      const medicineName = req.body.medicineName;

      const suggestions: any = await medicineModel.find(
        { medicineName: { $regex: medicineName, $options: "i" } },
        "name"
      );

      const Id: Types.ObjectId = suggestions.map((e: any) => {
        return e._id;
      });

      const medicineNames = await medicineModel.find({ _id: Id });

      res.json({ suggestions: medicineNames });
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function getReferData(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: "",
        message: "Booking update successfully",
        status: httpStatus.OK,
      });
    } else {
      const id = req.params.id;
      if (id) {
        const document = await referModel.findOne({ doctor: id });

        if (document) {
          res.json(document);
        } else {
          res.json();
        }
      } else {
        res.json();
      }
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function viewEmail(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const user: any = JSON.parse(res.get("user")!);
    const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const manageBooking: Array<Booking> =
      await consultantservices.myUpcomingBooking(id);

    if (mode == "api") {
    } else {
      //Web Code Start
      if (req.method == "GET") {
        const fileContent = getViewFile(
          "consultantDashboard",
          "view-email.ejs"
        );
        const user: any = JSON.parse(res.get("user")!);
        res.send(
          ejs.render(fileContent.file, {
            message: "",
            activeTab: "mail",
            user,
            manageBooking,
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function voiceCall(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    const { limit, page } = req.query;
    if (mode == "api") {
    } else {
      //Web Code Start

      if (req.method == "GET") {
        let patientId = new Types.ObjectId(req.params.id);
        const fileContent = getViewFile("consultantDashboard", "voice.ejs");
        const user: any = JSON.parse(res.get("user")!);
        const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
        let consultantId;
        if (user.addedBy == undefined) {
          consultantId = id;
        } else {
          consultantId = new Types.ObjectId(user.addedBy);
        }

        const manageBooking: Array<Booking> =
          await consultantservices.bookingGetById(consultantId, patientId);

        res.send(
          ejs.render(fileContent.file, {
            message: "",
            activeTab: "chat",
            user,
            manageBooking,
            filename: fileContent.templatePath,
          })
        );
      } else {
        //Post Method Code
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}

export async function getImage(req: Request, res: Response) {
  try {
    const user: any = JSON.parse(res.get("user")!);

    const userId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const { page, limit } = req.query;
    let getImage;
    if (user.addedBy) {
      getImage = await staffModel.findById(user._id);

      log;
    } else {
      getImage = await consultantModel.findById(userId);
    }

    res.status(httpStatus.OK).send({
      data: getImage,
      message: "data fetched successfully",
      status: httpStatus.OK,
    });
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      status: httpStatus.INTERNAL_SERVER_ERROR,
      message: err.message,
    });
  }
}

export async function getRole(req: Request, res: Response) {
  try {
    const user: any = JSON.parse(res.get("user")!);

    const userId: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

    const { page, limit } = req.query;
    let getImage;
    if (user.addedBy) {
      getImage = await staffModel
        .findById(user._id)
        .populate({ path: "role", model: roleAndPermissionModel });
    } else {
      getImage = await consultantModel.findById(userId);
    }

    res.status(httpStatus.OK).send({
      data: getImage,
      message: "data fetched successfully",
      status: httpStatus.OK,
    });
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      status: httpStatus.INTERNAL_SERVER_ERROR,
      message: err.message,
    });
  }
}

export async function getBooking(req: Request, res: Response) {
  
  let id = new Types.ObjectId(req.body.id);

  const booking = await bookingModel
    .findById(id)
    .populate({ path: "doctor", model: consultantModel })
    .populate({ path: "patient", model: patientModel });

  if (booking) {
    res.json(booking);
  } else {
    res.json("No Data");
  }
}



export async function updateBooking(req: Request, res: Response) {



  const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
  const user: any = JSON.parse(res.get("user")!);

        let consultantId;
        if (user.addedBy == undefined) {
          consultantId = id;
        } else {
          consultantId = new Types.ObjectId(user.addedBy);


        }


        const bookings= await consultantservices.updateBookings(consultantId );


        const currentDate = new Date();
const threeDaysAgo = new Date(currentDate);
threeDaysAgo.setDate(currentDate.getDate() - 2);



// Filter bookings with startTime within the last three days
const filteredBookings = bookings.filter(booking => booking.startTime <= threeDaysAgo );





const Id = filteredBookings.map(async(e: any) => {

  
const data:any= await bookingModel.findByIdAndUpdate({_id:e._id},{status:"cancelled",cancelReason:"Not Attend Booking"})


 
});



  
}

