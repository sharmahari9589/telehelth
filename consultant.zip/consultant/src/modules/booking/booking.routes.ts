import { Router } from "express";
import * as bookingController from "./booking.controller";

const router: Router = Router({ mergeParams: true });

router.get("/initial", bookingController.setInitalBookingSettings);
router.get("/getBookings", bookingController.getBookings);
router.get("/reschedule/:id", bookingController.reschedule);

router
  .route("/updateStatus/:id")
  .get(bookingController.statusupdate)
  .post(bookingController.statusupdate);

router.post("/create-notes", bookingController.createNotes);

router.get("/get-notes/:id", bookingController.getNotes);

router
  .route("/send-certificate")
  .get(bookingController.sendCertifiacte)
  .post(bookingController.sendCertifiacte);

export default router;
