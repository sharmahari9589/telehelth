import { Types } from "mongoose";
import patientModel from "../patient/patient.model";
import bookingModel, { Booking, BookingStatus } from "./booking.model";

export async function setIntitalBooingSetting(consultantId: Types.ObjectId) {
  return await bookingModel.create({
    consultant: consultantId,
    availability: {
      monday: {
        isAvailable: true,
        slots: [
          {
            startTime: 8000,
            endTime: 5000,
          },
        ],
      },
      tuesday: {
        isAvailable: true,
        slots: [
          {
            startTime: 8000,
            endTime: 5000,
          },
        ],
      },
      wednesday: {
        isAvailable: true,
        slots: [
          {
            startTime: 8000,
            endTime: 5000,
          },
        ],
      },
      thursday: {
        isAvailable: true,
        slots: [
          {
            startTime: 8000,
            endTime: 5000,
          },
        ],
      },
      friday: {
        isAvailable: true,
        slots: [
          {
            startTime: 8000,
            endTime: 5000,
          },
        ],
      },
      saturday: {
        isAvailable: true,
        slots: [
          {
            startTime: 8000,
            endTime: 5000,
          },
        ],
      },
      sunday: {
        isAvailable: true,
        slots: [
          {
            startTime: 8000,
            endTime: 5000,
          },
        ],
      },
    },
    durations: [15, 30, 60],
  });
}

export async function getMyBookings(
  consultantId: Types.ObjectId
): Promise<Array<Booking>> {
  return await bookingModel.find({
    doctor: consultantId,
  });
}

export async function rescheduleBooking(
  bookingId: Types.ObjectId,
  booking: any
): Promise<Booking | null> {
  return await bookingModel.findByIdAndUpdate(bookingId, booking);
}

export async function filterListing(
  consultantId: Types.ObjectId
): Promise<Array<Booking>> {
  return await bookingModel.aggregate([
    {
      $match: {
        $and: [
          {
            doctor: consultantId,
          },
          {
            status: {
              $in: ["pending", "reschedule"],
            },
          },
        ],
      },
    },

    {
      $lookup: {
        from: "patients",
        localField: "patient",
        foreignField: "_id",
        as: "patient",
      },
    },
    {
      $unwind: {
        path: "$patient",
        preserveNullAndEmptyArrays: true,
      },
    },

    {
      $lookup: {
        from: "healthproblems",
        localField: "problem",
        foreignField: "_id",
        as: "problem",
      },
    },
    {
      $unwind: {
        path: "$problem",
        preserveNullAndEmptyArrays: true,
      },
    },
  ]);
}

export async function updatestatus(
  bookingId: Types.ObjectId,
  booking: any
): Promise<Booking | null> {
  return await bookingModel.findByIdAndUpdate(bookingId, booking);
}



export async function createNewNotes(bookingId: Types.ObjectId, notesDto: any) {
  return await bookingModel.findByIdAndUpdate(
    bookingId,
    {
      $set: {
        "notes.subjectiveSymptoms": notesDto.subjectiveSymptoms,
        "notes.objectivefinding": notesDto.objectivefinding,
        "notes.assesment": notesDto.assesment,
        "notes.planOfAction": notesDto.planOfAction,
      },
    },
    { new: true }
  );
}

export async function getNewNotes(bookingId: Types.ObjectId) {
  return await bookingModel.findById(bookingId);
}
