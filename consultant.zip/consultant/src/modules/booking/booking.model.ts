import mongoose, { Document, model, Schema, Types } from "mongoose";

export enum BookingMode {
  Online = "online",
  Offline = "offline",
}

export enum Gender {
  Male = "male",
  Female = "female",
  Other = "other",
  Transgender = "transgender",
  Notdisclosed = "notDisclosed",
}
export enum MaritialStatus {
  Married = "married",
  Single = "single",
  Partnered = "partnered",
  Divorce = "divorce",
  Widow = "widow",
  Others = "others",
  Notdisclosed = "notDisclosed",
}

export enum BookingStatus {
  Pending = "pending",
  Cancelled = "cancelled",
  Accepted = "accepted",
  Reschedule = "reschedule",
  completed = "completed",
}
export interface Booking extends Document {
  doctor: Types.ObjectId;
  problem: Types.ObjectId;
  pharmacy: Types.ObjectId;
  payment: Types.ObjectId;
 chat: Types.ObjectId;
  date: Date;
  status: BookingStatus;
  bookingId: string;
  reschedule: [{ date: Date; startTime: Date; endTime: Date }];
  startTime: Date;
  endTime: Date;
  isAccepted: boolean;
  bookingMode: BookingMode;
  patient: Types.ObjectId;
  service: Types.ObjectId;
  bookingFor: object;
  referedTo: object;
  isPaid: boolean;
  cancelReason: string;
  notes: object;
  fess: Number;
  htmlContent: string;
  title: string;
  questions: Array<Object>;
  dynamicQuestions: Array<Object>;
  allergy: string;
  gmsNo: string;
  sendCertificate: Array<object>;
}

const referSchema = new mongoose.Schema(
  {
    doctorName: {
      type: String,
    },
    department: {
      type: String,
    },
    hospitalName: {
      type: String,
    },

    location: {
      type: String,
    },
    email: {
      type: String,
    },

    mobileNumber: {
      type: String,
    },
  },
  { _id: false }
);

const bookingForSchema = new mongoose.Schema(
  {
    patientName: {
      type: String,
    },
    dateofBirth: {
      type: Date,
    },
    gender: {
      type: String,
      enum: Gender,
    },
    maritalStatus: {
      type: String,
      enum: MaritialStatus,
    },
    location: {
      type: String,
    },
    eirCode: {
      type: String,
    },

    mobileNumber: {
      type: String,
    },
  },
  { _id: false }
);

const bookingSchema = new Schema<Booking>(
  {
    doctor: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "consultant",
    },
    problem: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "healthproblem",
    },
    service: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "service",
    },
    pharmacy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "pharmacy",
    },
    patient: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "patient",
    },
    chat: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "chat",
    },
    bookingId: {
      type: String,
    },
    date: {
      type: Date,
    },
    allergy: {
      type: String,
    },
    isPaid: {
      type: Boolean,
      default: false,
    },
    fess: {
      type: Number,
    },

    status: {
      type: String,
      default: BookingStatus.Accepted,
      enum: BookingStatus,
    },
    reschedule: {
      type: [{ date: Date, startTime: Date, endTime: Date }],
      default: [],
    },
    startTime: {
      type: Date,
    },
    endTime: {
      type: Date,
    },

    isAccepted: {
      type: Boolean,
      default: false,
    },
    bookingMode: {
      type: String,
      enum: BookingMode,
    },

    cancelReason: {
      type: String,
    },
    gmsNo: {
      type: String,
    },
    sendCertificate: [
      {
        to: { type: String },
        subject: { type: String },
        attachmentPath: { type: String },
        mailTime: { type: Date },
      },
    ],

    referedTo: referSchema,

    notes: {
      subjectiveSymptoms: [String],
      objectivefinding: [String],
      assesment: [String],
      planOfAction: [String],
    },
    bookingFor: bookingForSchema,
  },
  {
    timestamps: true,
  }
);

export default model<Booking>("booking", bookingSchema);
