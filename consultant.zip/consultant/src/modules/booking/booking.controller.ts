import { Request, Response } from "express";
import httpStatus from "http-status";
import { Types } from "mongoose";
import * as bookingService from "./booking.service";
import fs from "fs";
import path from "path";

//EJS Rendor
import ejs from "ejs";
import { getViewFile } from "../../utils/ejsHelper";
import bookingModel, { Booking } from "./booking.model";
import { sendCertifiacteByMail } from "../../utils/sendMail";
import consultantModel from "../consultant/consultant.model";
import * as templateService from "../emailTemplate/template.service";
import * as consultantservices from "../consultantDashboard/consultant.services";
import referModel from "../models/refer.model";
import { Order } from "../orders/orders.model";

export async function setInitalBookingSettings(req: Request, res: Response) {
  try {
    const data = await bookingService.setIntitalBooingSetting(
      new Types.ObjectId()
    );
    res.status(200).send(data);
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ message: err.message });
  }
}

export async function getBookings(req: Request, res: Response) {
  try {
    const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);
    const user = JSON.parse(res.get("user")!);
    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = id;
    } else {
      consultantId = new Types.ObjectId(user.addedBy);
    }
    const bookings = await bookingService.filterListing(consultantId);

    if (req.params.mode == "api") {
      res.status(httpStatus.OK).send({
        data: bookings,

        message: "Bookings fetched successfully",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start

      const fileContent = getViewFile("consultantDashboard", "new-booking.ejs");
      const user: any = JSON.parse(res.get("user")!);
      res.send(
        ejs.render(fileContent.file, {
          user,
          bookings,activeTab:"doctorDashboard",
          filename: fileContent.templatePath,
        })
      );
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({ message: err.message });
  }
}

export async function reschedule(req: Request, res: Response) {
  try {
    const { mode } = req.params;

    // const consultantId: Types.ObjectId = new Types.ObjectId(req.get("userId")!);
    const bookingId: Types.ObjectId = new Types.ObjectId(req.params.id);

    const booking = await bookingService.rescheduleBooking(bookingId, req.body);

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        message: "Booking has ben reschedule",
        data: booking,
        status: httpStatus.OK,
      });
    } else {
      res.redirect("/consultant/web/booking/get-all-bookings?limit=10&page=1");
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err.message,
    });
  }
}

export async function statusupdate(req: Request, res: Response) {
  try {
    // const consultantId: Types.ObjectId = new Types.ObjectId(req.get("userId")!);
    const bookingId: Types.ObjectId = new Types.ObjectId(req.params.id);

    const booking = await bookingService.rescheduleBooking(bookingId, req.body);
    res.status(httpStatus.OK).send({
      message: "Booking status updated",
      data: booking,
      status: httpStatus.OK,
    });
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.OK).send({
      message: err.message,
    });
  }
}

export async function createNotes(req: Request, res: Response) {
  const bookingId: Types.ObjectId = new Types.ObjectId(req.body.bookingId);

  const notesDto = {
    subjectiveSymptoms: req.body.newObj.subjectiveSymptoms,
    objectivefinding: req.body.newObj.objectivefinding,
    assesment: req.body.newObj.assesment,
    planOfAction: req.body.newObj.planOfAction,
  };

  const notes = await bookingService.createNewNotes(
    bookingId as Types.ObjectId,
    notesDto as any
  );
  res.status(httpStatus.OK).json({
    message: "Notes created succesfully",
  });
}

export async function getNotes(req: Request, res: Response) {
  const bookingId: Types.ObjectId = new Types.ObjectId(req.params.id);

  const notes = await bookingService.getNewNotes(bookingId as Types.ObjectId);
  res.status(httpStatus.OK).json({
    notes,
  });
}

export async function sendCertifiacte(req: Request, res: Response) {
  const id: Types.ObjectId = new Types.ObjectId(res.get("userId")!);

  const { name, startDate, endDate } = req.query;

  const baseDir = path.join(__dirname, "../../../../");
  const filePath = path.join(
    baseDir,
    "main",
    "uploads",
    req.body.files[0].filename
  );

  let pdfContent;
  if (fs.existsSync(filePath)) {
    pdfContent = fs.readFileSync(filePath);
  } else {
    console.log("File not found:", filePath);
  }

  if (pdfContent) {
    let bbokid;
    if (req.body.booking) {
      bbokid = new Types.ObjectId(req.body.booking);
    } else {
      bbokid = req.body.bookingid;
    }
    let newData = await sendCertifiacteByMail(
      req.body.to,
      req.body.subject,
      pdfContent
    );

    if (newData.message) {
      const booking = await bookingModel.findById(bbokid);

      if (booking) {
        const sendDto = {
          to: req.body.to,
          subject: req.body.subject,
          attachmentPath: filePath,
          mailTime: new Date(),
        };
        let result = await bookingModel.findByIdAndUpdate(booking._id, {
          $push: { sendCertificate: sendDto },
        });

        if (result) {
         

          const templates = await templateService.getTemplateByAddedBy(
            id,
            name as string
          );

          const doctorDetial = await consultantModel.findById(id);

          const manageBooking: Array<Booking> =
            await consultantservices.myUpcomingBooking(
              id
              
            );
          const user: any = JSON.parse(res.get("user")!);

          let consultantId;
          if (user.addedBy == undefined) {
            consultantId = id;
          } else {
            consultantId = new Types.ObjectId(user.addedBy);
          }

          const limit = 10;
          const page = Number(req.query.page) || 1;

          const manageBookings: Array<Booking> =
            await consultantservices.getManageBooking(
              consultantId,
              limit,
              page,
              name as string,
              startDate as string,
              endDate as string
            );

          const count = await bookingModel
            .find({
              doctor: consultantId,
              status: {
                $in: ["accepted", "reschedule"],
              },
            })
            .count();

          const editprescriptions: Array<Order> =
            await consultantservices.editPrescription(consultantId);
          const referals = await referModel.find({});

          const fileContent = getViewFile(
            "consultantDashboard",
            "manage-booking.ejs"
          );
          res.send(
            ejs.render(fileContent.file, {
              message: "Mail sent Succesfully",
              user,
              manageBookings,
              editprescriptions,
              referals,activeTab:"mangBook",
              manageBooking,
              templates,
              current: page,
              doctorDetial,
              message1: "",
              pages: Math.ceil(count / limit),
              filename: fileContent.templatePath,
            })
          );
        } else {
          const templates = await templateService.getTemplateByAddedBy(
            id,
            name as string
          );

          const doctorDetial = await consultantModel.findById(id);

          const manageBooking: Array<Booking> =
            await consultantservices.myUpcomingBooking(
              id
             
            );
          const user: any = JSON.parse(res.get("user")!);

          let consultantId;
          if (user.addedBy == undefined) {
            consultantId = id;
          } else {
            consultantId = new Types.ObjectId(user.addedBy);
          }

          const limit = 10;
          const page = Number(req.query.page) || 1;

          const manageBookings: Array<Booking> =
            await consultantservices.getManageBooking(
              consultantId,
              limit,
              page,
              name as string,
              startDate as string,
              endDate as string
            );

          const count = await bookingModel
            .find({
              doctor: consultantId,
              status: {
                $in: ["accepted", "reschedule"],
              },
            })
            .count();

          const editprescriptions: Array<Order> =
            await consultantservices.editPrescription(consultantId);
          const referals = await referModel.find({});

          const fileContent = getViewFile(
            "consultantDashboard",
            "manage-booking.ejs"
          );
          res.send(
            ejs.render(fileContent.file, {
              message: "Mail content or mail attecment not found",
              user,
              manageBookings,
              editprescriptions,
              referals,activeTab:"mangBook",
              manageBooking,
              templates,
              current: page,
              doctorDetial,
              message1: "",
              pages: Math.ceil(count / limit),
              filename: fileContent.templatePath,
            })
          );
        }
      }
    }
  } else {
    const templates = await templateService.getTemplateByAddedBy(
      id,
      name as string
    );

    const doctorDetial = await consultantModel.findById(id);

    const manageBooking: Array<Booking> =
      await consultantservices.myUpcomingBooking(id);
    const user: any = JSON.parse(res.get("user")!);

    let consultantId;
    if (user.addedBy == undefined) {
      consultantId = id;
    } else {
      consultantId = new Types.ObjectId(user.addedBy);
    }

    const limit = 10;
    const page = Number(req.query.page) || 1;

    const manageBookings: Array<Booking> =
      await consultantservices.getManageBooking(
        consultantId,
        limit,
        page,
        name as string,
        startDate as string,
        endDate as string
      );

    const count = await bookingModel
      .find({
        doctor: consultantId,
        status: {
          $in: ["accepted", "reschedule"],
        },
      })
      .count();

    const editprescriptions: Array<Order> =
      await consultantservices.editPrescription(consultantId);
    const referals = await referModel.find({});

    const fileContent = getViewFile(
      "consultantDashboard",
      "manage-booking.ejs"
    );
    res.send(
      ejs.render(fileContent.file, {
        message: "Mail attachment not found",
        user,
        manageBookings,
        editprescriptions,
        referals,activeTab:"mangBook",
        manageBooking,
        templates,
        current: page,
        doctorDetial,
        message1: "",
        pages: Math.ceil(count / limit),
        filename: fileContent.templatePath,
      })
    );
  }
}
