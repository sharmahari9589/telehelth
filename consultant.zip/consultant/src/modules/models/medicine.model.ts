import { Schema, model, Document } from "mongoose";

export interface Medicine extends Document {
  medicineName: string;
  mg: string;
  description: string;
}

const medicineSchema: Schema = new Schema<Medicine>({
  medicineName: {
    type: String,
  },
  mg: {
    type: String,
  },
  description: {
    type: String,
  },
});

export default model<Medicine>("medicine", medicineSchema);
