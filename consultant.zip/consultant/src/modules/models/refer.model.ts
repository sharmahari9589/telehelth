import { Schema, model, Document } from "mongoose";

export interface Refer extends Document {
  doctor: string;
  department: string;
  hospital: string;
  location: string;
  mobileNumber: Number;
  email: string;
}

const referSchema: Schema = new Schema<Refer>({
  doctor: {
    type: String,
  },
  department: {
    type: String,
  },
  hospital: {
    type: String,
  },
  location: {
    type: String,
  },
  mobileNumber: {
    type: Number,
  },
  email: {
    type: String,
  },
});

export default model<Refer>("referal", referSchema);
