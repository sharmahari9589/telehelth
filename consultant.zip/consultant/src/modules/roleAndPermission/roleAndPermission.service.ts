import { Types } from "mongoose";
import roleAndPermissionModel, { Role } from "./roleAndPermission.model";

/**
 * @description This function is used to create the role
 * @param createRoleDto
 * @returns Promise<Role>
 * @author sourav
 */
export async function createRole(createRoleDto: any): Promise<Role> {
  return await roleAndPermissionModel.create({
    name: createRoleDto.name,
    Description: createRoleDto.Description,
    addedBy: createRoleDto.addedBy,
  });
}

/**
 * @description This function is used to get the role
 * @param query
 * @returns Promise<Role>
 * @author Meet Gajera
 */
export async function getRoles(addedBy: Types.ObjectId): Promise<Array<Role>> {
  return await roleAndPermissionModel.aggregate([
    {
      $match: {
        addedBy: addedBy,
      },
    },
    {
      $match: {
        isDeleted: false,
      },
    },
  ]);
}

/**
 * @description This function is used to update the role
 * @param roleId
 * @param updateRoleDto
 * @returns Promise<Role>
 * @author Meet Gajera
 */
export async function updateRole(
  roleId: Types.ObjectId,
  updateRoleDto: any
): Promise<Role | null> {
  return await roleAndPermissionModel.findByIdAndUpdate(roleId, updateRoleDto);
}

/**
 * @description This function is used to delete the role
 * @param roleId
 * @returns Promise<Role>
 * @author Meet Gajera
 */
export async function deleteRole(roleId: Types.ObjectId): Promise<Role | null> {
  return await roleAndPermissionModel.findByIdAndUpdate(roleId, {
    isDeleted: true,
  });
}

export async function updateRoleAcces(roleId: any, updateRoleDto: any) {
  return await roleAndPermissionModel.findByIdAndUpdate(roleId, updateRoleDto);
}

export async function getMyRoles(addedBy: Types.ObjectId) {
  return await roleAndPermissionModel.findById(addedBy);
}
