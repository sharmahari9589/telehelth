import mongoose, { Schema, Document } from "mongoose";

export interface Role extends Document {
  name: string;
  Description: string;
  isDeleted: boolean;
  permission: {
    documentCenter: {
      view: boolean;
    };
    questionnaire: {
      view: boolean;
    };
    booking: {
      view: boolean;
    };
    manageRole: {
      view: boolean;
    };
    chat: {
      view: boolean;
    };
    myCalander: {
      view: boolean;
    };
    manageTemplate: {
      view: boolean;
    };
    email: {
      view: boolean;
    };
  };
  addedBy: mongoose.Schema.Types.ObjectId;
}

const accessSchema: Schema = new mongoose.Schema(
  {
    view: {
      type: Boolean,
      default: false,
    },
  },
  { _id: false }
);

const roleSchema: Schema = new mongoose.Schema<Role>(
  {
    name: {
      type: String,
    },
    Description: {
      type: String,
    },
    permission: {
      type: {
        documentCenter: accessSchema,
        questionnaire: accessSchema,
        booking: accessSchema,
        manageRole: accessSchema,
        chat: accessSchema,
        myCalander: accessSchema,
        manageTemplate: accessSchema,
        email: accessSchema,
      },
      default: {
        documentCenter: { view: false },
        questionnaire: { view: false },
        booking: { view: false },
        manageRole: { view: false },
        chat: { view: false },
        myCalander: { view: false },
        manageTemplate: { view: false },
        email: { view: false },
      },
    },
    addedBy: {
      type: mongoose.Schema.Types.ObjectId,
    },
    isDeleted: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
    minimize: false,
  }
);

export default mongoose.model<Role>("role", roleSchema);
