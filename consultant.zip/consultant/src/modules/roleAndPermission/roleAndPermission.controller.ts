import httpStatus from "http-status";
import { Request, Response } from "express";
import * as roleService from "./roleAndPermission.service";
import { Role } from "./roleAndPermission.model";
import mongoose, { Types, ObjectId } from "mongoose";

/**
 * @description This function is for create role
 * @param req
 * @param res
 * @author sourav
 */
export async function createRole(req: Request, res: Response) {
  try {
    const { name, Description } = req.body;
    if (name == undefined && Description == undefined) {
      res.redirect("/consultant/web/addrole");
    } else {
      const addedBy: Types.ObjectId = new Types.ObjectId(res.get("userId"));

      const data: Role = await roleService.createRole({
        name: name,
        Description: Description,
        addedBy: addedBy,
      });
      res.redirect("/consultant/web/addrole");
    }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err,
    });
  }
}

/**
 * @description This function is for get role
 * @param req
 * @param res
 * @author sourav
 */
export async function getRoles(req: Request, res: Response) {
  try {
    const addedBy: Types.ObjectId = new Types.ObjectId(res.get("userId"));
    const roles: Array<Role> = await roleService.getRoles(addedBy);
    res.status(httpStatus.OK).send({
      data: roles,
      message: "Role fetched successfully",
      status: httpStatus.OK,
    });
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err,
    });
  }
}

/**
 * @description This function is for update role
 * @param req
 * @param res
 * @author sourav
 */
export async function updateRole(req: Request, res: Response) {
  try {
    const roleId: Types.ObjectId = new Types.ObjectId(req.params.id);

    const role: Role | null = await roleService.updateRole(roleId, req.body);
    res.redirect("/consultant/web/addrole");
    // }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err,
    });
  }
}

/**
 * @description This function is for delete role
 * @param req
 * @param res
 * @author sourav
 */
export async function deleteRole(req: Request, res: Response) {
  try {
    const roleId: Types.ObjectId = new Types.ObjectId(req.params.id);
    const role: Role | null = await roleService.deleteRole(roleId);
    res.redirect("/consultant/web/addrole");
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err,
    });
  }
}

export async function updateRoleAces(req: Request, res: Response) {
  try {
    const roleId = new mongoose.Types.ObjectId(req.body.id);

    const keys = Object.keys(req.body);

    keys.forEach((key) => {
      if (!Array.isArray(key)) {
        req.body[key] = req.body[key] == "on" ? true : false;
      }
    });

    const permissionDto = {
      permission: {
        chat: {
          view: req.body["chat-view"] ? true : false,
        },
        manageTemplate: {
          view: req.body["template-view"] ? true : false,
        },
        documentCenter: {
          view: req.body["documentcenter-view"] ? true : false,
        },
        questionnaire: {
          view: req.body["questionnaire-view"] ? true : false,
        },
        booking: {
          view: req.body["booking-view"] ? true : false,
        },
        manageRole: {
          view: req.body["managerole-view"] ? true : false,
        },
        myCalander: {
          view: req.body["calender-view"] ? true : false,
        },
        email: {
          view: req.body["email-view"] ? true : false,
        },
      },
    };

    const role = await roleService.updateRoleAcces(roleId, permissionDto);

    res.redirect("/consultant/web/roleaccess");
    // }
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err,
    });
  }
}

export async function getRolesById(req: Request, res: Response) {
  try {
    const id: Types.ObjectId = new Types.ObjectId(req.params.id);

    const roles = await roleService.getMyRoles(id);

    res.status(httpStatus.OK).send({
      data: roles,
      message: "Role fetched successfully",
      status: httpStatus.OK,
    });
  } catch (error) {
    console.log(error);
    const err: Error = error as Error;
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: err,
    });
  }
}
