import { Types } from "mongoose";
import emailModel, { Email } from "./email.model";
import { log } from "console";

export async function createEmail(emailDto: Object) {
    return await emailModel.create(emailDto);
  }

export async function getEmailByUserId(userid: Types.ObjectId) {
    return await emailModel.findOne({userId:userid});
  }

export async function updateEmail(
    userId: Types.ObjectId,
    updateDto:any
  ): Promise<Email | null> {
         return await emailModel.findByIdAndUpdate(userId, updateDto);
  }