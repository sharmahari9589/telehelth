import { Router } from "express";
import * as emailController from "./email.controller";

const router: Router = Router({ mergeParams: true });

//Create Template
router
  .route("/createEmail")
  .get(emailController.createEmail)
  .post(emailController.createEmail);

//Update Template
router
  .route("/createEmail")
  .get(emailController.updateEmail)
  .post(emailController.updateEmail);

export default router;
