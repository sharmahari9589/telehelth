import mongoose, { Document, model, Schema, Types } from "mongoose";

export interface Email extends Document {
  userId: Types.ObjectId;
  emailPlatform: string;
  email: string;
  appPassword: string;
}

const emailManagementSchema = new Schema<Email>(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
    },
    emailPlatform: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
    },
    appPassword: {
      type: String,
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

export default model<Email>("emailManagement", emailManagementSchema);
