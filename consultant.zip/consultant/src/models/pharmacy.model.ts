import { Schema, model, Document } from "mongoose";

export enum Gender {
  Male = "male",
   Female = "female",
   Other = "other",
   Transgender = 'transgender' ,	
   Notdisclosed	='notDisclosed'
 }
 export enum MaritialStatus {
  Married = "married",
  Single = "single",	
Partnered	='partnered',
Divorce	='divorce',
Widow	='widow',
Others	='others',	
Notdisclosed	='notDisclosed'

}

export interface Pharmacy extends Document {
  firstName:string;
  lastName:string;
  email:string;
  profilePic:string;
  certificate:string;
  password?:string;
  mobileNumber:string;
  storeName:string;
  dlNumber:string;
  cho:string;
  country:string
  eircode:string
  opening_Hours:object
   gender:Gender;
   maritialStatus:MaritialStatus;
   dateOfBirth:Date;
  description:string;
  location:any;
  isAllow:Boolean;


  
  securityQuestion:string;
  securityAnswer:string;
}

const pharmacySchema: Schema = new Schema<Pharmacy>({
  firstName: {
    type:String,
  },
  lastName: {
    type:String,
  },
  storeName: {
    type:String,
  },

  email: {
    type:String,
    unique:true,
    required:true,
  },
  password: {
    type:String,
    required:true,
  },
  mobileNumber: {
    type:String,
  },
  profilePic: {
    type:String
  },
  certificate: {
    type:String
  },

  gender: {
    type:String,
    enum:Gender,
  },
  maritialStatus: {
    type:String,
    enum:MaritialStatus,
  },
  dateOfBirth: {
    type:Date,
  },
  description: {
    type:String,
  },
  location: {
    type:String,
  },
  cho: {
    type:String,
  },
country: {
    type:String,
  },
  dlNumber: {
    type:String,
  },
  isAllow:{
    type :Boolean,
    default :false
  },
  eircode: {
    type:String,
  },
  opening_Hours: {

    type:{
    Mon:String,
    Tue:String,
    Wed:String,
    Thu:String,
    Fri:String,
    Sat:String,
    Sun:String,

    }
  },
  securityQuestion:{
    type:String
  },
  securityAnswer:{
    type:String
  }
},{
  timestamps:true
});


export default model<Pharmacy>("pharmacy", pharmacySchema);
