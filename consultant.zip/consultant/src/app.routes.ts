import { Router } from "express";
import consultantRoutes from "./modules/consultantDashboard/consultant.routes";
import bookingRoutes from "./modules/booking/booking.routes";
import scheduleRoutes from "./modules/schedule/schedule.routes";
import verify, * as authorization from "./middleware/jwtAuth";
import appRouter from "./modules/consultant/consultant.routes";
import documentRoute from "./modules/documentcenter/document.routes";
import serviceRoute from "./modules/services/services.routes";
import questionnaireRoutes from "./modules/questionnaire/questionnaire.routes";

import roleRouter from "./modules/roleAndPermission/roleAndPermission.routes";
import staffRouter from "./modules/staff/staff.routes";
import templeteRoutes from "./modules/emailTemplate/template.routes";
import chatRoutes from "./modules/chat/chat.routes";
import notificationRoutes from "./modules/notification/notification.routes";
import setEmailRoutes from "./modules/emailManagement/email.routes";

const router = Router();
router.use(authorization.default);
router.use(verify);

router.use("/:mode/schedule", scheduleRoutes);
router.use("/:mode/bookings", bookingRoutes);

router.use("/:mode", consultantRoutes);

router.use("/:mode", setEmailRoutes);
router.use("/:mode", notificationRoutes);

router.use("/:mode", chatRoutes);
router.use("/:mode", documentRoute);
router.use("/:mode", roleRouter);
router.use("/:mode", staffRouter);

router.use("/:mode", serviceRoute);
router.use("/:mode", templeteRoutes);

router.use("/:mode", questionnaireRoutes);

export default router;
