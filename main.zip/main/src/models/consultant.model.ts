import mongoose, { Schema, model, Document } from "mongoose";

export enum Gender {
  Male = "male",
   Female = "female",
   Other = "other",
   Transgender = 'transgender' ,	
   Notdisclosed	='notDisclosed'
 }
 export enum MaritialStatus {
  Married = "married",
  Single = "single",	
Partnered	='partnered',
Divorce	='divorce',
Widow	='widow',
Others	='others',	
Notdisclosed	='notDisclosed'

}
export interface Consultant extends Document {
  firstName: string;
  lastName: string;
  email: string;
  password?: string;
  mobileNumber: string;
  gender: Gender;
  maritialStatus: MaritialStatus;
  dateOfBirth: Date;
  experience: Array<string>;
  certificate: Array<string>;
  speciality: Array<string>;
  description: string;
  location: any;
  isDeleted: boolean;
  role:{
    permission: 
    {
    documentCenter: {
      view: boolean;
    };
    questionnaire: {
      view: boolean;
    };
    booking: {
      view: boolean;
    };
    manageRole: {
      view: boolean;
    };
    template: {
      view: boolean;
    };
    email: {
      view: boolean;
    };
    myCalander: {
      view: boolean;
    };
    chat: {
      view: boolean;
    }}  
  };
  isAllow:Boolean;
  securityQuestion:string;
  securityAnswer:string;
}

const accessSchema: Schema = new mongoose.Schema({
  create:{
    type:Boolean,
    default:true
  },
view:{
  type:Boolean,
  default:true
},
update:{
type:Boolean,
default:true
},delete:{
type:Boolean,
default:true
}
},{_id:false});

const consultantSchema: Schema = new Schema<Consultant>({
  firstName: {
    type: String,
  },
  lastName: {
    type: String,
  },
  email: {
    type: String,
    unique: true,
    required: true,
  },
  password: {
    type: String,
    required: true,
  },
  mobileNumber: {
    type: String,
  },
  gender: {
    type: String,
    enum: Gender,
  },
  maritialStatus: {
    type: String,
    enum: MaritialStatus,
  },
  dateOfBirth: {
    type: Date,
  },
  experience: {
    type: [{ type: String }],
  },
  certificate: {
    type: [{ type: String }],
  },
  speciality: {
    type: [{ type: String }],
  },
  description: {
    type: String,
  },
  location: {
    type: {
      type: String, // Don't do `{ location: { type: String } }`
      enum: ["Point"], // 'location.type' must be 'Point'
    },
    coordinates: {
      type: [Number],
    },
  },
  isDeleted: {
    type: Boolean,
  },
  role:{
    permission: {
      type: {
        documentCenter: accessSchema,
        questionnaire: accessSchema,
        booking: accessSchema,
        manageRole: accessSchema,
        template: accessSchema,
        chat: accessSchema,
        email: accessSchema,
        myCalander: accessSchema,
      },
      default: {
        documentCenter: { view: true },
        questionnaire: { view: true },
        booking: { view: true },
        manageRole: { view: true },
        template: { view: true },
        chat: { view: true },
        myCalander: { view: true },
        email: { view: true },
      },
  }
  },
  isAllow:{
    type : Boolean,
    default : false
  },
  securityQuestion:{
    type:String
  },
  securityAnswer:{
    type:String
  }
},{
  timestamps:true
});

export default model<Consultant>("doctor", consultantSchema);
