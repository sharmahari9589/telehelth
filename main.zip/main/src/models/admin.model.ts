import mongoose, { Document, Schema } from "mongoose";

export interface Admin extends Document {
  firstName: string;
  lastName: string;
  email: string;
  password?: string;
  isAllow: Boolean;
  role: {
    permission: {
      patients: {
        view: boolean;
      };
      consultant: {
        view: boolean;
      };
      pharmacy: {
        view: boolean;
      };
      documentCenter: {
        view: boolean;
      };
      questionnaire: {
        view: boolean;
      };
      booking: {
        view: boolean;
      };
      manageRole: {
        view: boolean;
      };
      masterData: {
        view: boolean;
      };
      settings: {
        view: boolean;
      };
      template: {
        view: boolean;
      };
      order: {
        view: boolean;
      };
      medicine: {
        view: boolean;
      };
      email: {
        view: boolean;
      };
      referal: {
        view: boolean;
      };
      ICD: {
        view: boolean;
      };
    };
  };
}

const accessSchema: Schema = new mongoose.Schema(
  {
    view: {
      type: Boolean,
      default: true,
    },
  },
  { _id: true }
);

const adminSchema: mongoose.Schema = new mongoose.Schema<Admin>({
  firstName: {
    type: String,
  },
  lastName: {
    type: String,
  },
  email: {
    type: String,
  },
  password: {
    type: String,
  },
  isAllow: {
    type: Boolean,
    default: true,
  },
  role: {
    permission: {
      type: {
        patients: accessSchema,
        consultant: accessSchema,
        pharmacy: accessSchema,
        documentCenter: accessSchema,
        questionnaire: accessSchema,
        booking: accessSchema,
        manageRole: accessSchema,
        masterData: accessSchema,
        settings: accessSchema,
        template: accessSchema,
        order: accessSchema,
        medicine: accessSchema,
        email: accessSchema,
        referal: accessSchema,
        ICD: accessSchema,
      },
      default: {
        patients: { view: true },
        consultant: { view: true },
        pharmacy: { view: true },
        documentCenter: { view: true },
        questionnaire: { view: true },
        booking: { view: true },
        manageRole: { view: true },
        masterData: { view: true },
        settings: { view: true },
        template: { view: true },
        order: { view: true },
        medicine: { view: true },
        email: { view: true },
        referal: { view: true },
        ICD: { view: true },
      },
    },
  },
});

export default mongoose.model<Admin>("admin", adminSchema);
