import { Request, Response } from "express";
import * as authenticationService from "./authentication.service";
import consultantModel, { Consultant } from "./models/consultant.model";
import patientModel, { Patient } from "./models/patient.model";
import adminModel, { Admin } from "./models/admin.model";
import staffModel, { Staff } from "./models/staff.model";
import httpStatus from "http-status";
import pharmacyModel, { Pharmacy } from "./models/pharmacy.model";
import moment from "moment";

import * as mailService from "../../services/mail.service";
//EJS Render
import ejs from "ejs";
import { getViewFile } from "../../utils/ejsHelper";
import { Types } from "mongoose";
import otpModel from "./models/otp.model";
import { sendMail } from "../../utils//sendMail"
import {updateStatusInactive, updateUserStatus} from "../../middleware/changeStatus";
import roleModel from "./models/role.model";
import specialityModel from "./models/speciality.model";
import fileUpload from "../../middleware/fileUpload";
import * as notification  from "../notification/notification.controller"
import eirModel from "./models/eir-model";

/**
 * @description This Function is Used For Signup
 * @param {Request} req
 * @param {Response} res
 * @author Keshav Suman
 */
export async function signin(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { email, password, dashboardType } = req.body;
    if (mode == "api") {
      switch (dashboardType) {
        case "pharmacy":
          const pharmacy = await authenticationService.getPharmacyByEmail(
            email
          );
          if (pharmacy) {
            if (
              authenticationService.comparePassword(
                password,
                pharmacy.password!
              )
            ) {
              delete pharmacy.password;
              res.status(httpStatus.OK).send({
                data: {
                  user: pharmacy,
                  token: authenticationService.generateToken(
                    pharmacy.toObject(),
                    "authentication","pharmacy"
                  ),
                },
                message: "Login successfully",
                status: httpStatus.OK,
              });
            } else {
              res.status(httpStatus.BAD_REQUEST).send({
                message: "Password invalid",
                status: httpStatus.BAD_REQUESTs,
              });
            }
          } else {
            res.status(httpStatus.BAD_REQUEST).send({
              message: "User with this credentials not found",
              status: httpStatus.BAD_REQUESTs,
            });
          }
          break;
        case "patient":
          const patient: Patient | null =
            await authenticationService.getPatientByEmail(email);
          if (patient) {
            if (
              authenticationService.comparePassword(password, patient.password!)
            ) {
              delete patient.password;
              res.status(httpStatus.OK).send({
                data: {
                  user: patient,
                  token: authenticationService.generateToken(
                    patient.toObject(),
                    "authentication","patient"
                  ),
                },
                message: "Login successfully",
                status: httpStatus.OK,
              });
            } else {
              res.status(httpStatus.BAD_REQUEST).send({
                message: "Password invalid",
                status: httpStatus.BAD_REQUESTs,
              });
            }
          } else {
            res.status(httpStatus.BAD_REQUEST).send({
              message: "User with this credentials not found",
              status: httpStatus.BAD_REQUESTs,
            });
          }
          break;
        case "doctor":
          const consultant: Consultant | null =
            await authenticationService.getConsultantByEmail(email);
          if (consultant) {
            if (
              authenticationService.comparePassword(
                password,
                consultant.password!
              )
            ) {
              delete consultant.password;
              res.status(httpStatus.OK).send({
                data: {
                  user: consultant.toObject(),
                  token: authenticationService.generateToken(
                    consultant.toObject(),
                    "authentication","doctor"
                  ),
                },
                message: "Login successfully",
                status: httpStatus.OK,
              });
            } else {
              res.status(httpStatus.BAD_REQUEST).send({
                message: "Password invalid",
                status: httpStatus.BAD_REQUESTs,
              });
            }
          } else {
            res.status(httpStatus.BAD_REQUEST).send({
              message: "User with this credentials not found",
              status: httpStatus.BAD_REQUESTs,
            });
          }
          break;
        case "admin":
          const admin: Admin | null =
            await authenticationService.getAdminByEmail(email);
          if (admin) {
            if (
              authenticationService.comparePassword(password, admin.password!)
            ) {
              delete admin.password;
              res.status(httpStatus.OK).send({
                data: {
                  user: admin,
                  token: authenticationService.generateToken(
                    admin.toObject(),
                    "authentication","admin"
                  ),
                },
                message: "Login successfully",
                status: httpStatus.OK,
              });
            } else {
              res.status(httpStatus.BAD_REQUEST).send({
                message: "Password invalid",
                status: httpStatus.BAD_REQUESTs,
              });
            }
          } else {
            res.status(httpStatus.BAD_REQUEST).send({
              message: "User with this credentials not found",
              status: httpStatus.BAD_REQUESTs,
            });
          }
          break;
        case "staff":
          const staff: Staff | null =
            await authenticationService.getStaffByEmail(email);
          if (staff) {
            if (
              authenticationService.comparePassword(password, staff.password!)
            ) {
              delete staff.password;
              res.status(httpStatus.OK).send({
                data: {
                  user: staff,
                  token: authenticationService.generateToken(
                    staff.toObject(),
                    "authentication","staff"
                  ),
                },
                message: "Login successfully",
                status: httpStatus.OK,
              });
            } else {
              res.status(httpStatus.BAD_REQUEST).send({
                message: "Password invalid",
                status: httpStatus.BAD_REQUESTs,
              });
            }
          } else {
            res.status(httpStatus.BAD_REQUEST).send({
              message: "User with this credentials not found",
              status: httpStatus.BAD_REQUESTs,
            });
          }
          break;
        default:
          res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
            message: "Invalid URL",
          });
          break;
      }
    } else {
      //Web Code Start
      if (req.method == "GET") {
        res.send(
          ejs.render(getViewFile("authentication", "sign-in.ejs").file, {
            message: "",dropdownValue:req.body.dashboardType,
            emailValue:req.body.email,passwordValue:req.body.password,message1: ""
          })
        );
      } else {

        
        
        
        //POST Condition
        switch (dashboardType) {
          case "pharmacy":
            const pharmacy = await authenticationService.getPharmacyByEmail(
              email
            );


            if (pharmacy) {
              //Test Code Nikhil
            const userId = pharmacy._id
            //Test Code Nikhil
            if(pharmacy.restricLogin == true){

              res.send(
                ejs.render(getViewFile("authentication", "sign-in.ejs").file, {
                  message: "Login Restricition By Admin ",message1: "",
                  dropdownValue:req.body.dashboardType,emailValue:req.body.email,passwordValue:req.body.password
                })
              );
              return

            }



              if (
                authenticationService.comparePassword(
                  password,
                  pharmacy.password!
                )
              ) {

            await sendOtp(email, userId) 

                pharmacy.password = undefined;

                
                  
                 res.redirect(`/authentication/web/otp/${userId}/${dashboardType}`)
                  //.redirect("/pharmacy/web/");
              } else {
                res.send(
                  ejs.render(
                    getViewFile("authentication", "sign-in.ejs").file,
                    {
                      message: "Password invalid", message1: "",
                      dropdownValue:req.body.dashboardType,emailValue:req.body.email,passwordValue:req.body.password
                    }
                  )
                );
              }
            } else {
              res.send(
                ejs.render(getViewFile("authentication", "sign-in.ejs").file, {
                  message: "User with this credentials not found",message1: "",
                  dropdownValue:req.body.dashboardType,emailValue:req.body.email,passwordValue:req.body.password
                })
              );
            }
            break;
          case "patient":
            const patient: Patient | null =
              await authenticationService.getPatientByEmail(email);

              
            if (patient) {
              //Test Code Nikhil
            const userId = patient._id
            //Test Code Nikhil


          
            
              if (
                authenticationService.comparePassword(
                  password,
                  patient.password!
                )
              )
               {
          await   sendOtp(email, userId) 

                // patient.password = undefined;
              updateUserStatus(patient,"patient")
                res.redirect(`/authentication/web/otp/${userId}/${dashboardType}`)
                  //.redirect("/patient/web/");
              }
              
               else {
                res.send(
                  ejs.render(
                    getViewFile("authentication", "sign-in.ejs").file,
                    {
                      message: "Password invalid",message1: "",
                      dropdownValue:req.body.dashboardType,emailValue:req.body.email,passwordValue:req.body.password
                    }
                  )
                );
              }
            } else {
              res.send(
                ejs.render(getViewFile("authentication", "sign-in.ejs").file, {
                  message: "User with this credentials not found",message1: "",
                  dropdownValue:req.body.dashboardType,emailValue:req.body.email,passwordValue:req.body.password
                })
              );
            }
            break;
          case "doctor":
            const consultant: Consultant | null =
              await authenticationService.getConsultantByEmail(email);
            if (consultant) {

              function getCurrentDateInUTC() {
                const now = new Date();
                const utcDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(), 0, 0, 0, 0));
                return utcDate.toISOString();
              }
              
              const currentDateInUTC = getCurrentDateInUTC();
             
              const x= new Date( currentDateInUTC)
           
             
             
             
              if(consultant?.medicalCouncilExpiryDate?.getTime()<=x.getTime() &&  consultant?.indemnityExpiryDate?.getTime()<= x.getTime()){

                res.send(
                  ejs.render(getViewFile("authentication", "reUploadDoc.ejs").file, {
                    message: "Your certificate is expired please upload new one.",message1: "",
                    email
                  })
                );
                return

              }

              if(consultant.restricLogin == true){

                res.send(
                  ejs.render(getViewFile("authentication", "sign-in.ejs").file, {
                    message: "Login Restricition By Admin ",message1: "",
                    dropdownValue:req.body.dashboardType,emailValue:req.body.email,passwordValue:req.body.password
                  })
                );
                return

              }
            //Test Code Nikhil
            const userId = consultant._id
            //Test Code Nikhil
           
            if (
                authenticationService.comparePassword(
                  password,
                  consultant.password!
                )
              ) {

                sendOtp(email, userId) 

                consultant.password = undefined;
              updateUserStatus(consultant,"doctor")


                  //.redirect("/consultant/web/");
                 res .redirect(`/authentication/web/otp/${userId}/${dashboardType}`)
              } else {
                res.send(
                  ejs.render(
                    getViewFile("authentication", "sign-in.ejs").file,
                    {
                      message: "Password invalid",message1: "",
                      dropdownValue:req.body.dashboardType,emailValue:req.body.email,passwordValue:req.body.password
                    }
                  )
                );
              }
            } else {
              res.send(
                ejs.render(getViewFile("authentication", "sign-in.ejs").file, {
                  message: "User with this credentials not found",message1: "",
                  dropdownValue:req.body.dashboardType,emailValue:req.body.email,passwordValue:req.body.password
                })
              );
            }
            break;
          case "admin":
            const admin: Admin | null =
              await authenticationService.getAdminByEmail(email);
            if (admin) {
                //Test Code Nikhil
            const userId = admin._id
            //Test Code Nikhil
              if (
                authenticationService.comparePassword(password, admin.password!)
              ) {

            sendOtp(email, userId) 

                admin.password = undefined;
                res.redirect(`/authentication/web/otp/${userId}/${dashboardType}`)
                  //.redirect("/admin/web/");
              } else {
                res.send(
                  ejs.render(
                    getViewFile("authentication", "sign-in.ejs").file,
                    {
                      message: "Password invalid",message1: "",
                      dropdownValue:req.body.dashboardType,emailValue:req.body.email,passwordValue:req.body.password
                    }
                  )
                );
              }
            } else {
              res.send(
                ejs.render(getViewFile("authentication", "sign-in.ejs").file, {
                  message: "User with this credentials not found",message1: "",
                  dropdownValue:req.body.dashboardType,emailValue:req.body.email,passwordValue:req.body.password
                })
              );
            }
            break;
            // staff case
            case "staff":
              const staff: Staff | null =
                await authenticationService.getStaffByEmail(email);
              if (staff) {
                const userId = staff._id
                if (
                  authenticationService.comparePassword(password, staff.password!)
                ) {

                sendOtp(email, userId) 

                  staff.password = undefined;
                const consultant =  await consultantModel.findById(staff.addedBy);
                if(consultant){
               
        const dashboardType="doctor"
                     
                 
                    // .redirect('/consultant/web/');
                  res.redirect(`/authentication/web/otp/${userId}/${dashboardType}`)
       
                    }else{
                       const admin = await adminModel.findById(staff.addedBy);
        const dashboardType="admin"

                     
                    // .redirect('/admin/web/');
                    res.redirect(`/authentication/web/otp/${userId}/${dashboardType}`)



                    }
                    // .redirect("/admin/web/");
                } else {
                  res.send(
                    ejs.render(
                      getViewFile("authentication", "sign-in.ejs").file,
                      {
                        message: "Password invalid",message1: "",
                        dropdownValue:req.body.dashboardType,emailValue:req.body.email,passwordValue:req.body.password
                      }
                    )
                  );
                }
              } else {
                res.send(
                  ejs.render(getViewFile("authentication", "sign-in.ejs").file, {
                    message: "User with this credentials not found",message1: "",
                    dropdownValue:req.body.dashboardType,emailValue:req.body.email,passwordValue:req.body.password
                  })
                );
              }
              break;
  
          default:
            res.send(
              ejs.render(getViewFile("authentication", "sign-in.ejs").file, {
                message: "Invalid URL",message1: "",
              })
            );
            break;
        }
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: error,
      status: httpStatus.INTERNAL_SERVER_ERROR,
    });
  }
}

/**
 * @description This function is for Signup
 * @param {Request} req
 * @param {Request} res
 * @author Keshav Suman
 */
export async function signup(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    
    
    const { email, password, confirmpassword, 
      dashboardType,patientEmail,patientPassword,patientConfirmpassword,
      doctorEmail,doctorPassword,doctorConfirmpassword,
      pharmacyPassword,pharmacyConfirmpassword,pharmacyEmail
     } = req.body;

 

   

    if (mode == "api") {
    
      switch (dashboardType) {
        case "pharmacy":
          let pharmacy: Pharmacy | null =
            await authenticationService.getPharmacyByEmail(email);
          if (pharmacy) {
            res.status(httpStatus.BAD_REQUEST).send({
              message: "User with this email already exists",
              status: httpStatus.BAD_REQUEST,
            });
          } else {
            const names = req.body.name.split(" ");
            const createPharmacyDto = {
              firstName: names.splice(0, 1).join(""),
              lastName: names.join(" "),
              email: req.body.email,
              gender: req.body.gender,
              dateOfBirth: req.body.dateOfBirth,
              mobileNumber: req.body.mobileNumber,
              password: req.body.password,
            };
            
            pharmacy = await authenticationService.createPharmacy(
              createPharmacyDto
            );
            res.status(httpStatus.OK).send({
              data: {
                user: pharmacy.toObject(),
                token: authenticationService.generateToken(
                  pharmacy.toObject(),
                  "authentication","pharmacy"
                ),
              },
              message: "User created successfully",
              status: httpStatus.OK,
            });
          }
          break;
        case "patient":
          let patient: Patient | null =
            await authenticationService.getPatientByEmail(email);
          if (patient) {
            res.status(httpStatus.BAD_REQUEST).send({
              message: "User with this email already exists",
              status: httpStatus.BAD_REQUEST,
            });
          } else {
            patient = await authenticationService.createPatient(req.body);
            res.status(httpStatus.OK).send({
              data: {
                user: patient.toObject(),
                token: authenticationService.generateToken(
                  patient.toObject(),
                  "authentication","patient"
                ),
              },
              message: "User created successfully",
              status: httpStatus.OK,
            });
          }
          break;
        case "doctor":
          let consultant: Consultant | null =
            await authenticationService.getConsultantByEmail(email);
          if (consultant) {
            res.status(httpStatus.BAD_REQUEST).send({
              message: "User with this email already exists",
              status: httpStatus.BAD_REQUEST,
            });
          } else {
            consultant = await authenticationService.createConsultant(req.body);
            res.status(httpStatus.OK).send({
              data: {
                user: consultant.toObject(),
                token: authenticationService.generateToken(
                  consultant.toObject(),
                  "authentication","doctor"
                ),
              },
              message: "User created successfully",
              status: httpStatus.OK,
            });
          }
          break;
        case "admin":
          break;
        default:
      }
    } else {
      //Web Code Start

      const speciality= await specialityModel.find()
      if (req.method == "GET") {
        res.send(
          ejs.render(getViewFile("authentication", "sign-up.ejs").file, {
            message: "",body:req.body, speciality,message1: "",
          })
        );
      } else {
        // Post Method


        switch (dashboardType) {

          case "":

          res.send(
            ejs.render(getViewFile("authentication", "sign-up.ejs").file, {
              message: "Select Role",message1: "",  speciality
            })
          );
        
        break;
      

          case "pharmacy":

         
          


          if (pharmacyPassword !== pharmacyConfirmpassword) {
            res.send(
                   ejs.render(getViewFile("authentication", "sign-up.ejs").file, {
                     message: "Password and confirmPassword doesn`t matched",body:req.body, 
                     message1: "",speciality
                   })
                 );
              
           
               return
             }
            let pharmacy: Pharmacy | null =
              await authenticationService.getPharmacyByEmail(pharmacyEmail);
            if (pharmacy) {
              res.send(
                ejs.render(getViewFile("authentication", "sign-up.ejs").file, {
                  message: "User with this email already exists",body:req.body,
                  message1: "", speciality
                })
              );
            } else {

              const newv:any = req.files
              //const documentURL =   "/" + req.body?.files[0]?.path;
              const documentURL =    newv[0].path;

        
              
              await sendOtp(pharmacyEmail,dashboardType) 
        

              res.send(
                ejs.render(getViewFile("authentication", "signup-otp.ejs").file, {
                  message: "",documentURL,dashboardType:req.body.dashboardType, fullName:req.body.pharmacyName,
                  email:req.body.pharmacyEmail,gender:req.body.pharmacyGender,dob:req.body.pharmacyDateOfBirth,message1: "",
                  mobileNumber:req.body.pharmaMobileNumber,password:req.body.pharmacyPassword,confirmpassword:req.body.pharmacyConfirmpassword,
                  securityQuestion:req.body.pharmacySecurityQuestion,securityAnswer:req.body.pharmacySecurityAnswer,eirCode:"",
                  medicalDegree:"",specialistDegree:"",indemnityCertificate:"",medicalCouncilCertificate:"",cctCertification:"",medicalCouncilExpiryDate:"",indemnityExpiryDate:"",speciality:"",
                })
              );
            }
            break;

          case "patient":


          if (patientPassword !== patientConfirmpassword) {
         res.send(
                ejs.render(getViewFile("authentication", "sign-up.ejs").file, {
                  message: "Password and confirmPassword doesn`t matched",body:req.body,message1: "", speciality
                })
              );
           
        
            return
          }
            let patient: Patient | null =
              await authenticationService.getPatientByEmail(patientEmail);
            if ( patient) {
              res.send(
                ejs.render(getViewFile("authentication", "sign-up.ejs").file, {
                  message: "Patient with this email already exists",message1: "",body:req.body, speciality
                })
              );
            } else {


                
              await sendOtp(patientEmail,dashboardType) 
        

              res.send(
                ejs.render(getViewFile("authentication", "signup-otp.ejs").file, {
                  message: "",documentURL:"",dashboardType:req.body.dashboardType, fullName:req.body.patientName,
                  email:req.body.patientEmail,gender:req.body.patientGender,dob:req.body.patientDob,message1: "",
                  mobileNumber:req.body.PatientMobileNumber,password:req.body.patientPassword,confirmpassword:req.body.patientConfirmpassword,
                  securityQuestion:req.body.patientSecurityQuestion,securityAnswer:req.body.patientSecurityAnswer,eirCode:req.body.patientCode,
                  medicalDegree:"",specialistDegree:"",indemnityCertificate:"",medicalCouncilCertificate:"",cctCertification:"",medicalCouncilExpiryDate:"",indemnityExpiryDate:"",speciality:"",

                })
              );



            }
            break;
          case "doctor":


          if (doctorPassword !== doctorConfirmpassword) {
            res.send(
                   ejs.render(getViewFile("authentication", "sign-up.ejs").file, {
                     message: "Password and confirmPassword doesn`t matched",body:req.body,
                     message1: "", speciality
                   })
                 );
              
           
               return
             }


            let consultant: Consultant | null =
              await authenticationService.getConsultantByEmail(doctorEmail);
            if (consultant) {
              res.send(
                ejs.render(getViewFile("authentication", "sign-up.ejs").file, {
                  message: "Doctor with this email already exists",body:req.body, 
                  message1: "",speciality
                })
              );
            } else {
           
          
         
              const newv:any = req.files
              const medicalDegree =    newv[0].path;
              const specialistDegree =    newv[1].path;
              const indemnityCertificate =    newv[2].path;
              const medicalCouncilCertificate =    newv[3].path;
              const cctCertification =    newv[4].path;

          
                   
              await sendOtp(doctorEmail,dashboardType) 
        

              res.send(
                ejs.render(getViewFile("authentication", "signup-otp.ejs").file, {
                  message: "",medicalDegree,specialistDegree,indemnityCertificate,medicalCouncilCertificate,cctCertification,medicalCouncilExpiryDate:req.body.medicalExpirayDate,indemnityExpiryDate:req.body.indemintyDate,speciality:req.body.doctorSpeciality, documentURL:"",dashboardType:req.body.dashboardType, fullName:req.body.dcotorName,
                  email:req.body.doctorEmail,gender:req.body.doctorGender,dob:req.body.doctorDateOfBirth,message1: "",
                  mobileNumber:req.body.doctorMobileNumber,password:req.body.doctorPassword,confirmpassword:req.body.doctorConfirmpassword,
                  securityQuestion:req.body.doctorSecurityQuestion,securityAnswer:req.body.doctorsecurityAnswer,eirCode:"", 
                })
              );



            }
              







              
            break;
          case "admin":
            break;
          default:
        }
        //Post Method End
      }
      //Web Code End
    }
  } catch (error) {
    console.log(error);
  }
}

/**
 * @description This function is for Forget Password
 * @param {Request} req
 * @param {Request} res
 * @author Keshav Suman
 */
export async function forgetPassword(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { dashboardType, email,securityQuestion,securityAnswer } = req.body;
    let user: any;
    let userId: any;
    let userType:any;
    if (mode == "api") {
      switch (dashboardType) {
        case "pharmacy":
          user = await authenticationService.getPharmacyByEmail(email);
          break;
        case "patient":
          user = await authenticationService.getPatientByEmail(email);
          break;
        case "doctor":
          user = await authenticationService.getConsultantByEmail(email);
          break;
        case "admin":
          user = await authenticationService.getAdminByEmail(email);
          break;
      }
      if (!user) {
        res.status(httpStatus.BAD_REQUEST).send({
          message: "User doesn't exists with email",
          status: httpStatus.BAD_REQUEST,
        });
        return;
      }
      const otp: string = authenticationService.generateOTP();
      await authenticationService.saveOTP(user._id, dashboardType, otp);
      await mailService.sendMail(user.email, "Reset Password", otp);
      const token = authenticationService.generateToken(
        user.toObject(),
        "reset-password",user
      );
      res.status(httpStatus.OK).send({
        data: token,
        message: "OTP sent to your mail",
        status: httpStatus.OK,
      });
    } else {
      //Web Code Start
      if (req.method == "GET") {
        res.send(
          ejs.render(
            getViewFile("authentication", "forget-password.ejs").file,
            {
              message: "",message1: "",
            }
          )
        );
      } else {
        //Post Method 
        
        switch (dashboardType) {
          case "pharmacy":
            user = await authenticationService.getPharmacyByEmail(email);


    // Check if the user exists
    if (!user) {
      
      res.send(
        ejs.render(
          getViewFile("authentication", "forget-password.ejs").file,
          {
            message: "email is not valid",message1: "",
          }
        )
      );
    }

    // Check if security question and answer match
    if (
      user.securityQuestion !== securityQuestion ||
      user.securityAnswer !== securityAnswer
    ) {
      res.send(
        ejs.render(
          getViewFile("authentication", "forget-password.ejs").file,
          {
            message: 'Invalid security question or answer',message1: "",
          }
        )
      );
    }
else{
    userId=user

     userType=user._id

    sendOtp(email, user?._id) 



    // Generate a temporary password (you can use any password generatio…

 res.send(
        ejs.render(
          getViewFile("authentication", "enter-otp.ejs").file,
          {
            message1: " Otp Successfully send  on Your Email",
            email,user,userId,userType,dashboard:"",dashboardType,message: "",
          }
        )
      );
        
    
        }

            break;

          case "patient":
         user = await authenticationService.getPatientByEmail(email);
        
            
            
            
    // Check if the user exists
    if (!user) {
      
      res.send(
        ejs.render(
          getViewFile("authentication", "forget-password.ejs").file,
          {
            message: "email is not valid",message1: "",
          }
        )
      );
      
    }

  
    ;

    // Check if security question and answer match
    if (
      user.securityAnswer !== securityAnswer ||
      user.securityQuestion !== securityQuestion
     
    ) {


      res.send(
        ejs.render(
          getViewFile("authentication", "forget-password.ejs").file,
          {
            message: 'Invalid security question or answer',message1: "",
          }
        )
      );
      
    }

    else{


      userId=user
 
     userType=user._id
 
     sendOtp(email, user?._id) 
 
 
 
     // Generate a temporary password (you can use any password generatio…
 
  res.send(
         ejs.render(
           getViewFile("authentication", "enter-otp.ejs").file,
           {
             message1: " Otp Successfully send  on Your Email",message: "",
             email,user,userId,userType,dashboard:"",dashboardType
           }
         )
       );
       
         }

   
    


            break;
          case "doctor":
            user = await authenticationService.getConsultantByEmail(email);
            
    // Check if the user exists
    if (!user) {
      
      res.send(
        ejs.render(
          getViewFile("authentication", "forget-password.ejs").file,
          {
            message: "email is not valid",message1: "",
          }
        )
      );
    }

    // Check if security question and answer match
    if (
      user.securityQuestion !== securityQuestion ||
      user.securityAnswer !== securityAnswer
    ) {
      res.send(
        ejs.render(
          getViewFile("authentication", "forget-password.ejs").file,
          {
            message: 'Invalid security question or answer',message1: "",
          }
        )
      );
    }
    else{
    userId=user

     userType=user._id

    sendOtp(email, user?._id) 



    // Generate a temporary password (you can use any password generatio…

 res.send(
        ejs.render(
          getViewFile("authentication", "enter-otp.ejs").file,
          {
            message1: " Otp Successfully send  on Your Email",message: "",
            email,user,userId,userType,dashboard:"",dashboardType
          }
        )
      );
        
        }
            break;
          case "admin":
            user = await authenticationService.getAdminByEmail(email);
            
    // Check if the user exists
    if (!user) {
      
      res.send(
        ejs.render(
          getViewFile("authentication", "forget-password.ejs").file,
          {
            message: "email is not valid",message1: "",
          }
        )
      );
   
  
   }

    // Check if security question and answer match
     if  (
      user.securityQuestion !== securityQuestion ||
      user.securityAnswer !== securityAnswer
    ) {
      res.send(
        ejs.render(
          getViewFile("authentication", "forget-password.ejs").file,
          {
            message: 'Invalid security question or answer',message1: "",
            email,user,userId,userType,dashboard:"",dashboardType
          }
        )
      );

      
    }

    else{
    userId=user

     userType=user._id

    sendOtp(email, user?._id) 



    // Generate a temporary password (you can use any password generatio…

 res.send(
        ejs.render(
          getViewFile("authentication", "enter-otp.ejs").file,
          {
            message1: " Otp Successfully send  on Your Email",message: "",
            email,user,userId,userType,dashboard:"",dashboardType
          }
        )
      );
        }
      
        
    
            break;
        }

        

      }

      //Web Code End
    }
  } catch (error) {
    console.log(error);
  }
}

/**
 * @description This function is for Reset Password
 * @param { Request } req
 * @param { Response } res
 * @author Keshav Suman
 */
export async function resetPassword(req: Request, res: Response) {
  try {
    const { mode } = req.params;
    const { dashboardType, token, otp, password, confirmPassword } = req.body;
    if (password !== confirmPassword) {
      res.status(httpStatus.BAD_REQUEST).send({
        status: httpStatus.BAD_REQUEST,
        message: "Password and confimr password doesn't matched",message1: "",
      });
      return;
    }
    let user: any = authenticationService.verifyToken(token);
    if (mode == "api") {
      switch (dashboardType) {
        case "pharmacy":
          user = await authenticationService.getPharmacyByEmail(user.email);
          break;
        case "patient":
          user = await authenticationService.getPatientByEmail(user.email);
          break;
        case "doctor":
          user = await authenticationService.getConsultantByEmail(user.email);
          break;
        case "admin":
          user = await authenticationService.getAdminByEmail(user.email);
          break;
      }
      if (!user) {
        res.status(httpStatus.BAD_REQUEST).send({
          message: "Token not verified",
          status: httpStatus.BAD_REQUEST,
        });
        return;
      }
      const isOTPMatched = await authenticationService.verifyOTP(
        new Types.ObjectId(user._id),
        otp
      );
      if (isOTPMatched) {
        await authenticationService.changePassword(
          new Types.ObjectId(user._id),
          dashboardType,
          password
        );
        res.status(httpStatus.OK).send({
          message: "Password reset successfully",
          status: httpStatus.OK,
        });
      } else {
        res.status(httpStatus.BAD_REQUEST).send({
          message: "Otp didn't matched",
        });
      }
    } else {
      //Web Code Start
      if (req.method == "GET") {
        res.send(
          ejs.render(
            getViewFile("authentication", "forget-password.ejs").file,
            {
              message: "",message1: "",
            }
          )
        );
      } else {
        //Post Method Code
      }
    }
  } catch (error) {
    console.log(error);
  }
}

/**
 * @description This function is for Sign Out
 * @param { Request } req
 * @param { Response } res
 * @author Keshav Suman
 */

export async function signOut(req: Request, res: Response) {
  try {
    let token = req.cookies.token
    if(token){
      const user:any = authenticationService.verifyToken(token);

      updateStatusInactive(user)
      
      res.clearCookie("token");
      res.redirect("/authentication/web/signin");

    }
    else{

      res.redirect("/authentication/web/signin");

    }
    
  } catch (error) {
    res.redirect("/authentication/web/signin");

  }
}


/**
 * @description This function is for Change Password for all Dashboard
 * @param { Request } req
 * @param { Response } res
 * @author Keshav Suman
 */
export async function changePassword(req: Request, res: Response) {
  try {
    const { mode, dashboardType } = req.params;
    const { currentPassword, password, confirmPassword } = req.body;
    let user: any = JSON.parse(res.get('user')!);
    user = await authenticationService.getUserByUserID(user._id,dashboardType);
    const isMatch = authenticationService.comparePassword(currentPassword, user.password)
    
    if (mode == "api"){
      //API Code Start
      if (isMatch) {
        if (password === confirmPassword) {
          const data = await authenticationService.changePassword(user._id, dashboardType, password);
          res.status(httpStatus.OK).send({
            message: "Password reset successfully",
            status: httpStatus.OK,
          });
        } else {
          res.status(httpStatus.BAD_REQUEST).send({
            message: "Password not match",
            status: httpStatus.BAD_REQUESTs,
          });
        }
      } else {
        res.status(httpStatus.BAD_REQUEST).send({
          message: "Current password not match",
          status: httpStatus.BAD_REQUESTs,
        });
      }
      //API Code End
    }else{
      //Web Code Start
      if (isMatch) {
        if (password === confirmPassword) {
          const data = await authenticationService.changePassword(user._id, dashboardType, password);
          res.send(
            ejs.render(getViewFile("authentication", "forget-password.ejs").file,
              {
                message1: "Password reset successfully",message: "",
              }
            ));
        } else {
          res.send(
            ejs.render(getViewFile("authentication", "forget-password.ejs").file,
              {
                message: "Password not match",message1: "",
              }
            ));
        }
      } else {
        res.send(
          ejs.render(getViewFile("authentication", "forget-password.ejs").file,
            {
              message: "Current password not match",message1: "",
            }
          ));
      }

      //Web Code End
    }

   
  } catch (err) {
    console.log(err)
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: err,
      message: "Internal server error"
    });
  }
}


/**
 * @description This function is Send Otp
 * @param { Request } req
 * @param { Response } res
 * @author Nikhil Chouhan
 */
export async function sendOtp(email:any, userId:any) {
  try {
   
    

    const otp = Math.floor(100000 + Math.random() * 900000); // Generate a 6-digit OTP

    
    const expirationTime = moment().add(5, 'minutes'); // OTP expiration time
  
    const newOTP = new otpModel({

      user: userId,
    email,
      otp,
      createdAt : Date.now(),
      expirationTime,
      isUsed: false,
    });
    
  
    await newOTP.save();



    // const otp =  authenticationService.generateOTP();

    // const newOtpVerification = await new otpModel({
    //   user: userId,
    //   otp : otp,
    //   createdAt : Date.now(),
    //   expireAt : Date.now() + 3600000
    // });
    // await newOtpVerification.save()




    await sendMail(
      email,
      "Verify Your Email",
      `<p> Enter ${otp} in the app to verify your email address.</p>`
    )
  } catch (err) {
    
  }
};


/**
 * @description This function is Verify Otp
 * @param { Request } req
 * @param { Response } res
 * @author Nikhil Chouhan
 */
export async function verifyOtp(req: Request, res: Response) {
  try {

    const {userType,email,dashboardType}=req.body
    
     const userId: Types.ObjectId = new Types.ObjectId(req.params.id);
     const dashboard = req.params.dashboard;    
   if (req.method == "GET") {

    const fileContent = getViewFile("authentication", "enter-otp.ejs");
    res.send(
      ejs.render(fileContent.file, {
        message: "", userId,dashboard,userType,email,dashboardType,message1: "",
         filename: fileContent.templatePath,dropdownValue:dashboardType,emailValue:email,passwordValue:req.body.password
      })
    );
  } 
     
  else{
      
     }                 
  } catch (err) {
    
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: err,
      message: "Internal server error"
    });
  }
};


export async function otpVerify(req: Request, res: Response) {
  
  try {
    

    if(req.body.dashboard ==""){

      const { email,userId,userType,dashboard}=req.body
      



const user = req.body.userType
const dashboardType = req.body.dashboardType
const newOtp = parseInt(req.body.otp)

const findOtp: any = await otpModel.findOne({ user: user, otp: newOtp });



if (!findOtp || findOtp.isUsed || findOtp.otp !== newOtp || moment().isAfter(findOtp.expirationTime)) {
  res.send(
    ejs.render(getViewFile("authentication", "enter-otp.ejs").file, {
      message: "Otp does not match",user,message1: "",
      dashboardType,newOtp,email,userId,dashboard,userType,
      dropdownValue:dashboardType,emailValue:email,passwordValue:req.body.password
    })
  );
  return;
}

// Mark OTP as used
findOtp.isUsed = true;
await findOtp.save();



// Run the cleanup task every hour
setInterval(cleanupExpiredOTPs, 60 * 60 * 1000);


if (findOtp) {
 

  const fileContent = getViewFile("authentication", "reset-password.ejs");
  res.send(
    ejs.render(fileContent.file, {
      message: "", user,email,dashboardType,message1: "",
       filename: fileContent.templatePath,
    })
  );
} 




    }
    else{
      
    const user = req.body.userId

    
    const dashboardType = req.body.dashboard
    const newOtp = parseInt(req.body.otp)

    const{userId,email,dashboard,userType} = req.body

    const findOtp: any = await otpModel.findOne({ user: user, otp: newOtp });



    if (!findOtp || findOtp.isUsed || findOtp.otp !== newOtp || moment().isAfter(findOtp.expirationTime)) {
      res.send(
        ejs.render(getViewFile("authentication", "enter-otp.ejs").file, {
          message: "Otp does not match",user,message1: "",
          userId,email,dashboardType,dashboard,userType,
          dropDownValue:dashboard,emailvalue:email,passwordValue:req.body.password

        })
      );
      return;
    }
  
    // Mark OTP as used
    
    findOtp.isUsed = true;
    await findOtp.save();

    
    
    // Run the cleanup task every hour
   setInterval(cleanupExpiredOTPs, 60 * 60 * 1000);
    

    if (findOtp) {
      switch (dashboardType) {
        case "doctor":

const staff:any= await staffModel.findById(user).populate({path:"role",model:roleModel}); 



if(staff){

  res
  .cookie(
    "token",
    authenticationService.generateToken(
      staff.toObject(),
      "authentication","doctor"
    ),
    {
      maxAge: 24 * 60 * 60 * 1000,
      httpOnly: false,
    }
  ).redirect("/consultant/web/");

}

else{

const projection = {
  firstName: 1,
  lastName: 1,
  email: 1,
  password:1,
  gender:1,
  isActive:1,
  restricLogin:1,
  callStatus:1,
  maritialStatus:1,
  description:1,
  experience:1,
  profilePic:1,
  medicalCouncilExpiryDate:1,
  indemnityExpiryDate:1,
  securityQuestion:1,
  securityAnswer:1,
  isAllow:1.,

  mobileNumber: 1,
  speciality: 1,
  location: 1,
  role:1,
  dateOfBirth:1,



  
};

const consultants:any=await consultantModel.findById(user,projection)









  if(consultants.profilePic && consultants.experience){

    

    
          res
          .cookie(
            "token",
            authenticationService.generateToken(
              consultants.toObject(),
              "authentication","doctor"
            ),
            {
              maxAge: 24 * 60 * 60 * 1000,
              httpOnly: false,
            }
          ).redirect("/consultant/web/");
  }
  
  else{

    

    res
    .cookie(
      "token",
      authenticationService.generateToken(
        consultants.toObject(),
        "authentication","doctor"
      ),
      {
        maxAge: 24 * 60 * 60 * 1000,
        httpOnly: false,
      }
    ).redirect("/consultant/web/editprofile");
  }

}
          break;


        case "patient":

        const patient:any= await patientModel.findById(user)

if(patient.imageURL  && patient.location && patient.bloodGroup)
{

          res
          .cookie(
            "token",
            authenticationService.generateToken(
              patient.toObject(),
              "authentication","patient"
            ),
            {
              maxAge: 24 * 60 * 60 * 1000,
              httpOnly: false,
            }
          )
          .redirect("/patient/web/");
        
      }

        else{

          res
          .cookie(
            "token",
            authenticationService.generateToken(
              patient.toObject(),
              "authentication","patient"
            ),
            {
              maxAge: 24 * 60 * 60 * 1000,
              httpOnly: false,
            }
          )
          .redirect("/patient/web/editprofile");
          
        }
          

        break;

        case "admin":

const adminStaff:any= await staffModel.findById(user).populate({path:"role",model:roleModel}); 


    const admin:any=await adminModel.findById(user)
    

if(adminStaff){
        res
        .cookie(
          "token",
          authenticationService.generateToken(
            adminStaff.toObject(),
            "authentication","admin"
          ),
          {
            maxAge: 24 * 60 * 60 * 1000,
            httpOnly: false,
          }
        )
          .redirect("/admin/web/");
        }
        else{

          res
          .cookie(
            "token",
            authenticationService.generateToken(
              admin.toObject(),
              "authentication","admin"
            ),
            {
              maxAge: 24 * 60 * 60 * 1000,
              httpOnly: false,
            }
          )
            .redirect("/admin/web/");
            
        }
          break;
        case "pharmacy":
          
        const pharmacy:any=await pharmacyModel.findById(user)

        if(pharmacy.profilePic && pharmacy.cho && pharmacy.location){
        res
        .cookie(
          "token",
          authenticationService.generateToken(
            pharmacy.toObject(),
            "authentication","pharmacy"
          ),
          {
            maxAge: 24 * 60 * 60 * 1000,
            httpOnly: false,
          }
        )
        
        .redirect("/pharmacy/web/");
        }else{
          res
          .cookie(
            "token",
            authenticationService.generateToken(
              pharmacy.toObject(),
              "authentication","pharmacy"
            ),
            {
              maxAge: 24 * 60 * 60 * 1000,
              httpOnly: false,
            }
          )
          
          .redirect("/pharmacy/web/editprofile");

        }
          break;
      }



    }

    else {
      
      
      res.send(
        ejs.render(getViewFile("authentication", "sign-in.ejs").file, {
          message: "otp does not match",user,userId,dashboardType,dashboard:"",email,message1: "",
        })
      );
    }
  }
  } catch (err) {
    console.log(err)
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: err,
      message: "Internal server error"
    });
  }
};




export async function resendOtp(req: Request, res: Response) {
  try {

    
    const {userType,dashboardType,user,email}=req.body
     const userId: Types.ObjectId = new Types.ObjectId(req.params.id);
     const dashboard = req.params.dashboard;   
     
     const existingOTP:any = await otpModel.findOne({ user:userId });
     
     
if(existingOTP){
    const emailId = existingOTP.email

    // Generate a new OTP
    const otp = Math.floor(100000 + Math.random() * 900000);

    const expirationTime:any = moment().add(5, 'minutes');



    // Update the existing OTP
    existingOTP.otp = otp;


    existingOTP.expirationTime = expirationTime;

     existingOTP.isUsed = false;
      //  await existingOTP.save();
      await otpModel.findByIdAndUpdate(existingOTP._id, existingOTP)

    
    await sendMail(
      emailId,
      "Verify Your Email",
      `<p> Enter ${otp} in the app to verify your email address.</p>`
    )

    res.send(
      ejs.render(getViewFile("authentication", "enter-otp.ejs").file, {
        message1: "OTP Resend Successfully",message: "",
        userId,dashboard,emailId,dashboardType,userType,user,email,
      })
    );
}
    
  else  {
      res.send(
        ejs.render(getViewFile("authentication", "sign-in.ejs").file, {
          message: "resend otp again",message1: "",
        })
      );
    
    }
}
     
    //  if(dashboard=="patient"){
    //   let data =  await patientModel.findById(userId)
    //   sendOtp(data?.email,userId)
    //   res.send(
    //     ejs.render(getViewFile("authentication", "enter-otp.ejs").file, {
    //       message: "",
    //       userId,dashboard
    //     })
    //   );
    //    }
    //    if(dashboard=="doctor"){
    //     let data =  await consultantModel.findById(userId)
        
    //     sendOtp(data?.email,userId)
    //     res.send(
    //       ejs.render(getViewFile("authentication", "enter-otp.ejs").file, {
    //         message: "",
    //         userId,dashboard
    //       })
    //     );
    //      }
    //      if(dashboard=="pharmacy"){
    //       let data =  await pharmacyModel.findById(userId)
    //       sendOtp(data?.email,userId)
    //       res.send(
    //         ejs.render(getViewFile("authentication", "enter-otp.ejs").file, {
    //           message: "",
    //           userId,dashboard
    //         })
    //       );
    //        }
               
   catch (err) {
    console.log(err)
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: err,
      message: "Internal server error"
    });
  }
};



 export async function cleanupExpiredOTPs() {

      
  await otpModel.deleteMany({ expirationTime: { $lt: moment() } });
 }



 export async function verifyPassword(req: Request, res: Response) {
  
  try {

    const{userId,dashboardType,password,confirmpassword,email} =req.body

    const user=userId




let encreptedPassword
    if(password){

      encreptedPassword=await authenticationService.encryptedPassword(password)
    }

    if (password !== confirmpassword) {
    

  const fileContent = getViewFile("authentication", "reset-password.ejs");
  res.send(
    ejs.render(fileContent.file, {
      message: "password and confirm password not match", user,email,dashboardType,message1: "",
       filename: fileContent.templatePath,
    })
  );
 
      return;
    }




    
    
    
      switch (dashboardType) {
        case "doctor":

const staff:any= await staffModel.findById(user).populate({path:"role",model:roleModel}); 

const consultants:any=await consultantModel.findById(user)


if(staff){

  const data= await staffModel.findByIdAndUpdate(staff._id,{password:encreptedPassword});

  const fileContent = getViewFile("authentication", "sign-in.ejs");
  res.send(
    ejs.render(fileContent.file, {
      message1: "Password Updated successfully" ,message: "",
       filename: fileContent.templatePath,
    })
  );
 


}
 
else{
  const data1= await consultantModel.findByIdAndUpdate(consultants._id,{password:encreptedPassword});

  const fileContent = getViewFile("authentication", "sign-in.ejs");
  res.send(
    ejs.render(fileContent.file, {
      message1: "Password Updated successfully",message: "",
       filename: fileContent.templatePath,
    })
  );
 
}
          break;
        case "patient":

        const patient:any= await patientModel.findById(user)
        const data2= await patientModel.findByIdAndUpdate(patient._id,{password:encreptedPassword});

        const fileContent1 = getViewFile("authentication", "sign-in.ejs");
        res.send(
          ejs.render(fileContent1.file, {
            message1: "Password Updated successfully" ,message: "",
             filename: fileContent1.templatePath,
          })
        );
       
          break;
        case "admin":

const adminStaff:any= await staffModel.findById(user).populate({path:"role",model:roleModel}); 


    const admin:any=await adminModel.findById(user)
    

if(adminStaff){
  const data3= await staffModel.findByIdAndUpdate(adminStaff._id,{password:encreptedPassword});

  const fileContent = getViewFile("authentication", "sign-in.ejs");
  res.send(
    ejs.render(fileContent.file, {
      message1: "Password Updated successfully" ,message: "",
       filename: fileContent.templatePath,
    })
  );
 
        }
        else{

          const data= await adminModel.findByIdAndUpdate(admin._id,{password:encreptedPassword});

          const fileContent = getViewFile("authentication", "sign-in.ejs");
          res.send(
            ejs.render(fileContent.file, {
              message1: "Password Updated successfully",message: "",
               filename: fileContent.templatePath,
            })
          );
         
            
        }
          break;
        case "pharmacy":
          
        const pharmacy:any=await pharmacyModel.findById(user)

        const data= await pharmacyModel.findByIdAndUpdate(pharmacy._id,{password:encreptedPassword});

        const fileContent = getViewFile("authentication", "sign-in.ejs");
        res.send(
          ejs.render(fileContent.file, {
            message1: "Password Updated successfully",message: "", 
             filename: fileContent.templatePath,
          })
        );
       
          break;
      }



    }

    catch (err) {
    console.log(err)
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: err,
      message: "Internal server error"
    });
  }
};






export async function doctorUpload(req: Request, res: Response) {
  try {
    const { mode } = req.params;
   
    
   
    
    const { email, password, confirmpassword, 
      dashboardType,patientEmail,patientPassword,patientConfirmpassword,
      doctorEmail,doctorPassword,doctorConfirmpassword,
      pharmacyPassword,pharmacyConfirmpassword,pharmacyEmail
     } = req.body;

     const speciality= await specialityModel.find()
 

   

    if (mode == "api") {
    
      
    } else {
      //Web Code Start

      if (req.method == "GET") {
        res.send(
          ejs.render(getViewFile("authentication", "signup2.ejs").file, {
            message: "",body:req.body, speciality,message1: "",
          })
        );
      } else {
        // Post Method

        if (doctorPassword !== doctorConfirmpassword) {
            res.send(
                   ejs.render(getViewFile("authentication", "sign-up.ejs").file, {
                     message: "Password and confirm password doesn`t matched",body:req.body,
                     speciality,message1: "",
                   })
                 );
              
           
               return
             }


            let consultant: Consultant | null =
              await authenticationService.getConsultantByEmail(doctorEmail);
            if (consultant) {
              res.send(
                ejs.render(getViewFile("authentication", "sign-up.ejs").file, {
                  message: "Doctor with this email already exists",body:req.body,speciality,
                  message1: "",
                })
              );
            } else {



              res.send(
                ejs.render(getViewFile("authentication", "signup2.ejs").file, {
                  message: "",body:req.body,speciality,message1: "",
                })
              );
          
            }
      //Web Code End
    }}
  } catch (error) {
    console.log(error);
  }
}








export async function signupOtp(req: Request, res: Response) {
  try {


    
   if (req.method == "GET") {


    const{
      userId,name,email,eirCode,dashboardType,dashboard,userType,fullName,documentURL,gender,dob,mobileNumber,password,confirmPassword,securityAnswer,securityQuestion,
        medicalDegree,confirmpassword ,specialistDegree,indemnityCertificate,medicalCouncilCertificate,cctCertification,medicalCouncilExpiryDate,indemnityExpiryDate,speciality,

     } = req.body

    const fileContent = getViewFile("authentication", "signup-otp.ejs");
    res.send(
      ejs.render(fileContent.file, {
        message: "",message1: "",
        userId,name,email,eirCode,dashboardType,dashboard,userType,fullName,documentURL,gender,dob,mobileNumber,password,confirmPassword,securityAnswer,securityQuestion,
        medicalDegree,confirmpassword ,specialistDegree,indemnityCertificate,medicalCouncilCertificate,cctCertification,medicalCouncilExpiryDate,indemnityExpiryDate,speciality,

         filename: fileContent.templatePath,
        
      })
    );
  } 
     
  else{

   
    
    
   
    const dashboardType = req.body.dashboardType
    const newOtp = parseInt(req.body.otp)

    const{
      userId,name,email,eirCode,dashboard,userType,fullName,documentURL,gender,dob,mobileNumber,password,confirmPassword,securityAnswer,securityQuestion,
        medicalDegree,confirmpassword ,specialistDegree,indemnityCertificate,medicalCouncilCertificate,cctCertification,medicalCouncilExpiryDate,indemnityExpiryDate,speciality,

     } = req.body
    const findOtp: any = await otpModel.findOne({email:email, otp: newOtp });

    
   

    



    if ( !findOtp || findOtp.isUsed || findOtp.otp !== newOtp || moment().isAfter(findOtp.expirationTime)) {
      
      res.send(
        ejs.render(getViewFile("authentication", "signup-otp.ejs").file, {
          message: "otp does not match",message1: "",
          userId,name,email,eirCode,dashboardType,dashboard,userType,fullName,documentURL,gender,dob,mobileNumber,password,confirmPassword,securityAnswer,securityQuestion,
          medicalDegree,confirmpassword ,specialistDegree,indemnityCertificate,medicalCouncilCertificate,cctCertification,medicalCouncilExpiryDate,indemnityExpiryDate,speciality,
  
         

        })
      );
    
    }
  
   
    
  
    else {
        
    // Mark OTP as used
    findOtp.isUsed = true;
    await findOtp.save();

    
    
    // Run the cleanup task every hour
   setInterval(cleanupExpiredOTPs, 60 * 60 * 1000);



      const names = req.body.fullName.split(" ");

      switch (dashboardType) {
      
        case "doctor":


        // const names = req.body.dcotorName.split(" ");
        const createConsultantDto = {
          firstName: names.splice(0, 1).join(""),
          lastName: names.join(" "),
          email: req.body.email,
          gender: req.body.gender,
          medicalDegree:req.body.medicalDegree,
          specialistDegree:req.body.specialistDegree,
          indemnityCertificate:req.body.indemnityCertificate,
          medicalCouncilCertificate:req.body.medicalCouncilCertificate,
          cctCertification:req.body.cctCertification,
          indemnityExpiryDate:req.body.indemnityExpiryDate,
          medicalCouncilExpiryDate:req.body.medicalCouncilExpiryDate,
          dateOfBirth: req.body.dateOfBirth,
          mobileNumber: req.body.mobileNumber,
          password: req.body.password,
          speciality:req.body.speciality,
          securityQuestion: req.body.securityQuestion,
          securityAnswer: req.body.securityAnswer,
        };
       const consultant = await authenticationService.createConsultant(
          createConsultantDto
        );


    
        if( consultant){
          const shareDoc = await adminModel.find()

          



const shareDocIds = shareDoc.map((a:any)=>{
return new Types.ObjectId(a._id)
})




         
          //Create Notification
         const createNotificationDto:any ={
         notificationTitle: "New Doctor signup Sucessfully",
         notificationDescription: "signup notification",
         notificationBy:   consultant._id,
         notificationTo:  shareDocIds,
         notificationType :"signup_notification",
         notificationTypeId:  consultant._id,
         }
         
         const d:any=await notification.createNotification(createNotificationDto);
         
        }


        res.send(
          ejs.render(getViewFile("authentication", "sign-in.ejs").file, {
            message1: "Doctor created successfully",dropdownValue:req.body.dashboardType,
            emailValue:req.body.email,passwordValue:req.body.password,body:req.body,message: "",
          })
        );
      

          break;

          
        case "patient":



        

       
        const createPatientDto = {
          firstName: names.splice(0, 1).join(""),
          lastName: names.join(" "),
          email: req.body.email,
          gender: req.body.gender,
          dateOfBirth: req.body.dob,
          mobileNumber: req.body.mobileNumber,
          password: req.body.password,
          eirCode:req.body.eirCode,
          securityQuestion: req.body.securityQuestion,
          securityAnswer: req.body.securityAnswer,
        };
        
      const  patient = await authenticationService.createPatient(
          createPatientDto
        );
        

        if(patient){
          const shareDoc = await adminModel.find()

          



const shareDocIds = shareDoc.map((a:any)=>{
return new Types.ObjectId(a._id)
})




         
          //Create Notification
         const createNotificationDto:any ={
         notificationTitle: "New Patient signup Sucessfully",
         notificationDescription: "signup notification",
         notificationBy:  patient._id,
         notificationTo:  shareDocIds,
         notificationType :"signup_notification",
         notificationTypeId:  patient._id,
         }
         
         const d:any=await notification.createNotification(createNotificationDto);
         
        }

       
       

        res.send(
          ejs.render(getViewFile("authentication", "sign-in.ejs").file, {
            message1: "Patient created successfully",message: "",
            dropdownValue:req.body.dashboardType,emailValue:req.body.email,passwordValue:req.body.password,body:req.body

          })
        );
     

        break;

        
        case "pharmacy":

      
              

        const createPharmacyDto = {
          firstName: names.splice(0, 1).join(""),
          lastName: names.join(" "),
          email: req.body.email,
          gender: req.body.gender,
          dateOfBirth: req.body.dob,
          mobileNumber: req.body.mobileNumber,
          
          certificate:req.body.documentURL,
          securityQuestion: req.body.securityQuestion,
          securityAnswer: req.body.securityAnswer,
          password: req.body.password,
        };


        


     const pharmacy = await authenticationService.createPharmacy(
          createPharmacyDto
        );
        if(pharmacy){
          const shareDoc = await adminModel.find()

          



const shareDocIds = shareDoc.map((a:any)=>{
return new Types.ObjectId(a._id)
})

 
          //Create Notification
         const createNotificationDto:any ={
         notificationTitle: "New pharmacy signup Sucessfully",
         notificationDescription: "signup notification",
         notificationBy: pharmacy._id,
         notificationTo:  shareDocIds,
         notificationType :"signup_notification",
         notificationTypeId:pharmacy._id,
         }
         
         const d:any=await notification.createNotification(createNotificationDto);
         
        }




        res.send(
          ejs.render(getViewFile("authentication", "sign-in.ejs").file, {
            message1: "Pharmacy created successfully",message: "",
            dropdownValue:req.body.dashboardType,emailValue:req.body.email,passwordValue:req.body.password,body:req.body

          })
        );

        

        
          
          break;
      }



    }

    

      
     }                 
  } catch (err) {
    console.log(err);
    
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: err,
      message: "Internal server error"
    });
  }
};







export async function resendSignupOtp(req: Request, res: Response) {
  try {

    
    const{
      userId,name,email,eirCode,dashboardType,dashboard,userType,fullName,documentURL,gender,dob,mobileNumber,password,confirmPassword,securityAnswer,securityQuestion,
        medicalDegree,confirmpassword ,specialistDegree,indemnityCertificate,medicalCouncilCertificate,cctCertification,medicalCouncilExpiryDate,indemnityExpiryDate,speciality,

     } = req.body

    
     
     const existingOTP:any = await otpModel.findOne({ email:email });
     
     
if(existingOTP){
    const emailId = existingOTP.email

    // Generate a new OTP
    const otp = Math.floor(100000 + Math.random() * 900000);

    const expirationTime:any = moment().add(5, 'minutes');



    // Update the existing OTP
    existingOTP.otp = otp;


    existingOTP.expirationTime = expirationTime;

     existingOTP.isUsed = false;
      //  await existingOTP.save();
      await otpModel.findByIdAndUpdate(existingOTP._id, existingOTP)

    
    await sendMail(
      emailId,
      "Verify Your Email",
      `<p> Enter ${otp} in the app to verify your email address.</p>`
    )

    res.send(
      ejs.render(getViewFile("authentication", "signup-otp.ejs").file, {
        message1: "OTP Resend Successfully",message: "",
        userId,email,eirCode,name,dashboardType,confirmpassword , dashboard,userType,fullName,documentURL,gender,dob,mobileNumber,password,confirmPassword,securityAnswer,securityQuestion,
        medicalDegree,specialistDegree,indemnityCertificate,medicalCouncilCertificate,cctCertification,medicalCouncilExpiryDate,indemnityExpiryDate,speciality,

        
      })
    );
}
    
  else  {
      res.send(
        ejs.render(getViewFile("authentication", "signup-otp.ejs.ejs").file, {
          message: "resend otp again",message1: "",
          userId,email,name,eirCode,confirmpassword ,dashboardType,dashboard,userType,fullName,documentURL,gender,dob,mobileNumber,password,confirmPassword,securityAnswer,securityQuestion,
          medicalDegree,specialistDegree,indemnityCertificate,medicalCouncilCertificate,cctCertification,medicalCouncilExpiryDate,indemnityExpiryDate,speciality,
        })
      );
    
    }
}
     
               
   catch (err) {
    console.log(err)
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      data: err,
      message: "Internal server error"
    });
  }
};





export async function reUpload(req: Request, res: Response) {
  try {
    const { mode } = req.params;
   
    
  let mail = req.body.email;
    
  let doctor = await consultantModel.findOne({email:mail});

  
  

    if (mode == "api") {
    
      
    } else {
      //Web Code Start

      if (req.method == "GET") {
        res.send(
          ejs.render(getViewFile("authentication", "reUploadDoc.ejs").file, {
            message: "",body:req.body,
          })
        );
      } else {
        // Post Method


        const newv:any = req.files

        let ar:any;  
        

        let indeminty;
        let council;

        if(newv[0].fieldname=="indeminty"){
          indeminty =  newv[0].path;

        }
        else{
          council=newv[0].path;

        }

        
        if(newv[1]){
          council =newv[1].path;

        }
       
      
        const reUploadDto={
          medicalCouncilCertificate:indeminty,
          medicalCouncilExpiryDate : req.body.medicalExpirayDate ,
          indemnityCertificate:council,
          indemnityExpiryDate:req.body.indemintyDate,
          restricLogin:true

        }

      

if(doctor){
  ar=  await consultantModel.findByIdAndUpdate(doctor._id,reUploadDto)





  res.send(


    ejs.render(getViewFile("authentication", "sign-in.ejs").file, {
      message:"You can only login after admin verify your document.",
        message1: "",dropdownValue:"doctor",emailValue:req.body.email,
        passwordValue:req.body.password, 
        email: mail
  
     
    })
  );

}



    
if(ar){
  const shareDoc = await adminModel.find()

  



const shareDocIds = shareDoc.map((a:any)=>{
return new Types.ObjectId(a._id)
})




 
  //Create Notification
 const createNotificationDto:any ={
 notificationTitle: " Doctor Reupload Certificate ",
 notificationDescription: "signup notification",
 notificationBy:  ar._id,
 notificationTo:  shareDocIds,
 notificationType :"signup_notification",
 notificationTypeId:  ar._id,
 }
 
 const d:any=await notification.createNotification(createNotificationDto);
 
}



          
            
      //Web Code End
    }}
  } catch (error) {
    console.log(error);
  }
}




export async function eirSuggestion(req: Request, res: Response) {
  try {
    const { limit, page } = req.query;

    const { mode } = req.params;

    if (mode == "api") {
      res.status(httpStatus.OK).send({
        data: "",
        message: "Booking update successfully",
        status: httpStatus.OK,
      });
    } else {
      //web code
      
      

      const  eircode = req.body.eircode;

      const suggestions: any = await eirModel.find(
        { location: { $regex:  eircode, $options: "i" } },
        "name"
      );

      
      

      const Id: Types.ObjectId = suggestions.map((e: any) => {
        return e._id;
      });

      const  eircodes = await eirModel.find({ _id: Id });

    
      

      res.json({ suggestions:  eircodes });
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
}