
import { Router } from "express";
import * as genrateTokenController from "./vc.controler"


const vcrouter: Router = Router({ mergeParams: true });

vcrouter
  .route("/genratetoken")
  .get(genrateTokenController.genrateToken)
  .post(genrateTokenController.genrateToken);


  export default vcrouter;