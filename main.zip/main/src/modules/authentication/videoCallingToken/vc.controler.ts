import {  RtcTokenBuilder,RtmTokenBuilder, RtcRole,RtmRole,} from "agora-access-token";
import httpStatus from "http-status";
import dotenv from "dotenv";
import { Request, Response } from "express";
dotenv.config();

export function genrateToken(req: Request, res: Response) {
  try {
    const channelName = req.body.channelName;
    const uid = 0;
    const role = RtcRole.PUBLISHER;
    const expirationTimeInSeconds = 3600;
    const currentTimestamp = Math.floor(Date.now() / 1000);
    const privilegeExpiredTs = currentTimestamp + expirationTimeInSeconds;
    const appId = process.env.appId;
    const appCertificate = process.env.appCertificate;

    //     // Build token with uid
    if (appId == undefined || appCertificate == undefined) {
      console.log("no channel id");
    } else {
      const tokenA = RtcTokenBuilder.buildTokenWithUid(
        appId,
        appCertificate,
        channelName,
        uid,
        role,
        privilegeExpiredTs
      );
      res.status(httpStatus.OK).json({ tokenA });
    }
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      message: error,
      status: httpStatus.INTERNAL_SERVER_ERROR,
    });
  }
}
