import bcrypt from "bcryptjs";
import consultantModel, { Consultant } from "./models/consultant.model";
import patientModel, { Patient } from "./models/patient.model";
import pharmacyModel, { Pharmacy } from "./models/pharmacy.model";
import jsonwebtoken, { JwtPayload } from "jsonwebtoken";
import adminModel, { Admin } from "./models/admin.model";
import staffModel, { Staff } from "./models/staff.model";
import { Types } from "mongoose";
import otpGenerator from "otp-generator";
import otpModel from "./models/otp.model";
import roleModel from "./models/role.model";

/**
 * @description This function is used to createConsultants
 * @param createConsultantDto
 * @returns {Promise<Consultant>}
 * @author Keshav suman
 */
export async function createConsultant(
  createConsultantDto: any
): Promise<Consultant> {
  const role = {
    permission:{
      manageTemplate:{
        create:true,
        view:true,
        delete:true,
        update:true
      },
      documentCenter:{
        create:true,
        view:true,
        delete:true,
        update:true
      },
      questionnaire:{
        create:true,
        view:true,
        delete:true,
        update:true
      },
      booking:{
        create:true,
        view:true,
        delete:true,
        update:true
      },
      manageRole:{
        create:true,
        view:true,
        delete:true,
        update:true
      },
      email:{
        create:true,
        view:true,
        delete:true,
        update:true
      },
      chat:{
        create:true,
        view:true,
        delete:true,
        update:true
      },
      myCalander:{
        create:true,
        view:true,
        delete:true,
        update:true
      },
      template:{
        create:true,
        view:true,
        delete:true,
        update:true
      },
    }
  };
  return await consultantModel.create({...createConsultantDto,role});
}

/**
 * @description This function is used to createPharmacy
 * @param createPharmacyDto
 * @returns {Promise<Pharmacy>}
 * @author Keshav suman
 */
export async function createPharmacy(
  createPharmacyDto: any
): Promise<Pharmacy> {
  return await pharmacyModel.create(createPharmacyDto);
}

/**
 * @description This function is used to create patient
 * @param createPatientDto
 * @returns {Promise<Patient>}
 * @author Keshav suman
 */
export async function createPatient(createPatientDto: any): Promise<Patient> {
  return await patientModel.create(createPatientDto);
}

/**
 * @description This function to create admin
 * @param createAdminDto
 * @returns {Promise<Admin>}
 * @author Keshav suman
 */
export async function createAdmin(createAdminDto: any): Promise<Admin> {
  return await adminModel.create(createAdminDto);
}

/**
 * @description This function is used to get the admin using email
 * @param {String} email
 * @returns {Promise<Consultant|null>}
 * @author Keshav suman
 */
export async function getConsultantByEmail(
  email: string
): Promise<Consultant | null> {
  return await consultantModel.findOne({ email },{description:0});
}

/**
 * @description This function is used to get the admin using email
 * @param {String} email
 * @returns {Promise<Patient|null>}
 * @author Keshav suman
 */
export async function getPatientByEmail(
  email: string
): Promise<Patient | null> {
  return await patientModel.findOne({ email },{description:0});
}

/**
 * @description This function is used to get the admin using email
 * @param {String} email
 * @returns {Promise<Pharmacy|null>}
 * @author Keshav suman
 */
export async function getPharmacyByEmail(
  email: string
): Promise<Pharmacy | null> {
  return await pharmacyModel.findOne({ email },{description:0});
}

/**
 * @description This function is used to get the admin using email
 * @param {String} email
 * @returns {Promise<Admin|null>}
 * @author Keshav suman
 */
export async function getAdminByEmail(email: string): Promise<Admin | null> {
  return await adminModel.findOne({ email });
}

/**
 * @description This function is used to get the admin using email
 * @param {String} email
 * @returns {Promise<Admin|null>}
 * @author Vishv Desai
 */
export async function getStaffByEmail(email: string): Promise<Staff | null> {
  return await staffModel.findOne({ email }).populate({path:"role",model:roleModel});
}




/**
 * @description This function is used to generate authenticaton token
 * @param {User} user
 * @author Keshav sumanlo
 * @returns {String}
 */
export function generateToken(user: any, purpose: string,dashboardType:string): string {


  return jsonwebtoken.sign(

    
    {...user, purpose: purpose,dashboardType: dashboardType},
    process.env.JWT_Token!
  );
}

/**
 * @description this function is used to verify the token
 * @param {string} token
 * @returns {string|JwtPayload}
 * @author Keshav suman
 */
export const verifyToken = (token: string): string | JwtPayload => {
  return jsonwebtoken.verify(token, process.env.JWT_Token!);
};

/**
 * @description this function is used to hash password
 * @param {String} password
 * @author Keshav suman
 * @returns {String}
 */
export const generateHash = (password: string) => {
  const salt = bcrypt.genSaltSync();
  return bcrypt.hashSync(password, salt);
};

export const generatePasswordRefreshToken = (user: any): string => {
  const object = {
    ...user,
    type: "Password-Reset",
  };
  return jsonwebtoken.sign(object, process.env.SECRET!);
};

export const verifyPassword = async (password: any, passwordToVerify: any) => {
  const verifyPassword = await bcrypt.compare(password, passwordToVerify);
  return verifyPassword;
};

/**
 * @description this function is used to compare password
 * @param {String} password
 * @param {String} hashpassword
 * @author Keshav suman
 * @returns {Boolean}
 */
export function comparePassword(
  password: string,
  hashpassword: string
): boolean {
  return bcrypt.compareSync(password, hashpassword);
}

/**
 * @description THis function is used to get pharmacy by Id
 * @param {number} id
 * @returns {Promise<Pharmacy|null>}
 * @author Keshav suman
 */
export async function getPharmacyById(
  id: Types.ObjectId
): Promise<Pharmacy | null> {
  return await pharmacyModel.findById(id);
}

/**
 * @description this function is used to get the patient by Id
 * @param {Types.ObjectId} id
 * @returns {Promise<Patient|null>}
 * @author Keshav suman
 */
export async function getPatientById(
  id: Types.ObjectId
): Promise<Patient | null> {
  return await patientModel.findById(id);
}

/**
 * @description This function is used to get the admin by Id
 * @param {Types.ObjectId} id
 * @returns {Promise<Admin|null>}
 * @author Keshav suman
 */
export async function getAdminById(id: Types.ObjectId): Promise<Admin | null> {
  return await adminModel.findById(id);
}

/**
 * @description This function is used to get Consultant by Id
 * @param {Types.ObjectId} id
 * @returns {Promise<Consultant|null>}
 * @author Keshav suman
 */
export async function getConsultantById(
  id: Types.ObjectId
): Promise<Consultant | null> {
  return await consultantModel.findById(id);
}

/**
 * @description THis function is used to generate the OTP
 * @returns {string}
 * @author Keshav suman
 */
export function generateOTP(): string {
  return otpGenerator.generate(4, {
    digits: true,
    lowerCaseAlphabets: false,
    specialChars: false,
    upperCaseAlphabets: false,
  });
}

/**
 * @description this function is used to save the OTP
 * @param {Types.ObjectId} userId
 * @param {string} userType
 * @param {string} otp
 * @author Keshav suman
 */
export async function saveOTP(
  userId: Types.ObjectId,
  userType: string,
  otp: string
) {
  await otpModel.create({ user: userId, userType: userType, otp: otp });
}

/**
 * @description This function isused to verify the OTP
 * @param {Types.ObjectId} userId
 * @param {string} otp
 * @returns {Promise<Boolean>}
 * @author Keshav suman
 */
export async function verifyOTP(
  userId: Types.ObjectId,
  otp: string
): Promise<Boolean> {
  const otpObject = await otpModel.findOne({ user: userId, otp });
  if (otpObject) {
    await otpModel.deleteMany({ user: userId });
    return true;
  } else {
    return false;
  }
}

/**
 * @description This function is used to change the password
 * @param {Types.ObjectId} userId
 * @param {string} userType
 * @param {string} password
 */
export async function changePassword(
  userId: Types.ObjectId,
  userType: string,
  password: string
) {
  switch (userType) {
    case "pharmacy":
      return await pharmacyModel.findByIdAndUpdate(userId,{password:generateHash(password)});
    case "patient":
      return await patientModel.findByIdAndUpdate(userId,{password:generateHash(password)});
    case "consultant":
      return consultantModel.findByIdAndUpdate(userId,{password:generateHash(password)});
    case "admin":
      return await adminModel.findByIdAndUpdate(userId,{password:generateHash(password)});
  }
}




export async function getUserByUserID(
  userId: Types.ObjectId,
  dashboardType:string
){
  let user: any;
  switch (dashboardType) {
    case "pharmacy":
      user = await getPharmacyById(userId);
      break;
    case "patient":
      user = await getPatientById(userId);
      break;
    case "consultant":
      user = await getConsultantById(userId);
      break;
    case "admin":
      user = await getAdminById(userId);
      break;
  }
  return user;
}

export function encryptedPassword(
  password: string,
  
) 

{

  return bcrypt.hashSync(password, 10);
}