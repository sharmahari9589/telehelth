import mongoose, { Schema, Document, Types } from "mongoose";




export enum Gender {
  Male = "male",
   Female = "female",
   Other = "other",
   Transgender = 'transgender' ,	
   Notdisclosed	='notDisclosed'
 }
 

 export enum MaritialStatus {
  Married = "married",
  Single = "single",	
Partnered	='partnered',
Divorce	='divorce',
Widow	='widow',
Others	='others',	
Notdisclosed	='notDisclosed'

}

export interface Staff extends Document {
  firstName: string;
  lastName: string;
  email: string;
  password?: string;
  mobileNumber: string;
  isDeleted: boolean;
  addedBy: Types.ObjectId;
  role: Types.ObjectId;
}

const staffSchema: Schema = new Schema<Staff>({
  firstName: {
    type: String,
  },
  lastName: {
    type: String,
  },
  email: {
    type: String,
    unique: true,
    required: true,
  },
  password: {
    type: String,
    required: true,
  },
  mobileNumber: {
    type: String,
  },
  isDeleted: {
    type: Boolean,
    default: false,
  },
  addedBy: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
  },
  role: {
    type: Schema.Types.ObjectId,
    ref: 'role',
    // required: true,
  }
});


export default mongoose.model<Staff>("staff", staffSchema);