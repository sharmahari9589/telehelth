import mongoose, { Schema, model, Document } from "mongoose";
import { generateHash } from "../authentication.service";


export enum Gender {
 Male = "male",
  Female = "female",
  Other = "other",
  Transgender = 'transgender' ,	
	Notdisclosed	='notDisclosed'
}

export enum MaritialStatus {
  Married = "married",
  Single = "single",	
Partnered	='partnered',
Divorce	='divorce',
Widow	='widow',
Others	='others',	
Notdisclosed	='notDisclosed'

}

export interface Consultant extends Document {
  firstName: string;
  lastName: string;
  email: string;
  password?: string;
  mobileNumber: string;
  gender: Gender;
  maritialStatus: MaritialStatus;
  dateOfBirth: Date;
  experience: Array<string>;
  medicalDegree: string;
  specialistDegree: string;
  indemnityCertificate: string;
  medicalCouncilCertificate: string;
  cctCertification: string;
  indemnityExpiryDate: Date;
  medicalCouncilExpiryDate: Date;




  speciality: Array<string>;
  description: string;
  location: any;
  profilePic:string;

  isDeleted: boolean;
  eirCode: String
  role:{
  permission: 
      {
      documentCenter: {
        view: Boolean;
      },
      questionnaire: {
        view:Boolean;
      }
      booking: {
        view:Boolean;
      }
      manageRole: {
        view:Boolean;
      }
      manageTemplate: {
        view:Boolean
      }
      tempalte: {
        view:Boolean
      }
      email: {
        view:Boolean;
      }
      myCalander: {
        view:Boolean;
      }
      chat: {
        view:Boolean;
      }}
      
    }
  isAllow:Boolean;
  isActive: Boolean;
  securityQuestion:string;
  securityAnswer:string
  restricLogin:Boolean
}

const accessSchema: Schema = new mongoose.Schema({
  
view:{
  type:Boolean,
  default:true
}
},{_id:false});

const consultantSchema: Schema = new Schema<Consultant>({
  firstName: {
    type: String,
  },
  lastName: {
    type: String,
  },
  email: {
    type: String,
    unique: true,
    required: true,
  },
  password: {
    type: String,
    required: true,
  },
  mobileNumber: {
    type: String,
  },
  gender: {
    type: String,
    enum: Gender,
  },
  maritialStatus: {
    type: String,
    enum: MaritialStatus,
  },
  dateOfBirth: {
    type: Date,
  },
  experience: {
    type: [{ type: String }],
  },
 medicalDegree: {
    type: String 
  },
 specialistDegree: {
    type: String 
  },
 indemnityCertificate: {
    type: String 
  },
  cctCertification: {
    type: String 
  },
  medicalCouncilCertificate: {
    type: String 
  },
  medicalCouncilExpiryDate: {
    type: Date,
  },
  indemnityExpiryDate: {
    type: Date,
  },
  profilePic: {
    type: String 
  },
  speciality: {
    type: [{ type: String }],
  },
  description: {
    type: String,
  },
  eirCode:{
    type:String
  },
  location: {
       type: String 
      },
   
  isDeleted: {
    type: Boolean,
    default :false
  },
  isActive:{
 type: Boolean,
 default:false
  },
  restricLogin:{
    type : Boolean,
    default : true
  },

  

  role:{
    permission: {
      type: {
        manageTemplate:accessSchema,
        template:accessSchema,

        chat:accessSchema,
        email:accessSchema,
        myCalander:accessSchema,
        documentCenter:accessSchema,
        questionnaire:accessSchema,
        booking:accessSchema,
        manageRole:accessSchema,
        
      
      },
      default: {
        documentCenter: { view: true },
        questionnaire: { view: true },
        booking: { view: true },
        manageRole: { view: true },
        manageTemplate: { view: true },
        template: { view: true },
        chat: { view: true },
        myCalander: { view: true },
        email: { view: true },
      },
  }
  },
  isAllow:{
    type : Boolean,
    default : false
  },
  securityQuestion:{
    type:String
  },
  securityAnswer:{
    type:String
  }
},{
  timestamps:true
});

consultantSchema.pre("save", function (next) {
  this.password = generateHash(this.password);
  next();
});


export default model<Consultant>("doctor", consultantSchema);
