import { Schema, model, Document } from "mongoose";
import { generateHash } from "../authentication.service";
import { MaritialStatus } from "./consultant.model";

export enum Gender {
  Male = "male",
  Female = "female",
  Other = "other",
  Transgender = 'transgender' ,	
	Notdisclosed	='notDisclosed'
}

export enum MritialStatus {
  Married = "married",
  Single = "single",	
Partnered	='partnered',
Divorce	='divorce',
Widow	='widow',
Others	='others',	
Notdisclosed	='notDisclosed'

}

export enum BloodGroup {
  APlus = "A+",
  BPlus = "B+",
  AMinus="A-",
  BMinus="B-",
  OPlus = "O+",
  OMinus="O-",
  ABPlus="AB+",
  ABMinus="AB-",
}

export interface Patient extends Document {
  firstName: string;
  lastName: string;
  email: string;
  password?: string;
  mobileNumber: string;
  gender: Gender;
  maritialStatus: MaritialStatus;
  bloodGroup: BloodGroup;
  dateOfBirth: Date;
  weight: number;
  height: number;
  isAllow:Boolean;
  isActive:Boolean;
  socketId: String
  eirCode: String
  isDeleted:Boolean
  imageURL: string;
  location:any;
  securityQuestion:string;
  securityAnswer:string;
}

const patientSchema: Schema = new Schema<Patient>({
  firstName: {
    type: String,
  },
  lastName: {
    type: String,
  },
  isDeleted: {
    type: Boolean,
    default :false
  },
  email: {
    type: String,
    unique: true,
    required: true,
  },
  password: {
    type: String,
    required: true,
  },
  mobileNumber: {
    type: String,
  },
  gender: {
    type: String,
    enum: Gender,
  },
  maritialStatus: {
    type: String,
    enum: MritialStatus,
  },
  bloodGroup: {
    type: String,
    enum: BloodGroup,
  },
  dateOfBirth: {
    type: Date,
  },
  weight: {
    type: Number,
  },
  height: {
    type: Number,
  },
  socketId:{
    type:String
  },
  eirCode:{
    type:String
  },
  imageURL: {
    type: String,
  },
 location: {
    type: String, // Don't do `{ location: { type: String } }`
     
  },
  
  isAllow:{
    type : Boolean,
    default : false
  },
  isActive:{
    type: Boolean,
    default:false
     },
     securityQuestion:{
      type:String
    },
    securityAnswer:{
      type:String
    }
}
,{
  timestamps:true
});

patientSchema.pre("save", function (next) {
  this.password = generateHash(this.password);
  next();
});

export default model<Patient>("patient", patientSchema);
