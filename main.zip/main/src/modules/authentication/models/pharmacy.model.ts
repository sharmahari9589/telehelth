import { Schema, model, Document } from "mongoose";
import { generateHash } from "../authentication.service";


export enum Gender {
  Male = "male",
  Female = "female",
  Other = "other",
  Transgender = 'transgender' ,	
	Notdisclosed	='notDisclosed'
}

export enum MaritialStatus {
  Married = "married",
  Single = "single",	
Partnered	='partnered',
Divorce	='divorce',
Widow	='widow',
Others	='others',	
Notdisclosed	='notDisclosed'

}
export interface Pharmacy extends Document {
  firstName: string;
  lastName: string;
  email: string;

  profilePic:string;
  password?: string;
  mobileNumber: string;
  gender: Gender;
  maritialStatus: MaritialStatus;
  dateOfBirth: Date;
  description: string;
  dlNumber:string;
  storeName:string;
cho:string
country:string;
  location: any;
  isAllow: Boolean;
  isDeleted: Boolean;
  eirCode: String
  restricLogin:Boolean
certificate:string
  securityQuestion:string;
  securityAnswer:string;
}

const pharmacySchema: Schema = new Schema<Pharmacy>({
  firstName: {
    type: String,
  },
  lastName: {
    type: String,
  },
  email: {
    type: String,
    unique: false,
    required: true,
  },
  password: {
    type: String,
    required: true,
  },
  mobileNumber: {
    type: String,
  },
  eirCode:{
    type:String
  },
certificate:{
    type:String
  },
  
  profilePic:{
    type:String
  },
  dlNumber:{
    type:String
  },
  
  

  gender: {
    type: String,
    enum: Gender,
  },
  maritialStatus: {
    type: String,
    enum: MaritialStatus,
  },
  dateOfBirth: {
    type: Date,
  },
  description: {
    type: String,
  },
  location: {
  
      type: String, 
      
  },
  isAllow:{
    type : Boolean,
    default : false
  },
  isDeleted:{
    type : Boolean,
    default : false
  },
  restricLogin:{
    type : Boolean,
    default : true
  },
    
    
  securityQuestion:{
    type:String,
  },
  securityAnswer:{
    type:String
  }
}
,{
  timestamps:true
});

pharmacySchema.pre("save", function (next) {
  this.password = generateHash(this.password);
  next();
});

export default model<Pharmacy>("pharmacy", pharmacySchema);
