import mongoose, { Schema, Document, Types } from "mongoose";

export interface Role extends Document {
  name: string;
  Description: string;
  isDeleted:Boolean;
  permission: Object;
  addedBy: mongoose.Schema.Types.ObjectId;
}

const accessSchema: Schema = new mongoose.Schema({
  create:{
    type:Boolean,
    default:false
  },
view:{
  type:Boolean,
  default:false
},
update:{
type:Boolean,
default:false
},delete:{
type:Boolean,
default:false
}
},{_id:false});

const roleSchema: Schema = new mongoose.Schema<Role>(
  {
    name: {
      type: String,
    },
    Description: {
      type: String,
    },
    permission:{
      patients:accessSchema,
      consultant:accessSchema,
      pharmacy:accessSchema,
      documentCenter:accessSchema,
      questionnaire:accessSchema,
      booking:accessSchema,
      manageRole:accessSchema,
      masterData:accessSchema,
      settings:accessSchema
    },
    addedBy:{
   type:mongoose.Schema.Types.ObjectId
    },
    isDeleted:{
      type:Boolean,
      default:false
    } 
  },
  {
    timestamps: true,
    minimize:false
  }
);

export default mongoose.model<Role>("role", roleSchema);
