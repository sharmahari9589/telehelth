import mongoose, { Types, Document } from "mongoose";

export enum UserType {
  Patient = "patient",
  Consultant = "consultant",
  Pharmacy = "pharmacy",
  Admin = "admin",
}

export interface Otp extends Document {
  user:string;
  userType: UserType;
  otp: number;
  createdAt : Date;
  expireAt : Date;
  email: string;
  expirationTime:Date;
  isUsed:Boolean;

}

const otpSchema: mongoose.Schema = new mongoose.Schema<Otp>({
  user: {
    type:String,
  },
  userType: {
    type: String,
    enum: UserType,
  },
  otp: {
    type: Number,
  },
  createdAt: {
    type : Date
  },
  email: {
    type: String,
    
  },
  
  expirationTime: {
    type: Date,
    
  },
  isUsed: {
    type: Boolean,
    default: false,
  },
});

export default mongoose.model<Otp>("otp", otpSchema);
