import { Router } from "express";
import * as authenticationController from "./authentication.controller";
import verify from "../../middleware/jwtAuth";
import fileUpload from "../../middleware/fileUpload";
import multer from "multer";

const router: Router = Router({ mergeParams: true });


router
  .route("/signup")
  .get(authenticationController.signup)
  .post(authenticationController.signup);

  router
  .route("/doctorUpload")
  .get(authenticationController.doctorUpload)
  .post(authenticationController.doctorUpload);

  router
  .route("/reUpload")
  .get(authenticationController.reUpload)
  .post(authenticationController.reUpload);

 

router
  .route("/signin")
  .get(authenticationController.signin)
  .post(authenticationController.signin);

router
  .route("/forget-password")
  .get(authenticationController.forgetPassword)
  .post(authenticationController.forgetPassword);

router
  .route("/reset-password")
  .get(authenticationController.resetPassword)
  .post(authenticationController.resetPassword);

router
  .route("/signout")
  .get(authenticationController.signOut)
  .post(authenticationController.signOut);
  
router
.route("/:dashboardType/changepassword")
.get(authenticationController.changePassword)
.post(verify,authenticationController.changePassword)

router
.route("/otp/:id/:dashboard")
.get(authenticationController.verifyOtp)
.post(authenticationController.verifyOtp)

router
.route("/resend-otp/:id/:dashboard")
.get(authenticationController.resendOtp)
.post(authenticationController.resendOtp)


router
.route("/resendSignup-otp")
.get(authenticationController.resendSignupOtp)
.post(authenticationController.resendSignupOtp)





router.post("/otp",authenticationController.otpVerify)

router.post("/verify-password",authenticationController.verifyPassword)



router
.route("/signup-otp")
.get(authenticationController.signupOtp)
.post(authenticationController.signupOtp)





router
  .route("/eir-suggestion")
  .get(authenticationController.eirSuggestion)
  .post(authenticationController.eirSuggestion);

export default router;
