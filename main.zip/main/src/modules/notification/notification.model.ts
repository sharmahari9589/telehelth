import mongoose, { Document, model, ObjectId, Schema } from "mongoose";

export interface Notification extends Document {
  notificationTitle: string;
  notificationDescription: string;
  notificationType: NotificationType;
  userType: UserType;
  notificationBy: mongoose.Types.ObjectId;
  notificationTo : Array<ObjectId>;
  notificationTypeId : mongoose.Types.ObjectId; //BookingId , OrderId etc
  status : Status;
}

export enum Status {
  Read = "read",
  Unread = "unread"
}

export enum NotificationType {
  OrderNotification = "order_notification",
  BookingNotification = "booking_notification",
  Profile = "profile_notification",
  Authentication = "signup_notification",
  Reminder = "reminder_notification",
  DocumentCenter = "document_center_notification",
  Template = "template_notification",
  Questionnaire = "questionnaire_notification",
  Medicine = "medicine_notification",
  ICDCodeNotification = "icd10_notification",

  ServicesNotification = "services_notification"
}

export enum UserType {
  Patient = "patient",
  Consultant = "consultant",
  Pharmacy = "pharmacy",
  Admin = "admin",
}

const notificationSchema: Schema = new Schema<Notification>(
  {
    notificationTitle: {
      type: String,
      required: true,
    },
    notificationDescription: {
      type: String,
    },
    notificationBy: {
      type: mongoose.Schema.Types.ObjectId,
    },
    notificationTo: 
      [mongoose.Schema.Types.ObjectId],
  
    notificationTypeId: {
      type: mongoose.Schema.Types.ObjectId,
    },
    notificationType: {
      type: String,
      enum: NotificationType,
    },
    status: {
      type: String,
      enum: Status,
      default: Status.Unread
    },
  },
  {
    timestamps: true,
  }
);

export default mongoose.model<Notification>("notification", notificationSchema);
