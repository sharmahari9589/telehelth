import { Router } from "express";
import * as notificationController from "./notification.controller";

const router: Router = Router();

router.get("/", notificationController.getNotifications);
router.get("/notificationsById/:id ", notificationController.getNotifications);
router.post("/", notificationController.createNotification);
router.post("/update/:id", notificationController.updateNotification);
router.post("/delete/:id", notificationController.deleteNotification);

export default router;
