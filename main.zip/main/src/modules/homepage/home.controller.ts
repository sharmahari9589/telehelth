import { Request, Response } from "express";
import httpStatus from "http-status";
import moment from "moment";

import * as mailService from "../../services/mail.service";
//EJS Render
import ejs from "ejs";
import { getViewFile } from "../../utils/ejsHelper";
import { Types } from "mongoose";
import { sendMail } from "../../utils//sendMail"
import {updateStatusInactive, updateUserStatus} from "../../middleware/changeStatus";
/**
 * @description This Function is Used For Signup
 * @param {Request} req
 * @param {Response} res
 * @author Keshav Suman
 */

export async function viewHomePage(req: Request, res: Response) {
    try {
        
          
     if (req.method == "GET") {
  
      const fileContent = getViewFile("authentication", "home.ejs");
      res.send(
        ejs.render(fileContent.file, {
          message: "", 
           filename: fileContent.templatePath,
        })
      );
    } 
       
    else{
        
       }                 
    } catch (err) {
      console.log(err)
      res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
        data: err,
        message: "Internal server error"
      });
    }
  };
  