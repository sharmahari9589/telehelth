import { Router } from "express";
import * as homePageController from "./home.controller";
import verify from "../../middleware/jwtAuth";

const router: Router = Router({ mergeParams: true });

router
  .route("/home-page")
  .get(homePageController.viewHomePage)

export default router;
