import { Request, Response, NextFunction } from "express";
import httpStatus from "http-status";
import jsonwebtoken from "jsonwebtoken";
import patientModel from "../modules/authentication/models/patient.model";
import consultantModel from "../modules/authentication/models/consultant.model";
import bookingModel from "../models/booking.model";
import { sendMail } from "../utils/sendMail";

export  async function updateUserStatus(user:any,dashboard:string){
if(dashboard=="patient"){
    const patient = await patientModel.findByIdAndUpdate(user._id,{isActive:true});
    return patient;
}

 if(dashboard=="doctor"){
    const doctor = await consultantModel.findByIdAndUpdate(user._id,{isActive:true});
    return doctor;
 }
  }

  export  async function updateStatusInactive(user:any){
    const patient = await patientModel.findById(user._id);
    const doctor = await consultantModel.findById(user._id);

    if(patient){

        return await patientModel.findByIdAndUpdate(patient._id,{isActive:false})
        
    }
    if(doctor){

        return await consultantModel.findByIdAndUpdate(doctor._id,{isActive:false})
    }
      }



     export async function sendMailAlert () {
        const bookings = await bookingModel.aggregate([
            {
                $match: {
                    $or: [
                        { status: 'accepted' },
                        { status: 'reschedule' }
                    ]
                }
            },
            {
                        '$lookup': {
                          'from': 'patients', 
                          'localField': 'patient', 
                         'foreignField': '_id', 
                         'as': 'patient'
                        }
                      }, {
                        '$unwind': {
                          'path': '$patient', 
                          'preserveNullAndEmptyArrays': true
                        }
                    },
                    {
                        '$lookup': {
                          'from': 'doctors', 
                          'localField': 'doctor', 
                         'foreignField': '_id', 
                         'as': 'doctor'
                        }
                      }, {
                        '$unwind': {
                          'path': '$doctor', 
                          'preserveNullAndEmptyArrays': true
                        }
                    }
                
        ]);
        
      // Calculate the date three days ago from the current date
const currentDate = new Date();
const threeDaysAgo = new Date(currentDate);
threeDaysAgo.setDate(currentDate.getDate() - 3);

// Filter bookings with startTime within the last three days
const filteredBookings = bookings.filter(booking => booking.startTime >= threeDaysAgo && booking.startTime <= currentDate);

filteredBookings.forEach((a, index) => {
    setTimeout(() => {
      sendMail(
        a?.doctor?.email,
        'Regarding Booking Alert',
        `This is to inform you regarding your booking with ${a?.bookingFor?.patientName} is scheduled on ${JSON.stringify(a.startTime).slice(1, 11)}`
      );
      sendMail(
        a?.patient?.email,
        'Regarding Booking Alert',
        `This is to inform you regarding your booking with Dr ${a?.doctor?.firstName} ${a?.doctor?.LastName} is scheduled on ${JSON.stringify(a.startTime).slice(1, 11)}`
      );
    }, index * 4000); // Delay increases with index, 0 * 4000, 1 * 4000, 2 * 4000, ...
  });
  

      }