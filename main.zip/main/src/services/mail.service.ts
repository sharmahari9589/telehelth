import nodemailer from "nodemailer";

const transport = nodemailer.createTransport({
  service:"gmail",

  auth: {
    user: "demo28052002@gmail.com",
    pass: "sahul@123",
  }, 
});

export async function sendMail(to: string, subject: string, body: string) {
  console.log(to,"serviceme" );
  
  await transport.sendMail({
    to: "souravargade04@gmail.com",
    from:"demo28052002@gmail.com",
    subject: subject,
    text: body,
  });
}
