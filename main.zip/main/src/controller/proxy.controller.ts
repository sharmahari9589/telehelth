import { Request, Response } from "express";
import axios from "axios";
import * as proxyService from "./proxy.service";
import httpStatus from "http-status";

export interface TelehealthRequest extends Request {
  files: any;
}

export async function getProxy(req: Request, res: Response) {
  try {
    const url = proxyService.assembleURL(
      req.protocol,
      req.get("host")!,
      req.originalUrl
    );
    const { dashboardType, mode } = req.params;
    const response = await axios.get(
      proxyService.getMicroServiceURL(dashboardType, url),
      {
        headers: {
          authorization: proxyService.getAuthorizationHeader(req, mode),
        },
        withCredentials: true,
      }
    );
    res.status(response.status).send(response.data);
  } catch (error: any) {
    console.log(error.message);
    res
      .status(error.response?.status ?? httpStatus.INTERNAL_SERVER_ERROR)
      .send({
        status: error.response?.status ?? httpStatus.INTERNAL_SERVER_ERROR,
        data: error.message,
      });
  }
}

export async function postProxy(req: Request, res: Response) {
  try {
    const files = (req as TelehealthRequest).files;
    const url = proxyService.assembleURL(
      req.protocol,
      req.get("host")!,
      req.originalUrl
    );
    const { dashboardType, mode } = req.params;
    const response = await axios.post(
      proxyService.getMicroServiceURL(dashboardType, url),
      { ...req.body, files: files },
      {
        headers: {
          authorization: proxyService.getAuthorizationHeader(req, mode),
        },
        withCredentials: true,
        validateStatus: (status) => {
          return status >= 200 && status < 401;
        },
      }
    );
    res.status(response.status).send(response.data);
  } catch (error) {
    console.log(error);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).send({
      status: httpStatus.INTERNAL_SERVER_ERROR,
      data: error,
      message: "Internal server error",
    });
  }
}
