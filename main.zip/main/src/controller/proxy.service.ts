import { Request } from "express";

export function getMicroServiceURL(dashboardType: string, url: string): string {
  const urlParts: string[] = url.split("/");
  switch (dashboardType) {
    case "admin":
      urlParts[2] = "localhost:3001";
      break;
    case "consultant":
      urlParts[2] = "localhost:3002";
      break;
    case "patient":
      urlParts[2] = "localhost:3003";
      break;
    case "pharmacy":
      urlParts[2] = "localhost:3004";
      break;
  }
  // urlParts.splice(3, 1);
  return urlParts.join("/");
}

export function assembleURL(
  protocol: string,
  host: string,
  path: string
): string {
  return protocol + "://" + host + path;
}

export function getAuthorizationHeader(req: Request, mode: string): string {
  
  if (mode === "api") {
    return `${req.headers.authorization}`;
  } else {
    return `Bearer ${req.cookies.token}`;
  }
}
