class HttpException extends Error{
    statusCode
    constructor(message:string,statusCode:number){
        super(message);
        this.message = message;
        this.statusCode = statusCode;
    }
}

export default HttpException;