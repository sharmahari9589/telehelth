import { Response } from "express";

class HttpResponse {
  statusCode;
  data;
  message;
  constructor(
    res: Response,
    message: string,
    statusCode: number,
    data: any = undefined
  ) {
    this.message = message;
    this.statusCode = statusCode;
    this.data = data;

    res.status(this.statusCode).send({
      status: this.statusCode,
      message: this.message,
      data: this.data,
    });
  }
}

export default HttpResponse;
