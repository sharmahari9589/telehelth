import nodemailer from "nodemailer";

// create a function to send email
export async function sendMail(
  to: any,
  subject: string,
  html: string,
): Promise<void> {
    const transporter = nodemailer.createTransport({
        service: "​gmail",
        auth: {
          user: "telehealthonlineconsultation@gmail.com",
          pass: "rjwmatiqakwfnnfu",
        },
      });
  const mailOptions = {
    from: "telehealthonlineconsultation@gmail.com",
    to:to,
    subject:subject,
    html:html,
  };
  
  await transporter.sendMail(mailOptions);
}

