import { Router } from "express";
import { getProxy, postProxy } from "./src/controller/proxy.controller";
import fileUpload from "./src/middleware/fileUpload";
import authenticationRoutes from "./src/modules/authentication/authentication.routes";
import notificationRouter from "./src/modules/notification/notification.routes";
import vcrouter from "./src/modules/authentication/videoCallingToken/vc.routes";
import homerouter from "./src/modules/homepage/home.routes"

const appRouter = Router();

appRouter.use(fileUpload.any());
appRouter.use("/authentication/:mode", authenticationRoutes);
appRouter.use("/:mode", homerouter);

appRouter.use("/notifications", notificationRouter);
appRouter.use("/:dashboardType/:mode/vc", vcrouter);
appRouter.post("/:dashboardType/:mode/*", postProxy);
appRouter.get("/:dashboardType/:mode/*", getProxy);


export default appRouter;
