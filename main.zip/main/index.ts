import express from "express";
import routes from "./app.routes";
import { connect } from "mongoose";
import dotenv from "dotenv";
import path from "path";
import cookieParser from "cookie-parser";
// by hari
import { Server } from "socket.io";
import { createServer } from "http";
// by hari
import {verifyToken} from "./src/modules/authentication/authentication.service";
import { sendMailAlert } from "./src/middleware/changeStatus";
import player from "play-sound"

dotenv.config();

const app = express();

// by hari
const server = createServer(app);
// by hari

app.use(express.json());

app.use(express.urlencoded({ extended: true }));

app.use(cookieParser());

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "assets"));
app.use("/assets", express.static(path.join(__dirname, "src/assets")));
app.use("/uploads", express.static(path.join(__dirname, "./uploads")));
app.use("/", routes);

connect(process.env.MONGODB_URL!);

const users:Map<string,any> = new Map();

const io = new Server(server);
io.use((socket, next) => {
    try {
        let token:any; 
        
        // if(token.length>10){
          for (let i = 0; i < socket.request?.rawHeaders.length; i += 2) {
            if (socket.request?.rawHeaders[i] === 'Cookie') {
              const cookieValue = socket.request?.rawHeaders[i + 1];
              const tokenStart = 'token=';
              const tokenIndex = cookieValue.indexOf(tokenStart);
              
              if (tokenIndex !== -1) {
                token = cookieValue.slice(tokenIndex + tokenStart.length);
                break;
              }
            }
          }
            const user:any = verifyToken(token);
            // console.log(`${user.firstName} ${user.lastName} user connected`);
            users.set(user?._id,socket.id);
            next();
        // }else{
        //     console.log("Error");
        //     next(new Error("Unauthenticated"))
        //     // console.log(socket.request?.rawHeaders);
        // }
    } catch (error) {
        console.log(error);   
    }
});

io.on('connection', function(socket) {

      socket.on('chat_message',(receiverId,msg,senderId) => {

        
        // socket.broadcast.emit("chat_message",msg);
        io.to(users.get(receiverId)).emit("chat_message",msg,senderId,receiverId);
        // users[receiverId]?.emit('chat_message', msg);
    });
})
// Function to run sendMailAlert at a specific time
function runSendMailAlertAt(targetHour:any, targetMinute:any) {
    const now:any = new Date();
    const targetTime:any = new Date(now);
    targetTime.setHours(targetHour, targetMinute, 0, 0);
  
    if (targetTime > now) {
      const timeUntilTargetTime = targetTime - now;
      setTimeout(() => {
        sendMailAlert(); // Call the function after the specified time
      }, timeUntilTargetTime);
    } else {
      console.log("The specified time has already passed.");
    }
  }
  
  // Call runSendMailAlertAt to trigger the function at a specific time
  runSendMailAlertAt(23, 59); // Replace with your desired hour and minute
  
  // ... (rest of your code)
  
// socket server generation
server.listen(process.env.PORT,()=>{
  console.log(`Server started at ${process.env.PORT}`);
});
